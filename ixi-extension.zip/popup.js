// Popup view controller: tab switching, form submission, and the signed-in
// state. Everything is plain DOM — four small files do not justify a bundler,
// and MV3 forbids remote code anyway.

const $ = (id) => document.getElementById(id);

const els = {
  viewAuth: $("view-auth"),
  viewSession: $("view-session"),
  tabLogin: $("tab-login"),
  tabSignup: $("tab-signup"),
  tabUpdate: $("tab-update"),
  updateSlot: $("update-slot"),
  formLogin: $("form-login"),
  formSignup: $("form-signup"),
  authMessage: $("auth-message"),
  sessionEmail: $("session-email"),
  sessionMessage: $("session-message"),
  logout: $("btn-logout"),
  turnOff: $("btn-turn-off"),
  sessionTabs: $("session-tabs"),
  updateBanner: $("update-banner"),
  updateBannerAuth: $("update-banner-auth"),
  updateInstalled: $("update-installed"),
  updatePublished: $("update-published"),
  updateMessage: $("update-message"),
  updateManual: $("update-manual"),
  updateProgress: $("update-progress"),
  updateNote: $("update-note"),
  checkUpdate: $("btn-check-update"),
  updatePanel: $("update-panel"),
  downloadUpdate: $("btn-download-update"),
  installUpdate: $("btn-install-update"),
  setupUpdater: $("btn-setup-updater"),
};

// Both views used to carry an open-site button, so these were collected rather
// than looked up by id — two elements cannot share one id. The host label is
// gone now: the button moved into the chrome bar as an icon, and the label's
// job — showing the site host — was the one thing that needed the resolved
// origin at render time, which the icon does not.
const openSiteButtons = [...document.querySelectorAll(".js-open-site")];
const openAdminButtons = [...document.querySelectorAll(".js-open-admin")];

/** Show a message in whichever view is currently active. */
function showMessage(el, text, kind = "error") {
  el.textContent = text;
  el.className = kind === "ok" ? "ok" : "error";
}

function clearMessage(el) {
  el.textContent = "";
  el.className = "hidden";
}

/**
 * The Update panel is one node in two places. It holds live DOM references
 * (`els.updateInstalled` and friends) that `popup.js` wires up once, so it
 * cannot be duplicated into both views — it is moved instead, into whichever
 * view is on screen. `showAuthView` and `showSessionView` call this before
 * touching the panel, so the panel is never left in the view being hidden.
 */
function mountUpdatePanel(where) {
  const host = where === "auth" ? els.updateSlot : els.viewSession;
  if (els.updatePanel.parentElement === host) return;
  host.append(els.updatePanel);
}

function selectTab(which) {
  const isLogin = which === "login";
  const isSignup = which === "signup";
  const isUpdate = which === "update";
  els.tabLogin.classList.toggle("is-active", isLogin);
  els.tabSignup.classList.toggle("is-active", isSignup);
  els.tabUpdate.classList.toggle("is-active", isUpdate);
  els.tabLogin.setAttribute("aria-selected", String(isLogin));
  els.tabSignup.setAttribute("aria-selected", String(isSignup));
  els.tabUpdate.setAttribute("aria-selected", String(isUpdate));
  els.formLogin.classList.toggle("hidden", !isLogin);
  els.formSignup.classList.toggle("hidden", !isSignup);
  els.updatePanel.classList.toggle("hidden", !isUpdate);
  clearMessage(els.authMessage);
}

/**
 * The signed-in account's role, kept only for display (e.g. the Account panel).
 * Every Tools view — bookmarks, vault, todos, timers — is now *per-account*
 * data: each account reads and writes only its own rows, resolved server-side
 * by `lib/caller.ts`. So Tools is offered to every signed-in account, owner and
 * extension user alike. The server still owns the boundary; this is
 * presentation.
 */
let sessionRole = "user";

/** Every signed-in account gets Tools; keep the tab visible and enabled. */
function applyRoleToTabs() {
  for (const tab of els.sessionTabs.querySelectorAll('.tab[data-panel="tools"]')) {
    tab.classList.remove("hidden");
    tab.disabled = false;
  }
}

/** Switch the signed-in view's panels. */
function selectPanel(name) {
  for (const tab of els.sessionTabs.querySelectorAll(".tab")) {
    const on = tab.dataset.panel === name;
    tab.classList.toggle("is-active", on);
    tab.setAttribute("aria-selected", String(on));
  }
  for (const panel of els.viewSession.querySelectorAll(".panel")) {
    panel.classList.toggle("hidden", panel.dataset.panel !== name);
  }
  // Leaving Tools releases whatever view it had open — a ticking timer would
  // otherwise keep running against nodes nobody can see.
  if (name !== "tools") window.ixiTools?.closeTool();
}

function showAuthView() {
  // Move the Update panel before revealing the view, so it is never painted in
  // the hidden one and then yanked across.
  mountUpdatePanel("auth");
  selectTab("login");
  els.viewAuth.classList.remove("hidden");
  els.viewSession.classList.add("hidden");
}

function showSessionView(email, role = "user") {
  sessionRole = role === "owner" ? "owner" : "user";
  applyRoleToTabs();
  els.sessionEmail.textContent = email;
  mountUpdatePanel("session");
  els.viewAuth.classList.add("hidden");
  els.viewSession.classList.remove("hidden");
  clearMessage(els.sessionMessage);
  // Landing on Tools after signing in is the default now: every account gets its
  // own tools, and that is what people open the popup for.
  selectPanel("tools");
  els.updateBanner.classList.add("hidden");
}

/** Disable a form while its request is in flight, so a double-click cannot double-submit. */
async function withPending(form, fn) {
  const buttons = form.querySelectorAll("button, input");
  buttons.forEach((b) => (b.disabled = true));
  try {
    await fn();
  } finally {
    buttons.forEach((b) => (b.disabled = false));
  }
}

// ── password reveal ───────────────────────────────────────────────────────
// One delegated handler rather than one per field, so a password input added
// later only has to carry `js-secret` to get the eye.

for (const button of document.querySelectorAll(".js-secret-toggle")) {
  button.addEventListener("click", () => {
    const input = button.parentElement.querySelector(".js-secret");
    if (!input) return;
    // `input.type` is the switch, not a class: the browser's own password
    // manager keys off it, so flipping the attribute is what makes revealing
    // behave like a native reveal rather than a text field wearing a costume.
    const revealed = input.type === "password";
    input.type = revealed ? "text" : "password";
    button.setAttribute("aria-pressed", String(revealed));
    const label = revealed ? "Hide password" : "Show password";
    button.setAttribute("aria-label", label);
    button.title = label;
  });
}

els.tabLogin.addEventListener("click", () => selectTab("login"));
els.tabSignup.addEventListener("click", () => selectTab("signup"));
els.tabUpdate.addEventListener("click", () => {
  // The markup shows the auth view from the first frame, before the boot's
  // storage read has resolved and `showAuthView` has had a chance to mount the
  // panel here. Mounting again on the click covers that gap; it is a no-op once
  // the panel is already in place.
  mountUpdatePanel("auth");
  selectTab("update");
  // Same contract as the signed-in tab: paint the cached answer immediately,
  // and let `checkForUpdate` go to the network only when the cache is stale.
  checkForUpdate({ useCache: true }).catch(() => {});
});

els.formLogin.addEventListener("submit", (e) => {
  e.preventDefault();
  clearMessage(els.authMessage);
  const identifier = $("login-identifier").value.trim();
  const password = $("login-password").value;
  if (!identifier || !password) {
    showMessage(els.authMessage, "Email/username and password required");
    return;
  }
  withPending(els.formLogin, async () => {
    try {
      const session = await window.ixiAuth.login(identifier, password);
      showSessionView(session.email, session.role);
    } catch (err) {
      showMessage(els.authMessage, err instanceof Error ? err.message : "Sign in failed");
    }
  });
});

els.formSignup.addEventListener("submit", (e) => {
  e.preventDefault();
  clearMessage(els.authMessage);
  const email = $("signup-email").value.trim();
  const username = $("signup-username").value.trim();
  const password = $("signup-password").value;
  if (!email || !password) {
    showMessage(els.authMessage, "Email and password required");
    return;
  }
  if (password.length < 6) {
    showMessage(els.authMessage, "Password must be at least 6 characters");
    return;
  }
  withPending(els.formSignup, async () => {
    try {
      const session = await window.ixiAuth.signup(email, username, password);
      showSessionView(session.email, session.role);
    } catch (err) {
      showMessage(els.authMessage, err instanceof Error ? err.message : "Signup failed");
    }
  });
});

els.logout.addEventListener("click", async () => {
  await window.ixiAuth.logout();
  // Drop any tool view left open, so the next sign-in starts on a clean menu
  // rather than whatever the previous session was looking at.
  window.ixiTools?.closeTool();
  // `showAuthView` lands on Login itself — selecting it here as well would be
  // the same call twice.
  showAuthView();
});

els.turnOff.addEventListener("click", async () => {
  els.turnOff.disabled = true;
  try {
    // Resolves `false` when the user cancelled the confirm, and only returns
    // normally at all when Chrome kept the extension alive — a real switch-off
    // takes this popup with it.
    await window.ixiTools?.turnOffExtension();
  } catch (err) {
    showMessage(
      els.sessionMessage,
      err instanceof Error ? err.message : "Could not turn the extension off.",
    );
  } finally {
    els.turnOff.disabled = false;
  }
});

els.sessionTabs.addEventListener("click", (e) => {
  const tab = e.target.closest(".tab");
  if (!tab) return;
  selectPanel(tab.dataset.panel);
  // Render the cached answer first so the panel is never blank, then refresh it
  // only if the cache has aged out.
  if (tab.dataset.panel === "update") checkForUpdate({ useCache: true });
});

els.checkUpdate.addEventListener("click", async () => {
  els.checkUpdate.disabled = true;
  // The fill is the receipt that the click landed. On a sparse panel a button
  // that only dims reads as "nothing happened", and the request has no fraction
  // to report — the site answers in one round trip — so the sweep is paced to a
  // short fixed time rather than to real progress.
  els.checkUpdate.classList.add("is-checking");
  const startedAt = Date.now();
  try {
    // An explicit click always goes to the network — that is the point of it.
    await checkForUpdate();
  } finally {
    // A fast answer would otherwise flash the fill for one frame, which reads
    // as a glitch instead of as confirmation. Keep it up for the full sweep.
    const remaining = CHECK_SWEEP_MS - (Date.now() - startedAt);
    if (remaining > 0) await new Promise((r) => setTimeout(r, remaining));
    els.checkUpdate.classList.remove("is-checking");
    els.checkUpdate.disabled = false;
  }
});

// ── opening tabs ──────────────────────────────────────────────────────────

/**
 * Resolved once at boot and held as a plain string, so a click handler never
 * awaits storage inside the tab-opening gesture — Chrome can drop the
 * user-activation window across an await and the tab silently fails to open.
 */
let siteUrl = window.ixiAuth.SITE_ORIGIN;

function openTab(url) {
  chrome.tabs.create({ url });
}

for (const btn of openSiteButtons) {
  btn.addEventListener("click", () => openTab(siteUrl));
}
for (const btn of openAdminButtons) {
  btn.addEventListener("click", () => openTab(`${siteUrl}/admin`));
}

// ── update check ──────────────────────────────────────────────────────────
// The check itself — the version URL, the cache, the native-host probe and the
// install — lives in `update.js`, because the new tab page's right-click menu
// now offers the same command. What is here is only the painting: the panel's
// two version fields, its message line and its install controls.

/** How long the "Check for updates" button takes to fill, in ms. Matches the
 *  `.is-checking` sweep in popup.css — change both together, or the fill will
 *  finish early or be cut off part-way. */
const CHECK_SWEEP_MS = 900;

const UPDATE = window.ixiUpdate;

/** The last version the site was seen to publish, so the native-host probe can
 *  repaint the panel once it answers without asking the network a second time. */
let lastPublished = null;

/**
 * An unpacked extension cannot update itself: Chrome only runs update checks
 * for extensions installed from a CRX or the Web Store, and MV3 forbids
 * fetching and running remote code. So this compares the installed version
 * against a static file on the site and reports whether a newer build exists.
 *
 * `published` is the version string to judge against, or null when the site
 * could not be read at all.
 */
function renderUpdateState(installed, published, failure) {
  els.updateInstalled.textContent = installed;
  if (published) lastPublished = published;

  if (!published) {
    els.updatePublished.textContent = "unknown";
    els.updateMessage.textContent = failure ?? "Could not read the published version.";
    els.updateMessage.className = "error";
    offerInstall(false);
    return;
  }

  els.updatePublished.textContent = published;

  if (UPDATE.compareVersions(published, installed) > 0) {
    els.updateMessage.textContent = `Update available — ${installed} → ${published}`;
    els.updateMessage.className = "ok";
    offerInstall(true);
    for (const banner of [els.updateBanner, els.updateBannerAuth]) {
      banner.textContent = `Update available — ${installed} → ${published}`;
      banner.classList.remove("hidden");
    }
  } else {
    // The installed and published rows above already carry the number, so the
    // line only has to say the answer. Naming the version twice made a
    // two-word result read like a log entry.
    els.updateMessage.textContent = "You're on the latest version :)";
    els.updateMessage.className = "ok";
    offerInstall(false);
    for (const banner of [els.updateBanner, els.updateBannerAuth]) {
      banner.classList.add("hidden");
    }
  }
}

/** Show or hide the install controls for a known update.
 *
 *  Which of the two the user gets depends on whether the native host answered,
 *  and that is not known at this point — the probe is asynchronous. So both are
 *  wired off `updaterAvailable`, which starts `null` ("not asked yet") and is
 *  filled in by `probeUpdater`. Until it resolves, the manual route is shown:
 *  it is the one that always works, so the failure mode is a slightly more
 *  laborious install rather than a button that does nothing. */
function offerInstall(available) {
  const wanted = available && updaterAvailable === true;
  els.installUpdate.classList.toggle("hidden", !wanted);
  els.setupUpdater.classList.toggle("hidden", !(available && updaterAvailable === false));
  els.updateManual.classList.toggle("hidden", !available || updaterAvailable === true);
  els.updateNote.classList.toggle("hidden", !available);
}

/**
 * The Update panel. With `{ useCache: true }` this renders the last known result
 * immediately and only refreshes it if it has gone stale — so opening the popup
 * shows the banner instantly instead of after a round trip.
 */
async function checkForUpdate({ useCache = false } = {}) {
  if (useCache && !lastPublished) els.updateInstalled.textContent = UPDATE.installedVersion();
  const { installed, published, failure } = await UPDATE.check({ siteUrl, useCache });
  // A failed fetch must not clobber a banner we already know is true — offline
  // should not read as "up to date", and it should not read as an error either
  // when there is a valid answer on disk. `update.js` already prefers the cache
  // in that case, so anything here with a `failure` genuinely has nothing to
  // show.
  renderUpdateState(installed, published, failure);
}

// ── the self-updater ──────────────────────────────────────────────────────
// Chrome will not let an unpacked extension install into itself, so the actual
// file-writing is done by a native messaging host registered with the browser
// (see `scripts/install-updater.sh`). The popup's part is small: ask the host to
// update, then reload so the browser re-reads the folder it just wrote. The
// probe and the install both live in `update.js`; `updaterAvailable` here is
// just this panel's copy of the answer, so `offerInstall` can repaint from it.

/** Whether the native host is registered: `null` until asked, then a boolean.
 *  Cached in memory because the probe costs a process spawn and the answer only
 *  changes when the user runs the installer. */
let updaterAvailable = null;

async function probeUpdater() {
  updaterAvailable = await UPDATE.probeUpdater();
  return updaterAvailable;
}

/** Show a line in the Update panel while the host is working, and after. */
function setUpdaterProgress(text, kind = "") {
  els.updateProgress.textContent = text;
  // `progress-note`, not `progress`: see the rule in popup.css — the todos
  // tool owns `.progress` for its progress bar, and the two collide.
  els.updateProgress.className = kind ? `progress-note ${kind}` : "progress-note";
  els.updateProgress.classList.toggle("hidden", !text);
}

els.installUpdate.addEventListener("click", async () => {
  els.installUpdate.disabled = true;
  els.checkUpdate.disabled = true;
  setUpdaterProgress("Downloading and installing…");
  try {
    const { version } = await UPDATE.install();
    setUpdaterProgress(`Installed ${version} — reloading…`, "is-ok");
    // The files on disk are the new build; this is what makes the browser read
    // them. `storage.local` is untouched by a reload, so settings, layout and
    // the session all survive it.
    setTimeout(() => chrome.runtime.reload(), 600);
  } catch (err) {
    setUpdaterProgress(
      `Install failed — ${err instanceof Error ? err.message : String(err)}`,
      "is-error",
    );
    els.installUpdate.disabled = false;
    els.checkUpdate.disabled = false;
  }
});

els.setupUpdater.addEventListener("click", async () => {
  // The one-time setup is a shell script and cannot be run from here — a browser
  // has no way to execute a program. Opening the site is the closest honest
  // thing: the instructions live there, next to the download.
  openTab(`${siteUrl}/admin`);
});

// Exposed for `tools.js`, which owns the Tools panel and so cannot switch to it
// itself: the tab buttons and their panels live here. The one caller is the note
// shown after the extension is re-enabled following a new-tab switch-off — it
// has something to say and no way to be seen unless the popup brings the Tools
// tab forward.
window.ixiPopup = { showPanel: selectPanel };

// ── boot ──────────────────────────────────────────────────────────────────
;(async () => {
  siteUrl = await window.ixiAuth.baseUrl();
  // The site URL is held in `siteUrl` for the tab-opening gesture; the chrome
  // icon needs no label, it is a constant glyph regardless of which origin is
  // resolved.
  els.updateInstalled.textContent = UPDATE.installedVersion();

  // A relative href would resolve against the extension origin, where the zip
  // does not exist — it has to be absolute against the site.
  els.downloadUpdate.href = `${siteUrl}/ixi-extension.zip`;

  // Ask whether the native updater is registered, then repaint the Update panel
  // so the right button replaces the fallback. Both of these are deliberately
  // not awaited — the popup must not wait on a network round trip or a process
  // spawn before it renders the account.
  probeUpdater()
    .then((available) => {
      // `offerInstall` re-runs the visibility rules now that the answer is
      // known; without this the panel would keep whatever the first, unprobed
      // render chose.
      const installed = UPDATE.installedVersion();
      const cached = lastPublished;
      if (cached) renderUpdateState(installed, cached, null);
      else if (!available) offerInstall(false);
    })
    .catch(() => {});
  checkForUpdate({ useCache: true }).catch(() => {});

  const session = await window.ixiAuth.readSession();
  if (!session?.email) {
    showAuthView();
    return;
  }

  // The stored session paints the signed-in view at once, rather than leaving
  // the login form up for the length of the session round trip — the common
  // case is a session that is still valid, and making it wait on the network
  // every open was the popup's slowest path. The check below then confirms it
  // and corrects the role; only an explicit rejection sends the user back.
  showSessionView(session.email, session.role);

  // The stored session is only a claim until the server agrees. Checking in the
  // background means a stale token lands on the login form a beat later instead
  // of the popup refusing to paint. A network failure must not sign anyone out,
  // so only an explicit negative clears the session.
  const check = await window.ixiApi.checkSession();
  if (check.authenticated) {
    // The server's view of the role wins over what storage held: it is the one
    // that also gates the Tools routes, so a stale stored role can never widen
    // what is offered.
    showSessionView(check.email || session.email, check.role ?? session.role);
    return;
  }
  // Only an explicit rejection clears the session. A failed check (`ok: false`)
  // means the server was unreachable, which must not sign anyone out — and now
  // that the signed-in view is already painted above, falling through to the
  // login form would *un*-sign a valid user on a flaky connection. So the
  // switch back happens only when the server actually said no.
  if (check.ok) {
    await window.ixiAuth.logout();
    showAuthView();
  }
})();
