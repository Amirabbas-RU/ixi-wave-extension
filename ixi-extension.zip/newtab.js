// The custom new tab page.
//
// This file is the page's conductor: it owns the clock, the search box and the
// wire-up between the settings panel and the widgets. The three files loaded
// before it do the actual work — `settings.js` holds per-user preferences,
// `widgets.js` draws the floating panels, `panel.js` is the settings UI.
//
// This is an extension page, so it shares `chrome.storage.local` with the
// popup: the session written there by a popup login is visible here with no
// extra plumbing. That is the whole reason the account widgets can exist — a
// plain web page could not read that storage at all.

// These bind off the namespace objects under fresh names. auth.js, api.js,
// settings.js and widgets.js are plain scripts, not modules, so all of them
// share one global lexical scope — and `baseUrl`, `readToken`, `API`, `node`
// and several others are already declared at the top level. Binding any of
// those names again here (which is what destructuring does) is a redeclaration,
// and it throws before a single line of this file runs.
const PageAuth = window.ixiAuth;
const PageApi = window.ixiApi;
const PageSettings = window.ixiNewtabSettings;
const PageWidgets = window.ixiNewtabWidgets;
const PageDecor = window.ixiNewtabDecor;
const PageShortcuts = window.ixiNewtabShortcuts;
const PagePanel = window.ixiNewtabPanel;
// Loaded before this file, so the binding is live by the time anything here
// reads it. The modal itself lives in bangs.js; this file only opens it.
const PageBangs = window.ixiNewtabBangs;

const pad = (n) => String(n).padStart(2, "0");

// ── the clock ─────────────────────────────────────────────────────────────

const timeEl = document.getElementById("clock-time");
const dateLineEl = document.getElementById("date-line");
const dateYearEl = document.getElementById("date-year");
let clockTimer = null;

// Page state that other handlers read at event time. Declared as module-level
// bindings rather than stashed on `window` so a name collision is a load-time
// error here instead of a silently overwritten global.
let pageEngineId = "ddg";
let pageClock24 = true;
let pageSettings = null;
/** The bang list the search box matches against, cached at submit time for the
 *  same reason the engine is: a change in the modal applies to the next search
 *  with no reload. */
let pageBangs = [];

// ── the calendar ──────────────────────────────────────────────────────────
// A month grid in the Monday-first order the rest of the page's dates use.
// Rebuilt on every tick rather than cached: it is 42 nodes once a minute, and a
// cached grid would be one more thing that has to be invalidated at midnight,
// at a month boundary, and on a timezone change.

function buildCalendar(now, target) {
  // `target` is passed by the calendar widget's renderer, which has just made a
  // node that is *not in the document yet*. Looking the grid up there finds the
  // previous one — still attached, and about to be discarded — and fills it
  // instead, leaving the new grid empty. The clock's own tick has no such node to
  // hand, so it repaints every live grid it can find.
  //
  // A marker attribute rather than an id: calendars are multiple, so two
  // Gregorian grids on one page are a supported layout and two elements sharing
  // an id would be invalid — and `getElementById` would silently repaint only
  // the first of them.
  const grids = target ? [target] : [...document.querySelectorAll("[data-cal-grid]")];
  for (const calGrid of grids) paintCalendarGrid(calGrid, now);
}

function paintCalendarGrid(calGrid, now) {
  const today = now.getDate();
  const daysInMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0).getDate();

  // Leading blanks come from the weekday of the **1st**, not of today. Reading
  // today's weekday here instead puts the 1st under the wrong column and slides
  // the whole month sideways — the grid then disagrees with the weekday name the
  // date line above it prints, which is the one thing a calendar must not do.
  //
  // `getDay()` is Sunday-first; the grid is Monday-first, so Sunday is shifted
  // to the end (0 → 7 → index 6).
  const firstDay = new Date(now.getFullYear(), now.getMonth(), 1).getDay();
  const mondayIndex = (firstDay + 6) % 7;

  const cells = [];
  // The weekday header row. `2024-01-01` is a Monday, which is the anchor that
  // makes the locale name the right day without a lookup table.
  for (let i = 0; i < 7; i += 1) {
    const ref = new Date(2024, 0, 1 + i);
    const head = document.createElement("span");
    head.className = "cal-dow";
    head.textContent = ref.toLocaleDateString(undefined, { weekday: "narrow" });
    cells.push(head);
  }
  // Leading blanks so the 1st lands under its own column. `data-empty` rather
  // than a class: the cell is a grid item with no content, and a class would
  // need a rule; an attribute the CSS can match keeps the two in one place.
  for (let i = 0; i < mondayIndex; i += 1) {
    const blank = document.createElement("span");
    blank.className = "cal-day";
    blank.dataset.empty = "true";
    cells.push(blank);
  }
  for (let d = 1; d <= daysInMonth; d += 1) {
    const cell = document.createElement("span");
    cell.className = d === today ? "cal-day is-today" : "cal-day";
    cell.textContent = String(d);
    cells.push(cell);
  }
  calGrid.replaceChildren(...cells);
}

function tick() {
  const now = new Date();
  const h24 = pageClock24;
  let hours = now.getHours();
  let suffix = "";
  if (!h24) {
    suffix = hours < 12 ? " am" : " pm";
    hours = hours % 12 || 12;
  }
  timeEl.textContent = `${h24 ? pad(hours) : hours}:${pad(now.getMinutes())}${suffix}`;

  // The date reads as a stack: `Monday, 25 October` over the year, which is the
  // least interesting part of a date you already know. `day` and `month` are
  // separate options so the runtime's own locale decides their order and
  // punctuation.
  dateLineEl.textContent = now.toLocaleDateString(undefined, {
    weekday: "long",
    day: "numeric",
    month: "long",
  });
  dateYearEl.textContent = String(now.getFullYear());
  buildCalendar(now);
  // Any floating clock panels read the same minute. Repainted in place rather
  // than rebuilt: `renderWidgets` would replace every panel, dropping their
  // scroll positions and interrupting a drag that happens to span the minute.
  PageWidgets.refreshClockBodies?.(h24, now);
}

/** Start the minute-aligned clock loop. Re-runnable: a 12/24-hour change has to
 *  repaint immediately, and the interval is realigned so the next automatic
 *  tick still lands on a minute boundary. */
function startClock() {
  tick();
  clearTimeout(clockTimer);
  clearInterval(clockTimer);
  const now = new Date();
  const msToNextMinute = (60 - now.getSeconds()) * 1000 - now.getMilliseconds();
  clockTimer = setTimeout(() => {
    tick();
    clockTimer = setInterval(tick, 60_000);
  }, msToNextMinute);
}

// ── search ────────────────────────────────────────────────────────────────

const form = document.getElementById("search-form");
const input = document.getElementById("search-input");
const hint = document.getElementById("search-hint");

/** Whether what is typed is a URL to open rather than a query to search.
 *
 *  The last dot-separated label has to look like a TLD — letters only, two or
 *  more of them. Requiring *some* dot is not enough: `1.5` clears that bar and
 *  `new URL` then normalises the pair into the IP `https://1.0.0.5/`, so a
 *  fractional number sends you to a stranger's address. `a.b` is dropped by the
 *  same rule and becomes a search, which is the right answer for a two-letter
 *  name that is not a TLD either.
 *
 *  A dotted word like `foo.js` still resolves as a host, which is what Chrome's
 *  own omnibox does with it — `.js` really is a ccTLD. */
function asUrl(value) {
  const hasScheme = /^[a-z][a-z0-9+.-]*:\/\//i.test(value);
  // `localhost` and `localhost:3000` carry no TLD, so the rule above drops them,
  // but they are the addresses most often typed by hand. Matched on their own.
  const isLoopback = /^(localhost|127\.0\.0\.1)(:\d+)?(\/|$|\?|#)/i.test(value);
  if (!hasScheme && !isLoopback && !/^[\w-]+(\.[\w-]+)*\.[a-z]{2,}(\/|$|\?|#)/i.test(value)) return null;
  const withScheme = hasScheme ? value : `https://${value}`;
  try {
    const url = new URL(withScheme);
    // A bare `http://` with nothing after it parses fine but goes nowhere.
    if (!url.hostname.includes(".") && url.hostname !== "localhost") return null;
    return url.href;
  } catch {
    return null;
  }
}

// ── click outside the box loses it ─────────────────────────────────────────
// The box is autofocused on a new tab, and the only way out today is Escape.
// Clicking the page — the most common gesture on a new tab — should hand the
// page back the same way: the box is the thing holding focus, so a click that
// is not on the box is a click that is done with it.
//
// The whole form counts as the box: the prompt, the engine hint and the bangs
// button are part of it, and clicking any of them should keep the field alive.
// A click on a widget, a shortcut or the settings gear is what this is for.
document.addEventListener("click", (event) => {
  if (!document.activeElement || document.activeElement !== input) return;
  if (event.target instanceof Element && event.target.closest("#search-form")) return;
  input.blur();
});

form.addEventListener("submit", (e) => {
  e.preventDefault();
  const value = input.value.trim();
  if (!value) return;
  // A bang is checked *before* the URL test, so it always wins. That ordering is
  // what keeps the two apart on its own: `yt car` is the token `yt` followed by
  // words, while `yt.com` is a single token that equals no trigger and falls
  // through to `asUrl` exactly as it does today. Triggers match whole tokens
  // only, so a one-letter bang can never fire on the front of a longer word.
  const bang = PageSettings.parseBang(value, pageBangs);
  if (bang) {
    window.location.href = bang;
    return;
  }
  const url = asUrl(value);
  // The engine is read at submit time rather than captured, so changing it in
  // the settings panel applies to the very next search with no reload.
  const engine = PageSettings.engineById(pageEngineId);
  window.location.href = url ?? `${engine.url}${encodeURIComponent(value)}`;
});

// ── paste a link ──────────────────────────────────────────────────────────
// A copied address is the commonest way someone has a site in hand: it is on
// the clipboard from the tab they were just on. Ctrl + V turns it into a
// shortcut icon where the pointer is — the same object a site becomes when its
// tile is dragged out of a panel — so putting a site on the page never costs a
// trip through the settings panel and a two-field form.

/** Where the pointer last was. A paste has no coordinates of its own, and
 *  "under the cursor" is the least surprising place for something to appear.
 *  Passive and on the window so it costs nothing while it is never used.
 *
 *  Only a *hover* counts, and it goes stale. The previous mark was set by any
 *  pointermove, including a drag's — so a paste made with the pointer parked
 *  (which is most pastes) could land on the coordinates a panel was last
 *  dragged to, i.e. underneath that panel, where it cannot be clicked or
 *  grabbed. A mark left over from another tab's time is the same problem. */
let pasteSpot = null;
const PASTE_SPOT_MAX_AGE_MS = 10 * 60 * 1000;
// The top strip the search box and clock live in. An icon dropped under a hover
// there would be clamped up to it, so a paste with the pointer in that band is
// treated as "no spot" and placed in a free one instead.
const PASTE_MIN_Y = 96;

const SC_ICON_WIDTH = 76;
const SC_ICON_HALF = SC_ICON_WIDTH / 2;
const SC_ICON_HALF_TOP = 30;
const SC_ICON_PITCH = 88;
window.addEventListener(
  "pointermove",
  (e) => {
    // While a button is held this is a drag, not a hover: the coordinates are
    // where something is being *moved to*, not where the user is looking, and
    // a block dropped under a panel being dragged there would be lost.
    if (e.buttons) return;
    pasteSpot = { x: e.clientX, y: e.clientY, at: Date.now() };
  },
  { passive: true },
);

/** The spot a paste should use, or `null` for "let the page find a free one".
 *
 *  `null` is the honest answer more often than it looks: a paste into a page
 *  nobody has hovered has no pointer position to speak of, and a spot found
 *  from the layout is always somewhere the icon can be reached. A stale or
 *  off-screen spot is refused for the same reason. */
function livePasteSpot() {
  if (!pasteSpot) return null;
  if (Date.now() - pasteSpot.at > PASTE_SPOT_MAX_AGE_MS) return null;
  // A hover under the top ws strip is over the page's chrome, not its open
  // area, and the clamp would drag a block dropped there up against the edge.
  if (pasteSpot.y < PASTE_MIN_Y) return null;
  const page = document.getElementById("widgets") || document.documentElement;
  const box = page.getBoundingClientRect();
  if (pasteSpot.x < box.left || pasteSpot.y < box.top) return null;
  if (pasteSpot.x > box.right || pasteSpot.y > box.bottom) return null;
  return pasteSpot;
}

/** The address in a pasted string, or `null`.
 *
 *  A clipboard usually holds a bare address because it came from an address
 *  bar, but it just as often holds a line of prose with the link inside it.
 *  The explicit scheme is looked for first and the whole string is only tried
 *  whole when there is none — so "see https://x.dev/a" yields the link while
 *  `github.com` still yields itself. `asUrl` makes the same judgement the
 *  search box does, so a thing that would have opened as a site is a thing that
 *  can become one. */
function pastedUrlOf(text) {
  const embedded = text.match(/https?:\/\/[^\s<>"']+/i);
  if (embedded) return asUrl(embedded[0]);
  if (/\s/.test(text)) return null;
  return asUrl(text);
}

/** Whether this paste belongs to a field rather than to the page.
 *
 *  Anything the browser would put text into keeps its own paste — the widget
 *  forms, the rename field, the account fields.
 *
 *  The search box counts, always, and the empty-box case is the reason to say
 *  so out loud. It is autofocused on a new tab, and the way to *go* to a page
 *  is to paste its address into it, so treating an empty box as "nothing to
 *  lose" would quietly turn the most common paste on this page — a link copied
 *  so it can be opened — into a widget instead. Pinning a link is the gesture
 *  you reach for with the box out of the way: press Escape or click the page
 *  first, and the paste lands on the page. */
function pasteIsForField(target) {
  if (!(target instanceof Element)) return false;
  return Boolean(
    target.closest(
      "input, textarea, [contenteditable=''], [contenteditable='true'], [contenteditable='plaintext-only']",
    ),
  );
}

/** A brief line at the bottom of the page. Placed only because the block itself
 *  can land under the pointer and be half-covered by the hand; the line names
 *  the site so the user can tell what was made without hunting for it. */
let pasteNoticeTimer = null;

const ASCII_FONT = {
  A: ["111", "101", "101", "111", "101"],
  B: ["110", "101", "110", "101", "110"],
  C: ["111", "100", "100", "100", "111"],
  D: ["110", "101", "101", "101", "110"],
  E: ["111", "100", "111", "100", "111"],
  F: ["111", "100", "111", "100", "100"],
  G: ["111", "100", "101", "101", "111"],
  H: ["101", "101", "111", "101", "101"],
  I: ["111", "010", "010", "010", "111"],
  J: ["001", "001", "001", "101", "111"],
  K: ["101", "101", "110", "101", "101"],
  L: ["100", "100", "100", "100", "111"],
  M: ["101", "111", "111", "101", "101"],
  N: ["110", "101", "101", "101", "101"],
  O: ["111", "101", "101", "101", "111"],
  P: ["111", "101", "111", "100", "100"],
  Q: ["111", "101", "101", "111", "001"],
  R: ["111", "101", "110", "101", "101"],
  S: ["111", "100", "111", "001", "111"],
  T: ["111", "010", "010", "010", "010"],
  U: ["101", "101", "101", "101", "111"],
  V: ["101", "101", "101", "101", "010"],
  W: ["101", "101", "111", "111", "101"],
  X: ["101", "101", "010", "101", "101"],
  Y: ["101", "101", "010", "010", "010"],
  Z: ["111", "001", "010", "100", "111"],
  0: ["111", "101", "101", "101", "111"],
  1: ["010", "110", "010", "010", "111"],
  2: ["111", "001", "111", "100", "111"],
  3: ["111", "001", "111", "001", "111"],
  4: ["101", "101", "111", "001", "001"],
  5: ["111", "100", "111", "001", "111"],
  6: ["111", "100", "111", "101", "111"],
  7: ["111", "001", "010", "010", "010"],
  8: ["111", "101", "111", "101", "111"],
  9: ["111", "101", "111", "001", "111"],
  ".": ["000", "000", "000", "000", "010"],
  ",": ["000", "000", "000", "010", "100"],
  "-": ["000", "000", "111", "000", "000"],
  "—": ["000", "000", "111", "000", "000"],
  "!": ["010", "010", "010", "000", "010"],
  "?": ["111", "001", "010", "000", "010"],
  "/": ["001", "001", "010", "100", "100"],
  ":": ["000", "010", "000", "010", "000"],
  "'": ["010", "010", "000", "000", "000"],
  " ": ["000", "000", "000", "000", "000"],
};

function asciiArtEl(text) {
  const line = document.createElement("div");
  line.className = "paste-notice-art";
  const scale = document.createElement("div");
  scale.className = "paste-notice-pixels";
  const letters = String(text).toUpperCase();
  for (let i = 0; i < letters.length; i += 1) {
    const glyph = ASCII_FONT[letters[i]] ?? ASCII_FONT[" "];
    const letter = document.createElement("span");
    letter.className = "paste-notice-letter";
    letter.style.setProperty("--d", `${i * 45}ms`);
    for (const row of glyph) {
      for (const bit of row) {
        const cell = document.createElement("i");
        if (bit === "1") cell.className = "on";
        letter.append(cell);
      }
    }
    scale.append(letter);
  }
  line.append(scale);
  return line;
}

function pasteNotice(text) {
  clearTimeout(pasteNoticeTimer);
  let el = document.getElementById("paste-notice");
  if (!el) {
    el = document.createElement("div");
    el.className = "paste-notice";
    el.id = "paste-notice";
    el.setAttribute("role", "status");
    document.body.append(el);
  }
  el.setAttribute("aria-label", text);
  el.replaceChildren(asciiArtEl(text));
  el.classList.add("is-on");
  pasteNoticeTimer = setTimeout(() => el.classList.remove("is-on"), 2600);
}

function shortcutFailure(result) {
  return result.reason === "full" ? "PANEL IS FULL" : "NOT AN ADDRESS";
}

async function addShortcutAt(url, spot) {
  const first = await PageSettings.addPageShortcut({
    url,
    x: spot ? spot.x - SC_ICON_HALF : null,
    y: spot ? spot.y - SC_ICON_HALF_TOP : null,
  });
  if (first.ok || first.reason !== "spot") return first;
  const free = nextShortcutSpot();
  return free ? PageSettings.addPageShortcut({ url, x: free.x, y: free.y }) : first;
}

async function placePastedIcon(url) {
  const spot = livePasteSpot();
  const host = PageSettings.hostOfUrl(url);
  const placed = await addShortcutAt(url, spot);
  if (!placed.ok) {
    pasteNotice(shortcutFailure(placed));
    return;
  }
  await applySettings();
  PageShortcuts.select?.(placed.specId, placed.linkId);
  pasteNotice(`PLACED ${host}`);
}

function nextShortcutSpot() {
  const step = SC_ICON_PITCH;
  const first = { x: 32, y: 128 };
  for (let i = 0; i < 240; i += 1) {
    const x = first.x + (i % 6) * step;
    const y = first.y + Math.floor(i / 6) * step;
    if (y > window.innerHeight - step) break;
    const rect = { left: x, top: y, right: x + step, bottom: y + step };
    const clear = [...document.querySelectorAll(".wg")].every((panel) => {
      const r = panel.getBoundingClientRect();
      if (!r.width || !r.height) return true;
      return !(rect.left < r.right && rect.right > r.left && rect.top < r.bottom && rect.bottom > r.top);
    });
    if (clear) return { x, y };
  }
  return null;
}

document.addEventListener("paste", (event) => {
  // While a surface is open the user is editing, not laying out. An icon
  // appearing behind the panel would read as the paste having been swallowed.
  const panel = document.getElementById("settings-panel");
  if (panel && !panel.classList.contains("hidden")) return;
  if (document.querySelector(".wg-modal-scrim")) return;
  // A menu or a form is a surface too, and a paste arriving while one is open
  // used to be the page's: the icon was placed behind whatever the user was
  // actually looking at, which then reads as "the paste made something I cannot
  // find, select or move". The selectors are the two surfaces that take typing
  // — the widget menu (its rename and city fields) and the page-level modals —
  // plus the settings panel itself, which is answered by the check above.
  //
  // The widgets' own in-page forms (`.wg-add`, `.wg-search-input`) are *not*
  // listed here, and must not be: their forms are built on every page whether
  // or not they are open, so a bare selector matched the closed add form of a
  // bookmarks panel and swallowed every paste on the page. A paste over a form
  // that is actually open is a paste into one of its fields, and
  // `pasteIsForField` below answers that from the target rather than from
  // whether such a form exists somewhere.
  if (document.querySelector(".wg-menu, .wg-modal-scrim")) return;
  // A paste another handler already claimed keeps its claim: the two ways to
  // get here with a link are the page's own gesture and a field's edit, and a
  // field answers first.
  if (event.defaultPrevented) return;
  if (pasteIsForField(event.target)) return;

  const text = (event.clipboardData?.getData("text") ?? "").trim();
  if (!text) return;
  const url = pastedUrlOf(text);
  if (!url) return;
  // Only a paste that became a shortcut is swallowed; anything else keeps the
  // browser's own behaviour.
  event.preventDefault();
  placePastedIcon(url);
});

/** Escape leaves the search box, so the page-level paste is reachable from the
 *  one state the new tab always starts in. A new tab focuses the box on load,
 *  and every paste with it focused goes into the box — which is right for
 *  opening a link and wrong for pinning one. Escape is the key that already
 *  means "leave this field" everywhere else, and a focused box is the only
 *  thing standing between the user and the gesture. */
input.addEventListener("keydown", (event) => {
  if (event.key !== "Escape") return;
  // The panel closes on Escape from a document-level listener in panel.js, and
  // letting this key reach it would do two things at once: clear or leave the
  // box *and* drop focus onto the gear, which is where `panelClose` parks it.
  // Escape belongs to whichever surface has focus, so this one keeps it.
  event.stopPropagation();
  if (!input.value) {
    // Empty, so there is nothing to lose by blurring — and blurring keeps the
    // key from doing anything else on a page with nothing open.
    event.preventDefault();
    input.blur();
    pasteNotice("PASTE A LINK");
    return;
  }
  // A query in the box is cleared first, matching what Escape does in the
  // browser's own address bar. The second press then leaves the box.
  event.preventDefault();
  input.value = "";
});

// ── Space goes to the box ─────────────────────────────────────────────────
// The box is the page's primary control and the one thing that has to be
// reachable without aiming at it. A new tab starts with it focused, but a click
// on the page, a drag, or Escape takes the focus away — and from there the only
// ways back are a click on a 520px-wide target or a Tab chain through every
// widget. Space is the key every launcher on this machine already means "give
// me the box".
//
// The handler is deliberately conservative. It runs on the document in the
// bubble phase, so anything that owns the key has already had it, and it only
// takes the key when it is certain nothing else wants it — because the cost of
// being wrong is a page that cannot scroll and buttons that will not press.

/** A control that Space belongs to. `<button>`, a link and a tab all activate on
 *  Space (or on Space's keyup), and a page-level "focus the box" that ate it
 *  would make the keyboard unusable inside a widget. */
const SPACE_OWNS_KEY =
  "a[href], button, summary, select, [role='button'], [role='switch'], [role='tab'], [role='menuitem'], [role='menuitemcheckbox'], [role='menuitemradio'], [role='option'], [role='checkbox'], [role='radio'], [role='combobox'], [contenteditable=''], [contenteditable='true'], [contenteditable='plaintext-only']";

/** Open surfaces, and gestures in flight. While one of these is running the
 *  pointer owns the page and a Space is "keep going", not "find the box". */
function pageSurfaceBusy() {
  if (PageShortcuts?.busy?.()) return true;
  if (document.querySelector(".wg-menu, .wg-modal-scrim, .sc-marquee")) return true;
  if (document.querySelector(".is-dragging, .is-moving, .is-resizing")) return true;
  const panel = document.getElementById("settings-panel");
  if (panel && !panel.classList.contains("hidden")) return true;
  const scrim = document.getElementById("settings-scrim");
  return Boolean(scrim && !scrim.classList.contains("hidden"));
}

document.addEventListener("keydown", (event) => {
  // `key` rather than `code`: an IME or a non-Latin layout should still reach
  // the box on the key labelled Space.
  if (event.key !== " ") return;
  if (event.repeat) return;
  if (event.ctrlKey || event.metaKey || event.altKey) return;
  // Someone below already handled this key, and a second handler acting on it
  // would be two things to one gesture.
  if (event.defaultPrevented) return;
  if (pageSurfaceBusy()) return;

  const target = event.target instanceof Element ? event.target : null;
  // Typing, in a field of any kind: the space is a character.
  if (target && pasteIsForField(target)) return;
  // Focused on something Space activates. `activeElement` rather than only the
  // event target, because the key can be pressed while the body has focus in
  // browsers that keep the activation on a previously focused control.
  const focused = document.activeElement instanceof Element ? document.activeElement : null;
  if (focused && focused !== document.body && focused.closest(SPACE_OWNS_KEY)) return;

  // Only now is the key ours — and only now is scrolling the page stopped.
  event.preventDefault();
  input.focus();
  // Placing the caret at the end rather than selecting: typing continues a
  // query that was left there, which is what the box's text still means.
  const end = input.value.length;
  try {
    input.setSelectionRange(end, end);
  } catch {
    /* a non-text input would refuse; there is nothing to place a caret in */
  }
});

// ── moving the search box ─────────────────────────────────────────────────
// The box lives in the stage's centred column by default. Dragging it takes it
// out of that column and fixes it wherever it is dropped, which is a stored
// `{ searchX, searchY }` — see the note beside those defaults in settings.js
// for why the centred position is `null` rather than a pair of coordinates.
//
// The drag is the same shape as `decor.js`'s: pointer capture, a `move` that
// only writes inline styles, and one storage write on release. Writing per
// frame would be a write per pixel and a full page re-render behind each one.

/** The gap the box keeps from every edge of the viewport. */
const SEARCH_MARGIN = 12;

function clampSearch(x, y, width, height) {
  const maxX = Math.max(SEARCH_MARGIN, window.innerWidth - width - SEARCH_MARGIN);
  const maxY = Math.max(SEARCH_MARGIN, window.innerHeight - height - SEARCH_MARGIN);
  return {
    x: Math.min(Math.max(SEARCH_MARGIN, x), maxX),
    y: Math.min(Math.max(SEARCH_MARGIN, y), maxY),
  };
}

function stageGuideObstacles(skip) {
  const skipped = new Set(Array.isArray(skip) ? skip : [skip]);
  const rects = PageWidgets?.dragObstacles?.(undefined) ?? [];
  for (const id of ["clock-block", "search-form"]) {
    if (skipped.has(id)) continue;
    const el = document.getElementById(id);
    if (!el || el.hidden || el.classList.contains("hidden") || el.classList.contains("is-hidden")) continue;
    const rect = el.getBoundingClientRect();
    if (!rect.width || !rect.height) continue;
    rects.push(rect);
  }
  return rects;
}

/** Put the box at a stored position, or back into the stage's centred column.
 *
 *  Applied as inline styles, which is what lets the position survive the
 *  settings panel repainting around it; the class carries the `position:
 *  fixed` and the dropped `max-width`. Clearing the inline styles on the way
 *  back matters: a left/top left behind on a static element does nothing today,
 *  but it would spring the box across the page the moment the class came back. */
function placeSearch(settings) {
  // A free box is a thing the user turned on; it is not drawn at all when it is
  // off. The centred column and the free box share one element, so "turned off"
  // is the only state in which `applySettings` has to say anything about it.
  const shown = settings.searchShown !== false;
  form.hidden = !shown;
  form.classList.toggle("is-hidden", !shown);
  if (!shown) {
    form.classList.remove("is-free");
    form.style.left = "";
    form.style.top = "";
    placeClockAfterSearch(settings);
    return;
  }
  const x = settings.searchX;
  const y = settings.searchY;
  // The size the grip wrote, if it ever has. `null` is the shipped state and
  // means "whatever the stylesheet says, or whatever the last drag froze".
  const stored = Number(settings.searchWidth);
  const sized = Number.isFinite(stored) && stored > 0;

  if (x == null || y == null) {
    form.classList.remove("is-free");
    form.style.left = "";
    form.style.top = "";
    // Restored here too, not just in the free branch: the two states share one
    // width, so a box resized while pinned and then sent back to the centre
    // keeps the size that was chosen. The stylesheet's own 520px cap applies
    // only when no choice was ever made.
    setSearchWidthStyle(sized ? stored : null);
    placeClockAfterSearch(settings);
    return;
  }
  // Measured *before* the class goes on. `is-free` is what drops the 520px
  // max-width, so a box measured after it reports the width of the whole page —
  // and freezing that as an inline style is how a restored box came back
  // spanning the viewport rather than sitting at its own size. An inline width
  // already there (a re-apply onto a box that is already free) wins over the
  // measurement, because it is the width the user dragged it to. */
  const rect = form.getBoundingClientRect();
  const width = sized ? stored : parseFloat(form.style.width) || rect.width || 520;
  const height = rect.height || 40;
  form.classList.add("is-free");
  const spot = clampSearch(x, y, width, height);
  // An explicit `max-width` too. The class drops the stylesheet's cap, but an
  // inline one survives the class going away, and a box last sized at 700px
  // would otherwise be squeezed to 520 the moment it went back to the centre.
  form.style.width = `${Math.round(width)}px`;
  form.style.maxWidth = "none";
  form.style.left = `${spot.x}px`;
  form.style.top = `${spot.y}px`;
  placeClockAfterSearch(settings);
}

/** Write the box's width as inline styles, or clear them back to the
 *  stylesheet's own `width: 100%; max-width: 520px`.
 *
 *  Both properties, always: `width` alone is capped by the 520px `max-width`
 *  while the box sits in the centred column, so a wider choice would silently
 *  do nothing there. */
function setSearchWidthStyle(width) {
  const n = Number(width);
  if (!Number.isFinite(n) || n <= 0) {
    form.style.width = "";
    form.style.maxWidth = "";
    return;
  }
  form.style.width = `${Math.round(n)}px`;
  form.style.maxWidth = `${Math.round(n)}px`;
}

/** Start a drag from anywhere on the box except the text field.
 *
 *  The input is excluded because dragging it would fight text selection — the
 *  whole point of the field is to be typed in. The prompt and the engine hint
 *  are the handles, and both carry `cursor: grab` so the gesture is visible.
 *  A drag is also refused while the settings panel is open: the panel covers
 *  the right two-fifths of the page, and dropping the box under it would be
 *  moving something the user then cannot see or reach. */
function startSearchDrag(event) {
  if (event.button !== 0) return;
  if (event.target === input) return;
  // The bang button sits on the box too, and it is a control rather than a
  // handle — a drag that started on it would open the modal and move the box at
  // once. Matched with `closest` because the press lands on the svg inside it.
  if (event.target.closest?.(".search-bang")) return;
  // The resize grip is the other control on the box. It handles its own press
  // and stops propagation, so this should never see one — but the guard costs a
  // line and keeps the two gestures from ever both starting.
  if (event.target.closest?.(".search-resize")) return;
  const panel = document.getElementById("settings-panel");
  if (panel && !panel.classList.contains("hidden")) return;

  event.preventDefault();
  // Read once, at the start: the box's own rect and the pointer's offset inside
  // it. Measuring per frame instead would make the box lag the pointer.
  const rect = form.getBoundingClientRect();
  const grabX = event.clientX - rect.left;
  const grabY = event.clientY - rect.top;
  const width = rect.width;
  const height = rect.height;

  form.classList.add("is-free", "is-dragging");
  form.style.width = `${Math.round(width)}px`;
  // Capture keeps the events coming once the pointer leaves the box's own
  // rectangle — a drag to the far corner of the page would otherwise stop
  // tracking the moment it crossed the edge. It is best-effort because it needs
  // a live pointer: a synthetic event, or a pointer the browser has already
  // released, throws `NotFoundError` and would abort the whole drag. The move
  // and release listeners go on `window` for the same reason — with capture
  // they arrive retargeted to the box, without it they still arrive at the
  // window, and a drag never breaks either way.
  try {
    form.setPointerCapture(event.pointerId);
  } catch {
    /* tracking below still works while the pointer is over the box */
  }

  let spot = clampSearch(rect.left, rect.top, width, height);
  const size = { width, height };
  const obstacles = stageGuideObstacles(pageSettings?.clockDocked ? ["search-form", "clock-block"] : "search-form");
  const move = (e) => {
    let x = e.clientX - grabX;
    let y = e.clientY - grabY;
    if (e.shiftKey) {
      const snapped = PageWidgets?.guideSnap?.(x, y, size, obstacles);
      if (snapped) {
        x = snapped.x;
        y = snapped.y;
      }
    }
    spot = clampSearch(x, y, width, height);
    form.style.left = `${spot.x}px`;
    form.style.top = `${spot.y}px`;
    if (pageSettings?.clockDocked) placeClockAfterSearch(pageSettings);
    if (e.shiftKey) {
      const lines = PageWidgets?.guidesAt?.(spot.x, spot.y, size, obstacles);
      if (lines) PageWidgets.paintGuides(lines.verticals, lines.horizontals);
    } else {
      PageWidgets?.clearGuides?.();
    }
  };
  const up = async () => {
    window.removeEventListener("pointermove", move);
    window.removeEventListener("pointerup", up);
    window.removeEventListener("pointercancel", up);
    PageWidgets?.clearGuides?.();
    form.classList.remove("is-dragging");
    // Written once, on release. What is on screen is already correct — this is
    // only what makes it survive a reload.
    await PageSettings.setSearchPosition(spot.x, spot.y);
  };
  window.addEventListener("pointermove", move);
  window.addEventListener("pointerup", up);
  window.addEventListener("pointercancel", up);
}

form.addEventListener("pointerdown", startSearchDrag);

// ── moving the clock ──────────────────────────────────────────────────────
// The same gesture as the search box above, on the same terms: the stage centres
// it by default, and a drag takes it out of the column and pins it wherever it
// is dropped. It is deliberately a separate function rather than a shared one
// with a parameter — the two elements differ in which node is the handle, in how
// their size is measured, and in which stored pair they write, and a shared
// helper would spend more lines on those three differences than the two copies
// do on the whole drag.

/** The gap the clock keeps from every edge of the viewport. */
const CLOCK_MARGIN = 8;

function clampClock(x, y, width, height) {
  const maxX = Math.max(CLOCK_MARGIN, window.innerWidth - width - CLOCK_MARGIN);
  const maxY = Math.max(CLOCK_MARGIN, window.innerHeight - height - CLOCK_MARGIN);
  return {
    x: Math.min(Math.max(CLOCK_MARGIN, x), maxX),
    y: Math.min(Math.max(CLOCK_MARGIN, y), maxY),
  };
}

function placeClock(settings) {
  const x = settings.clockX;
  const y = settings.clockY;
  const block = document.getElementById("clock-block");
  if (!block) return;
  const docked = settings.clockDocked === true;
  block.classList.toggle("is-docked", docked);
  document.getElementById("search-dock")?.classList.toggle("is-docked", docked);
  block.style.width = "";
  if (docked) {
    block.classList.remove("is-free");
    block.style.left = "";
    block.style.top = "";
    placeClockAfterSearch(settings);
    return;
  }
  if (x == null || y == null) {
    block.classList.remove("is-free");
    block.style.left = "";
    block.style.top = "";
    return;
  }
  block.classList.add("is-free");
  const rect = block.getBoundingClientRect();
  const spot = clampClock(x, y, rect.width, rect.height);
  block.style.left = `${spot.x}px`;
  block.style.top = `${spot.y}px`;
}

const DOCK_GAP = 14;
const DOCK_HINT_MIN = 48;
const CLOCK_DRAG_SLOP = 4;

function placeClockAfterSearch(settings) {
  const block = document.getElementById("clock-block");
  const dock = document.getElementById("search-dock");
  if (!block || !dock) return;
  const time = document.getElementById("clock-time");
  if (!time) return;

  const docked = settings.clockDocked === true;
  dock.classList.toggle("is-docked", docked);
  dock.classList.toggle("is-free", form.classList.contains("is-free"));

  const live = docked && settings.searchShown !== false && settings.clockShown !== false;
  if (docked) block.classList.toggle("is-hidden", !live);
  if (!live) {
    block.style.left = "";
    block.style.top = "";
    block.style.width = "";
    dock.style.setProperty("--dock-gap", "");
    dock.style.width = "";
    dock.style.maxWidth = "";
    return;
  }

  const base = Number(settings.clockSize);
  const size = Number.isFinite(base)
    ? Math.min(PageSettings.CLOCK_SIZE_MAX, Math.max(PageSettings.CLOCK_SIZE_MIN, base))
    : 68;
  const box = form.getBoundingClientRect();
  const roomAbove = Math.max(0, box.top - SEARCH_MARGIN - DOCK_GAP);
  const blockHeight = block.offsetHeight || 0;
  const timeHeight = time.getBoundingClientRect().height || 0;
  const chrome = Math.max(0, blockHeight - timeHeight);
  const roomForTime = Math.max(0, roomAbove - chrome);
  const current = parseFloat(getComputedStyle(time).fontSize) || size;
  const fit = timeHeight > 0 ? current * (roomForTime / timeHeight) : size;
  const next = Math.max(PageSettings.CLOCK_SIZE_MIN, Math.round(Math.min(size, fit)));
  time.style.fontSize = `${next}px`;

  if (!form.classList.contains("is-free")) {
    block.style.left = "";
    block.style.top = "";
    block.style.width = "";
    dock.style.width = `${Math.round(box.width)}px`;
    dock.style.maxWidth = "none";
    dock.style.setProperty("--dock-gap", `${DOCK_GAP}px`);
    return;
  }

  block.style.width = `${Math.round(box.width)}px`;
  const rect = block.getBoundingClientRect();
  const left = box.left + (box.width - rect.width) / 2;
  const top = box.top - rect.height - DOCK_GAP;
  block.style.left = `${Math.round(Math.max(SEARCH_MARGIN, left))}px`;
  block.style.top = `${Math.round(Math.max(SEARCH_MARGIN, top))}px`;
  dock.style.setProperty("--dock-gap", "");
}

function startClockDrag(event) {
  if (event.button !== 0) return;
  if (event.target.closest?.(".clock-resize")) return;
  const block = event.currentTarget;
  const panel = document.getElementById("settings-panel");
  if (panel && !panel.classList.contains("hidden")) return;

  event.preventDefault();
  const wasDocked = block.classList.contains("is-docked");
  const rect = block.getBoundingClientRect();
  const startX = event.clientX;
  const startY = event.clientY;
  const chosen = Number(pageSettings?.clockSize);
  const looseSize = Number.isFinite(chosen) ? chosen : 68;

  block.style.transform = "";
  block.classList.add("is-dragging");
  try {
    block.setPointerCapture(event.pointerId);
  } catch {
    /* tracking below still works while the pointer is over the block */
  }

  let moved = false;
  let spot = { x: rect.left, y: rect.top };
  const size = { width: rect.width, height: rect.height };
  const obstacles = stageGuideObstacles("clock-block");
  const move = (e) => {
    if (!moved && Math.hypot(e.clientX - startX, e.clientY - startY) >= CLOCK_DRAG_SLOP) moved = true;
    let x = rect.left + (e.clientX - startX);
    let y = rect.top + (e.clientY - startY);
    if (e.shiftKey) {
      const snapped = PageWidgets?.guideSnap?.(x, y, size, obstacles);
      if (snapped) {
        x = snapped.x;
        y = snapped.y;
      }
    }
    spot = clampClock(x, y, rect.width, rect.height);
    block.style.transform = `translate(${spot.x - rect.left}px, ${spot.y - rect.top}px)`;
    setClockDockHint(overSearchBox(e.clientX, e.clientY));
    if (e.shiftKey) {
      const lines = PageWidgets?.guidesAt?.(spot.x, spot.y, size, obstacles);
      if (lines) PageWidgets.paintGuides(lines.verticals, lines.horizontals);
    } else {
      PageWidgets?.clearGuides?.();
    }
  };
  const up = async (e) => {
    window.removeEventListener("pointermove", move);
    window.removeEventListener("pointerup", up);
    window.removeEventListener("pointercancel", up);
    PageWidgets?.clearGuides?.();
    block.classList.remove("is-dragging");
    block.style.transform = "";
    setClockDockHint(false);
    if (!moved) {
      applySettings();
      return;
    }
    const px = e?.clientX ?? startX;
    const py = e?.clientY ?? startY;
    if (overSearchBox(px, py)) {
      block.classList.remove("is-free");
      block.style.left = "";
      block.style.top = "";
      block.style.width = "";
      await PageSettings.setClockDocked(true);
      applySettings();
      return;
    }
    if (wasDocked) await PageSettings.setClockDocked(false);
    if (wasDocked) timeEl.style.fontSize = `${Math.round(looseSize)}px`;
    await PageSettings.setClockPosition(spot.x, spot.y);
    applySettings();
  };
  window.addEventListener("pointermove", move);
  window.addEventListener("pointerup", up);
  window.addEventListener("pointercancel", up);
}

function overSearchBox(clientX, clientY) {
  if (form.hidden || form.classList.contains("is-hidden")) return false;
  const rect = form.getBoundingClientRect();
  const block = document.getElementById("clock-block");
  const reach = Math.max(DOCK_HINT_MIN, block?.offsetHeight ?? DOCK_HINT_MIN);
  return (
    clientX >= rect.left &&
    clientX <= rect.right &&
    clientY >= rect.top - reach &&
    clientY <= rect.bottom
  );
}

function setClockDockHint(on) {
  const dock = document.getElementById("search-dock");
  if (!dock) return;
  const want = Boolean(on);
  form.classList.toggle("is-dock-target", want);
  if (!want) {
    dock.style.removeProperty("--dock-hint");
    return;
  }
  const block = document.getElementById("clock-block");
  const carried = block?.offsetHeight ?? 0;
  dock.style.setProperty("--dock-hint", `${Math.max(DOCK_HINT_MIN, Math.round(carried))}px`);
}

{
  const clockBlock = document.getElementById("clock-block");
  if (clockBlock) clockBlock.addEventListener("pointerdown", startClockDrag);
}

// ── sizing the clock and the search box ───────────────────────────────────
// Both stage controls are already draggable, so a resize has to be a control
// of its own rather than a second meaning for the same pixels: the widgets'
// `.wg-resize` corner, same glyph and same cursor, on the two elements that
// sit in the stage instead of on the widget layer. Each grip stops its own
// press, which is what keeps the move-drag underneath it from also starting.

/** The shared corner grip. Faint and hit-free until its parent is hovered —
 *  the `.wg-resize` idiom, for the same reason: a control that only appears on
 *  hover is one the user has to already know about. */
function stageResizeGrip(className, onStart) {
  const grip = document.createElement("span");
  grip.className = className;
  grip.textContent = "◢";
  grip.title = "Drag to resize";
  grip.setAttribute("aria-hidden", "true");
  grip.addEventListener("pointerdown", onStart);
  return grip;
}

/** Resize the search box by its width. Free between the store's limits, written
 *  inline per frame so the corner tracks the pointer, and stored once on
 *  release — the same accounting the move-drag does. */
function startSearchResize(event) {
  if (event.button !== 0) return;
  // Both, and in this order: the browser would otherwise start a text selection
  // on the first move, and the press would reach the box's own move-drag.
  event.preventDefault();
  event.stopPropagation();
  const panel = document.getElementById("settings-panel");
  if (panel && !panel.classList.contains("hidden")) return;

  const startX = event.clientX;
  const startWidth = form.getBoundingClientRect().width;
  const min = PageSettings.SEARCH_WIDTH_MIN;
  const max = PageSettings.SEARCH_WIDTH_MAX;
  form.classList.add("is-resizing");

  let width = startWidth;
  const nextWidth = (e) =>
    Math.min(max, Math.max(min, startWidth + (e.clientX - startX)));

  const move = (e) => {
    width = nextWidth(e);
    setSearchWidthStyle(width);
  };
  const up = async () => {
    window.removeEventListener("pointermove", move);
    window.removeEventListener("pointerup", up);
    window.removeEventListener("pointercancel", up);
    form.classList.remove("is-resizing");
    setSearchWidthStyle(width);
    const next = await PageSettings.setSearchWidth(Math.round(width));
    // Re-placed rather than fully re-applied: a wider box can now overhang the
    // edge it was dropped against, and only `placeSearch` re-clamps it against
    // the width it actually has. A full `applySettings` would also re-render
    // every widget, which resizing the box has no business doing.
    placeSearch(next);
  };

  window.addEventListener("pointermove", move);
  window.addEventListener("pointerup", up);
  window.addEventListener("pointercancel", up);
}

/** Resize the clock by its type size.
 *
 *  There is no width to store, unlike the search box: the clock's width is a
 *  product of its face and its size, so freezing a pixel width here would be
 *  undone by the next face change. The gesture scales the digits, and the
 *  pointer delta is read as a *ratio* against the block's starting width,
 *  which is what keeps the corner roughly under the pointer as it moves. */
function startClockResize(event) {
  if (event.button !== 0) return;
  event.preventDefault();
  event.stopPropagation();
  const panel = document.getElementById("settings-panel");
  if (panel && !panel.classList.contains("hidden")) return;
  const block = document.getElementById("clock-block");
  if (!block) return;

  const startX = event.clientX;
  // The rendered width, not the stored size: the face's own weight and slant
  // change how wide the same font size draws, and the ratio has to start from
  // what is on screen. `|| 1` so a hidden or not-yet-laid-out block cannot
  // divide by zero.
  const startWidth = block.getBoundingClientRect().width || 1;
  const startSize = parseFloat(getComputedStyle(timeEl).fontSize) || 68;
  const min = PageSettings.CLOCK_SIZE_MIN;
  const max = PageSettings.CLOCK_SIZE_MAX;
  block.classList.add("is-resizing");

  let size = startSize;
  const nextSize = (e) =>
    Math.min(max, Math.max(min, (startSize * (startWidth + (e.clientX - startX))) / startWidth));

  const move = (e) => {
    size = nextSize(e);
    timeEl.style.fontSize = `${size}px`;
  };
  const up = async () => {
    window.removeEventListener("pointermove", move);
    window.removeEventListener("pointerup", up);
    window.removeEventListener("pointercancel", up);
    block.classList.remove("is-resizing");
    timeEl.style.fontSize = `${size}px`;
    const next = await PageSettings.setClockSize(Math.round(size));
    // A larger clock can now reach past the edge it was pinned near, and a
    // smaller one leaves a gap where it used to sit. `placeClock` measures the
    // block and re-clamps.
    if (next) placeClock(next);
  };

  window.addEventListener("pointermove", move);
  window.addEventListener("pointerup", up);
  window.addEventListener("pointercancel", up);
}

{
  const clockBlock = document.getElementById("clock-block");
  if (clockBlock) clockBlock.appendChild(stageResizeGrip("clock-resize", startClockResize));
  form.appendChild(stageResizeGrip("search-resize", startSearchResize));
}

// ── applying settings ─────────────────────────────────────────────────────

/** The clock's face and size. Written as inline styles rather than a class per
 *  face because the size is a free number — a class would have to be a matrix
 *  of font × size, and the panel's slider makes that matrix unbounded. */
function applyClock(settings) {
  // The clock block is added and removed from the panel's widget list with the
  // same switch every panel has, so the one attribute that hides it is read
  // here rather than in a second place.
  const clockEl = document.getElementById("clock-block");
  if (clockEl) clockEl.classList.toggle("is-hidden", settings.clockShown === false);
  const font = PageSettings.clockFontById(settings.clockFont);
  timeEl.style.fontFamily = font.stack;
  // Weight and slant come from the face, not from a rule here. A face that
  // borrows a cut the family actually ships renders as designed; asking an
  // @font-face for a weight it does not have makes the browser synthesise one,
  // which smears a pixel grid into something that is neither face.
  timeEl.style.fontWeight = String(font.weight ?? 400);
  timeEl.style.fontStyle = font.style ?? "normal";
  // The effect faces (outline, glow) are CSS on the element rather than a font.
  // A face with no effect sets no class, so a plain face clears whatever the
  // previous one left behind.
  timeEl.classList.toggle("is-outline", font.effect === "outline");
  timeEl.classList.toggle("is-glow", font.effect === "glow");
  const size = Number(settings.clockSize);
  timeEl.style.fontSize = `${Number.isFinite(size) ? Math.min(160, Math.max(32, size)) : 68}px`;
}

/** The built-in backdrops, as CSS background layers. Each is one or two
 *  gradients and the tile size it has to be drawn at — `grid` is the only one
 *  that needs two, since its vertical and horizontal rules have to share a
 *  tile.
 *
 *  Published rather than kept local because the settings panel's wallpaper
 *  preview has to paint exactly what the page paints; two copies of this map
 *  would be two things to keep in sync. */
const WALLPAPER_CSS = {
  none: { image: "none", size: "auto" },
  // The patterns are drawn in `--ink-rgb`, the theme's own ink, so they are
  // faint bone marks on black paper and faint dark marks on bone paper. Written
  // as `rgba(var(--ink-rgb), a)` rather than resolved here because a pattern is
  // applied once and then sits in an inline style: a resolved hex would keep
  // the old theme's colour after a switch until the page re-applied it, and a
  // variable keeps following the stylesheet on its own.
  dots: { image: "radial-gradient(circle at 1px 1px, rgba(var(--ink-rgb), 0.10) 1px, transparent 0)", size: "22px 22px" },
  grid: {
    image:
      "linear-gradient(rgba(var(--ink-rgb), 0.06) 1px, transparent 1px), linear-gradient(90deg, rgba(var(--ink-rgb), 0.06) 1px, transparent 1px)",
    size: "32px 32px, 32px 32px",
  },
  scan: { image: "repeating-linear-gradient(0deg, rgba(var(--ink-rgb), 0.05) 0 1px, transparent 1px 3px)", size: "auto" },
  // Vignette is a wash in the paper colour rather than in black — the same
  // reasoning as the scrim: on bone paper a black wash is a smudge, while a
  // paper-coloured one quiets the page's edges the way this pattern intends.
  vignette: { image: "radial-gradient(ellipse at center, rgba(var(--paper-rgb), 0.9) 0%, rgba(var(--paper-rgb), 1) 78%)", size: "auto" },
};

/** The page's backdrop, in three layers that overwrite each other in one order:
 *  the dimming scrim, a photographic image on top of the built-in pattern, and
 *  the pattern underneath both. The image has its own opacity and blur on top of
 *  that, which is why it lives on its own element — see the note in theme.css.
 *
 *  Every layer is always written, so clearing the URL falls back to the pattern
 *  the user last chose rather than to nothing, and switching wallpaper is a
 *  variable write rather than a branch. */
async function applyWallpaper(settings) {
  const root = document.documentElement.style;
  const pattern = WALLPAPER_CSS[settings.wallpaperPattern] ?? WALLPAPER_CSS.none;
  root.setProperty("--wp-pattern", pattern.image);
  root.setProperty("--wp-pattern-size", pattern.size);

  // The uploaded image wins over the URL when both exist — see the note beside
  // `wallpaperUpload` in settings.js for why that precedence, and why the bytes
  // are read from their own storage key rather than out of the settings blob.
  const upload = settings.wallpaperUpload ? await PageSettings.getWallpaperUpload() : "";
  const url = String(settings.wallpaperUrl ?? "").trim();
  const image = upload || url;
  // Stripped of quotes and backslashes before it goes into `url("...")`, so a
  // stored value cannot close the string and append a second declaration. A data
  // URL from an upload contains neither, so the same treatment is harmless.
  root.setProperty("--wp-image", image ? `url("${image.replace(/["\\]/g, "")}")` : "none");

  const dim = Number(settings.wallpaperDim);
  root.setProperty("--wp-dim", String((Number.isFinite(dim) ? Math.min(90, Math.max(0, dim)) : 45) / 100));

  // The image's own alpha, which is a different control from `--wp-dim`: dim is
  // a veil painted over the image and the page, opacity fades the image into the
  // black paper behind it. Written as a plain 0-1 number because it lands in
  // `opacity: var(--wp-opacity)`, and clamped the way `dim` is — a stored blob is
  // one of several sources, none of which this code controls.
  const opacity = Number(settings.wallpaperOpacity);
  root.setProperty("--wp-opacity", String((Number.isFinite(opacity) ? Math.min(100, Math.max(0, opacity)) : 100) / 100));

  // A length, because it lands in `blur()`. 0px is no blur, which is also the
  // fallback for a stored value that is missing or NaN.
  const blur = Number(settings.wallpaperBlur);
  root.setProperty("--wp-blur", `${Number.isFinite(blur) ? Math.min(40, Math.max(0, blur)) : 0}px`);
}

// ── the theme ─────────────────────────────────────────────────────────────
// `data-theme` on `<html>` is what the stylesheet keys on, and it has to be
// right before the first paint or the page flashes its default. The <head>
// script does that synchronously from the `localStorage` mirror; everything
// here is the *live* half — keeping the attribute true when the OS preference
// changes, and re-painting the accent when a theme switch makes the other
// value of the hue correct.

/** The theme actually in force for a settings blob. `system` asks the device;
 *  anything else is the user overriding it. Unknown values read as `system`,
 *  which is also the shipped default — so a blob from a build that never had
 *  this field behaves exactly like a fresh install. */
function themeNow(settings) {
  return PageSettings.themeIsLight(settings) ? "light" : "dark";
}

/** Write the theme to the document and keep the mirror in step.
 *
 *  The mirror is written here as well as in `setTheme`, because settings can
 *  also arrive from the account (a pull replacing the blob under the page) and
 *  the <head> script will read the mirror on the *next* load. A failure to
 *  write it is not fatal — see the note in `setTheme`. */
function applyTheme(settings) {
  const theme = themeNow(settings);
  const root = document.documentElement;
  if (root.dataset.theme !== theme) root.dataset.theme = theme;
  try {
    localStorage.setItem(PageSettings.THEME_MIRROR_KEY, settings.theme === "light" || settings.theme === "dark" ? settings.theme : "system");
  } catch {
    /* the mirror is a first-paint optimisation, never the source of truth */
  }
}

/** Keep a `system` choice following the device while the page is open.
 *
 *  Only one listener exists, bound once at boot; it re-reads settings rather
 *  than trusting a cached blob, because the choice may have changed since the
 *  media query was registered. A page with an explicit light or dark choice
 *  still runs this listener — `themeNow` ignores the media query in that case
 *  and the handler settles on a no-op — which is one condition fewer than
 *  attaching and detaching a listener on every settings write. */
let mediaThemeQuery = null;
function watchSystemTheme() {
  if (mediaThemeQuery) return;
  try {
    mediaThemeQuery = window.matchMedia("(prefers-color-scheme: light)");
  } catch {
    return;
  }
  mediaThemeQuery.addEventListener("change", () => {
    PageSettings.get().then((settings) => {
      if (settings.theme !== "system") return;
      applyTheme(settings);
      applySettings();
    });
  });
}

/** Push current settings into the page: accent colour, clock face, backdrop,
 *  engine hint, and the widgets. The settings panel calls this after every
 *  change, so this is the one place that knows how a setting reaches the
 *  screen. */
async function applySettings() {
  const settings = await PageSettings.get();
  pageSettings = settings;

  applyTheme(settings);

  // One accent for the whole page, in two roles. `--accent` is the chosen hue
  // as material and `--accent-ink` the same hue as ink; every rule in
  // newtab.css picks the role it needs, so a palette that reads on black and
  // one that reads on paper both come out of these two lines.
  const accent = PageSettings.accentById(settings.accent);
  const accentHex = PageSettings.accentValueFor(accent, PageSettings.themeIsLight(settings));
  const root = document.documentElement.style;
  root.setProperty("--accent", accentHex);
  // Cleared rather than set to the same hex: the stylesheet's own
  // `color-mix` deeper for light mode is a better ink than the fill colour
  // restated, and an inline value would shadow it forever.
  root.removeProperty("--accent-ink");

  document.body.dataset.clock = settings.clock24 ? "24" : "12";

  // The page's default widget style, published once as a variable so each panel
  // can inherit it by simply not setting one of its own.
  document.documentElement.style.setProperty("--wg-style", settings.widgetStyle ?? "glass");

  applyClock(settings);
  // Awaited because the uploaded wallpaper is read out of its own storage key,
  // which is a promise — the rest of this function can run while it resolves,
  // but the widgets below must not paint before the backdrop is set.
  await applyWallpaper(settings);

  pageEngineId = settings.engine;
  pageClock24 = settings.clock24;
  // Read here rather than in the submit handler so a write in the modal updates
  // the very next search, the same way the engine does above. Nothing below
  // depends on it: bangs change no hint, no placeholder and no layout.
  pageBangs = settings.searchBangs ?? [];
  const engine = PageSettings.engineById(settings.engine);
  hint.textContent = engine.hint;
  input.placeholder = `Search ${engine.label}, or type a URL`;
  // After the hint and the placeholder, because both change the box's own width
  // and `placeSearch` freezes whichever width it finds.
  placeSearch(settings);
  // After `applyClock`, so a drag-restored clock is clamped against the size it
  // is actually being drawn at rather than the one it had last paint.
  placeClock(settings);

  startClock();
  // Three layers that do not touch each other — widgets into `#widgets`, decor
  // into `#decor-layer`, the floating shortcut icons into `#shortcut-layer` — so
  // they are built together rather than one after another. Sequentially the page
  // waited for the widgets' account round trips *before* it even started the
  // decor, which cost nothing to overlap; each renderer reads the same settings
  // blob and writes only its own host, so running them together cannot make them
  // disagree (the shortcut note still holds: they draw from their own read of
  // the blob, not from the panels' DOM).
  await Promise.all([
    PageWidgets.renderWidgets(),
    PageDecor.render(),
    PageShortcuts.render(settings),
  ]);
}

window.ixiNewtabPage = { applySettings, WALLPAPER_CSS, applyTheme, placeSearch, placeClock };

if (typeof ResizeObserver === "function") {
  const dockObserver = new ResizeObserver(() => {
    if (!pageSettings?.clockDocked) return;
    placeClockAfterSearch(pageSettings);
  });
  try {
    dockObserver.observe(form);
  } catch {
  }
}
// ── the settings panel ────────────────────────────────────────────────────

document.getElementById("settings-toggle").addEventListener("click", () => PagePanel.open());
document.getElementById("settings-close").addEventListener("click", () => PagePanel.close());
document.getElementById("settings-scrim").addEventListener("click", () => PagePanel.close());
// The bang manager's own doorway, on the right of the search box.
document.getElementById("search-bangs").addEventListener("click", () => PageBangs.open());

// ── the page's own context menu ───────────────────────────────────────────
// Right-clicking the empty page offers the three page-level commands. This has
// to coexist with the widget and decor menus, which handle the same event on
// their own nodes and call `preventDefault` there — so by the time anything
// reaches this listener the default menu is already suppressed and a widget's
// menu is already open. One guard keeps the two apart: the listener is on
// `window` in the *bubble* phase, so a handler on the header or body of a widget
// runs first and its `preventDefault` is visible here as
// `event.defaultPrevented`. Without that check a right-click on a widget would
// open both menus on top of each other.

let pageMenuNode = null;

function closePageMenu() {
  if (!pageMenuNode) return;
  pageMenuNode.remove();
  pageMenuNode = null;
  document.removeEventListener("pointerdown", onPageMenuOutside, true);
  document.removeEventListener("keydown", onPageMenuKey, true);
  window.removeEventListener("scroll", closePageMenu, true);
  window.removeEventListener("resize", closePageMenu);
}

function onPageMenuOutside(e) {
  if (pageMenuNode && !pageMenuNode.contains(e.target)) closePageMenu();
}

function onPageMenuKey(e) {
  if (e.key !== "Escape") return;
  // Stopped here for the same reason the widget menu stops it: `panel.js` has a
  // document-level Escape handler that closes the settings panel outright, so
  // letting this bubble would dismiss the menu *and* the panel behind it.
  e.stopPropagation();
  closePageMenu();
}

// ── the search box and clock's own menus ──────────────────────────────────
// Both are page furniture rather than panels: they paint inline, they are
// dragged rather than moved by a grip, and their settings live at the top level
// of the blob (`searchWidth`, `clockSize`, …) rather than in a widget entry. So
// they cannot borrow the widget menu — that one builds its rows from a `spec`
// and writes through `writeSettings({ widgets })`. What they *can* borrow is
// its shape, so the right-click means the same thing here as everywhere else on
// the page: a small list of the things that apply to what you pressed on, with
// the current value shown beside each one.
//
// The page's own right-click handler ignores `.search` (a text field's
// right-click is a request for the *edit* menu), so it already leaves the box
// alone; the clock block it does not, and the clock's listener claims it with a
// `stopPropagation` so the blanket handler on `window` never sees it. Inside the
// input the browser's own menu still wins, which is why this listener leaves a
// right-click in the field alone and only claims the box's chrome — the prompt,
// the engine hint, the bang button and the empty space around them.

let furnitureMenuNode = null;
let furnitureMenuAnchorNode = null;
/** The node whose menu is showing: "search", "clock" or null. A second
 *  right-click on the *same* piece closes, which makes the gesture a toggle;
 *  a right-click on the other one swaps the menu rather than stacking a second. */
let furnitureMenuOpen = null;

let furnitureSubNode = null;
let furnitureSubParent = null;
let furnitureSubTimer = 0;

function closeFurnitureSubmenu() {
  clearTimeout(furnitureSubTimer);
  furnitureSubTimer = 0;
  furnitureSubParent?.classList.remove("is-open");
  furnitureSubParent = null;
  if (!furnitureSubNode) return;
  furnitureSubNode.remove();
  furnitureSubNode = null;
}

function closeFurnitureMenu() {
  closeFurnitureSubmenu();
  furnitureMenuAnchorNode?.removeAttribute("aria-expanded");
  furnitureMenuAnchorNode = null;
  furnitureMenuOpen = null;
  if (!furnitureMenuNode) return;
  furnitureMenuNode.remove();
  furnitureMenuNode = null;
  document.removeEventListener("pointerdown", onFurnitureMenuOutside, true);
  document.removeEventListener("keydown", onFurnitureMenuKey, true);
  window.removeEventListener("scroll", closeFurnitureMenu, true);
  window.removeEventListener("resize", closeFurnitureMenu);
}

function onFurnitureMenuOutside(e) {
  if (furnitureSubNode?.contains(e.target)) return;
  if (furnitureMenuNode && !furnitureMenuNode.contains(e.target)) closeFurnitureMenu();
}

function onFurnitureMenuKey(e) {
  if (e.key !== "Escape") return;
  // Stopped for the same reason both other menus stop it: panel.js's document
  // Escape handler would otherwise close the settings panel behind the menu.
  e.stopPropagation();
  closeFurnitureMenu();
}

/** One row of a furniture menu. `row.active` paints the tick and `row.detail`
 *  the value on the right. */
function furnitureMenuRow(row) {
  const el = document.createElement("button");
  el.type = "button";
  el.className = row.danger ? "wg-menu-item is-danger" : "wg-menu-item";
  el.append(node("span", "wg-menu-mark", row.active ? "✓" : ""));
  el.append(node("span", "wg-menu-item-label", row.label));
  if (row.detail) el.append(node("span", "wg-menu-value", row.detail));
  el.addEventListener("click", () => {
    // Closed before the command, never after — the command may repaint the
    // page and take this button's anchor with it.
    closeFurnitureMenu();
    row.onSelect();
  });
  return el;
}

/** Rows for a radio group: the chosen one is ticked, and pressing it again is a
 *  no-op (the value is already the one it would write). */
function furnitureRadio(options, current, onPick) {
  return options.map((option) => ({
    active: option.id === current,
    label: option.label,
    detail: option.detail,
    onSelect: () => onPick(option),
  }));
}

function placeFurnitureSubmenu(sub, row) {
  const GUTTER = 6;
  const MIN_VISIBLE = 140;
  const rect = row.getBoundingClientRect();
  const menuRect = furnitureMenuNode?.getBoundingClientRect() ?? rect;
  const width = sub.offsetWidth;

  const fitsRight = menuRect.right + width <= window.innerWidth - GUTTER;
  const fitsLeft = menuRect.left - width >= GUTTER;
  let left;
  if (fitsRight) left = menuRect.right;
  else if (fitsLeft) left = menuRect.left - width;
  else left = Math.max(GUTTER, Math.min(menuRect.left - width, window.innerWidth - width - GUTTER));

  sub.style.maxHeight = "";
  const height = sub.offsetHeight;
  const spaceBelow = window.innerHeight - rect.top - GUTTER;
  const spaceAbove = rect.bottom - GUTTER;

  let top;
  let maxHeight = "";
  if (height <= spaceBelow) {
    top = rect.top - 5;
  } else if (height <= spaceAbove) {
    top = rect.bottom - height + 5;
  } else if (spaceBelow >= spaceAbove) {
    top = rect.top - 5;
    maxHeight = `${Math.max(MIN_VISIBLE, spaceBelow + 5)}px`;
  } else {
    top = Math.max(GUTTER, rect.bottom - Math.max(MIN_VISIBLE, spaceAbove));
    maxHeight = `${Math.max(MIN_VISIBLE, spaceAbove)}px`;
  }

  sub.style.left = `${left}px`;
  sub.style.top = `${Math.max(GUTTER, top)}px`;
  sub.style.maxHeight = maxHeight;
}

function furnitureSubmenuRow({ label, detail, entries }) {
  const row = node("div", "wg-menu-item has-sub");
  row.append(node("span", "wg-menu-item-label", label));
  if (detail) row.append(node("span", "wg-menu-value", detail));
  row.append(node("span", "wg-menu-caret", "▸"));

  const open = () => {
    clearTimeout(furnitureSubTimer);
    furnitureSubTimer = 0;
    if (furnitureSubParent === row) return;
    closeFurnitureSubmenu();

    const sub = node("div", "wg-submenu furniture-submenu");
    for (const entry of entries) sub.append(furnitureMenuRow(entry));
    sub.addEventListener("mousedown", (e) => e.stopPropagation());
    sub.addEventListener("mouseenter", () => {
      clearTimeout(furnitureSubTimer);
      furnitureSubTimer = 0;
    });
    sub.addEventListener("mouseleave", scheduleClose);

    document.body.append(sub);
    furnitureSubNode = sub;
    furnitureSubParent = row;
    row.classList.add("is-open");
    placeFurnitureSubmenu(sub, row);
  };

  function scheduleClose() {
    clearTimeout(furnitureSubTimer);
    furnitureSubTimer = setTimeout(closeFurnitureSubmenu, 160);
  }

  row.addEventListener("mouseenter", open);
  row.addEventListener("mouseleave", scheduleClose);
  row.addEventListener("click", (e) => {
    e.stopPropagation();
    if (furnitureSubParent === row) closeFurnitureSubmenu();
    else open();
  });
  return row;
}

/** A slider row, the same control the widget menu's Width row uses. The thumb
 *  previews live and the value is written once on release: a storage round trip
 *  per pixel of travel would be hundreds of writes and a full repaint behind
 *  each one. */
function furnitureSlider(label, { min, max, step, value, format, onInput, onCommit }) {
  const row = node("div", "wg-menu-slider");
  const head = node("div", "wg-menu-slider-head");
  head.append(node("span", "wg-menu-item-label", label));
  const readout = node("span", "wg-menu-value", format(value));
  head.append(readout);
  const input = node("input", "wg-menu-range");
  input.type = "range";
  input.min = String(min);
  input.max = String(max);
  input.step = String(step ?? 1);
  input.value = String(value);
  input.setAttribute("aria-label", label);
  input.addEventListener("input", () => {
    readout.textContent = format(Number(input.value));
    onInput(Number(input.value));
  });
  input.addEventListener("change", () => onCommit(Number(input.value)));
  // The menu's dismissal listener is on `pointerdown` capture and would read a
  // press on the track as a click outside, so the press is stopped here.
  input.addEventListener("mousedown", (e) => e.stopPropagation());
  input.addEventListener("click", (e) => e.stopPropagation());
  row.append(head, input);
  return row;
}

async function openFurnitureMenu(name, event) {
  const anchorNode = event.currentTarget;
  // `isConnected` rather than a bare `furnitureMenuOpen === name`: if anything
  // else took the node out of the document (a repaint, or devtools), the state
  // would still say a menu is open and this press would close a menu that is no
  // longer there — one dead right-click before the next one works.
  const wasOpen = furnitureMenuOpen === name && furnitureMenuNode?.isConnected;
  closeFurnitureMenu();
  if (wasOpen) return;

  const menu = node("div", "wg-menu furniture-menu");
  const settings = await PageSettings.get();

  if (name === "search") {
    menu.append(node("div", "wg-menu-head", "Search"));
    // The engine is what changes where a query goes, so it leads.
    const engines = furnitureRadio(
      PageSettings.SEARCH_ENGINES.map((e) => ({ id: e.id, label: e.label })),
      settings.engine,
      (option) => PageSettings.set({ engine: option.id }).then(() => applySettings()),
    );
    for (const row of engines) menu.append(furnitureMenuRow(row));

    menu.append(node("div", "wg-menu-sep"));
    const width = Number(settings.searchWidth);
    const sized = Number.isFinite(width) && width > 0;
    menu.append(
      furnitureSlider("Width", {
        min: PageSettings.SEARCH_WIDTH_MIN,
        max: PageSettings.SEARCH_WIDTH_MAX,
        step: 10,
        value: sized ? width : 520,
        format: (v) => `${Math.round(v)}px`,
        onInput: (v) => setSearchWidthStyle(v),
        onCommit: async (v) => {
          await PageSettings.setSearchWidth(v);
          await applySettings();
        },
      }),
    );
    menu.append(
      furnitureMenuRow({
        label: "Fit to content",
        active: !sized,
        onSelect: () => PageSettings.setSearchWidth(null).then(() => applySettings()),
      }),
    );
    // Same rule as the panel's reset buttons: a row with nothing to undo is a
    // dead control, so it is only offered once the box has been moved.
    if (settings.searchX != null && settings.searchY != null) {
      menu.append(
        furnitureMenuRow({
          label: "Reset position",
          onSelect: () => PageSettings.setSearchPosition(null, null).then(() => applySettings()),
        }),
      );
    }
    menu.append(node("div", "wg-menu-sep"));
    menu.append(
      furnitureMenuRow({
        label: "Search bangs…",
        onSelect: () => window.ixiNewtabBangs.open(),
      }),
    );
    menu.append(
      furnitureMenuRow({
        label: "Search settings…",
        onSelect: () => PagePanel.openSection("Search engine"),
      }),
    );
    menu.append(
      furnitureMenuRow({
        label: "Hide search bar",
        onSelect: () => PageSettings.setWidgetVisible("search", false).then(() => applySettings()),
      }),
    );
  } else {
    menu.append(node("div", "wg-menu-head", "Clock"));
    menu.append(
      furnitureMenuRow({
        active: settings.clock24 !== false,
        label: "24-hour",
        onSelect: () => PageSettings.set({ clock24: settings.clock24 === false }).then(() => applySettings()),
      }),
    );

    menu.append(node("div", "wg-menu-sep"));
    const currentFace = PageSettings.clockFontById(settings.clockFont);
    menu.append(
      furnitureSubmenuRow({
        label: "Face",
        detail: currentFace.label,
        entries: furnitureRadio(
          PageSettings.CLOCK_FONTS.map((f) => ({ id: f.id, label: f.label })),
          currentFace.id,
          (option) => PageSettings.set({ clockFont: option.id }).then(() => applySettings()),
        ),
      }),
    );

    menu.append(node("div", "wg-menu-sep"));
    menu.append(
      furnitureSlider("Size", {
        min: PageSettings.CLOCK_SIZE_MIN,
        max: PageSettings.CLOCK_SIZE_MAX,
        step: 2,
        value: Number(settings.clockSize) || 68,
        format: (v) => `${Math.round(v)}px`,
        // Live on the digits themselves, the way the panel's slider is: a size
        // you cannot see while dragging is a size you have to guess at.
        onInput: (v) => {
          const time = document.getElementById("clock-time");
          if (time) time.style.fontSize = `${v}px`;
        },
        onCommit: async (v) => {
          await PageSettings.setClockSize(v);
          await applySettings();
        },
      }),
    );

    if (settings.clockX != null && settings.clockY != null) {
      menu.append(
        furnitureMenuRow({
          label: "Reset position",
          onSelect: () => PageSettings.setClockPosition(null, null).then(() => applySettings()),
        }),
      );
    }
    menu.append(node("div", "wg-menu-sep"));
    menu.append(
      furnitureMenuRow({
        label: "Clock settings…",
        onSelect: () => PagePanel.openSection("Clock"),
      }),
    );
    menu.append(
      furnitureMenuRow({
        label: "Hide clock",
        onSelect: () => PageSettings.setWidgetVisible("clock", false).then(() => applySettings()),
      }),
    );
  }

  document.body.append(menu);
  // Positioned at the pointer, then pulled inside the viewport if that would
  // push it off an edge — the same clamp both other menus use.
  const left = Math.min(Math.max(6, event.clientX), Math.max(6, window.innerWidth - menu.offsetWidth - 6));
  const top = Math.min(Math.max(6, event.clientY), Math.max(6, window.innerHeight - menu.offsetHeight - 6));
  menu.style.left = `${left}px`;
  menu.style.top = `${top}px`;

  furnitureMenuNode = menu;
  furnitureMenuOpen = name;
  furnitureMenuAnchorNode = anchorNode;
  anchorNode?.setAttribute("aria-expanded", "true");
  document.addEventListener("pointerdown", onFurnitureMenuOutside, true);
  document.addEventListener("keydown", onFurnitureMenuKey, true);
  window.addEventListener("scroll", closeFurnitureMenu, true);
  window.addEventListener("resize", closeFurnitureMenu);
}

/** "Add bookmark icon" from the page's right-click menu.
 *
 *  Two acts in one: the site is saved to the bookmark list, and a shortcut icon
 *  for it is placed where the user right-clicked. The icon is the same object a
 *  site becomes when its tile is dragged out of a Shortcuts panel, so it can be
 *  selected, moved with a group, and deleted like any other. */
function openPageBookmarkPrompt() {
  // One string, parsed by the browser before any of it is live: a dialog is a
  // fixed shape, and building it row by row is a lot of statements for markup
  // that never varies. Nothing in it is user-supplied — the address goes into
  // the field's *value*, never into the HTML.
  const template = document.createElement("template");
  template.innerHTML = `
    <div class="wg-modal-scrim">
      <div class="wg-modal wg-bookmark-modal" role="dialog" aria-modal="true" aria-label="Add bookmark icon">
        <div class="wg-modal-head">
          <div class="wg-modal-title">Add bookmark icon</div>
          <button class="wg-modal-close" type="button" title="Close" aria-label="Close">×</button>
        </div>
        <div class="wg-modal-body">
          <form class="wg-bookmark-form">
            <input class="wg-search-input" type="text" placeholder="example.com" aria-label="Bookmark address">
            <button class="wg-add-save" type="submit">Add</button>
          </form>
          <div class="wg-search-status" hidden>Saved to your bookmarks and placed on the page.</div>
        </div>
      </div>
    </div>`;
  const scrim = template.content.firstElementChild;
  const dialog = scrim.firstElementChild;
  const close = dialog.querySelector(".wg-modal-close");
  const form = dialog.querySelector(".wg-bookmark-form");
  const input = dialog.querySelector(".wg-search-input");
  const save = dialog.querySelector(".wg-add-save");
  const status = dialog.querySelector(".wg-search-status");

  const key = (e) => {
    // The page's own keys (the search box's, the shortcut letters) are not
    // commands while an address is being typed.
    e.stopPropagation();
    if (e.key === "Escape") {
      e.preventDefault();
      dismiss();
    }
  };
  const onKey = (e) => {
    if (e.key === "Escape") {
      e.preventDefault();
      e.stopPropagation();
      dismiss();
    }
  };
  const dismiss = () => {
    document.removeEventListener("keydown", onKey, true);
    scrim.remove();
  };

  close.addEventListener("click", dismiss);
  scrim.addEventListener("mousedown", (e) => {
    if (e.target === scrim) dismiss();
  });
  document.addEventListener("keydown", onKey, true);
  input.addEventListener("keydown", key);
  // The press that opened this dialog is still travelling when it arrives, and
  // listeners further up the document (the page menu's own dismissal) must not
  // treat the click inside the new dialog as a click outside whatever it was
  // that opened it.
  scrim.addEventListener("pointerdown", (e) => e.stopPropagation());
  scrim.addEventListener("mousedown", (e) => e.stopPropagation());

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const raw = input.value.trim();
    const url = asUrl(raw);
    if (!url) {
      status.hidden = false;
      status.textContent = "That is not an address.";
      input.focus();
      return;
    }
    save.disabled = true;
    status.hidden = false;
    status.textContent = "Adding...";
    try {
      const placed = await addShortcutAt(url, nextBlockSpot());
      if (!placed.ok) throw new Error(shortcutFailure(placed));
      const host = PageSettings.hostOfUrl(url);
      const saved = await PageWidgets.saveBookmark({ title: host || url, url });
      await applySettings();
      PageShortcuts.select?.(placed.specId, placed.linkId);
      dismiss();
      pasteNotice(saved.ok ? `BOOKMARKED ${host}` : `PLACED ${host}`);
    } catch (err) {
      save.disabled = false;
      status.textContent = err instanceof Error ? err.message : "Could not add the bookmark.";
    }
  });

  document.body.append(scrim);
  input.focus();
  // A bare host is the common case; typing the scheme is not.
  if (!input.value) input.placeholder = "example.com";
}

/** One row of the page menu. `onSelect` may be async; the menu is closed first
 *  either way, because every command here either opens a surface that would
 *  have the menu floating over it or navigates away. */
/** What the menu last opened *for*: the pointer, and the widget whose header
 *  was right-clicked, if any.
 *
 *  Read at event time by whoever the menu hands work to, the same way
 *  `pasteSpot` is. The widget matters because a row that places a shortcut
 *  should not drop it under the panel it was invoked from. */
let pageMenuOrigin = null;

/** Where a shortcut the user just added should go: the pointer, unless the
 *  pointer is still on a panel — beside the cursor when the page is open, and
 *  in the page's own next free spot when the cursor is sitting on a panel. */
function nextBlockSpot() {
  if (!pageMenuOrigin) return null;
  const { x, y } = pageMenuOrigin;
  // The same band the paste gesture ignores: above it is the clock and the
  // search box's strip, where a block would be clamped up against the edge.
  if (y < 96) return null;
  // Off the page's right edge or below its bottom would place a block the user
  // cannot see; the panel it came from is not a place to put a new one.
  if (x > window.innerWidth - 40 || y > window.innerHeight - 40) return null;

  for (const panel of document.querySelectorAll(".wg")) {
    const r = panel.getBoundingClientRect();
    if (r.width && r.height && x >= r.left - 8 && x <= r.right + 8 && y >= r.top - 8 && y <= r.bottom + 8) {
      return null;
    }
  }
  return { x, y };
}

function pageMenuItem(label, onSelect) {
  const b = node("button", "wg-menu-item");
  b.type = "button";
  b.append(node("span", "wg-menu-item-label", label));
  b.addEventListener("click", () => {
    // The menu is closed *first*, synchronously, before the row's command runs.
    // This is not only tidiness: the page's outside-press listener is on
    // `document` in the capture phase (`onPageMenuOutside`), and the press that
    // is still travelling towards this button on the real page has already
    // reached the document — so it fires on the *next* press instead. A command
    // that opens a dialog there would put the dialog under that listener and
    // have it dismissed by the first click anywhere. Taking the menu and its
    // listeners down before the command runs means the new surface starts with
    // a clean document to listen on.
    closePageMenu();
    onSelect();
  });
  return b;
}

/** The "Check for update" row, which reports in place rather than opening
 *  anything.
 *
 *  It carries its own result line because there is nowhere else on this page to
 *  put one — the popup has an Update panel, and sending the user there to read
 *  an answer they asked for here would be a worse trade than a line of text.
 *  The check itself is `update.js`, the same module the popup's panel uses, so
 *  the two can never disagree about whether a new build exists. */
function pageMenuUpdateItem() {
  // A wrapper, not the button alone. The note has to sit *beside* the row, and
  // `insertAdjacentElement` on a detached button is a no-op — the node it
  // creates goes nowhere and the result of the check is written into an element
  // no one can see. Returning the pair as one node is what removes the ordering
  // hazard: the rows are appended to the menu after this returns, so anything
  // built around the button has to travel with it.
  const wrap = node("div", "wg-menu-group");
  const b = node("button", "wg-menu-item");
  b.type = "button";
  const label = node("span", "wg-menu-item-label", "Check for update");
  b.append(label);
  const note = node("div", "wg-menu-note");
  wrap.append(b, note);

  b.addEventListener("click", async () => {
    // Not closed on click, unlike the other rows: the answer appears here, and
    // a menu that vanished on the press would take the answer with it.
    label.textContent = "Checking...";
    note.textContent = "";
    note.className = "wg-menu-note";
    try {
      const result = await window.ixiUpdate.check({ siteUrl: PageAuth.SITE_ORIGIN });
      if (!result.published) {
        label.textContent = "Check for update";
        note.textContent = result.failure ?? "Could not read the published version.";
        note.classList.add("is-error");
        return;
      }
      const newer = window.ixiUpdate.compareVersions(result.published, result.installed) > 0;
      label.textContent = "Check for update";
      if (newer) {
        note.textContent = `Update available — ${result.installed} → ${result.published}. Install it from the extension popup.`;
        note.classList.add("is-ok");
      } else {
        note.textContent = "You're on the latest version :)";
        note.classList.add("is-ok");
      }
      // The menu grew taller under the pointer; the clamp that positioned it
      // ran before this line existed. Re-pinned to the same corner rather than
      // left to hang off the bottom edge on a short window.
      repinPageMenu();
    } catch (err) {
      label.textContent = "Check for update";
      note.textContent = err instanceof Error ? err.message : "Could not check for updates.";
      note.classList.add("is-error");
      repinPageMenu();
    }
  });
  return wrap;
}

/** Keep the menu inside the viewport after its own contents grew. */
let pageMenuAnchor = null;

function repinPageMenu() {
  if (!pageMenuNode || !pageMenuAnchor) return;
  const { x, y } = pageMenuAnchor;
  const left = Math.min(Math.max(6, x), Math.max(6, window.innerWidth - pageMenuNode.offsetWidth - 6));
  const top = Math.min(Math.max(6, y), Math.max(6, window.innerHeight - pageMenuNode.offsetHeight - 6));
  pageMenuNode.style.left = `${left}px`;
  pageMenuNode.style.top = `${top}px`;
}

function openPageMenu(event) {
  const wasOpen = pageMenuNode != null;
  closePageMenu();
  if (wasOpen) return;

  const menu = node("div", "wg-menu page-menu");
  menu.append(node("div", "wg-menu-head", "New tab"));
  menu.append(
    pageMenuItem("Open settings", () => PagePanel.open()),
    pageMenuItem("Widgets", () => PagePanel.openSection("Widgets")),
    pageMenuItem("Add bookmark icon", () => openPageBookmarkPrompt()),
    pageMenuUpdateItem(),
  );
  document.body.append(menu);
  pageMenuNode = menu;

  pageMenuAnchor = { x: event.clientX, y: event.clientY };
  pageMenuOrigin = {
    x: event.clientX,
    y: event.clientY,
    widgetId: event.target instanceof Element ? event.target.closest(".wg")?.dataset.id ?? null : null,
  };
  repinPageMenu();

  document.addEventListener("pointerdown", onPageMenuOutside, true);
  document.addEventListener("keydown", onPageMenuKey, true);
  window.addEventListener("scroll", closePageMenu, true);
  window.addEventListener("resize", closePageMenu);
}

window.addEventListener("contextmenu", (event) => {
  // A widget, a decoration or a bookmark row already claimed this — see the
  // note above. `defaultPrevented` is the only signal available, since those
  // handlers run on nodes this listener never sees.
  if (event.defaultPrevented) return;
  const el = event.target instanceof Element ? event.target : null;
  if (!el) return;
  if (el.closest(".wg-menu, .wg-modal-scrim")) return;
  if (el.closest("input, textarea, select, [contenteditable]")) return;

  event.preventDefault();
  openPageMenu(event);
});

// The search box and the clock get their own menus, on the same terms as a
// widget. Bound to the elements rather than to `window`, so the page menu's
// blanket listener above never sees them and the two cannot both open.
//
// The search box's listener sits on the form, but a right-click in the *field*
// is left alone: that is a request for the browser's own text menu (copy,
// paste, spell-check), and replacing it with this page's menu would take those
// away from the one place on the page that has a caret.
form.addEventListener("contextmenu", (event) => {
  if (event.target === input) return;
  if (event.target instanceof Element && event.target.closest(".search-bang")) return;
  event.preventDefault();
  event.stopPropagation();
  openFurnitureMenu("search", event);
});

const clockBlock = document.getElementById("clock-block");
if (clockBlock) {
  clockBlock.addEventListener("contextmenu", (event) => {
    // The resize grip is a control, like the bang button: it resizes the clock
    // and has no menu of its own to offer.
    if (event.target instanceof Element && event.target.closest(".clock-resize")) return;
    event.preventDefault();
    event.stopPropagation();
    openFurnitureMenu("clock", event);
  });
}

// ── the account mirror ────────────────────────────────────────────────────
// A pull can replace the whole settings blob under the page (see settings.js),
// after the first paint has already run against whatever local storage held.
// This is what redraws the page when that happens — without it, the account's
// layout would land in the store and never reach the screen.
PageSettings.subscribe(() => {
  applySettings();
  PagePanel.paint();
});

// ── signing in from here ──────────────────────────────────────────────────
// The account widgets say "Sign in from the extension" when there is no
// session, but the popup is two clicks away and easy to miss. This quietly
// repaints the widgets once a session appears, so a login in the popup reaches
// an already-open new tab without a reload.

PageAuth.readToken().then((token) => {
  if (token) return;
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "local" && changes.ixiSession?.newValue) {
      // The session is what makes the account copy reachable, so this is the
      // moment to fetch it — and to send any change made while signed out, which
      // had nowhere to go. The pull runs first so a fresh sign-in on a new
      // machine adopts the account's layout rather than overwriting it with
      // this profile's defaults.
      PageSettings.hydrateFromAccount()
        .then(() => PageSettings.flushRemotePush())
        .catch(() => {});
      PageWidgets.refreshWidgetData();
      PageWidgets.paintWidgetBodies();
    }
  });
});

// ── boot: handing the tab back ────────────────────────────────────────────
// The switch that turns the new tab page off lives in the popup, which writes
// `ixiNewtabOff`. Chrome will not let an extension detach
// `chrome_url_overrides.newtab`, so this page is still what a new tab opens —
// "off" is therefore this file's decision to hand the tab straight back to the
// browser's own new tab and paint nothing at all.
//
// How the hand-back is done was measured, not assumed, because the obvious way
// does not work: `window.location.replace("chrome://new-tab-page")` returns
// normally, throws nothing, and goes nowhere — Chrome silently ignores a
// script-driven navigation to `chrome://` from an extension page. `chrome.tabs`
// is not ignored, and creating and closing a tab needs no extra permission. So
// the hand-back opens the browser's new tab and then closes this one, which has
// the side benefit of leaving no extension-page entry underneath for Back to
// bounce onto.
//
// Two URLs, tried in order. The first is Chrome's own new tab; the second is the
// pre-2024 spelling of the same page, kept because Chrome removed the original in
// March 2024 while other Chromium browsers did not — and those refuse the
// replacement. Whichever answers, the tab ends up on the browser's page.
//
// `NEWTAB_OFF_KEY` must stay equal to the same literal in `tools.js`: the popup
// writes it, this reads it, and neither file loads the other.
const NEWTAB_OFF_KEY = "ixiNewtabOff";
const BROWSER_NEW_TAB = ["chrome://new-tab-page", "chrome-search://local-ntp/local-ntp.html"];

/** How long to stay dark before deciding the hand-back did not take. Only the
 *  failure path ever reaches this timer — opening the replacement tab and
 *  closing this one destroys this document first — so it is short enough that a
 *  tab which does stay put is not blank for longer than a flicker. */
const NEWTAB_HANDBACK_GRACE_MS = 400;

/** Whether the popup's switch has the new tab page off. */
async function newtabIsOff() {
  try {
    return (await chrome.storage.local.get(NEWTAB_OFF_KEY))[NEWTAB_OFF_KEY] === true;
  } catch {
    // Storage unreadable. `tools.js` answers the same question the same way, so
    // the two cannot disagree about what "on" means.
    return false;
  }
}

/** Send this tab to the browser's own new tab.
 *
 *  Resolves true once the replacement tab exists and this one is on its way out,
 *  false when no candidate could be opened, which is the caller's signal to
 *  paint this page after all.
 *
 *  The replacement opens at this tab's index so the new tab lands where the
 *  user's tab was rather than at the far right of the strip. The `tabs`
 *  permission is not needed for any of this: `getCurrent` and `create` work
 *  without it, and `remove` is scoped to the caller's own tab. */
async function handBackToBrowser() {
  let tab;
  try {
    tab = await chrome.tabs.getCurrent();
  } catch {
    return false;
  }
  if (!tab) return false;

  let opened = null;
  for (const url of BROWSER_NEW_TAB) {
    try {
      opened = await chrome.tabs.create({ url, active: true, index: tab.index });
      break;
    } catch {
      /* try the next spelling of the same page */
    }
  }
  // Order matters: closing this tab tears down this document, so everything
  // else has to happen first. The close is deliberately not awaited — its
  // promise may never settle, because the promise's own context is the tab
  // going away — and a close that fails is survivable rather than fatal: the
  // browser's new tab is already open and in front, and this document being
  // still alive is exactly what the caller's grace timer treats as "paint
  // me again", so the worst case is the old page reappearing behind the new
  // tab rather than a blank one.
  if (!opened) return false;
  chrome.tabs.remove(tab.id).catch(() => {});
  return true;
}

// Bound before the first `applySettings`, so a device switch during boot is
// caught too — the callback re-reads settings and is a no-op when the choice
// is an explicit one.
watchSystemTheme();

(async () => {
  if (!(await newtabIsOff())) {
    applySettings();
    return;
  }
  if (!(await handBackToBrowser())) {
    applySettings();
    return;
  }
  // A hand-back that took leaves this document destroyed along with its tab, so
  // reaching this timer at all means something went wrong — the close was
  // refused, or the tab could not be opened. Painting a beat later is then the
  // only way to leave the user with a usable new tab instead of a blank one.
  setTimeout(applySettings, NEWTAB_HANDBACK_GRACE_MS);
})();

// A widget dragged past the right edge stays reachable after the window
// narrows, and the cascade has to be recomputed when the viewport changes
// width — so the layout is re-clamped on resize rather than left to overflow.
let resizeTimer = null;
window.addEventListener("resize", () => {
  clearTimeout(resizeTimer);
  resizeTimer = setTimeout(async () => {
    PageWidgets.renderWidgets();
    PageDecor.reclamp();
    // A free search box or clock can end up off the right or bottom edge when
    // the window narrows. Re-clamped rather than left to overflow, but *not*
    // written back: a resize is not a decision the user made, so the stored
    // position stays where they put it and the element returns there when the
    // window grows again.
    const settings = await PageSettings.get();
    placeSearch(settings);
    placeClock(settings);
  }, 150);
});
