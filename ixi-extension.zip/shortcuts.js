// Floating shortcuts: the pinned sites that live on the page itself rather
// than inside a panel.
//
// A shortcut link carries `x`/`y` once it has been taken out of its panel, and
// this file is what draws those. The panel keeps every link *without* a
// placement, so the two views never show the same site twice — dropping a tile
// on the page moves it from one to the other, and "Return to panel" moves it
// back.
//
// Three gestures live here, all built on the same idiom as the widget drag in
// `widgets.js`: pointer events, a 4px slop before a press becomes a drag,
// deferred pointer capture (so a press that never moves still delivers its
// click to the link), window listeners, and one storage write on release.
//
//   * drag one icon, or a whole selection of them, across the page
//   * drag a band across the empty background to select several
//   * Escape clears the selection, Delete removes it
//
// Everything at the top level is `sc`-prefixed. These are classic scripts
// sharing one global lexical scope: a bare `const` here would be a
// redeclaration the moment it collided with a name in another file.

const SC_SAFE = window.ixiNewtabSettings;

/** The same slop the widget and decor drags use. Below it a press is a click;
 *  above it, a drag that must not also navigate. */
const SC_DRAG_SLOP = 4;

/** Every placed icon on the page, by `scKey`. Rebuilt by `scRender`. */
const scNodes = new Map();

/** The selected keys. A `Set` of `specId::linkId` rather than of elements, so a
 *  repaint does not lose the selection to a discarded node. */
let scSelection = new Set();

/** True while a marquee or a drag is running. The page's Space-to-search
 *  shortcut reads this — a space pressed mid-gesture belongs to the gesture. */
let scGesture = false;

let scMenuNode = null;

function scKey(specId, linkId) {
  return `${specId}::${linkId}`;
}

function scLayer() {
  return document.getElementById("shortcut-layer");
}

/** The page's own empty background. `.widgets`, `.decor-layer` and
 *  `#shortcut-layer` are all `pointer-events: none` with their children
 *  re-enabling it, so a press in the gaps between things lands on `<body>` —
 *  which is the one test that separates "the user grabbed the page" from "the
 *  user grabbed something on it". */
function scOnEmptyBackground(event) {
  const target = event.target;
  return target === document.body || target === document.documentElement;
}

// ── icons ─────────────────────────────────────────────────────────────────

/** Chrome's own favicon service, which needs no host permission beyond the
 *  `favicon` entry in the manifest. `null` when the API is missing, so a page
 *  opened outside the extension falls through the chain instead of throwing. */
function scFaviconServiceUrl(pageUrl) {
  try {
    if (!chrome?.runtime?.getURL) return null;
    return chrome.runtime.getURL(`_favicon/?pageUrl=${encodeURIComponent(pageUrl)}&size=64`);
  } catch {
    return null;
  }
}

/** The image sources for one shortcut, in the order they are tried.
 *
 *  An upload is the user's own picture and comes first. `favicon` and `auto`
 *  differ only in which site icon is tried: Chrome's service, which knows about
 *  the icons a site declares in its markup, or the `/favicon.ico` guess the
 *  page made before any of this existed. Both fall through to the other and
 *  then to the host's first letter, so a site that has no icon still draws
 *  something recognisable. */
function scIconSources(link) {
  const host = SC_SAFE.hostOfUrl(link.url);
  const icon = link.icon;
  const list = [];
  if (icon?.mode === "upload" && icon.src) list.push(icon.src);
  if (icon?.mode === "favicon") {
    const service = scFaviconServiceUrl(SC_SAFE.shortcutHref(link.url));
    if (service) list.push(service);
  }
  if (host) list.push(`https://${host}/favicon.ico`);
  return { list, host };
}

/** One shortcut's icon box: the first source that loads, else the host's first
 *  letter. Shared by the panel's tiles and the page's icons, so a site cannot
 *  look like two different things depending on where it is drawn.
 *
 *  The size is written inline because the two callers set it from different
 *  places — the tile from its own variant, the page icon from the fixed 40px —
 *  and an inline size is the one thing both agree on. */
function scIconEl(link, size = 40, className = "sc-icon") {
  const box = document.createElement("span");
  box.className = className;
  box.style.width = `${size}px`;
  box.style.height = `${size}px`;
  // The tile's own class carries the rules for an image inside an icon box, so
  // the page's icons inherit exactly what the panel's tiles wear.
  box.classList.add("wg-tile-icon");

  // A chosen picture from the bundled set short-circuits the source chain: it
  // is the user's explicit answer, so it does not fall through to the favicon
  // if it fails to draw — there is nothing for it to fail at, the markup ships
  // with the page.
  const chosen = link.icon?.mode === "set" ? SC_SAFE.SHORTCUT_ICON_GLYPHS[link.icon.name] : null;
  if (chosen) {
    box.classList.add("wg-tile-set-icon");
    box.innerHTML =
      `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" ` +
      `stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${chosen}</svg>`;
    return box;
  }

  const { list, host } = scIconSources(link);
  const letter = () => {
    box.textContent = (host.match(/[a-z0-9]/i) || ["?"])[0].toUpperCase();
  };

  let index = 0;
  const attempt = () => {
    if (index >= list.length) {
      letter();
      return;
    }
    const src = list[index++];
    const img = document.createElement("img");
    img.className = "wg-tile-favicon";
    img.alt = "";
    img.loading = "lazy";
    img.referrerPolicy = "no-referrer";
    img.addEventListener("error", () => {
      img.remove();
      attempt();
    });
    img.src = src;
    box.append(img);
  };
  attempt();
  return box;
}

// ── painting the layer ────────────────────────────────────────────────────

/** Clamp a placed icon into the viewport. Not written back: a window that was
 *  narrow for a moment must not permanently move the user's icons, and the
 *  stored position brings them back when there is room again — the same rule
 *  `placeSearch` follows. */
function scClamp(x, y, width, height) {
  const maxX = Math.max(0, window.innerWidth - width);
  const maxY = Math.max(0, window.innerHeight - height);
  return {
    x: Math.min(Math.max(0, x), maxX),
    y: Math.min(Math.max(0, y), maxY),
  };
}

function scBuildIcon(spec, link) {
  const a = document.createElement("a");
  a.className = "sc";
  a.href = SC_SAFE.shortcutHref(link.url);
  a.title = link.label;
  a.dataset.scKey = scKey(spec.id, link.id);
  // The pointer drag owns the gesture; the browser's own link drag would fight
  // it on the first move.
  a.draggable = false;
  a.style.left = `${link.x}px`;
  a.style.top = `${link.y}px`;
  const label = document.createElement("span");
  label.className = "sc-label";
  label.textContent = link.label;
  a.append(scIconEl(link, 40), label);
  a.addEventListener("pointerdown", (e) => scIconPointerDown(e, spec, link, a));
  a.addEventListener("contextmenu", (e) => {
    e.preventDefault();
    e.stopPropagation();
    scOpenMenu(e, spec, link);
  });
  return a;
}

async function scRender(settings) {
  const host = scLayer();
  if (!host) return;
  const all = settings ?? (await SC_SAFE.get());

  scNodes.clear();
  const nodes = [];
  for (const spec of all.widgets) {
    if (SC_SAFE.widgetKindOf(spec) !== "shortcuts") continue;
    const links = Array.isArray(spec.data?.links) ? spec.data.links : [];
    for (const link of links) {
      if (link.x == null || link.y == null) continue;
      const el = scBuildIcon(spec, link);
      scNodes.set(scKey(spec.id, link.id), { el, spec, link });
      nodes.push(el);
    }
  }
  host.replaceChildren(...nodes);

  // Measured after the nodes are in the document, because a detached element
  // reports a zero-sized rect and every clamp would then be a no-op.
  for (const { el } of scNodes.values()) {
    const rect = el.getBoundingClientRect();
    const spot = scClamp(parseFloat(el.style.left) || 0, parseFloat(el.style.top) || 0, rect.width, rect.height);
    el.style.left = `${spot.x}px`;
    el.style.top = `${spot.y}px`;
  }

  // A selection outlives a repaint only while the icons it names still exist.
  for (const key of [...scSelection]) {
    if (!scNodes.has(key)) scSelection.delete(key);
  }
  scPaintSelection();
}

function scPaintSelection() {
  for (const [key, { el }] of scNodes) {
    el.classList.toggle("is-selected", scSelection.has(key));
  }
}

function scClearSelection() {
  if (!scSelection.size) return;
  scSelection = new Set();
  scPaintSelection();
}

function scToggleSelection(key) {
  if (scSelection.has(key)) scSelection.delete(key);
  else scSelection.add(key);
  scPaintSelection();
}

function scSelectOnly(specId, linkId) {
  const key = scKey(specId, linkId);
  scSelection = scNodes.has(key) ? new Set([key]) : new Set();
  scPaintSelection();
}

/** Redraw both halves of a shortcut change: the page's icons and the panels'
 *  grids. Targeted at the shortcuts panels rather than at every widget, so a
 *  drag does not tear down and rebuild the bookmarks and timers as well. */
async function scAfterWrite(settings) {
  const all = settings ?? (await SC_SAFE.get());
  await scRender(all);
  for (const spec of all.widgets) {
    if (SC_SAFE.widgetKindOf(spec) === "shortcuts") window.ixiNewtabWidgets?.repaintShortcutsWidget?.(spec);
  }
}

// ── dragging one icon, or the whole selection ─────────────────────────────

/** Swallow the click that trails a drag. The press half is stopped in the
 *  gesture itself, but a click still arrives after the release; without this a
 *  drag would end by opening the link. Gives up after a moment in case no click
 *  follows. */
function scSuppressClick() {
  const swallow = (e) => {
    e.preventDefault();
    e.stopPropagation();
    window.removeEventListener("click", swallow, true);
  };
  window.addEventListener("click", swallow, true);
  setTimeout(() => window.removeEventListener("click", swallow, true), 400);
}

function scIconPointerDown(event, spec, link, el) {
  if (event.button !== 0) return;
  const key = scKey(spec.id, link.id);

  // A modifier press adds to or removes from the selection without starting a
  // drag, which is the only way to pick a scattered few without a band.
  if (event.shiftKey || event.metaKey || event.ctrlKey) {
    event.preventDefault();
    event.stopPropagation();
    scToggleSelection(key);
    return;
  }

  event.preventDefault();
  event.stopPropagation();

  // Pressing inside an existing multi-selection moves all of it; pressing
  // anything else makes that icon the selection. Both are what a user means by
  // grabbing a group versus grabbing one thing.
  const bulk = scSelection.has(key) && scSelection.size > 1;
  if (!bulk) {
    scSelection = new Set([key]);
    scPaintSelection();
  }
  const group = bulk ? [...scSelection] : [key];

  // Read once: the icons do not move relative to each other during a gesture,
  // and measuring per frame would make the group lag the pointer.
  const moves = group
    .map((k) => scNodes.get(k))
    .filter(Boolean)
    .map(({ el: iconEl, spec: iconSpec, link: iconLink }) => {
      const rect = iconEl.getBoundingClientRect();
      return {
        el: iconEl,
        spec: iconSpec,
        link: iconLink,
        left: rect.left,
        top: rect.top,
        width: rect.width,
        height: rect.height,
      };
    })
    .filter((m) => m.spec && m.link);

  const startX = event.clientX;
  const startY = event.clientY;
  let dragging = false;

  const move = (e) => {
    if (!dragging) {
      if (Math.hypot(e.clientX - startX, e.clientY - startY) < SC_DRAG_SLOP) return;
      dragging = true;
      scGesture = true;
      for (const m of moves) m.el.classList.add("is-dragging");
      // Deferred to here for the same reason `startDrag` defers it: capture
      // retargets the trailing click, and a press that never moved has to stay
      // a click on the link.
      try {
        el.setPointerCapture(event.pointerId);
      } catch {
        /* tracking still works while the pointer is over the icons */
      }
    }
    const dx = e.clientX - startX;
    const dy = e.clientY - startY;
    for (const m of moves) {
      const spot = scClamp(m.left + dx, m.top + dy, m.width, m.height);
      m.el.style.left = `${spot.x}px`;
      m.el.style.top = `${spot.y}px`;
    }
  };

  const up = async () => {
    window.removeEventListener("pointermove", move);
    window.removeEventListener("pointerup", up);
    window.removeEventListener("pointercancel", up);
    if (!dragging) return; // a click, and the link is about to follow it
    scGesture = false;
    scSuppressClick();
    for (const m of moves) m.el.classList.remove("is-dragging");

    // One write per icon, on release. Sequential on purpose: each is a
    // read-modify-write of the same `widgets` array, so firing them together
    // would let the last one read a list the others have not finished writing.
    let next = null;
    for (const m of moves) {
      const rect = m.el.getBoundingClientRect();
      next = await SC_SAFE.setShortcutPlacement(m.spec.id, m.link.id, rect.left, rect.top);
    }
    await scAfterWrite(next);
  };

  window.addEventListener("pointermove", move);
  window.addEventListener("pointerup", up);
  window.addEventListener("pointercancel", up);
}

// ── the marquee ───────────────────────────────────────────────────────────

/** A band across the empty background selects every icon it touches.
 *
 *  The listener is on `document` in the *bubble* phase, not capture. Every
 *  surface that could own the press — a widget header, a decor piece, the
 *  settings panel — runs its own handler first and can claim the event, and by
 *  the time this sees it `defaultPrevented` says so. On top of that the target
 *  has to *be* the body: the layers are pointer-events-none, so an empty press
 *  is the only one that reaches here at all. */
function scBackgroundPointerDown(event) {
  if (event.button !== 0) return;
  if (event.defaultPrevented) return;
  if (!scOnEmptyBackground(event)) return;
  if (scOverlayOpen()) return;

  // Stops the browser starting a text selection across the page as the band is
  // dragged. The click that follows a press-and-release still arrives, which is
  // what lets a plain empty click clear the selection below.
  event.preventDefault();

  const startX = event.clientX;
  const startY = event.clientY;
  // Shift keeps what was already selected, the same modifier the icons use.
  const base = event.shiftKey ? new Set(scSelection) : new Set();
  let band = null;

  const move = (e) => {
    if (!band) {
      if (Math.hypot(e.clientX - startX, e.clientY - startY) < SC_DRAG_SLOP) return;
      band = document.createElement("div");
      band.className = "sc-marquee";
      (scLayer() ?? document.body).append(band);
      scGesture = true;
    }
    const left = Math.min(startX, e.clientX);
    const top = Math.min(startY, e.clientY);
    const width = Math.abs(e.clientX - startX);
    const height = Math.abs(e.clientY - startY);
    band.style.left = `${left}px`;
    band.style.top = `${top}px`;
    band.style.width = `${width}px`;
    band.style.height = `${height}px`;

    const next = new Set(base);
    for (const [key, { el }] of scNodes) {
      const r = el.getBoundingClientRect();
      // Intersection, not containment: a band that catches the corner of an
      // icon selects it, which is what a marquee means everywhere else.
      if (r.left < left + width && r.right > left && r.top < top + height && r.bottom > top) {
        next.add(key);
      }
    }
    scSelection = next;
    scPaintSelection();
  };

  const up = () => {
    window.removeEventListener("pointermove", move);
    window.removeEventListener("pointerup", up);
    window.removeEventListener("pointercancel", up);
    if (!band) {
      // A press that never became a band is a click on the empty page, and the
      // empty page is where a selection is put down.
      scClearSelection();
      return;
    }
    scGesture = false;
    band.remove();
    band = null;
  };

  window.addEventListener("pointermove", move);
  window.addEventListener("pointerup", up);
  window.addEventListener("pointercancel", up);
}

// ── keyboard ──────────────────────────────────────────────────────────────

/** Any surface that owns Escape while it is open. The settings panel's own
 *  document handler closes it unconditionally, and a menu or a modal is a
 *  smaller thing in front of it — so a selection must not eat the key those
 *  are waiting for. */
function scOverlayOpen() {
  if (scMenuNode) return true;
  if (document.querySelector(".wg-modal-scrim")) return true;
  const panel = document.getElementById("settings-panel");
  return Boolean(panel && !panel.classList.contains("hidden"));
}

function scInField(target) {
  if (!(target instanceof Element)) return false;
  if (target.closest("input, textarea, select")) return true;
  return target.isContentEditable || Boolean(target.closest("[contenteditable='']"));
}

function scKeyDown(event) {
  if (event.key === "Escape") {
    if (!scSelection.size) return;
    if (scOverlayOpen()) return;
    // Capture plus `stopPropagation`: `panel.js` listens for Escape on the
    // document and would close the settings panel as well. The selection is the
    // nearer thing, so it takes the key.
    event.preventDefault();
    event.stopPropagation();
    scClearSelection();
    return;
  }
  if (event.key !== "Delete" && event.key !== "Backspace") return;
  if (!scSelection.size) return;
  if (scOverlayOpen()) return;
  if (scInField(event.target)) return;
  event.preventDefault();
  event.stopPropagation();
  scDeleteSelection();
}

async function scDeleteSelection() {
  // Grouped by panel, because `removeShortcuts` is one write per panel and a
  // selection can span several of them.
  const bySpec = new Map();
  for (const key of scSelection) {
    const entry = scNodes.get(key);
    if (!entry) continue;
    if (!bySpec.has(entry.spec.id)) bySpec.set(entry.spec.id, []);
    bySpec.get(entry.spec.id).push(entry.link.id);
  }
  if (!bySpec.size) return;
  scSelection = new Set();
  let next = null;
  for (const [specId, ids] of bySpec) next = await SC_SAFE.removeShortcuts(specId, ids);
  await scAfterWrite(next);
}

// ── the per-icon menu ─────────────────────────────────────────────────────

function scCloseMenu() {
  if (!scMenuNode) return;
  scMenuNode.remove();
  scMenuNode = null;
  document.removeEventListener("pointerdown", scOnMenuOutside, true);
  document.removeEventListener("keydown", scOnMenuKey, true);
  window.removeEventListener("scroll", scCloseMenu, true);
  window.removeEventListener("resize", scCloseMenu);
}

function scOnMenuOutside(e) {
  if (scMenuNode && !scMenuNode.contains(e.target)) scCloseMenu();
}

function scOnMenuKey(e) {
  if (e.key !== "Escape") return;
  // As in `widgets.js`: stopped so the settings panel behind the menu does not
  // close on the same key.
  e.stopPropagation();
  scCloseMenu();
}

function scMenuItem(menu, label, onSelect, danger = false) {
  const b = document.createElement("button");
  b.type = "button";
  b.className = danger ? "wg-menu-item is-danger" : "wg-menu-item";
  const span = document.createElement("span");
  span.className = "wg-menu-item-label";
  span.textContent = label;
  b.append(span);
  b.addEventListener("click", () => {
    scCloseMenu();
    onSelect();
  });
  menu.append(b);
}

function scOpenMenu(event, spec, link) {
  const wasOpen = scMenuNode != null;
  scCloseMenu();
  if (wasOpen) return;

  const menu = document.createElement("div");
  menu.className = "wg-menu sc-menu";

  scMenuItem(menu, "Edit site...", async () => {
    const settings = await SC_SAFE.get();
    const live = settings.widgets.find((w) => w.id === spec.id);
    const index = (live?.data?.links ?? []).findIndex((l) => l.id === link.id);
    window.ixiNewtabWidgets?.openShortcutModal?.(spec, { index, link });
  });
  scMenuItem(menu, "Icon...", () => scOpenIconEditor(spec, link));
  scMenuItem(menu, "Return to panel", async () => {
    const next = await SC_SAFE.setShortcutPlacement(spec.id, link.id, null, null);
    scSelection.delete(scKey(spec.id, link.id));
    await scAfterWrite(next);
  });
  scMenuItem(
    menu,
    "Remove",
    async () => {
      const next = await SC_SAFE.removeShortcuts(spec.id, [link.id]);
      scSelection.delete(scKey(spec.id, link.id));
      await scAfterWrite(next);
    },
    true,
  );

  document.body.append(menu);
  const width = menu.offsetWidth;
  const height = menu.offsetHeight;
  menu.style.left = `${Math.min(Math.max(6, event.clientX), Math.max(6, window.innerWidth - width - 6))}px`;
  menu.style.top = `${Math.min(Math.max(6, event.clientY), Math.max(6, window.innerHeight - height - 6))}px`;

  scMenuNode = menu;
  document.addEventListener("pointerdown", scOnMenuOutside, true);
  document.addEventListener("keydown", scOnMenuKey, true);
  window.addEventListener("scroll", scCloseMenu, true);
  window.addEventListener("resize", scCloseMenu);
}

// ── the icon editor ───────────────────────────────────────────────────────

/** Read one picked file and return a 64×64 WebP data URL.
 *
 *  The same canvas pipeline `panelDownscaleImage` uses, at an icon's size
 *  instead of a wallpaper's — that one is not exported, and the two have
 *  nothing in common but the shape of the call. The image is *fitted* into the
 *  square rather than cropped: a wide logo letterboxed inside the box still
 *  reads as the logo, where a centre crop would cut its ends off. */
function scDownscaleIcon(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error("Could not read that file."));
    reader.onload = () => {
      const img = new Image();
      img.onerror = () => reject(new Error("That image could not be decoded."));
      img.onload = () => {
        const SIZE = 64;
        // Upscaled as well as downscaled: a 16px favicon saved as an upload
        // should fill the box rather than sit tiny in its middle.
        const fit = Math.min(SIZE / Math.max(img.width, 1), SIZE / Math.max(img.height, 1));
        const w = Math.max(1, Math.round(img.width * fit));
        const h = Math.max(1, Math.round(img.height * fit));
        const canvas = document.createElement("canvas");
        canvas.width = SIZE;
        canvas.height = SIZE;
        const ctx = canvas.getContext("2d");
        if (!ctx) {
          reject(new Error("Could not process that image."));
          return;
        }
        ctx.drawImage(img, Math.round((SIZE - w) / 2), Math.round((SIZE - h) / 2), w, h);
        // WebP keeps transparency, and `normaliseShortcutIcon` accepts it; a
        // browser that falls back to PNG produces a legal `data:` URI too.
        const data = canvas.toDataURL("image/webp", 0.9);
        if (data.length > SC_SAFE.SHORTCUT_ICON_MAX_BYTES) {
          reject(new Error("That image is too detailed for an icon — try a smaller one."));
          return;
        }
        resolve(data);
      };
      img.src = String(reader.result ?? "");
    };
    reader.readAsDataURL(file);
  });
}

function scOpenIconEditor(spec, link) {
  const scrim = document.createElement("div");
  scrim.className = "wg-modal-scrim";
  const dialog = document.createElement("div");
  dialog.className = "wg-modal is-wide";
  dialog.setAttribute("role", "dialog");
  dialog.setAttribute("aria-modal", "true");
  dialog.setAttribute("aria-label", "Site icon");

  const head = document.createElement("div");
  head.className = "wg-modal-head";
  const title = document.createElement("span");
  title.className = "wg-modal-title";
  title.textContent = "Site icon";
  const close = document.createElement("button");
  close.type = "button";
  close.className = "wg-modal-close";
  close.textContent = "×";
  close.setAttribute("aria-label", "Close");
  head.append(title, close);
  dialog.append(head);

  // The draft the dialog is editing. Nothing here touches storage until Save,
  // so backing out leaves the icon exactly as it was. Reset is the exception —
  // see its own note below.
  let mode = link.icon?.mode ?? "auto";
  let upload = link.icon?.mode === "upload" ? link.icon.src : null;
  let picked = link.icon?.mode === "set" ? link.icon.name : null;

  const draft = () => {
    if (mode === "set") return picked ? { mode: "set", name: picked } : null;
    if (mode === "upload") return upload ? { mode: "upload", src: upload } : null;
    return { mode };
  };

  const body = document.createElement("div");
  body.className = "sc-icon-body";

  const preview = document.createElement("div");
  preview.className = "sc-icon-preview";
  const caption = document.createElement("div");
  caption.className = "sc-icon-caption";
  caption.textContent = link.label;
  const who = document.createElement("div");
  who.className = "sc-icon-who";
  who.textContent = SC_SAFE.hostOfUrl(link.url) || link.url;

  const paintPreview = () => {
    const painted = SC_SAFE.normaliseShortcutIcon(draft());
    preview.replaceChildren(scIconEl({ ...link, icon: painted }, 64), caption, who);
  };

  const status = document.createElement("div");
  status.className = "wg-search-status";

  const options = document.createElement("div");
  options.className = "sc-icon-opts";
  const picks = [
    { id: "auto", label: "Automatic", hint: "The site's own favicon" },
    { id: "favicon", label: "Site favicon", hint: "Chrome's favicon service" },
    { id: "upload", label: "Upload", hint: "An image from this computer" },
  ];
  const radios = [];
  for (const pick of picks) {
    const row = document.createElement("label");
    row.className = "sc-icon-opt";
    const radio = document.createElement("input");
    radio.type = "radio";
    radio.name = "sc-icon-mode";
    radio.value = pick.id;
    radio.checked = pick.id === mode;
    radio.addEventListener("change", () => {
      mode = pick.id;
      if (pick.id !== "set") picked = null;
      status.textContent = "";
      status.classList.remove("is-error");
      paintCells();
      paintPreview();
    });
    const text = document.createElement("span");
    text.className = "sc-icon-opt-text";
    const name = document.createElement("span");
    name.textContent = pick.label;
    const hint = document.createElement("span");
    hint.className = "sc-icon-opt-hint";
    hint.textContent = pick.hint;
    text.append(name, hint);
    row.append(radio, text);
    radios.push(radio);
    options.append(row);
  }

  const file = document.createElement("input");
  file.type = "file";
  file.accept = "image/*";
  file.hidden = true;
  const choose = document.createElement("button");
  choose.type = "button";
  choose.className = "wg-add-toggle";
  choose.textContent = "Choose image...";
  choose.addEventListener("click", () => file.click());

  // The bundled pictures, as a grid of the stones themselves. A press picks one
  // and stages it like any other mode — Save is still what writes — so choosing
  // an icon and then changing your mind costs a Cancel, not a storage round
  // trip. The last cell is the upload, because an uploaded picture is the
  // *other* way to answer the same question ("which picture?"), not a separate
  // setting.
  const galleryLabel = document.createElement("div");
  galleryLabel.className = "sc-icon-gallery-label";
  galleryLabel.textContent = "Or pick a picture";
  const gallery = document.createElement("div");
  gallery.className = "sc-icon-gallery";
  const cells = [];
  for (const stone of SC_SAFE.SHORTCUT_ICONS) {
    const cell = document.createElement("button");
    cell.type = "button";
    cell.className = "sc-icon-cell";
    cell.title = stone.label;
    cell.setAttribute("aria-label", stone.label);
    cell.setAttribute("aria-pressed", "false");
    cell.dataset.name = stone.id;
    cell.append(scIconEl({ url: "https://set.invalid/", icon: { mode: "set", name: stone.id } }, 26));
    cell.addEventListener("click", () => {
      mode = "set";
      picked = stone.id;
      upload = null;
      for (const r of radios) r.checked = false;
      status.textContent = `${stone.label} selected. Save to use it.`;
      status.classList.remove("is-error");
      paintCells();
      paintPreview();
    });
    gallery.append(cell);
    cells.push(cell);
  }
  const uploadCell = document.createElement("button");
  uploadCell.type = "button";
  uploadCell.className = "sc-icon-cell is-upload";
  uploadCell.title = "Your own image";
  uploadCell.setAttribute("aria-label", "Your own image");
  uploadCell.textContent = "+";
  uploadCell.addEventListener("click", () => file.click());
  gallery.append(uploadCell);

  const paintCells = () => {
    for (const cell of cells) {
      const on = mode === "set" && cell.dataset.name === picked;
      cell.classList.toggle("is-on", on);
      cell.setAttribute("aria-pressed", String(on));
    }
    uploadCell.classList.toggle("is-on", mode === "upload");
  };
  file.addEventListener("change", async () => {
    const chosenFile = file.files?.[0];
    if (!chosenFile) return;
    choose.disabled = true;
    try {
      upload = await scDownscaleIcon(chosenFile);
      mode = "upload";
      picked = null;
      for (const r of radios) r.checked = r.value === "upload";
      paintCells();
      status.textContent = "Ready to save.";
      status.classList.remove("is-error");
      paintPreview();
    } catch (err) {
      status.textContent = err instanceof Error ? err.message : "That image could not be used.";
      status.classList.add("is-error");
    } finally {
      choose.disabled = false;
      file.value = "";
    }
  });

  const row = document.createElement("div");
  row.className = "wg-shortcut-actions";
  const reset = document.createElement("button");
  reset.type = "button";
  reset.className = "wg-add-toggle";
  reset.textContent = "Reset";
  const cancel = document.createElement("button");
  cancel.type = "button";
  cancel.className = "wg-add-toggle";
  cancel.textContent = "Cancel";
  const save = document.createElement("button");
  save.type = "button";
  save.className = "wg-add-save";
  save.textContent = "Save";
  row.append(reset, cancel, save);

  const dismiss = () => {
    document.removeEventListener("keydown", onKey, true);
    scrim.remove();
  };
  const onKey = (e) => {
    if (e.key !== "Escape") return;
    e.preventDefault();
    // Stopped so the page's selection handler and the settings panel behind
    // this dialog do not also act on the key.
    e.stopPropagation();
    dismiss();
  };

  // Reset is decisive: it writes the default chain straight away rather than
  // staging "automatic" for a Save the user might then not press. There is
  // nothing to lose — an icon is one choice, and Reset means it is gone.
  reset.addEventListener("click", async () => {
    save.disabled = true;
    const next = await SC_SAFE.setShortcutIcon(spec.id, link.id, null);
    dismiss();
    await scAfterWrite(next);
  });

  cancel.addEventListener("click", dismiss);
  close.addEventListener("click", dismiss);
  save.addEventListener("click", async () => {
    if (mode === "upload" && !upload) {
      status.textContent = "Choose an image first.";
      status.classList.add("is-error");
      return;
    }
    save.disabled = true;
    const next = await SC_SAFE.setShortcutIcon(spec.id, link.id, draft());
    dismiss();
    await scAfterWrite(next);
  });
  scrim.addEventListener("mousedown", (e) => {
    if (e.target === scrim) dismiss();
  });
  document.addEventListener("keydown", onKey, true);

  body.append(preview, options, galleryLabel, gallery, choose, file, status, row);
  dialog.append(body);
  scrim.append(dialog);
  document.body.append(scrim);
  paintCells();
  paintPreview();
}

// ── dragging a panel tile onto the page ───────────────────────────────────

/** A grid tile is dragged *out* of its panel to put the site on the page.
 *
 *  The gesture only counts if the release happens outside the panel: a tile
 *  nudged a few pixels and dropped is a click, and the link still opens. The
 *  capture is deferred past the slop for the same reason the widget drag defers
 *  it — capturing on the press would retarget the trailing click to the panel
 *  and a plain click on a tile would do nothing. */
function scStartTileDrag(event, tile, spec, link) {
  if (event.button !== 0) return;
  const panel = tile.closest(".wg");
  const startX = event.clientX;
  const startY = event.clientY;
  let dragging = false;

  const move = (e) => {
    if (!dragging) {
      if (Math.hypot(e.clientX - startX, e.clientY - startY) < SC_DRAG_SLOP) return;
      dragging = true;
      scGesture = true;
      tile.classList.add("is-dragging");
      // Captured for the move's own pointer, not the press's: the two share an
      // id, but reading it off `event` reads a dictionary that may already have
      // been recycled, and a throw here left the gesture uncaptured.
      try {
        tile.setPointerCapture(e.pointerId);
      } catch {
        /* tracking still works while the pointer is over the panel */
      }
    }
  };

  const up = async (e) => {
    window.removeEventListener("pointermove", move);
    window.removeEventListener("pointerup", up);
    window.removeEventListener("pointercancel", up);
    if (!dragging) return;
    dragging = false;
    scGesture = false;
    tile.classList.remove("is-dragging");

    // A cancel is not a drop: the browser took the pointer away (a system
    // gesture, the window losing focus), and there is no release position to
    // place anything at. `cancel` used to share this handler, so a cancelled
    // gesture fell through to the `startX` fallback below and wrote an icon to
    // the corner of the screen from coordinates that were never there.
    if (e.type === "pointercancel") return;

    // Dropped back on its own panel: that is not a placement, it is a drag that
    // changed its mind. Nothing is written and the tile stays where it was.
    const box = panel?.getBoundingClientRect();
    if (box && e.clientX >= box.left && e.clientX <= box.right && e.clientY >= box.top && e.clientY <= box.bottom) {
      return;
    }
    scSuppressClick();
    // Centred on the pointer, because the drop point is where the cursor is and
    // the cursor was never at the icon's top-left corner. The press point is the
    // fallback for a browser that delivers a release without coordinates; it is
    // never `undefined`, because it was read from the press itself.
    const x = (Number.isFinite(e.clientX) ? e.clientX : startX) - 38;
    const y = (Number.isFinite(e.clientY) ? e.clientY : startY) - 30;
    const next = await SC_SAFE.setShortcutPlacement(spec.id, link.id, x, y);
    await scAfterWrite(next);
  };

  window.addEventListener("pointermove", move);
  window.addEventListener("pointerup", up);
  window.addEventListener("pointercancel", up);
}

// ── wiring ────────────────────────────────────────────────────────────────

document.addEventListener("pointerdown", scBackgroundPointerDown);
document.addEventListener("keydown", scKeyDown, true);

window.ixiNewtabShortcuts = {
  render: scRender,
  iconEl: scIconEl,
  select: scSelectOnly,
  // The local-favicon URL builder, shared so bookmark rows can prefer Chrome's
  // own cache over a live `host/favicon.ico` round trip without spelling the
  // service URL a second time.
  faviconServiceUrl: scFaviconServiceUrl,
  openMenu: scOpenMenu,
  startTileDrag: scStartTileDrag,
  /** True while a drag or a marquee owns the pointer. The page's Space-to-search
   *  shortcut asks this before taking the key. */
  busy: () => scGesture,
};