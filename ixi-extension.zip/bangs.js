// The search-bang manager.
//
// A bang is a typed prefix that picks where one search goes — `yt car` searches
// YouTube for car. This file is the surface for managing them: a modal opened
// from the button on the right of the search box, and from the settings panel's
// "Search bangs" row. Both call `window.ixiNewtabBangs.open()`, so there is one
// implementation rather than two that drift.
//
// The rules live in `settings.js` (`validateBang`, `parseBang`) so the store and
// this UI cannot disagree about what a valid bang is. This file is presentation
// and nothing else.
//
// Every top-level name here is `bang`-prefixed. The extension's classic scripts
// share one lexical scope, so a bare `open` or `view` would be a load-time
// SyntaxError for the whole page the moment another file declared it.

const BANGS_SAFE = window.ixiNewtabSettings;

/** The open dialog, or null. Doubles as the open/closed test. */
let bangsScrim = null;
/** Which body the dialog is drawing: "list" or "form". Swapped in place rather
 *  than stacking a second dialog — two scrims would mean two Escape
 *  arbitrations and two focus traps for one task. */
let bangsView = "list";
/** The id the form is editing, or null when it is adding. */
let bangsEditId = null;
/** Focus goes back here on close, so the keyboard user lands where they left. */
let bangsOpener = null;

/** Build one row of the bang list. Shared by the active list and the catalogue,
 *  which differ only in what their trailing control does. */
function bangRow({ trigger, label, sub, actions }) {
  const row = node("div", "wg-row");
  const badge = node("span", "wg-row-icon", trigger);
  const stack = node("div", "wg-row-stack");
  stack.append(node("div", "wg-row-title", label));
  if (sub) stack.append(node("div", "wg-row-sub", sub));
  row.append(badge, stack);
  if (actions?.length) {
    const rail = node("div", "wg-bangs-acts");
    for (const a of actions) rail.append(a);
    row.append(rail);
  }
  return row;
}

/** A small square button for a row's action rail. `.wg-add-toggle` already
 *  carries the right weight for a secondary control inside a panel. */
function bangButton(text, className, onClick) {
  const button = node("button", `wg-add-toggle${className ? ` ${className}` : ""}`, text);
  button.type = "button";
  button.addEventListener("click", onClick);
  return button;
}

/** The host a bang's template points at, for the row's second line — the thing
 *  that tells two similar labels apart. */
function bangHost(url) {
  try {
    return new URL(String(url).replace("%s", "")).hostname.replace(/^www\./, "");
  } catch {
    return "";
  }
}

/** The editor, shown in place of the list. Four text fields and the usual
 *  action row.
 *
 *  Every field is `type="text"`, never `type="url"`. Two reasons, and the second
 *  is decisive: the browser's URL validation silently refuses a bare host (the
 *  note on `buildShortcutForm` covers that at length), and it would refuse a
 *  template outright, because `%s` is not a legal host character. A form that
 *  cannot be submitted and does not say why is the worst version of this. */
function buildBangForm(bang) {
  const form = node("form", "wg-add wg-shortcut-form");

  const trigger = node("input", "wg-search-input");
  trigger.type = "text";
  trigger.placeholder = "yt";
  trigger.maxLength = 16;
  trigger.value = bang?.trigger ?? "";
  trigger.setAttribute("aria-label", "Trigger");

  const label = node("input", "wg-search-input");
  label.type = "text";
  label.placeholder = "YouTube";
  label.maxLength = 40;
  label.value = bang?.label ?? "";
  label.setAttribute("aria-label", "Name");

  const url = node("input", "wg-search-input");
  url.type = "text";
  url.placeholder = "https://www.youtube.com/results?search_query=%s";
  url.value = bang?.url ?? "";
  url.setAttribute("aria-label", "Search address");

  const note = node("div", "wg-bangs-note", "Put %s where the search words go.");

  const home = node("input", "wg-search-input");
  home.type = "text";
  home.placeholder = "Blank for the site's home page";
  home.value = bang?.home ?? "";
  home.setAttribute("aria-label", "Home page");

  const row = node("div", "wg-shortcut-actions");
  const save = node("button", "wg-add-save", bang ? "Save" : "Add");
  save.type = "submit";
  const cancel = node("button", "wg-add-toggle", "Cancel");
  cancel.type = "button";
  row.append(save, cancel);

  const status = node("div", "wg-search-status");

  form.append(trigger, label, url, note, home, row, status);

  const back = () => {
    bangsView = "list";
    bangsEditId = null;
    paintBangs();
  };
  cancel.addEventListener("click", back);

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const draft = {
      trigger: trigger.value,
      label: label.value,
      url: url.value,
      home: home.value,
    };
    // Validated here rather than only inside the store, because this is where
    // the reason can be shown. `validateBang` is the same function the store
    // runs, so the two cannot disagree about what it refuses.
    const settings = await BANGS_SAFE.get();
    const checked = BANGS_SAFE.validateBang(draft, settings.searchBangs, bangsEditId);
    if (!checked.ok) {
      status.textContent = checked.error;
      status.className = "wg-search-status is-error";
      return;
    }
    save.disabled = true;
    if (bangsEditId) await BANGS_SAFE.updateBang(bangsEditId, draft);
    else await BANGS_SAFE.addBang(draft);
    save.disabled = false;
    back();
    afterBangWrite();
  });

  return { form, focus: () => trigger.focus() };
}

/** The list body: your bangs, the way in to a custom one, and the catalogue. */
async function paintBangsList(body) {
  const settings = await BANGS_SAFE.get();
  const bangs = settings.searchBangs;
  const taken = new Set(bangs.map((b) => b.trigger.toLowerCase()));

  // ── your bangs ──
  const head = node("div", "wg-bangs-head");
  head.append(node("span", "wg-bangs-head-title", "Your bangs"));
  if (bangs.length) {
    const reset = bangButton("Reset", null, async () => {
      await BANGS_SAFE.resetBangs();
      paintBangs();
      afterBangWrite();
    });
    reset.title = "Put the shipped starter bangs back";
    head.append(reset);
  }
  const sec = node("section", "wg-bangs-sec");
  sec.append(head);

  if (!bangs.length) {
    sec.append(node("div", "wg-empty", "No bangs yet. Add one below, or pick from the catalogue."));
  } else {
    const list = node("div", "wg-list");
    for (const b of bangs) {
      list.append(
        bangRow({
          trigger: b.trigger,
          label: b.label,
          sub: bangHost(b.url),
          actions: [
            bangButton("Edit", null, () => {
              bangsEditId = b.id;
              bangsView = "form";
              paintBangs();
            }),
            bangButton("Remove", "is-remove", async () => {
              await BANGS_SAFE.removeBang(b.id);
              paintBangs();
              afterBangWrite();
            }),
          ],
        }),
      );
    }
    sec.append(list);
  }

  const add = node("button", "wg-add-toggle", "+ Add a custom bang");
  add.type = "button";
  add.addEventListener("click", () => {
    bangsEditId = null;
    bangsView = "form";
    paintBangs();
  });
  const addWrap = node("div", "wg-bangs-foot");
  addWrap.append(add);
  sec.append(addWrap);
  body.append(sec);

  // ── the catalogue, grouped in the order the groups first appear ──
  const groups = [];
  for (const entry of BANGS_SAFE.BANG_CATALOG) {
    if (!groups.includes(entry.group)) groups.push(entry.group);
  }
  for (const group of groups) {
    const groupSec = node("section", "wg-bangs-sec");
    groupSec.append(node("div", "wg-bangs-group-title", group));
    const list = node("div", "wg-list");
    for (const entry of BANGS_SAFE.BANG_CATALOG.filter((e) => e.group === group)) {
      const already = taken.has(entry.trigger.toLowerCase());
      const button = bangButton(already ? "Added" : "Add", null, async () => {
        await BANGS_SAFE.addBang(BANGS_SAFE.bangFromCatalog(entry));
        paintBangs();
        afterBangWrite();
      });
      // Disabled once it is in the list, so a duplicate cannot be made by
      // clicking — the store would refuse it anyway, but a button that silently
      // does nothing is worse than one that says it is already there.
      button.disabled = already;
      const sub = entry.note ? `${bangHost(entry.url)} — ${entry.note}` : bangHost(entry.url);
      list.append(bangRow({ trigger: entry.trigger, label: entry.label, sub, actions: [button] }));
    }
    groupSec.append(list);
    body.append(groupSec);
  }
}

/** Draw the dialog's body for whichever view is current. */
async function paintBangs() {
  if (!bangsScrim) return;
  const body = bangsScrim.querySelector(".wg-bangs");
  if (!body) return;
  if (bangsView === "form") {
    const settings = await BANGS_SAFE.get();
    const editing = bangsEditId ? settings.searchBangs.find((b) => b.id === bangsEditId) : null;
    const { form, focus } = buildBangForm(editing);
    body.replaceChildren(form);
    focus();
    return;
  }
  body.replaceChildren();
  await paintBangsList(body);
}

/** The one step every write ends with.
 *
 *  `applySettings` is the page's own refresh and is what every panel control
 *  already calls — it re-caches the bang list the search box submits against.
 *  `PagePanel.paint` keeps the settings panel's summary line honest when the
 *  modal was opened from that row. Bangs are edited rarely, so the full refresh
 *  costs nothing that matters here. */
async function afterBangWrite() {
  await window.ixiNewtabPage?.applySettings?.();
  window.ixiNewtabPanel?.paint?.();
}

function bangDismiss() {
  if (!bangsScrim) return;
  document.removeEventListener("keydown", bangOnKey, true);
  bangsScrim.remove();
  bangsScrim = null;
  bangsView = "list";
  bangsEditId = null;
  bangsOpener?.focus?.();
  bangsOpener = null;
}

/** Escape belongs to the modal while it is up. Stopped before it can reach the
 *  document-level listener in `panel.js`, which would otherwise close the
 *  settings panel behind the modal at the same moment — one key, two surfaces
 *  gone, which reads as the page having dropped the user's work. */
function bangOnKey(e) {
  if (e.key !== "Escape") return;
  e.preventDefault();
  e.stopPropagation();
  bangDismiss();
}

/** Open the manager, or do nothing when it is already up.
 *
 *  Built on demand and torn down on close, matching the widget modals: a dialog
 *  kept hidden in the document is a dialog whose state has to be reset by hand
 *  on every open, and whose ids can collide with a second one. */
function openBangs() {
  if (bangsScrim) return;
  bangsOpener = document.activeElement;
  bangsView = "list";
  bangsEditId = null;

  const scrim = node("div", "wg-modal-scrim");
  const dialog = node("div", "wg-modal is-wide");
  dialog.setAttribute("role", "dialog");
  dialog.setAttribute("aria-modal", "true");
  dialog.setAttribute("aria-label", "Search bangs");

  const head = node("div", "wg-modal-head");
  head.append(node("span", "wg-modal-title", "Search bangs"));
  const close = node("button", "wg-modal-close", "×");
  close.type = "button";
  close.setAttribute("aria-label", "Close");
  head.append(close);
  dialog.append(head, node("div", "wg-bangs"));

  close.addEventListener("click", bangDismiss);
  // Only a press that started on the backdrop closes: a drag that began inside
  // the dialog and ended on the scrim is not a request to dismiss.
  scrim.addEventListener("mousedown", (e) => {
    if (e.target === scrim) bangDismiss();
  });
  document.addEventListener("keydown", bangOnKey, true);

  scrim.append(dialog);
  document.body.append(scrim);
  bangsScrim = scrim;
  paintBangs();
}

window.ixiNewtabBangs = { open: openBangs, close: bangDismiss, isOpen: () => Boolean(bangsScrim) };
