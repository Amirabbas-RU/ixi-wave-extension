// The new tab page's settings panel, opened by the gear in the topbar.
//
// Every control here writes straight through `settings.js` and then asks the
// page to re-apply, so there is no Save button and no draft state to keep in
// sync — the page behind the panel is already showing the result.
//
// Top-level names carry a `panel`/`pn` prefix because this page loads several
// classic scripts into one shared lexical scope, and a bare `open`, `close` or
// `section` would collide with a future file's declaration and throw before any
// of this ran.

const PANEL_SAFE = window.ixiNewtabSettings;
const PANEL_AUTH = window.ixiAuth;
const PANEL_DECOR = window.ixiNewtabDecor;

// `paintPanel` replaces the *body's* children, not the panel's: the panel's
// first child is the header with the close button, and painting into the panel
// itself would delete that button along with the body it repaints into.
let panelBody = null;

/** The session the account section renders from. Read once per paint rather
 *  than held as the source of truth — `auth.js`'s storage is the authority, and
 *  caching the email here would leave the section showing a stale account after
 *  a sign-out in the popup. */
let panelSession = null;

/** Which full-panel sub-view is showing: `null` is the main settings list, and
 *  "decor"/"widgets" are the two galleries that outgrew a section. It lives out
 *  here rather than being passed around because `paintPanel` is called after
 *  nearly every change — a toggle inside the widgets view repaints the panel,
 *  and this flag is what keeps that repaint landing on the same view instead of
 *  bouncing the user back to the list they came from. */
let panelView = null;

/** A note for the Backup section that has to survive the repaint its own action
 *  triggers. `restore` repaints the panel as its last step, so the "Restored."
 *  line is queued here and shown by the section that replaces the one that
 *  queued it. Deliberately not generalised: it is one line, set from one place,
 *  and a notice queue for the whole panel would be a mechanism nobody asked for. */
let panelBackupNotice = null;

/** One labelled section of the panel.
 *
 *  Absent children are dropped rather than appended. Several sections have a
 *  part that only exists in some states — the widgets section's "Added" group
 *  has nothing to show until the user adds something — and those call sites pass
 *  the result of that condition directly. `append(null)` would stringify it, so
 *  a profile with no added widgets would read a literal "null" in the section. */
function panelSection(title, ...children) {
  const section = node("section", "pn-sec");
  section.append(node("h3", "pn-sec-title", title), ...children.filter(Boolean));
  return section;
}

/** A live miniature of one widget, for the list that switches it on and off.
 *
 *  The obvious shortcut is a small icon per kind, and it is the wrong one: it is
 *  a second drawing of the widget that has to be kept in step with the first, and
 *  it answers "which row is this?" when the list's real question is "what will
 *  this put on my page?". So the row shows the widget — the same `body()` the
 *  page renders, wrapped in the same `data-widget`/`data-style` the page sets, so
 *  the miniature is styled by the stylesheet the page uses and cannot drift from
 *  it.
 *
 *  It sits inside the row's `<button>`, which is why the copy is inert: no
 *  pointer events reach it, and it is hidden from assistive tech so the switch
 *  still reads as one control. The events the body's own controls would answer
 *  go nowhere, which is correct — this is a picture of a widget, not a widget. */
async function buildWidgetPreview(spec, settings) {
  const kind = PANEL_SAFE.widgetKindOf(spec);
  // `wg` is not decoration: the six style blocks are written as `.wg[data-style]`,
  // so the class is what brings the widget's material with it.
  const frame = node("div", "wg pn-wg-preview");
  frame.setAttribute("aria-hidden", "true");
  // The kind, matching what the page writes — an added panel's minted id has no
  // rule behind it, and the miniature would render unstyled without this.
  frame.dataset.widget = kind;
  frame.dataset.style = PANEL_SAFE.widgetStyleFor(settings, spec.id);
  const variant = PANEL_SAFE.widgetVariantFor(settings, spec.id);
  if (variant) frame.dataset.variant = variant;
  // The second axis, for the one kind that has it — the page writes the same
  // attribute, so the miniature's caption and year columns are sized by the same
  // rules the real panel is.
  if (kind === "calendar") frame.dataset.calendar = PANEL_SAFE.calendarSystemFor(settings, spec.id);
  // The face, for every kind — the miniature has to wear it or the picker would
  // be choosing a font the picture beside it does not show.
  frame.dataset.font = PANEL_SAFE.widgetFontFor(settings, spec.id);

  const body = node("div", "wg-body");
  if (kind === "search") {
    // The search bar and the clock are page furniture, not panels, so their
    // miniatures are drawn rather than rendered: the box is one element on the
    // page and `renderWidgets` has no renderer for it to copy.
    body.append(node("div", "wg-search-mini", "Search the web, or type a URL"));
    frame.append(body);
    return frame;
  }
  try {
    // `spec` rather than just the id, because a shortcuts panel draws its own
    // pins and nothing else can tell it what they are.
    //
    // The shipped clock entry is the one spec the renderer would answer wrongly
    // here: on the page it *is* the header block, so its body is the note "On
    // the page." — which in the list is a blank box that does not read as the
    // clock. A synthetic id keeps it off that branch, so the card shows the
    // clock's own face (the same one an added clock draws), which is what the
    // miniature is for.
    const renderSpec =
      kind === "clock" && spec?.id === "clock" ? { ...spec, id: "clock-preview" } : spec;
    body.append(await window.ixiNewtabWidgets.WIDGET_RENDERERS[kind].body(renderSpec));
  } catch {
    // A widget whose data could not be read still gets a row — the switch is
    // what this list is for, and it must not be lost to a failed read.
    body.append(node("div", "wg-empty", "Nothing to show."));
  }
  frame.append(body);
  return frame;
}

/** A row that behaves like a checkbox. `leading` is optional, and is whatever
 *  node should sit at the start of the row — the widget list passes a live
 *  miniature; a toggle without one is exactly the row this always was. */
function panelToggle(label, on, onChange, leading) {
  const row = node("button", on ? "pn-toggle is-on" : "pn-toggle");
  row.type = "button";
  row.setAttribute("role", "switch");
  row.setAttribute("aria-checked", String(on));
  if (leading) row.append(leading);
  row.append(node("span", "pn-toggle-label", label), node("span", "pn-switch", on ? "on" : "off"));
  row.addEventListener("click", () => onChange(!on));
  return row;
}

/** One widget's row in the list: its miniature, its name, its switch, and the
 *  two small things that can be done *to the card itself* — place another of
 *  the same kind, and take an added one away.
 *
 *  The wrapper exists because a row carrying extra buttons cannot be one big
 *  `<button>`: a button inside a button is invalid, and the browser would hand
 *  the inner click to the outer switch. So the switch is the button and the
 *  actions are its siblings, and the row is a plain flex container holding all
 *  three.
 *
 *  `onAdd` is passed in rather than derived here because the page decides who
 *  gets it: only the shipped singleton of an addable kind offers it. The control
 *  therefore sits on the kind's own card instead of in a list of its own below
 *  the grid — one "+" per kind, on the thing it duplicates, so "another of
 *  these" is read off the widget rather than off a separate menu of names. */
function panelWidgetCard(spec, preview, onToggle, onRemove, onAdd) {
  const name = PANEL_SAFE.widgetLabelOf(spec);
  const toggle = panelToggle(name, Boolean(spec.visible), onToggle, preview);
  const removable = PANEL_SAFE.isRemovableWidget(spec);
  if (!onAdd && !removable) return toggle;

  const card = node("div", "pn-widget-card");
  card.append(toggle);

  // The actions share one rail rather than each taking a corner of its own: two
  // absolutely-placed corners would collide the moment a card has both, and an
  // added panel of an addable kind is exactly that case.
  const acts = node("div", "pn-widget-acts");
  if (onAdd) {
    const add = node("button", "pn-widget-act", "+");
    add.type = "button";
    add.title = `Add another ${name}`;
    add.setAttribute("aria-label", `Add another ${name}`);
    add.addEventListener("click", onAdd);
    acts.append(add);
  }
  if (removable) {
    const remove = node("button", "pn-widget-act is-remove", "×");
    remove.type = "button";
    remove.title = `Remove ${name}`;
    remove.setAttribute("aria-label", `Remove ${name}`);
    remove.addEventListener("click", onRemove);
    acts.append(remove);
  }
  card.append(acts);
  return card;
}

/** One labelled row: a caption on the left, a control on the right. Used by
 *  every setting that is a value rather than an on/off — a font, a style, a
 *  size — so the panel does not grow a different shape per control. */
function panelRow(label, control) {
  const row = node("div", "pn-row");
  row.append(node("span", "pn-row-label", label), control);
  return row;
}

/** A `<select>` over `options` (`{ id, label }`), reporting the chosen id.
 *
 *  `extra` is prepended as a first option, which is how the per-widget style
 *  picker offers "Inherit" — an id that is not in `WIDGET_STYLES` at all, so it
 *  cannot collide with a real style. */
function panelSelect(options, value, onChange, extra) {
  const select = node("select", "pn-select is-compact");
  if (extra) {
    const opt = node("option", null, extra.label);
    opt.value = extra.id;
    select.append(opt);
  }
  for (const option of options) {
    const opt = node("option", null, option.label);
    opt.value = option.id;
    if (option.id === value) opt.selected = true;
    select.append(opt);
  }
  select.setAttribute("aria-label", extra?.aria ?? "");
  select.addEventListener("change", () => onChange(select.value));
  return select;
}

/** A range slider with its value shown beside the caption. `format` turns the
 *  raw number into whatever unit the setting is in, so the readout says `68px`
 *  rather than `68` — the number on its own does not say what it measures. */
function panelSlider(label, { min, max, step = 1, value, format }, onInput, onDone) {
  const readout = node("span", "pn-range-value", format(value));
  const input = node("input", "pn-range");
  input.type = "range";
  input.min = String(min);
  input.max = String(max);
  input.step = String(step);
  input.value = String(value);
  input.setAttribute("aria-label", label);
  // Live on the page while dragging (the readout and the page move together),
  // written once on release — a storage write per input event would be hundreds
  // of writes for one gesture.
  input.addEventListener("input", () => {
    const next = Number(input.value);
    readout.textContent = format(next);
    onInput(next);
  });
  input.addEventListener("change", () => onDone(Number(input.value)));

  const head = node("div", "pn-row");
  head.append(node("span", "pn-row-label", label), readout);
  const wrap = node("div", "pn-slider");
  wrap.append(head, input);
  return wrap;
}

/** One text field. `type` is `url` for the wallpaper and `datetime-local` for
 *  the schedule; both are native controls, so the platform supplies the
 *  validation and the picker rather than this file. */
function panelText(value, { type = "text", placeholder = "", label, onInput }) {
  const input = node("input", "pn-input");
  input.type = type;
  input.value = value ?? "";
  input.placeholder = placeholder;
  input.setAttribute("aria-label", label);
  input.addEventListener("input", () => onInput(input.value));
  return input;
}

/** A text field with a × beside it, for a value that means something on its own
 *  rather than merely being empty.
 *
 *  Returns the wrapper, so it is the wrapper the panel lays out — the caller
 *  keeps the input it built and goes on reading its `.value`, which is why this
 *  is a separate step rather than a flag on `panelText`. Only the backdrop URL
 *  wants one: an unset URL *is* a backdrop of "none", and dropping it used to
 *  mean selecting the text and deleting it by hand. */
function panelClearable(input, onClear) {
  const clear = node("button", "pn-clear", "×");
  clear.type = "button";
  const what = input.getAttribute("aria-label") || "this field";
  clear.title = `Clear ${what}`;
  clear.setAttribute("aria-label", `Clear ${what}`);
  clear.addEventListener("click", () => {
    input.value = "";
    onClear();
    input.focus();
  });

  const wrap = node("div", "pn-text-wrap");
  wrap.append(input, clear);
  return wrap;
}

/** The uploaded-wallpaper control: pick a file, or clear the one already there.
 *
 *  Returns `{ node, currentImage, onChange }` rather than being a plain field, so
 *  the caller can ask for the image synchronously when it paints the swatch —
 *  the bytes live under their own storage key and reading them is async, so the
 *  control keeps its own copy and calls `onChange` when the read lands.
 *
 *  The image is re-encoded through a canvas before it is stored. A phone photo
 *  is several megabytes of JPEG, and `chrome.storage.local` caps at 10MB for the
 *  whole profile — one wallpaper straight off a camera roll could consume most
 *  of that, or exceed it and make every later write fail. Downscaling to a
 *  2560px long edge and re-encoding as WebP keeps a full-screen wallpaper well
 *  under a megabyte, which is the difference between this working and not.
 */
function panelWallpaperUpload(settings) {
  const state = { image: "" };
  const listeners = [];
  const note = node("div", "pn-note");
  const row = node("div", "pn-row");
  const controls = node("div", "pn-upload");

  const picker = node("input", "pn-file-input");
  picker.type = "file";
  picker.accept = "image/*";
  picker.setAttribute("aria-label", "Upload a wallpaper image");

  const choose = node("button", "pn-upload-btn", "Upload");
  choose.type = "button";
  choose.addEventListener("click", () => picker.click());

  // Always on screen, greyed out when there is nothing to remove. Hiding it
  // entirely made deleting an upload look like a feature that had gone away —
  // the button a user is looking for is exactly the one that is not there. A
  // disabled control still answers "yes, this is where you get rid of it".
  const clear = node("button", "pn-upload-btn is-quiet", "Remove");
  clear.type = "button";

  const paint = () => {
    clear.disabled = !state.image;
    clear.title = state.image ? "Remove the uploaded image" : "No uploaded image to remove";
    // A successful upload gets no line of its own — the swatch right above shows
    // it, and saying so in words was a status message for a state the user can
    // already see. The note stays for what they *cannot* see by looking: an error,
    // or work in progress. The guard is not decorative: clearing unconditionally
    // wiped the error message the instant `paint()` ran, so a failed upload showed
    // nothing at all — which reads as the button being broken rather than the file.
    if (!note.classList.contains("is-error")) note.textContent = "";
  };

  const announce = () => {
    paint();
    for (const fn of listeners) fn();
  };

  picker.addEventListener("change", async () => {
    const file = picker.files?.[0];
    if (!file) return;
    note.classList.remove("is-error");
    if (!file.type.startsWith("image/")) {
      note.textContent = "That file is not an image.";
      note.classList.add("is-error");
      return;
    }
    try {
      note.textContent = "Processing...";
      state.image = await panelDownscaleImage(file);
      await PANEL_SAFE.setWallpaperUpload(state.image);
      await window.ixiNewtabPage.applySettings();
      note.classList.remove("is-error");
      announce();
    } catch (err) {
      state.image = "";
      note.textContent = err instanceof Error ? err.message : "Could not read that image.";
      note.classList.add("is-error");
      paint();
    } finally {
      // Cleared so choosing the same file twice in a row still fires `change`.
      picker.value = "";
    }
  });

  clear.addEventListener("click", async () => {
    state.image = "";
    note.classList.remove("is-error");
    await PANEL_SAFE.clearWallpaperUpload();
    await window.ixiNewtabPage.applySettings();
    announce();
  });

  row.append(node("span", "pn-row-label", "Upload"), controls);
  controls.append(choose, clear, picker);
  const node_ = node("div", "pn-upload-wrap");
  node_.append(row, note);

  // Seeded from storage: the panel can be opened long after the upload, and the
  // swatch has to show it without a second trip through the picker.
  PANEL_SAFE.getWallpaperUpload()
    .then((image) => {
      state.image = image;
      announce();
    })
    .catch(() => {});

  return {
    node: node_,
    currentImage: () => state.image,
    onChange: (fn) => listeners.push(fn),
  };
}

/** Read one picked file, downscale it to a 2560px long edge, and return it as a
 *  WebP data URL. Rejects with a message the panel can show rather than a raw
 *  DOM exception.
 *
 *  WebP rather than JPEG because it keeps transparency, so a logo or a cut-out
 *  used as a backdrop does not land on a black rectangle. Every browser this
 *  extension is registered for is Chromium, so the encoder is always present. */
function panelDownscaleImage(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error("Could not read that file."));
    reader.onload = () => {
      const img = new Image();
      img.onerror = () => reject(new Error("That image could not be decoded."));
      img.onload = () => {
        const MAX = 2560;
        const scale = Math.min(1, MAX / Math.max(img.width, img.height));
        const w = Math.max(1, Math.round(img.width * scale));
        const h = Math.max(1, Math.round(img.height * scale));
        const canvas = document.createElement("canvas");
        canvas.width = w;
        canvas.height = h;
        const ctx = canvas.getContext("2d");
        if (!ctx) {
          reject(new Error("Could not process that image."));
          return;
        }
        ctx.drawImage(img, 0, 0, w, h);
        let data = canvas.toDataURL("image/webp", 0.85);
        // `canvas.toDataURL` silently falls back to PNG when WebP is not
        // supported, and a photograph as PNG is exactly the several-megabyte
        // document this is trying to avoid. Re-encoding as JPEG is the safer
        // fallback — the alpha is lost, but the file stays small.
        if (data.startsWith("data:image/png")) data = canvas.toDataURL("image/jpeg", 0.85);
        // ~4MB of base64 is approximately 3MB of bytes, which leaves room for
        // the rest of the profile's storage.
        if (data.length > 4_000_000) {
          reject(new Error("That image is too large even after resizing — try a smaller one."));
          return;
        }
        resolve(data);
      };
      img.src = String(reader.result ?? "");
    };
    reader.readAsDataURL(file);
  });
}

// ── the decor gallery ─────────────────────────────────────────────────────
// Every piece of art in `extension/decor/`, as a thumbnail that can be dragged
// onto the page. The gallery is the only way art gets onto the page, so it has
// to be reachable while the page behind it is covered by the scrim — see
// `decorDropTarget` in `decor.js` for how the scrim becomes the drop target.

function panelDecorGallery() {
  const grid = node("div", "pn-decor");

  if (!PANEL_SAFE.DECOR_CATALOG.length) {
    grid.append(node("div", "pn-note", "No art is bundled with this build."));
    return grid;
  }

  for (const art of PANEL_SAFE.DECOR_CATALOG) {
    const cell = node("button", "pn-decor-cell");
    cell.type = "button";
    cell.title = `Add ${art.label}`;
    cell.setAttribute("aria-label", `Add ${art.label} to the page`);
    // `draggable` is what makes the drop target worthwhile: dragging a thumbnail
    // out to a spot on the page is the whole gesture, and a click cannot say
    // *where*. The click path stays as the no-mouse route, cascading the piece
    // into the corner instead.
    cell.draggable = true;
    cell.addEventListener("dragstart", (e) => {
      e.dataTransfer.setData("text/plain", art.id);
      e.dataTransfer.effectAllowed = "copy";
      cell.classList.add("is-dragging");
    });
    cell.addEventListener("dragend", () => cell.classList.remove("is-dragging"));
    cell.addEventListener("click", async () => {
      await PANEL_DECOR.place(art.id);
      await window.ixiNewtabPage.applySettings();
    });

    const thumb = node("img", "pn-decor-thumb");
    thumb.src = `decor/${art.id}.webp`;
    thumb.alt = "";
    thumb.draggable = false;
    thumb.loading = "lazy";
    cell.append(thumb, node("span", "pn-decor-name", art.label));
    grid.append(cell);
  }
  return grid;
}

/** The line above the gallery, and the button that clears what has been placed.
 *  A separate builder because the count in it has to track placements, and the
 *  gallery itself never changes. */
function panelDecorHead(count) {
  const row = node("div", "pn-row");
  row.append(
    node("span", "pn-note", count ? `${count} on the page.` : "Drag one onto the page."),
  );
  if (count) {
    const clear = node("button", "pn-mini", "Clear");
    clear.type = "button";
    clear.title = "Remove every decoration";
    clear.addEventListener("click", async () => {
      await PANEL_SAFE.clearDecor();
      await window.ixiNewtabPage.applySettings();
      paintPanel();
    });
    row.append(clear);
  }
  return row;
}

/** The header of a full-panel sub-view: a back control and the view's name.
 *
 *  The same `← label` the popup uses to leave a tool, because it is the same
 *  move — a second level that puts the first back where you left it. */
function panelSubHead(title, onBack) {
  const back = node("button", "pn-back");
  back.type = "button";
  back.setAttribute("aria-label", `Back to settings from ${title}`);
  back.append(node("span", "pn-back-arrow", "←"), node("span", null, title));
  back.addEventListener("click", onBack);
  return back;
}

/** The collapsed form of a section whose content moved to a sub-view: a one-line
 *  summary of what is there now, and the button that opens the view. Same argument
 *  as `panelDecorHead` for being its own builder — the summary is the only part
 *  that changes between paints. */
function panelExpand(summary, label, onOpen) {
  const row = node("div", "pn-row pn-expand");
  row.append(node("span", "pn-note", summary));
  const open = node("button", "pn-mini", label);
  open.type = "button";
  open.addEventListener("click", onOpen);
  row.append(open);
  return row;
}

/** A whole panel page: the back header over the view's own content, with no
 *  section title of its own — the header already names it, and a title repeating
 *  the back label would read as two headings for one page. */
function panelSubView(title, children) {
  const section = node("section", "pn-sec");
  section.append(panelSubHead(title, () => setPanelView(null)), ...children.filter(Boolean));
  return section;
}

/** Switch the panel between the main list and a sub-view, then repaint into it.
 *  The paint *is* the swap: nothing else touches the body, and `paintPanel` reads
 *  `panelView` back to decide which page to draw. */
async function setPanelView(view) {
  panelView = view;
  await paintPanel();
  // A view opens at its top; without this the body keeps the previous page's
  // scroll offset and the user lands part-way down the gallery they just opened.
  panelBody?.scrollTo?.({ top: 0 });
}

// ── the account ───────────────────────────────────────────────────────────
// Signing in used to be popup-only, which meant the new tab page — the surface
// where the account actually matters, because every widget but the clock reads
// from it — told you to "sign in from the extension" and gave you no way to do
// it. The section below is the same `auth.js` the popup uses, so a session
// created in either place is the same session; there is no second login.
//
// Signed out it is a login form with a signup tab; signed in it names the
// account and offers a way out. Both states are built here rather than in the
// markup, because the panel's whole body is rebuilt on every change anyway.

/** A labelled input for the account forms. Small variant of `panelText` — the
 *  panel's fields are 168px in a row, and a login form needs the full width. */
function panelAccountField(label, { type = "text", autocomplete, placeholder }) {
  const field = node("div", "pn-field");
  field.append(node("label", "pn-micro", label));
  const input = node("input", "pn-input pn-input-full");
  input.type = type;
  input.autocomplete = autocomplete ?? "off";
  if (placeholder) input.placeholder = placeholder;
  field.append(input);
  return { field, input };
}

function panelAccountSection() {
  const wrap = node("div", "pn-account");

  /** Set a message inside the section. `ok` colours it as a confirmation rather
   *  than an error, which matters because signup success and a wrong password
   *  both arrive here. */
  const message = node("div", "pn-msg hidden");
  const say = (text, ok = false) => {
    message.textContent = text;
    message.className = ok ? "pn-msg is-ok" : "pn-msg";
  };

  /** Run a submit with every control in the form disabled, so a double-click
   *  cannot post twice, and report the outcome through `say`. */
  const submit = async (controls, run) => {
    controls.forEach((c) => (c.disabled = true));
    say("…");
    try {
      const session = await run();
      // A sign-in makes the account copy reachable, so this is the moment to
      // pull it — and to send anything changed while signed out. Pull first, so
      // a fresh sign-in on a new machine adopts the account's layout instead of
      // overwriting it with this profile's.
      await PANEL_SAFE.hydrateFromAccount().catch(() => {});
      await PANEL_SAFE.flushRemotePush().catch(() => {});
      // Repaint the page and this panel: the widgets behind are full of data
      // that was not reachable a moment ago.
      await window.ixiNewtabPage.applySettings();
      say(`Signed in as ${session.email}.`, true);
      await paintPanel();
      return;
    } catch (err) {
      say(err instanceof Error ? err.message : "Something went wrong");
    } finally {
      controls.forEach((c) => (c.disabled = false));
    }
  };

  // ── signed in ───────────────────────────────────────────────────────────
  const session = panelSession;
  if (session?.email) {
    const who = node("div", "pn-account-who");
    who.append(node("span", "pn-micro", "signed in"), node("span", "pn-account-email", session.email));
    wrap.append(who);

    const row = node("div", "pn-account-actions");
    const out = node("button", "pn-mini", "Sign out");
    out.type = "button";
    out.addEventListener("click", async () => {
      out.disabled = true;
      await PANEL_AUTH.logout();
      // The account's copy is no longer reachable, so anything pending has
      // nowhere to go. Left as-is: the local blob keeps the layout and the next
      // sign-in pushes it.
      panelSession = null;
      await paintPanel();
    });
    row.append(out);
    wrap.append(row, message);
    return wrap;
  }

  // ── signed out ──────────────────────────────────────────────────────────
  const tabs = node("div", "pn-subtabs");
  const loginTab = node("button", "pn-subtab is-active", "Log in");
  const signupTab = node("button", "pn-subtab", "Sign up");
  loginTab.type = signupTab.type = "button";
  loginTab.setAttribute("aria-pressed", "true");
  signupTab.setAttribute("aria-pressed", "false");
  tabs.append(loginTab, signupTab);

  const identifier = panelAccountField("email or username", { autocomplete: "username", placeholder: "you@example.com" });
  const password = panelAccountField("password", { type: "password", autocomplete: "current-password", placeholder: "••••••••" });
  const loginForm = node("form", "pn-form");
  loginForm.append(identifier.field, password.field);
  const loginBtn = node("button", "pn-primary", "Sign in");
  loginBtn.type = "submit";
  loginForm.append(loginBtn);

  const email = panelAccountField("email", { type: "email", autocomplete: "email", placeholder: "you@example.com" });
  const username = panelAccountField("username (optional)", { placeholder: "letters, digits, _ or -" });
  const newPassword = panelAccountField("password", { type: "password", autocomplete: "new-password", placeholder: "min 6 characters" });
  const signupForm = node("form", "pn-form hidden");
  signupForm.append(email.field, username.field, newPassword.field);
  const signupBtn = node("button", "pn-primary", "Create account");
  signupBtn.type = "submit";
  signupForm.append(signupBtn);

  loginForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const id = identifier.input.value.trim();
    const pw = password.input.value;
    if (!id || !pw) return say("Email/username and password required");
    submit([identifier.input, password.input, loginBtn], () => PANEL_AUTH.login(id, pw));
  });

  signupForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const mail = email.input.value.trim();
    const pw = newPassword.input.value;
    if (!mail || !pw) return say("Email and password required");
    if (pw.length < 6) return say("Password must be at least 6 characters");
    submit(
      [email.input, username.input, newPassword.input, signupBtn],
      () => PANEL_AUTH.signup(mail, username.input.value.trim(), pw),
    );
  });

  const showForm = (which) => {
    const onLogin = which === "login";
    loginTab.classList.toggle("is-active", onLogin);
    signupTab.classList.toggle("is-active", !onLogin);
    loginTab.setAttribute("aria-pressed", String(onLogin));
    signupTab.setAttribute("aria-pressed", String(!onLogin));
    loginForm.classList.toggle("hidden", !onLogin);
    signupForm.classList.toggle("hidden", onLogin);
    message.className = "pn-msg hidden";
  };
  loginTab.addEventListener("click", () => showForm("login"));
  signupTab.addEventListener("click", () => showForm("signup"));

  wrap.append(tabs, loginForm, signupForm, message);
  return wrap;
}

/** The widgets list — the shipped cards, the user's own under an "Added" heading,
 *  and the reset button. Returned as the nodes the Widgets view lays out, so the
 *  view shows exactly this and there is no second drawing of the list to keep in
 *  step with the first.
 *
 *  Each row shows the widget it controls, drawn live, so the list answers
 *  "what does this put on my page?" rather than "which row is this?". The
 *  previews are built together rather than one per iteration: each one may go
 *  to the network for its data, and the first read caches it for the rest.
 *
 *  The list is built from `settings.widgets` rather than from `WIDGET_KINDS`:
 *  an added panel has an id the kinds list has never heard of, and the things
 *  the added kinds need — a remove affordance, a name of its own — are
 *  per-instance facts that only the stored entries carry. */
/** The one-click way to put a single-icon block on the page.
 *
 *  The kind's own "+" makes another *grid* shortcuts panel, because a kind's
 *  card can only offer the layout its kind defaults to. A single-icon block is
 *  the other half of that idea and the thing people most often want a second of
 *  — one icon per site, not one panel per site — so it gets a control of its
 *  own rather than being two clicks deep in the widget menu of a block that
 *  does not exist yet.
 *
 *  The block it makes starts empty, so it is the block's own "+" tile that asks
 *  for the site. That is deliberate: the panel is 340px and already holds the
 *  whole settings tree, and a two-field form wedged in here would be a third
 *  way to add a site when the page has two. The line underneath names the
 *  faster path — paste — because a user who already has the address copied
 *  should never have to open this panel at all. */
function panelSingleIconAdd() {
  const row = node("div", "pn-add-single");
  const add = node("button", "pn-mini", "+ Single icon");
  add.type = "button";
  add.title = "Place a widget that is one site";
  add.setAttribute("aria-label", "Add a single icon widget");
  add.addEventListener("click", async () => {
    add.disabled = true;
    await PANEL_SAFE.addSingleIconWidget();
    await window.ixiNewtabPage.applySettings();
    await paintPanel();
  });
  row.append(add, node("span", "pn-note", "or paste a link anywhere with Ctrl + V"));
  return row;
}

/** Which face each widget's own dates and numerals wear.
 *
 *  A row per *instance* like the calendar group below, and for the same reason:
 *  two panels side by side answering in different languages is the layout this
 *  setting exists for. It lists every visible widget rather than only the
 *  calendar, because a timer's digits and a weather day's temperature are as
 *  much a reading in the reader's script as a month name is.
 *
 *  Returns `null` when nothing is visible, so the caller can leave the heading
 *  out rather than show it over an empty list. */
function panelFontGroup(settings) {
  // The search bar and the clock are page furniture, not panels, so they carry
  // no `data-font` of their own for a picker to move: the clock's face is the
  // Clock section's business and the box is one system input. A row for either
  // here would be a control that changes nothing on the page.
  const shown = settings.widgets.filter(
    (spec) => spec.visible && !["search", "clock"].includes(PANEL_SAFE.widgetKindOf(spec)),
  );
  if (!shown.length) return null;

  const group = node("div", "pn-group pn-widget-fonts");
  for (const spec of shown) {
    const name = PANEL_SAFE.widgetLabelOf(spec);
    const select = panelSelect(
      PANEL_SAFE.WIDGET_FONTS,
      PANEL_SAFE.widgetFontFor(settings, spec.id),
      async (font) => {
        await PANEL_SAFE.setWidgetFont(spec.id, font);
        await window.ixiNewtabPage.applySettings();
        await paintPanel();
      },
    );
    select.setAttribute("aria-label", `${name} font`);
    // Each option is drawn in the face it names, so the list reads as the choice
    // rather than as four words about it.
    for (const option of select.querySelectorAll("option")) {
      option.style.fontFamily = PANEL_SAFE.widgetFontById(option.value).stack;
    }
    group.append(panelRow(name, select));
  }
  return group;
}

/** Which calendar each calendar panel counts in.
 *
 *  A row per *instance* rather than one page-wide switch, because two calendars
 *  side by side is the layout this setting exists for: a lunar panel next to a
 *  Gregorian one is a single page with two answers, and a global switch could
 *  only ever offer one of them.
 *
 *  Returns `null` when the page has no visible calendar, so the caller can leave
 *  the group out entirely instead of showing an empty heading — the same rule
 *  the "Added" group follows. */
function panelCalendarGroup(settings) {
  const calendars = settings.widgets.filter(
    (spec) => PANEL_SAFE.widgetKindOf(spec) === "calendar" && spec.visible,
  );
  if (!calendars.length) return null;

  const group = node("div", "pn-group pn-calendars");
  for (const spec of calendars) {
    const current = PANEL_SAFE.calendarSystemFor(settings, spec.id);
    const name = PANEL_SAFE.widgetLabelOf(spec);
    const select = panelSelect(PANEL_SAFE.CALENDAR_SYSTEMS, current, async (system) => {
      await PANEL_SAFE.setWidgetCalendar(spec.id, system);
      await window.ixiNewtabPage.applySettings();
      await paintPanel();
    });
    select.setAttribute("aria-label", `${name} calendar`);
    group.append(panelRow(name, select));
  }
  return group;
}

async function panelWidgetsBody(settings) {
  const previews = await Promise.all(
    settings.widgets.map((spec) => buildWidgetPreview(spec, settings)),
  );
  // Which kinds may be placed again, as a set of ids, so the loop below can ask
  // per card instead of the list growing a second section of add buttons.
  const addable = new Set(PANEL_SAFE.addableWidgetKinds().map((k) => k.id));

  // The shipped entry of a kind — the one whose id *is* its kind. Everything
  // else in the list is an instance the user added, and the two are shown apart
  // below so the shipped set stays a fixed, scannable list and the user's own
  // additions cannot push it around.
  const isShipped = (spec) => PANEL_SAFE.widgetKindOf(spec) === spec.id;

  /** One card, wired to the panel's own repaint. Shared by both groups so an
   *  added instance behaves in every way like the shipped one it was made from.
   *  The handlers call `paintPanel` rather than switching view: the current view
   *  is `panelView`, which `paintPanel` re-reads, so a toggle inside this list
   *  lands back on the list it was pressed in. */
  const buildCard = (spec, i) =>
    panelWidgetCard(
      spec,
      previews[i],
      async (v) => {
        await PANEL_SAFE.setWidgetVisible(spec.id, v);
        await window.ixiNewtabPage.applySettings();
        paintPanel();
      },
      async () => {
        await PANEL_SAFE.removeWidget(spec.id);
        await window.ixiNewtabPage.applySettings();
        paintPanel();
      },
      // Every card of an addable kind carries the "+", not just the shipped one.
      // A second shortcut panel is often the thing you want next to a first —
      // one grid and one single-icon block, say — and making the user scroll
      // back to the kind's original card to place it reads as a limit that is
      // not there. The "+" always makes a panel of *this* card's kind, so the
      // two are the same button wherever they appear.
      addable.has(PANEL_SAFE.widgetKindOf(spec))
        ? async () => {
            await PANEL_SAFE.addWidget(PANEL_SAFE.widgetKindOf(spec));
            await window.ixiNewtabPage.applySettings();
            await paintPanel();
          }
        : null,
    );

  const shipped = settings.widgets.map((spec, i) => ({ spec, i })).filter(({ spec }) => isShipped(spec));
  const added = settings.widgets.map((spec, i) => ({ spec, i })).filter(({ spec }) => !isShipped(spec));

  const widgetList = node("div", "pn-group pn-widgets");
  for (const { spec, i } of shipped) widgetList.append(buildCard(spec, i));

  // The user's own panels, under a heading of their own. Built only when there
  // is at least one, so a profile that has added nothing sees exactly the list
  // it always did rather than an empty group with a label over it.
  const children = [widgetList];
  if (added.length) {
    const addedGroup = node("div", "pn-subgroup");
    addedGroup.append(node("h4", "pn-subgroup-title", `Added (${added.length})`));
    const addedList = node("div", "pn-group pn-widgets");
    for (const { spec, i } of added) addedList.append(buildCard(spec, i));
    addedGroup.append(addedList);
    children.push(addedGroup);
  }

  // The calendar-system pickers, under their own heading so the rows read as
  // "which calendar" rather than as more widget switches above them. Omitted
  // entirely when no calendar is visible.
  const calendarGroup = panelCalendarGroup(settings);
  if (calendarGroup) {
    const section = node("div", "pn-subgroup");
    section.append(node("h4", "pn-subgroup-title", "Calendar system"), calendarGroup);
    children.push(section);
  }

  // The font pickers, one row per visible widget, under their own heading for
  // the same reason the calendar ones are: these dress the widgets rather than
  // switch them, and a row that reads like a switch would be the wrong ask.
  const fontGroup = panelFontGroup(settings);
  if (fontGroup) {
    const section = node("div", "pn-subgroup");
    section.append(node("h4", "pn-subgroup-title", "Widget font"), fontGroup);
    children.push(section);
  }

  children.push(panelSingleIconAdd());

  const reset = node("button", "pn-reset", "Reset layout & widgets");
  reset.type = "button";
  reset.addEventListener("click", async () => {
    await PANEL_SAFE.resetWidgets();
    await window.ixiNewtabPage.applySettings();
    paintPanel();
  });
  children.push(reset);

  return children;
}

/** Save the whole page to a file, and put one back.
 *
 *  Three steps rather than one, and the middle one is the point. Picking a file
 *  *reads* it and shows what it holds; nothing is written until Restore is
 *  pressed. A picker that applied immediately would make opening a file to see
 *  what is in it a destructive act — and the one thing a backup is for is the
 *  moment when the current layout is not what you want to lose.
 *
 *  The status line is a `.pn-note` rather than a modal or a toast: it is a
 *  sentence about what just happened, and it belongs next to the buttons that
 *  caused it. */
function panelBackupSection() {
  const wrap = node("div", "pn-backup");
  const status = node("div", "pn-note");
  // A restore repaints the whole panel, which throws this section away — so a
  // message set after the repaint would be written into a node no longer in the
  // document. The note is handed across the repaint instead, and read here on
  // the way back in.
  if (panelBackupNotice) {
    status.textContent = panelBackupNotice;
    panelBackupNotice = null;
  }
  const setStatus = (text, isError = false) => {
    status.textContent = text;
    status.classList.toggle("is-error", isError);
  };

  const picker = node("input", "pn-file-input");
  picker.type = "file";
  picker.accept = "application/json,.json";
  picker.setAttribute("aria-label", "Choose a backup file");

  const exportBtn = node("button", "pn-upload-btn", "Export");
  exportBtn.type = "button";
  exportBtn.addEventListener("click", async () => {
    exportBtn.disabled = true;
    try {
      const result = await window.ixiNewtabBackup.download();
      setStatus(`Saved ${result.name}.`);
    } catch (err) {
      setStatus(err instanceof Error ? err.message : "The backup could not be saved.", true);
    } finally {
      exportBtn.disabled = false;
    }
  });

  const importBtn = node("button", "pn-upload-btn is-quiet", "Import");
  importBtn.type = "button";
  importBtn.addEventListener("click", () => picker.click());

  // The pending file, between choosing and restoring. Drawn into its own row so
  // it can be replaced without rebuilding the section around it.
  const pending = node("div", "pn-note is-pending");
  pending.hidden = true;
  let doc = null;

  const restoreBtn = node("button", "pn-mini", "Restore");
  restoreBtn.type = "button";
  const cancelBtn = node("button", "pn-mini", "Cancel");
  cancelBtn.type = "button";

  const clearPending = () => {
    doc = null;
    pending.hidden = true;
    pending.replaceChildren();
  };
  cancelBtn.addEventListener("click", () => {
    clearPending();
    setStatus("");
  });

  picker.addEventListener("change", async () => {
    const file = picker.files?.[0];
    // Cleared straight away so picking the *same* file twice fires a change
    // event the second time — a file input that remembers its last value is a
    // button that stops working after one use.
    picker.value = "";
    if (!file) return;
    importBtn.disabled = true;
    setStatus("Reading…");
    try {
      const result = await window.ixiNewtabBackup.inspect(file);
      if (!result.ok) {
        clearPending();
        setStatus(result.reason, true);
        return;
      }
      doc = result.doc;
      const when = result.exportedAt ? ` from ${result.exportedAt.slice(0, 10)}` : "";
      const dropped = result.dropped
        ? ` ${result.dropped} ${result.dropped === 1 ? "entry was" : "entries were"} skipped.`
        : "";
      pending.replaceChildren(
        node("span", "pn-backup-summary", `Backup${when}: ${result.summary}.${dropped}`),
        restoreBtn,
        cancelBtn,
      );
      pending.hidden = false;
      setStatus("Nothing has been changed yet.");
    } catch (err) {
      clearPending();
      setStatus(err instanceof Error ? err.message : "That file could not be read.", true);
    } finally {
      importBtn.disabled = false;
    }
  });

  restoreBtn.addEventListener("click", async () => {
    if (!doc) return;
    restoreBtn.disabled = true;
    // Set *before* the restore, not after: the restore ends by repainting this
    // panel, so a note written afterwards would go into a node that is no
    // longer in the document. The fresh section reads it on the way in.
    panelBackupNotice = "Restored.";
    try {
      await window.ixiNewtabBackup.restore(doc);
      clearPending();
    } catch (err) {
      panelBackupNotice = null;
      restoreBtn.disabled = false;
      setStatus(err instanceof Error ? err.message : "The backup could not be restored.", true);
    }
  });

  const row = node("div", "pn-row pn-backup-actions");
  row.append(exportBtn, importBtn, picker);
  wrap.append(row, pending, status);
  return wrap;
}

/** Rebuild the panel's contents from current settings. Called on open and
 *  after every change, which is what keeps the markers honest without any
 *  per-control state to update by hand. */
async function paintPanel() {
  if (!panelBody) return;
  const settings = await PANEL_SAFE.get();
  // Read per paint: the session is the one thing in this panel that another
  // surface (the popup) can change behind it.
  panelSession = await PANEL_AUTH.readSession().catch(() => null);

  // A native <select> rather than a list of radio rows: eight engines stacked
  // as rows filled the whole panel and pushed the widget switches below the
  // fold. The native control also gets keyboard type-ahead, the platform's own
  // popup, and the right behaviour on touch for free, none of which a
  // hand-rolled dropdown would.
  const engineSelect = node("select", "pn-select");
  engineSelect.setAttribute("aria-label", "Search engine");
  for (const engine of PANEL_SAFE.SEARCH_ENGINES) {
    const option = node("option", null, engine.label);
    option.value = engine.id;
    if (settings.engine === engine.id) option.selected = true;
    engineSelect.append(option);
  }
  engineSelect.addEventListener("change", async () => {
    await PANEL_SAFE.set({ engine: engineSelect.value });
    await window.ixiNewtabPage.applySettings();
    // No repaint: the control already shows the new value, and repainting here
    // would collapse an open native popup mid-selection.
  });

  const engineRow = node("div", "pn-field");
  engineRow.append(engineSelect);

  // The search box can be dragged anywhere on the page, and once it is off the
  // centred column there is nothing on screen that says how to get it back —
  // dragging it to a spot and then wanting the old one back is not a rare thing
  // to want. Shown only when there is something to undo, so the section does
  // not carry a dead control in its shipped state.
  const searchReset = node("button", "pn-reset", "Reset search position");
  searchReset.type = "button";
  searchReset.classList.toggle("hidden", settings.searchX == null || settings.searchY == null);
  searchReset.addEventListener("click", async () => {
    await PANEL_SAFE.setSearchPosition(null, null);
    await window.ixiNewtabPage.applySettings();
    paintPanel();
  });

  const clockToggle = panelToggle(settings.clock24 ? "Clock — 24-hour" : "Clock — 12-hour", settings.clock24, async (v) => {
    await PANEL_SAFE.set({ clock24: v });
    await window.ixiNewtabPage.applySettings();
    paintPanel();
  });

  // The clock is draggable like the search box, and the same dead end applies:
  // once it is off the centred column nothing on screen says how to put it
  // back. Shown only when there is something to undo, like the search reset.
  const clockReset = node("button", "pn-reset", "Reset clock position");
  clockReset.type = "button";
  clockReset.classList.toggle("hidden", settings.clockX == null || settings.clockY == null);
  clockReset.addEventListener("click", async () => {
    await PANEL_SAFE.setClockPosition(null, null);
    await window.ixiNewtabPage.applySettings();
    paintPanel();
  });

  // The clock's face. A select rather than a row of radio buttons because the
  // faces are named rather than shown — each label is set in the face it
  // selects, which is the preview.
  const fontSelect = panelSelect(PANEL_SAFE.CLOCK_FONTS, settings.clockFont, async (id) => {
    await PANEL_SAFE.set({ clockFont: id });
    await window.ixiNewtabPage.applySettings();
    paintPanel();
  }, { id: "__aria", label: "", aria: "Clock font" });
  // The blank first option is only there to carry the accessible name; drop it,
  // since the caption beside the control already says what this is.
  fontSelect.firstChild?.remove();
  for (const option of fontSelect.options) {
    const face = PANEL_SAFE.clockFontById(option.value);
    option.style.fontFamily = face.stack;
    // Several faces share a family and differ only by cut, so the weight and
    // slant have to travel with the family or "Hairline" and "Black" would
    // preview as the same thing.
    option.style.fontWeight = String(face.weight ?? 400);
    option.style.fontStyle = face.style ?? "normal";
  }

  const sizeSlider = panelSlider(
    "Clock size",
    { min: 40, max: 140, value: Number(settings.clockSize) || 68, format: (n) => `${n}px` },
    // Live: a size you cannot see while dragging the slider is a size you have
    // to guess at. Only the clock is touched, so this is cheap.
    (n) => {
      const el = document.getElementById("clock-time");
      if (el) el.style.fontSize = `${n}px`;
    },
    async (n) => {
      await PANEL_SAFE.set({ clockSize: n });
      await window.ixiNewtabPage.applySettings();
    },
  );

  // When the page is on screen at all. Both ends are inclusive and blank means
  // "no bound", so the shipped state is always-visible and a schedule is opt-in.
  const fromField = panelText(settings.scheduleFrom, {
    type: "datetime-local",
    label: "Show from",
    onInput: (v) => PANEL_SAFE.set({ scheduleFrom: v }).then(() => window.ixiNewtabPage.applySettings()),
  });
  const toField = panelText(settings.scheduleTo, {
    type: "datetime-local",
    label: "Show until",
    onInput: (v) => PANEL_SAFE.set({ scheduleTo: v }).then(() => window.ixiNewtabPage.applySettings()),
  });

  const pageStyleSelect = panelSelect(PANEL_SAFE.WIDGET_STYLES, settings.widgetStyle ?? "glass", async (id) => {
    await PANEL_SAFE.set({ widgetStyle: id });
    await window.ixiNewtabPage.applySettings();
    paintPanel();
  }, { id: "__aria", label: "", aria: "Default widget style" });
  pageStyleSelect.firstChild?.remove();

  // A page-wide rule about how the panels may be arranged rather than a fact
  // about any one of them, so it sits with the page-wide style above the
  // per-widget list. Off is the free arrangement the page shipped with; on is
  // the one the switch explains.
  const noOverlapToggle = panelToggle(
    "Keep widgets from overlapping",
    !PANEL_SAFE.widgetOverlapAllowed(settings),
    async (v) => {
      await PANEL_SAFE.set({ widgetNoOverlap: v });
      await window.ixiNewtabPage.applySettings();
      paintPanel();
    },
  );

  // ── wallpaper ───────────────────────────────────────────────────────────
  const wallpaperPreview = node("div", "pn-wp-preview");
  wallpaperPreview.style.setProperty("--wp-pattern", "");
  const patternSelect = panelSelect(
    PANEL_SAFE.WALLPAPER_PATTERNS,
    settings.wallpaperPattern ?? "none",
    async (id) => {
      await PANEL_SAFE.set({ wallpaperPattern: id });
      await window.ixiNewtabPage.applySettings();
      paintPanel();
    },
    { id: "__aria", label: "", aria: "Backdrop pattern" },
  );
  patternSelect.firstChild?.remove();

  const urlField = panelText(settings.wallpaperUrl, {
    type: "url",
    placeholder: "https://…/photo.jpg",
    label: "Image URL",
    // Live as it is typed: the page is right there behind the panel, and having
    // to blur the field to see whether a URL resolved would be a bad trade.
    onInput: (v) => PANEL_SAFE.set({ wallpaperUrl: v.trim() }).then(() => window.ixiNewtabPage.applySettings()),
  });
  // `urlField` stays the bare input so the preview below can read its `.value`;
  // what the panel lays out is this wrapper, with the × on the end.
  const urlRow = panelClearable(urlField, () => {
    PANEL_SAFE.set({ wallpaperUrl: "" }).then(() => {
      window.ixiNewtabPage.applySettings();
      paintPanel();
    });
  });

  const uploader = panelWallpaperUpload(settings);

  const dimSlider = panelSlider(
    "Dim",
    { min: 0, max: 90, value: Number(settings.wallpaperDim) ?? 45, format: (n) => `${n}%` },
    (n) => wallpaperPreview.style.setProperty("--wp-dim", String(n / 100)),
    async (n) => {
      await PANEL_SAFE.set({ wallpaperDim: n });
      await window.ixiNewtabPage.applySettings();
    },
  );

  // Opacity and blur sit beside Dim but are not the same control. Dim is a black
  // veil over the whole backdrop, so raising it crushes a photo toward black;
  // opacity is the photo's own alpha, so lowering it fades the photo into the
  // black paper instead — the two do not substitute for each other. Blur softens
  // the photo alone.
  //
  // Read defensively: a blob written before these two settings existed has
  // neither field, and `Number(undefined)` is NaN, which no slider can hold.
  // 100/0 is exactly the untouched look such a blob expects.
  const opacityValue = Number.isFinite(Number(settings.wallpaperOpacity)) ? Number(settings.wallpaperOpacity) : 100;
  const blurValue = Number.isFinite(Number(settings.wallpaperBlur)) ? Number(settings.wallpaperBlur) : 0;
  const opacitySlider = panelSlider(
    "Image opacity",
    { min: 0, max: 100, value: opacityValue, format: (n) => `${n}%` },
    (n) => wallpaperPreview.style.setProperty("--wp-opacity", String(n / 100)),
    async (n) => {
      await PANEL_SAFE.set({ wallpaperOpacity: n });
      await window.ixiNewtabPage.applySettings();
    },
  );
  // 40px is past the point where a full-screen photo is recognisable as anything
  // but colour, so the slider tops out where the setting stops being useful
  // rather than offering a range whose last half all looks the same.
  const blurSlider = panelSlider(
    "Blur",
    { min: 0, max: 40, value: blurValue, format: (n) => `${n}px` },
    (n) => wallpaperPreview.style.setProperty("--wp-blur", `${n}px`),
    async (n) => {
      await PANEL_SAFE.set({ wallpaperBlur: n });
      await window.ixiNewtabPage.applySettings();
    },
  );

  // The section heads and their controls are assembled at the end, so a section
  // that has nothing to show can simply not be appended.

  // There is no pin picker here. Pinning is done from the bookmarks widget
  // itself, where the bookmark is on screen and the row is already in front of
  // the user; a second copy of the whole list in the panel was a scroll box
  // that repeated what the widget shows and pushed Appearance below the fold.

  // The accent swatches show the hue the page is actually painting with, which
  // depends on the theme: `ACCENTS` carries a second hex tuned for paper, and
  // the swatch is the one place a user compares the five side by side, so it
  // has to answer in the current theme or it lies about what picking one does.
  const accentIsLight = PANEL_SAFE.themeIsLight(settings);
  // The accent the page is really painting, not merely the stored choice. A
  // stored `"custom"` with no usable hex resolves to the first preset (see
  // `resolveAccent`), so an orphaned choice must not light the custom swatch
  // while the page draws something else — and the preset swatches must light
  // the one it fell back to, or the row would show nothing selected at all.
  const customAccent = PANEL_SAFE.sanitiseAccentHex(settings.customAccent);
  const customChosen = settings.accent === "custom" && Boolean(customAccent);
  const activeAccentId =
    settings.accent === "custom" && !customAccent ? PANEL_SAFE.ACCENTS[0].id : settings.accent;
  const accents = node("div", "pn-accents");
  for (const accent of PANEL_SAFE.ACCENTS) {
    const swatch = node("button", activeAccentId === accent.id ? "pn-swatch is-on" : "pn-swatch");
    swatch.type = "button";
    swatch.title = accent.label;
    swatch.setAttribute("aria-label", `Accent ${accent.label}`);
    swatch.setAttribute("aria-pressed", String(activeAccentId === accent.id));
    swatch.style.setProperty("--swatch", PANEL_SAFE.accentValueFor(accent, accentIsLight));
    swatch.addEventListener("click", async () => {
      // Only `accent` is written, never `customAccent` — the two are separate
      // fields precisely so that picking a preset keeps the user's custom hex
      // stored, ready for the swatch below to return to.
      await PANEL_SAFE.set({ accent: accent.id });
      await window.ixiNewtabPage.applySettings();
      paintPanel();
    });
    accents.append(swatch);
  }

  // The sixth choice: a real colour input, which is the one control here that
  // needs a whole picker and so borrows the platform's. It is a peer of the
  // presets, not a separate setting, so it sits in the same row and wears the
  // same `is-on` state.
  const customSwatch = node("input", "pn-swatch-color");
  customSwatch.type = "color";
  customSwatch.title = "Custom accent colour";
  customSwatch.setAttribute("aria-label", "Custom accent colour");
  // With no colour chosen yet the input still needs a value — a native colour
  // input cannot be blank — so it is seeded with the resolved page accent while
  // `is-empty` draws the neutral ring over the top, keeping the seed from
  // reading as a choice already made.
  const painted = PANEL_SAFE.resolveAccent(settings);
  customSwatch.value = customAccent ?? PANEL_SAFE.accentValueFor(painted, accentIsLight);
  if (!customAccent) customSwatch.classList.add("is-empty");
  if (customChosen) customSwatch.classList.add("is-on");
  // Live while the chooser is open. `--accent` is written straight to the root,
  // exactly as `applySettings` would, so the page behind previews the hue as it
  // is dragged — but storage is deliberately left alone, because a colour
  // picker fires this on every pixel of a drag and the blob is mirrored to the
  // account.
  customSwatch.addEventListener("input", () => {
    document.documentElement.style.setProperty("--accent", customSwatch.value);
  });
  // Committed on `change` — the picker closing, which is the moment the user
  // means it. Same flow as a preset press: write, apply, repaint.
  customSwatch.addEventListener("change", async () => {
    await PANEL_SAFE.set({ accent: "custom", customAccent: customSwatch.value });
    await window.ixiNewtabPage.applySettings();
    paintPanel();
  });
  accents.append(customSwatch);

  // Theme and accent share a section because they are one decision — "what the
  // page is made of" — and because the accent's correct hex depends on the
  // theme above it. A native `<select>` rather than a three-way switch: it is
  // keyboard-operable for free, the arrow keys already move between options,
  // and it matches every other choice in this panel.
  const themeSelect = panelSelect(
    [
      { id: "system", label: "System" },
      { id: "light", label: "Light" },
      { id: "dark", label: "Dark" },
    ],
    settings.theme ?? "system",
    async (value) => {
      await PANEL_SAFE.setTheme(value);
      await window.ixiNewtabPage.applySettings();
      // The whole panel repaints: every swatch, preview and thumbnail wearing a
      // hardcoded dark value has to follow, and the swatch row's own hues come
      // from the other theme.
      paintPanel();
    },
  );

  // The wallpaper section is preview-led: a small swatch of the chosen pattern
  // (or image, if one is set) above the controls, because "Dots" and "Grid" are
  // two words for two very different densities and a preview settles it faster
  // than applying each one and looking at the page behind the panel.
  // Painted from the same map the page paints from, so the swatch cannot show
  // a pattern the page will not draw.
  const paintWallpaperPreview = (patternId, urlValue) => {
    const pattern = window.ixiNewtabPage.WALLPAPER_CSS[patternId] ?? window.ixiNewtabPage.WALLPAPER_CSS.none;
    wallpaperPreview.style.setProperty("--wp-pattern", pattern.image);
    wallpaperPreview.style.setProperty("--wp-pattern-size", pattern.size);
    wallpaperPreview.style.setProperty("--wp-image", urlValue ? `url("${urlValue.replace(/["\\]/g, "")}")` : "none");
  };
  // The swatch shows the same precedence `applyWallpaper` applies, so an upload
  // is what the preview draws once one exists.
  const paintFromState = () => {
    const upload = uploader.currentImage();
    paintWallpaperPreview(settings.wallpaperPattern, upload || urlField.value.trim());
  };
  paintFromState();
  wallpaperPreview.style.setProperty("--wp-dim", String((Number(settings.wallpaperDim) ?? 45) / 100));
  wallpaperPreview.style.setProperty("--wp-opacity", String(opacityValue / 100));
  wallpaperPreview.style.setProperty("--wp-blur", `${blurValue}px`);
  // Typing in the URL field repaints the swatch too, so it keeps up with the
  // page rather than only with the stored value.
  urlField.addEventListener("input", paintFromState);
  uploader.onChange(paintFromState);

  // A sub-view replaces the whole body: the header's back control and the one
  // gallery the view is for, with nothing else — the point of moving the gallery
  // here is to be the whole panel while it is open.
  if (panelView === "decor") {
    panelBody.replaceChildren(
      panelSubView("Decor gallery", [panelDecorHead(settings.decor.length), panelDecorGallery()]),
    );
    return;
  }
  if (panelView === "widgets") {
    panelBody.replaceChildren(panelSubView("Widgets", await panelWidgetsBody(settings)));
    return;
  }

  // The collapsed summaries. Both count the same live `settings` the views do, so
  // the section says what opening it would show without building the list.
  const onCount = settings.widgets.filter((spec) => spec.visible).length;
  const decorSummary = settings.decor.length
    ? `${settings.decor.length} on the page.`
    : "Nothing placed yet.";
  const widgetSummary = `${onCount} of ${settings.widgets.length} on.`;
  // The bang list lives in its own modal — it is a scrollable catalogue of two
  // dozen platforms, which is not a section of a panel. This row is the way in
  // when the search box's own button is not where the user is looking.
  const bangSummary = settings.searchBangs.length
    ? `${settings.searchBangs.length} set. Type one at the start of a search.`
    : "None set.";

  // The account leads, because it is the one thing here that changes what the
  // page can show at all — every widget but the clock is empty without it.
  panelBody.replaceChildren(
    panelSection(panelSession?.email ? "Account" : "Account — sign in", panelAccountSection()),
    panelSection("Search engine", engineRow, searchReset),
    panelSection("Search bangs", panelExpand(bangSummary, "Manage bangs", () => window.ixiNewtabBangs.open())),
    panelSection("Clock", clockToggle, panelRow("Face", fontSelect), sizeSlider, clockReset),
    panelSection("Show between", panelRow("From", fromField), panelRow("Until", toField),
      node("div", "pn-note", "Leave either blank to keep the page always open.")),
    panelSection("Backdrop", wallpaperPreview, panelRow("Pattern", patternSelect), panelRow("Image", urlRow), uploader.node, dimSlider, opacitySlider, blurSlider),
    panelSection("Decor", panelExpand(decorSummary, "Open decor gallery", () => setPanelView("decor"))),
    panelSection("Widgets", panelExpand(widgetSummary, "Edit widgets", () => setPanelView("widgets"))),
    panelSection("Widget default", panelRow("Style", pageStyleSelect), noOverlapToggle),
    panelSection("Appearance", panelRow("Theme", themeSelect), accents),
    // Last, because it is the only section that acts on every other one at
    // once. It reads better after the things it saves than before them.
    panelSection("Backup",
      panelBackupSection(),
      node("div", "pn-note", "A backup holds the layout, theme, accent, fonts, shortcuts and their icons, the uploaded wallpaper, and the local lists and timers in this browser. All of it goes into one file.")),
  );
}

/** Wired once, at load. The scrim is exactly the page's own area, so a piece of
 *  art dragged out of the gallery and dropped on it lands where the user aimed
 *  rather than on nothing — without this a drag can only ever be cancelled,
 *  because the panel covers the page it is being dragged onto. */
function panelWireDecorDrop() {
  PANEL_DECOR.decorDropTarget(document.getElementById("settings-scrim"));
  PANEL_DECOR.decorDropTarget(document.getElementById("decor-layer"));
}

/** Open the panel, revealing one section and briefly marking it.
 *
 *  The page's right-click menu offers "Widgets" as a destination, and a menu
 *  item that opened the panel at the top would leave the user to scroll past
 *  five other sections to find the thing they picked. `paintPanel` is awaited
 *  because the sections do not exist until it has run — and it is genuinely
 *  asynchronous, since it reads the session and the bookmark list.
 *
 *  The flash is a short-lived class rather than a scroll-and-hope: `scrollInto
 *  view` on its own is invisible when the section is already on screen, and the
 *  user then has no way to tell whether the command did anything.
 *
 *  "Decor" and "Widgets" have outgrown a section — their content is a whole
 *  panel now — so asking for one opens its view. That is the useful reading of
 *  "take me to Widgets", and it is what the page menu's item depends on. */
async function panelOpenSection(title) {
  const view = { Decor: "decor", Widgets: "widgets" }[title];
  const host = document.getElementById("settings-panel");
  // A plain destination while a sub-view is open has to come back to the list
  // first, or there is no section on screen to scroll to.
  if (host?.classList.contains("hidden") || !panelBody) await panelOpen();
  else if (!view && panelView) await setPanelView(null);
  else if (!view) await paintPanel();
  if (!panelBody) return;

  if (view) {
    await setPanelView(view);
    return;
  }

  const wanted = [...panelBody.querySelectorAll(".pn-sec")].find(
    (s) => s.querySelector(".pn-sec-title")?.textContent === title,
  );
  if (!wanted) return;
  wanted.scrollIntoView({ block: "start", behavior: "smooth" });
  wanted.classList.add("is-flash");
  setTimeout(() => wanted.classList.remove("is-flash"), 1400);
}

async function panelOpen() {
  const host = document.getElementById("settings-panel");
  const scrim = document.getElementById("settings-scrim");
  if (!host || !scrim) return;
  panelBody = document.getElementById("settings-body");
  // Forced to re-read, so a sign-out in the popup since the last open is not
  // still showing a signed-in account here.
  panelSession = null;
  // A fresh open lands on the settings list, not wherever the last one was left.
  panelView = null;
  host.classList.remove("hidden");
  scrim.classList.remove("hidden");
  await paintPanel();
  // Focus the first control so the panel is keyboard-drivable from the moment
  // it opens, and so Escape lands on something inside it. `.pn-select` is the
  // engine picker, which is the panel's first control — `.pn-choice` was the
  // radio rows it replaced, and had been matching nothing since.
  panelBody.querySelector(".pn-select")?.focus();
}

function panelClose() {
  const host = document.getElementById("settings-panel");
  const scrim = document.getElementById("settings-scrim");
  if (!host || !scrim) return;
  host.classList.add("hidden");
  scrim.classList.add("hidden");
  document.getElementById("settings-toggle")?.focus();
}

document.addEventListener("keydown", (e) => {
  if (e.key === "Escape") panelClose();
});

panelWireDecorDrop();

window.ixiNewtabPanel = {
  open: panelOpen,
  close: panelClose,
  paint: paintPanel,
  openSection: panelOpenSection,
};
