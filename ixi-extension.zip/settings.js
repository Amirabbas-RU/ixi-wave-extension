// Per-user settings for the new tab page.
//
// The working copy lives in `chrome.storage.local` and is what the page reads:
// a new tab has to render instantly and offline, so storage — never the network
// — is what `get()` touches. When a session exists the same blob is mirrored to
// the account, so signing in on another machine reinstates the layout instead
// of handing the user a default page. Storage is the cache; the account is the
// durable copy.
//
// Defaults are applied on read rather than written on install, so a profile
// that has never opened settings still gets the full page.

const SETTINGS_KEY = "ixiNewtab";

/**
 * The schema version this build writes, and the floor it will still read.
 *
 * The settings blob carries no version today, so a new build cannot tell a
 * profile it wrote from one an older build wrote — it just spreads the stored
 * fields over the new defaults, which means every default the user never
 * explicitly set is overwritten on upgrade and a widget kind that no longer
 * exists is silently dropped. A version number makes both visible: the blob is
 * now stamped on write, and a read below the current version runs the
 * migration for that jump before the page ever sees it.
 *
 * Bumping this is a release decision, not a code one: every bump has to ship a
 * migration that lands the old shape on the new one, and a migration that
 * cannot run (a field renamed with nowhere to put the old value) is a reason
 * to keep the old field rather than to bump. The table below is the contract.
 */
const SCHEMA_VERSION = 2;

// The account mirror. `GET` returns `{ config: object | null }` and a new
// account legitimately has none, so null is a normal answer rather than an
// error. `PUT` replaces the whole blob — it is a document, not a patch, which
// is what makes a failed push self-heal on the next change.
const SYNC_PATH = "/api/admin/newtab-config";

// A drag of the clock-size or wallpaper-dim slider fires a write per pixel, and
// each one would otherwise be a request. Debouncing collapses a drag into one
// PUT of the final value. Long enough to cover a drag, short enough that a
// change is durable before the user can close the tab.
const SYNC_PUSH_DELAY_MS = 600;

// The server's own cap, mirrored so an oversized blob is dropped here instead
// of being sent to earn a guaranteed 400.
const SYNC_MAX_BYTES = 256 * 1024;

// The engines offered in the settings panel. `url` is built from the query
// alone, which is the one property that matters here: a result URL that needs a
// token or a redirect bounce cannot be assembled on the client.
//
// DuckDuckGo leads because it is the default — no redirect hop, no ad tracking.
const SEARCH_ENGINES = [
  { id: "ddg", label: "DuckDuckGo", hint: "ddg", url: "https://duckduckgo.com/?q=" },
  { id: "google", label: "Google", hint: "goog", url: "https://www.google.com/search?q=" },
  { id: "brave", label: "Brave", hint: "brave", url: "https://search.brave.com/search?q=" },
  { id: "bing", label: "Bing", hint: "bing", url: "https://www.bing.com/search?q=" },
  { id: "startpage", label: "Startpage", hint: "sp", url: "https://www.startpage.com/sp/search?query=" },
  { id: "ecosia", label: "Ecosia", hint: "eco", url: "https://www.ecosia.org/search?q=" },
  { id: "wikipedia", label: "Wikipedia", hint: "wiki", url: "https://en.wikipedia.org/w/index.php?search=" },
  { id: "github", label: "GitHub", hint: "gh", url: "https://github.com/search?q=" },
];

/** The platforms a search bang can point at.
 *
 *  Each row is `{ trigger, label, url, home, group }`. `url` is the *template*
 *  the typed words go into and carries a literal `%s` — a prefix would not do,
 *  because the query is not always a query parameter (`map` searches a path
 *  segment, `spotify` likewise). `home` is where a bare trigger with no words
 *  goes; it is written out rather than derived from the template's origin,
 *  because a bare `map` should reach `/maps` and not the Google front page.
 *  `note` is an optional caveat the modal prints under the row.
 *
 *  `group` is presentation only — the modal buckets the catalogue by it, in the
 *  order the first row of each group appears here.
 *
 *  Google Maps and Spotify are why `%s` is a template rather than a query
 *  prefix: their search words are a path segment, which no prefix can express. */
const BANG_CATALOG = [
  { trigger: "pp", label: "Perplexity", group: "Search & AI", url: "https://www.perplexity.ai/search?q=%s", home: "https://www.perplexity.ai" },
  // ChatGPT and Claude no longer auto-run a query that arrives from another
  // page — both still land with the words in the box, which is most of the way
  // there and is worth saying rather than leaving to look broken.
  { trigger: "gpt", label: "ChatGPT", group: "Search & AI", url: "https://chatgpt.com/?q=%s", home: "https://chatgpt.com", note: "Opens with the words in the box — press Enter to send." },
  { trigger: "claude", label: "Claude", group: "Search & AI", url: "https://claude.ai/new?q=%s", home: "https://claude.ai", note: "Opens with the words in the box — press Enter to send." },
  { trigger: "gi", label: "Google Images", group: "Search & AI", url: "https://www.google.com/search?tbm=isch&q=%s", home: "https://www.google.com/imghp" },
  { trigger: "tr", label: "Google Translate", group: "Search & AI", url: "https://translate.google.com/?text=%s", home: "https://translate.google.com" },

  { trigger: "wiki", label: "Wikipedia", group: "Reference", url: "https://en.wikipedia.org/w/index.php?search=%s", home: "https://en.wikipedia.org" },
  { trigger: "arch", label: "Arch Wiki", group: "Reference", url: "https://wiki.archlinux.org/index.php?search=%s", home: "https://wiki.archlinux.org" },
  { trigger: "mdn", label: "MDN", group: "Reference", url: "https://developer.mozilla.org/en-US/search?q=%s", home: "https://developer.mozilla.org" },
  { trigger: "map", label: "Google Maps", group: "Reference", url: "https://www.google.com/maps/search/%s", home: "https://www.google.com/maps" },
  { trigger: "imdb", label: "IMDb", group: "Reference", url: "https://www.imdb.com/find/?q=%s", home: "https://www.imdb.com" },

  { trigger: "gh", label: "GitHub", group: "Dev", url: "https://github.com/search?q=%s", home: "https://github.com" },
  { trigger: "so", label: "Stack Overflow", group: "Dev", url: "https://stackoverflow.com/search?q=%s", home: "https://stackoverflow.com" },
  { trigger: "npm", label: "npm", group: "Dev", url: "https://www.npmjs.com/search?q=%s", home: "https://www.npmjs.com" },
  { trigger: "pypi", label: "PyPI", group: "Dev", url: "https://pypi.org/search/?q=%s", home: "https://pypi.org" },
  { trigger: "crates", label: "crates.io", group: "Dev", url: "https://crates.io/search?q=%s", home: "https://crates.io" },
  { trigger: "hf", label: "Hugging Face", group: "Dev", url: "https://huggingface.co/models?search=%s", home: "https://huggingface.co" },

  { trigger: "yt", label: "YouTube", group: "Media", url: "https://www.youtube.com/results?search_query=%s", home: "https://www.youtube.com" },
  { trigger: "spotify", label: "Spotify", group: "Media", url: "https://open.spotify.com/search/%s", home: "https://open.spotify.com" },
  { trigger: "sc", label: "SoundCloud", group: "Media", url: "https://soundcloud.com/search?q=%s", home: "https://soundcloud.com" },
  { trigger: "tw", label: "Twitch", group: "Media", url: "https://www.twitch.tv/search?term=%s", home: "https://www.twitch.tv" },

  { trigger: "reddit", label: "Reddit", group: "Social", url: "https://www.reddit.com/search/?q=%s", home: "https://www.reddit.com" },
  { trigger: "x", label: "X", group: "Social", url: "https://x.com/search?q=%s", home: "https://x.com" },

  { trigger: "amz", label: "Amazon", group: "Shopping", url: "https://www.amazon.com/s?k=%s", home: "https://www.amazon.com" },
];

/** The triggers that work the moment the extension is installed. The rest of
 *  the catalogue is one click away in the modal, so the shipped list stays short
 *  enough to read and nothing is missing. */
const STARTER_BANGS = ["yt", "gh", "wiki", "map"];

/** A catalogue row as a stored bang. The id is derived from the trigger
 *  (`c:yt`) rather than minted, so the shipped four keep one identity across
 *  reloads and a profile that never edited them can be reset back to the exact
 *  entries they shipped with. */
function bangFromCatalog(entry) {
  return {
    id: `c:${entry.trigger}`,
    trigger: entry.trigger,
    label: entry.label,
    url: entry.url,
    home: entry.home,
  };
}

/** Derived rather than written out, so the shipped four cannot drift from the
 *  catalogue rows the modal offers — there is one definition of what `yt` means. */
const DEFAULT_BANGS = BANG_CATALOG.filter((b) => STARTER_BANGS.includes(b.trigger)).map(bangFromCatalog);

/** Key each widget by id, with its label for the settings list. A widget that
 *  appears here but not in `widgets.js` simply renders nothing — the two lists
 *  are independent so neither has to be reordered when the other changes.
 *
 *  `multiple: true` marks a kind the user may place more than once: each
 *  placement is its own widget with its own position, size and contents. Every
 *  other kind is a singleton — a second clock or a second calendar would only
 *  be the same panel twice. See `defaultWidgets` for how an entry's `kind`
 *  relates to its `id`. */
const WIDGET_KINDS = [
  { id: "timers", label: "Running timers", multiple: true },
  { id: "tasks", label: "Open tasks", multiple: true },
  { id: "bookmarks", label: "Bookmarks", multiple: true },
  { id: "calendar", label: "Calendar", multiple: true },
  { id: "clock", label: "Clock", multiple: true },
  // Each instance holds its own set of pinned sites and is one click away from
  // every one of them — the whole point is that a user who wants "work" and
  // "media" in separate corners is not forced to choose.
  { id: "shortcuts", label: "Shortcuts", multiple: true },
  { id: "weather", label: "Weather", multiple: true },
  // The page's two pieces of furniture, listed with the widgets so they can be
  // added and removed on the same terms. Neither is a panel: `search` draws the
  // box at the top of the page (see `placeSearch`), and the clock's entry above
  // already switches the block. `multiple` is off for both — there is one of
  // each on a page by definition, and a second search box would have no meaning.
  { id: "search", label: "Search bar", multiple: false },
];

/** The faces the big clock can wear. `stack` is the CSS font stack, resolved
 *  here rather than in a CSS class per face so one `style.fontFamily` write can
 *  change it — and so a face that fails to load falls back to the mono the rest
 *  of the page uses rather than to the browser's default serif.
 *
 *  The pixel cuts are display faces: they have one weight, no italics, and they
 *  are legible only large, which is precisely what a 68px clock is. */
/** The faces the big clock can wear.
 *
 *  Each entry carries the cut it renders at — `weight` and `style` — because a
 *  family is not one weight. Asking an @font-face for a weight it does not ship
 *  makes the browser synthesise one, and a synthesised bold smears a pixel grid
 *  into something that is neither face, so the two are stored together and
 *  `theme.css` declares exactly these cuts. `mono` is first: `clockFontById`
 *  falls back to `[0]`, so that is the face an unknown id resolves to.
 *
 *  The pixel cuts ship 400 only; the mono and the sans each ship every weight
 *  listed here, which is why they can be worn hairline or black. */
const CLOCK_FONTS = [
  { id: "mono", label: "Mono", stack: '"Geist Mono", ui-monospace, monospace', weight: 500 },
  { id: "mono-bold", label: "Mono Bold", stack: '"Geist Mono", ui-monospace, monospace', weight: 700 },
  { id: "sans", label: "Sans", stack: '"Geist Sans", system-ui, sans-serif', weight: 400 },
  { id: "thin", label: "Hairline", stack: '"Geist Sans", system-ui, sans-serif', weight: 100 },
  { id: "bold", label: "Bold", stack: '"Geist Sans", system-ui, sans-serif', weight: 700 },
  { id: "black", label: "Black", stack: '"Geist Sans", system-ui, sans-serif', weight: 900 },
  { id: "square", label: "Square", stack: '"Geist Pixel Square", "Geist Mono", monospace', weight: 400 },
  { id: "grid", label: "Grid", stack: '"Geist Pixel Grid", "Geist Mono", monospace', weight: 400 },
  { id: "line", label: "Line", stack: '"Geist Pixel Line", "Geist Mono", monospace', weight: 400 },
  { id: "circle", label: "Circle", stack: '"Geist Pixel Circle", "Geist Mono", monospace', weight: 400 },
  { id: "triangle", label: "Triangle", stack: '"Geist Pixel Triangle", "Geist Mono", monospace', weight: 400 },
  // Effect faces: the same mono, dressed rather than re-cut. `effect` names a
  // rule in newtab.css — there is no font behind these, which is why they need
  // no new file, and why the picker's option preview (a font stack) cannot show
  // them. The live clock behind the panel is the preview.
  { id: "outline", label: "Outline", stack: '"Geist Mono", ui-monospace, monospace', weight: 700, effect: "outline" },
  { id: "glow", label: "Glow", stack: '"Geist Mono", ui-monospace, monospace', weight: 500, effect: "glow" },
];

/** How a floating widget is framed. The head/body geometry is identical in all
 *  of them; only the surface changes, which is what makes the picker in the
 *  panel able to render each one as a live miniature of the real thing.
 *
 *  `glass` is the shipped default — the translucent blurred panel the page has
 *  always drawn. */
const WIDGET_STYLES = [
  { id: "glass", label: "Glass" },
  { id: "solid", label: "Solid" },
  { id: "outline", label: "Outline" },
  { id: "accent", label: "Accent" },
  { id: "glow", label: "Glow" },
  { id: "bare", label: "Bare" },
];

/** The layouts the calendar panel can wear.
 *
 *  A *variant* is a different thing from a `WIDGET_STYLES` treatment: the style
 *  changes the panel's material (glass, solid, outline), while the variant
 *  changes what the widget draws inside itself. A calendar keeps its grid but
 *  can present it as a dense block, spaced dots, week rows, a timeline, or a
 *  headline date — the same cells, rearranged.
 *
 *  `grid` is the shipped default and is what the widget has always drawn.
 *
 *  The six after it divide into two families. `dots`, `week`, `outline` and
 *  `agenda` are *readings of the month* — the grid's own cells laid out for a
 *  different question ("which days are past", "what date is Friday", "what is
 *  left"). `focus`, `timeline` and `year` are the modern ones: they stop trying
 *  to show thirty-one cells at once and instead give the thing a small panel can
 *  actually say — today, this week, this year — the room to say it. */
const CALENDAR_STYLES = [
  { id: "grid", label: "Grid" },
  { id: "focus", label: "Today" },
  { id: "timeline", label: "Week strip" },
  { id: "year", label: "Year" },
  { id: "dots", label: "Dots" },
  { id: "week", label: "Week rows" },
  { id: "outline", label: "Outline" },
  { id: "agenda", label: "Agenda" },
];

/** The faces a widget's own text may wear.
 *
 *  `mono` is the shipped page face and first in the list, so it is what an
 *  unknown or unset id resolves to — the same fallback rule `CLOCK_FONTS` uses.
 *
 *  A face may carry a `locale`. That is not decoration: a Persian face is
 *  chosen by someone reading Persian, so the dates and the numerals inside that
 *  widget come out in Persian too — `آبان ۱۴۰۵` rather than `October 2026`.
 *  `locale` is the tag handed to `Intl`, and it decides the digits as well as
 *  the month and weekday names — which is why there is no separate
 *  numbering-system field to keep in step with it.
 *
 *  The widget's *labels* stay English either way. This changes what the widget
 *  counts and names, not what the page says about itself. */
const WIDGET_FONTS = [
  { id: "mono", label: "Mono", stack: '"Geist Mono", ui-monospace, monospace', locale: null },
  { id: "sans", label: "Sans", stack: '"Geist Sans", system-ui, sans-serif', locale: null },
  { id: "vazirmatn", label: "Vazirmatn", stack: '"Vazirmatn", "Geist Sans", sans-serif', locale: "fa-IR" },
  { id: "doran", label: "Doran", stack: '"Doran", "Vazirmatn", "Geist Sans", sans-serif', locale: "fa-IR" },
];

/** Which calendar a widget counts in.
 *
 *  `gregory` is the shipped default. The other two are drawn by the browser's
 *  own `Intl` calendar machinery rather than by lookup tables: `islamic-umalqura`
 *  is the Umm al-Qura computation Saudi Arabia uses to fix its months, and
 *  `persian` is the Solar Hijri calendar (`شمسی`). Both come with month names,
 *  weekday names and era markers in the reader's own locale, and both stay
 *  correct for years this build has never heard of — a bundled table would not.
 *
 *  `id` is the value `Intl` takes, so nothing downstream has to keep a second
 *  vocabulary; `label` is what the picker says. */
const CALENDAR_SYSTEMS = [
  { id: "gregory", label: "Gregorian میلادی" },
  { id: "islamic-umalqura", label: "Hijri قمری" },
  { id: "persian", label: "Persian شمسی" },
];

/** The layouts the bookmarks panel can wear.
 *
 *  `folders` is the shipped default — the tag-grouped list with pins lifted to
 *  the top. The other three trade that structure away for something else:
 *  `pinned` shows only what has been pinned, `compact` is a flat dense list with
 *  no subtitles, and `search` adds a filter field and an inline form so a link
 *  can be saved from the new tab itself. */
const BOOKMARK_STYLES = [
  { id: "folders", label: "Folders" },
  { id: "pinned", label: "Pinned only" },
  { id: "compact", label: "Compact" },
  { id: "search", label: "Search & add" },
];

/** The layouts the tasks panel can wear.
 *
 *  `summary` is the shipped default — a read-only digest of what is open across
 *  the first few lists. `picker` makes the widget a working surface instead:
 *  choose which list it shows, tick items off, and add a task without leaving
 *  the new tab. */
const TASK_STYLES = [
  { id: "summary", label: "Summary" },
  { id: "picker", label: "List & add" },
];

/** The layouts the timers panel can wear.
 *
 *  `list` is the shipped default — the running timers read-only. `studio` adds
 *  the controls: start a stopwatch or a countdown from the new tab, pause and
 *  resume what is running, and stop it. */
const TIMER_STYLES = [
  { id: "list", label: "List" },
  { id: "studio", label: "Controls" },
];

/** The layouts a shortcuts panel can wear.
 *
 *  `grid` is the shipped default — every pinned site as a tile, the speed dial
 *  the widget was asked for. `single` is the other half of that idea: one site
 *  on its own, drawn large, for a panel that exists to be one button. It shows
 *  the first pinned site and nothing else, so the two layouts are one list read
 *  two ways rather than two lists to keep in step. */
const SHORTCUT_STYLES = [
  { id: "grid", label: "Grid" },
  { id: "single", label: "Single icon" },
];

/** Which kinds have variants, and what they are. A kind absent from this map
 *  draws the same content under every setting, so `widgetVariantFor` returns
 *  `null` for it and nothing downstream has to branch. */
const WIDGET_VARIANTS = {
  calendar: CALENDAR_STYLES,
  bookmarks: BOOKMARK_STYLES,
  tasks: TASK_STYLES,
  timers: TIMER_STYLES,
  shortcuts: SHORTCUT_STYLES,
};

/** The variant each kind falls back to. These are the layouts that shipped
 *  before variants existed, so an existing profile that has never chosen one
 *  keeps the page it already had. */
const WIDGET_VARIANT_DEFAULTS = {
  calendar: "grid",
  bookmarks: "folders",
  tasks: "summary",
  timers: "list",
  shortcuts: "grid",
};

/** The built-in backdrops. These are CSS, not files: they render offline, cost
 *  no request, and sit in the same warm-monochrome register as the site's own
 *  grain — a photographic wallpaper is the other thing this feature is for, and
 *  that arrives by URL or upload. */
const WALLPAPER_PATTERNS = [
  { id: "none", label: "None" },
  { id: "dots", label: "Dots" },
  { id: "grid", label: "Grid" },
  { id: "scan", label: "Scan" },
  { id: "vignette", label: "Vignette" },
];

/** The art the page can be decorated with, generated by
 *  `scripts/import-decor.mjs` into `extension/decor/catalog.js` as a plain
 *  global. Each entry is `{ id, label, width, height, animated }`, and the id is
 *  also the filename: `decor/<id>.webp`.
 *
 *  Read through a guarded accessor because the catalog is generated and the
 *  settings store has to keep working if it is missing — a build that shipped
 *  without it must degrade to "no decorations", not throw on the first paint. */
const DECOR_CATALOG = Array.isArray(window.ixiDecorCatalog) ? window.ixiDecorCatalog : [];

function decorById(id) {
  return DECOR_CATALOG.find((d) => d.id === id) ?? null;
}

/** A layout that shows everything, in the order the kinds are declared. Used
 *  both as the shipped default and as the target of "Reset layout".
 *
 *  Every widget carries both an `id` and a `kind`. The shipped default of each
 *  kind has them equal — which is what keeps an existing profile's saved layout
 *  readable, since every mutation, style resolution and renderer lookup keys on
 *  `id`. The split becomes visible for every *added* instance, where the id is
 *  minted per instance and the kind is what the page looks up a renderer under.
 *  An entry written before `kind` existed has none, and `widgetKindOf` reads a
 *  missing one as "the id". */
function defaultWidgets() {
  return WIDGET_KINDS.map(({ id, label, multiple }, index) => ({
    id,
    kind: id,
    // The kind's own name, carried per instance so a card in the panel list can
    // read it without another lookup — `widgetLabelOf` falls back to the kind
    // for an older blob that has none.
    label,
    // Which kind may be placed more than once. Kept on the entry rather than
    // read off `WIDGET_KINDS` everywhere, because a widget that is already on
    // the page has to survive that kind being withdrawn from the list later.
    multiple: Boolean(multiple),
    visible: true,
    // Whether the widget's title bar is drawn. A header is chrome: it says the
    // widget's name and carries the drag handle and the close button, none of
    // which a settled layout needs once the panel is where the user wants it.
    // Hiding it *collapses* rather than removes — see `buildWidget`, which
    // keeps the header in the DOM and reveals it on hover, because it is the
    // only thing that can drag the panel.
    hideHeader: false,
    // Whether a shortcut tile draws its name under the icon. Like `hideHeader`,
    // this is chrome that a settled layout stops needing: once the icon is
    // recognised, the words are the slow half of the tile. Only read by the
    // shortcuts renderer and only off `data-variant="single"`, where the tile is
    // one block — a grid tile without its label is an unlabelled square, which is
    // a worse guess than the name is a cost.
    hideLabel: false,
    x: null,
    y: null,
    // `null` means "wear whatever style the page wears". Per-widget rather than
    // a per-kind map on the settings object: a widget *is* the unit the user
    // sees on the page, so a style belongs to the panel, not to the kind.
    style: null,
    // Which layout this widget draws inside its panel, for the kinds that have
    // more than one. `null` means "the kind's default", resolved by
    // `widgetVariantFor` — so a new kind, or a new variant with a different
    // default later, moves every widget that never explicitly chose one.
    variant: null,
    // 1 = the size the widget was designed at. A multiplier rather than a pixel
    // width because the six styles and every body are laid out in px, and
    // `zoom` scales all of it — text, padding, icons — together. Storing a
    // width instead would only stretch the box and leave the type at one size.
    scale: 1,
    // The panel's own width in px, or `null` for the kind's. The counterpart to
    // `scale` and a different axis on purpose: this moves the box only, so a
    // grid of pinned sites can be widened to fit more per row while its names
    // stay the size they were. `null` is not the same as the kind's number —
    // it means "ask the stylesheet", so the calendar stays narrow without this
    // file having to know that it is the narrow kind.
    width: null,
    // The stacking order. Seeded from the declaration index so a profile that has
    // never brought anything forward keeps the arrangement `WIDGET_KINDS`
    // describes, with later kinds drawn over earlier ones. A plain number rather
    // than a list of ids: an array would have to be renormalised every time a
    // widget was hidden or a new kind added, and a widget that is not in it would
    // silently drop to the bottom.
    z: index,
    // Per-instance contents, for the kinds that carry any. A singleton leaves
    // this `null` and gets everything it draws from the account — only a widget
    // the user fills in themselves, like a shortcuts panel, has anything to
    // keep here. Stored on the widget rather than in a settings key of its own
    // so a second instance is free to hold something different without the
    // first having to be told, and so "reset layout" clears it along with the
    // panel it belonged to.
    data: null,
    // Which calendar this panel counts in, for the calendar kind only. `null`
    // means Gregorian, resolved by `calendarSystemFor` — so a profile that never
    // chose one keeps the page it always had, and a kind that has no calendar
    // ignores the field entirely rather than needing it stripped.
    calendar: null,
    font: null,
  }));
}

/** How many sites one shortcuts panel will hold. A cap rather than no limit
 *  because every pinned site is a favicon request the moment the new tab opens,
 *  and forty of them is a page that waits on the network to look finished. It
 *  is also what the account mirror is spared: the whole settings blob is pushed
 *  on change, so an unbounded list is an unbounded payload. */
const SHORTCUT_MAX = 24;

/** The range one widget's own width may take, in px. The floor is above the
 *  narrowest kind (the single-icon block is 92px, and it never offers this
 *  control) so a panel cannot be made thinner than its own title bar; the
 *  ceiling is a comfortable full-width panel on a laptop, since a widget wider
 *  than the screen is one the user cannot reach the right edge of. */
const WIDGET_WIDTH_MIN = 140;
const WIDGET_WIDTH_MAX = 640;

/** The range the search box may be dragged to. The floor sits just above the
 *  width the prompt, the engine hint and the bang button need between them; the
 *  ceiling is a wide single-line box rather than a band across the screen,
 *  which is why it is smaller than the page width. */
const SEARCH_WIDTH_MIN = 320;
const SEARCH_WIDTH_MAX = 900;

/** The range the clock may be dragged to, matching what its slider offers. */
const CLOCK_SIZE_MIN = 32;
const CLOCK_SIZE_MAX = 160;

/** Where the theme choice is mirrored for the synchronous head script. Shared as
 *  a name rather than restated so the writer here and the reader in the page
 *  cannot drift apart. */
const THEME_MIRROR_KEY = "ixiTheme";

/** Which renderer a widget entry draws with.
 *
 *  For every kind that has ever shipped this is the entry's own id, and a blob
 *  written before the field existed has no `kind` at all — both of those read
 *  as "the id", so an existing profile renders exactly as it did. Only a
 *  multi-instance widget stores a kind that differs from its id. */
function widgetKindOf(spec) {
  return typeof spec?.kind === "string" && spec.kind ? spec.kind : spec?.id;
}

/** The kind descriptors a user can add another of. The panel renders one "Add"
 *  control per entry here, so a second addable kind needs no new code. */
function addableWidgetKinds() {
  return WIDGET_KINDS.filter((k) => k.multiple);
}

/** Whether one widget may be removed from the page entirely.
 *
 *  Only an instance the user *added* can go — one whose id was minted, so it is
 *  not the entry `defaultWidgets` ships. The test is therefore "minted", not
 *  "multi-instance": every kind is multi-instance now, which would have made the
 *  clock removable too, and `mergeStored` rebuilds the shipped default of every
 *  kind on each load. Removing one would delete the entry and then watch it
 *  reappear on the next reload — a control that does not do what it says.
 *
 *  An added instance has the opposite property: nothing recreates it, so
 *  removing it sticks. Hiding remains the reversible move for everything else,
 *  and it is what the header's × already does. */
function isRemovableWidget(spec) {
  // The search bar and the clock are the exception to "the shipped entry stays":
  // they are the two things on the page that are not panels, and the one people
  // most often want gone. Their removal hides rather than deletes — the entry
  // survives, so the card stays in the list to put them back with.
  const kind = widgetKindOf(spec);
  if (kind === "search" || kind === "clock") return true;
  return Boolean(spec?.multiple) && kind !== spec?.id;
}

/** A new instance of an addable kind, placed unpositioned so the page cascades
 *  it like any other widget that has never been dragged, and raised to the top
 *  of the stack so it is visible the moment it is added rather than buried
 *  under whatever the profile had brought forward last. */
function newWidgetInstance(kind, widgets, existing) {
  const taken = new Set(widgets.map((w) => w.id));
  let n = 1;
  while (taken.has(`${kind.id}-${n}`)) n += 1;
  const zs = widgets.map((w) => Number(w.z)).filter(Number.isFinite);
  const count = existing.filter((w) => widgetKindOf(w) === kind.id).length;
  return {
    ...defaultWidgets().find((w) => w.id === kind.id),
    // The id is minted, the kind is fixed. The number also seeds the label
    // ("Shortcuts 2"), so the two never drift apart.
    id: `${kind.id}-${n}`,
    kind: kind.id,
    multiple: true,
    label: `${kind.label} ${count + 1}`,
    x: null,
    y: null,
    z: (zs.length ? Math.max(...zs) : 0) + 1,
    // Only shortcuts carries its own contents — every other kind draws from the
    // account. A fresh one of those gets `null` rather than `{}` so it reads as
    // "this kind has no stored data", which is what `sanitiseWidgetData`
    // returns for it and what the renderers expect.
    data: kind.id === "shortcuts" ? { links: [] } : null,
  };
}

const DEFAULTS = {
  engine: "ddg",
  // `system` | `light` | `dark`. `system` follows the device and keeps
  // following it; the other two are the user overriding that. The choice is
  // mirrored to `localStorage` under `THEME_MIRROR_KEY` and read by a
  // synchronous script in the page's <head>, because `chrome.storage` is async
  // and cannot decide the theme before the first paint — see the note there.
  theme: "system",
  clock24: true,
  showClock: true,
  showLinks: true,
  showLive: true,
  // `--sun` from the site. The page keeps exactly one accent so the ink stays
  // quiet; this only decides which hue it is. The literal `"custom"` is the
  // sixth choice, and it resolves through `customAccent` below rather than to
  // an `ACCENTS` entry.
  accent: "sun",
  // The hue behind `accent: "custom"`, or `null` until the user picks one. Kept
  // as its own field rather than appended to `ACCENTS` because the preset list
  // is the shipped, hand-tuned set while this is arbitrary user input that has
  // to be validated on every read — see `sanitiseAccentHex`. Separating the
  // choice (`accent`) from the colour (`customAccent`) is what lets a user
  // switch to a preset and back without the custom hex being forgotten.
  customAccent: null,
  // The face the big clock wears. `CLOCK_FONTS` ids, and `clockSize` in px —
  // the one number the page's own stylesheet cannot know, since the clock is
  // sized by the viewport elsewhere.
  clockFont: "mono",
  clockSize: 68,
  // The style every widget wears unless it has picked its own.
  widgetStyle: "glass",
  // Whether a dragged widget must never cover another one. On, the drag
  // resolves to a spot beside whatever it would have landed on; off, panels
  // stack freely as they always could. On by default because a layout the
  // widgets hide one another in is not a layout the user meant to make.
  widgetNoOverlap: true,
  // `datetime-local` strings, local time, both ends inclusive. "" means no
  // bound on that end, so the shipped default is "always".
  scheduleFrom: "",
  scheduleTo: "",
  // The page's own backdrop. `wallpaperUrl` is a remote image or an uploaded
  // one; when set it wins over `wallpaperPattern`, and `wallpaperDim` is the
  // black scrim over it — a photo behind bone-coloured text needs one, and how
  // much is a taste call rather than something to guess at.
  wallpaperUrl: "",
  wallpaperPattern: "none",
  // Whether an uploaded image exists in `WALLPAPER_KEY`. Deliberately a bare
  // flag rather than the image itself: the account mirror carries this boolean
  // and nothing heavier, so the upload cannot push the settings blob over the
  // server's size cap. When set, the uploaded image wins over `wallpaperUrl` —
  // an upload is the more deliberate act, and a URL left in the field from
  // earlier should not silently override the picture the user just chose.
  wallpaperUpload: false,
  wallpaperDim: 45,
  // Where the search box sits, or `null` for "where the stage puts it". The
  // default is the centred column the page has always drawn, and a pair of
  // numbers is a free position the user dragged it to. `null` rather than a
  // centred pair of coordinates because the centred position is not a fixed
  // point — it depends on the viewport and has to keep tracking a resize, where
  // a stored pair that merely happened to be centred would stay behind.
  searchX: null,
  searchY: null,
  // The box's width once it has been dragged to one, or `null` for the shipped
  // 520px max-width. Same `null`-means-default discipline as the position pair
  // above: a fixed number here would pin the box at a width that stops tracking
  // the stylesheet, and the round trip back to the centred column has to be
  // able to drop the inline style rather than write 520.
  searchWidth: null,
  // Whether the box is on the page at all. The search bar and the clock are
  // both toggled from the panel's widget list now, on the same "add or remove"
  // terms as the widgets, so "remove the search bar" needed a state that is not
  // a position — `searchX: null` already means "centred", not "gone".
  searchShown: true,
  // Where the clock sits, on the same terms as the search box above: `null` is
  // "the centred column the stage draws", a pair of numbers is a position the
  // user dragged it to. The clock was the one thing on the page that never
  // moved, so this is what lets a layout be arranged *around* it rather than
  // only around the widget panels.
  clockX: null,
  clockY: null,
  // Whether the big clock draws at all, on the same terms as `searchShown`:
  // `clockX: null` means "centred", so it cannot also mean "gone".
  clockShown: true,
  clockDocked: false,
  widgets: defaultWidgets(),
  // Bookmark ids lifted to the top of the bookmarks widget. Bookmark ids are
  // per-row and stable, so the set is a plain array of ids rather than a
  // per-account list rebuilt from the server — pinning is a view preference of
  // this browser profile, deliberately not a column on the bookmarks table.
  pins: [],
  // The decorations dropped on the page: art from `extension/decor/`, placed
  // wherever the user dragged it and scaled to taste. An array of
  // `{ id, asset, x, y, scale }` where `asset` is the catalog id and `id` is a
  // per-placement identity — the same piece of art can be dropped three times
  // and each copy has to be movable and removable on its own.
  decor: [],
  // Folder names whose group is closed in the widget. Storing the *closed* ones
  // rather than the open ones means the default `[]` already reads as "every
  // group expanded", including folders created after this setting was written.
  collapsedFolders: [],
  // Which todo list the tasks widget's "List & add" layout is showing. A page id
  // rather than a name, because a list can be renamed. `null` means "whichever
  // the widget picks" — see the tasks renderer, which falls back to the first
  // non-archived list rather than rendering nothing.
  taskPageId: null,
  // The typed prefixes that pick a search destination for one query — `yt car`
  // searches YouTube for car. Seeded from `DEFAULT_BANGS`, which is derived from
  // `BANG_CATALOG`, so the shipped starters cannot drift from the catalogue rows
  // the modal also offers. An entry is `{ id, trigger, label, url, home }` where
  // `url` is a template carrying a literal `%s` and `home` is where a bare
  // trigger with no words goes. This list is mirrored to the account like the
  // rest of the blob; `sanitiseBangs` is what makes that safe to read back.
  searchBangs: DEFAULT_BANGS,
};

// Each accent carries two hexes rather than one, because an ink that reads on
// black and an ink that reads on paper are not the same colour. `value` is what
// the dark page paints; `light` is the same hue darkened until it clears
// contrast against the light palette. `bone` is the extreme case — on black it
// *is* the page's own text colour, and on paper the same value would be
// invisible, so its light variant is the palette's mid grey instead.
const ACCENTS = [
  { id: "sun", label: "Sun", value: "#ce5e32", light: "#a34420" },
  { id: "bone", label: "Bone", value: "#cdc4ba", light: "#5a544d" },
  { id: "moss", label: "Moss", value: "#6b8f5e", light: "#456b39" },
  { id: "sky", label: "Sky", value: "#5e8fce", light: "#33629e" },
  { id: "plum", label: "Plum", value: "#a06bb0", light: "#6f3f80" },
];

// Named `settingsCache` rather than `cache`, and the accessors below likewise,
// because every script on this page shares one top-level lexical scope. `get`,
// `set` and `cache` are exactly the names a future file would redeclare by
// accident, and a redeclaration throws before any of these lines run.
let settingsCache = null;

/** Where an uploaded wallpaper's bytes live.
 *
 *  A storage key of its own, deliberately outside `SETTINGS_KEY`: the settings
 *  blob is mirrored to the account under `SYNC_MAX_BYTES` (256 KB), and a
 *  photograph — even one re-encoded down — is larger than the whole settings
 *  document. Keeping the bytes local and syncing only a boolean flag means an
 *  upload cannot break the account mirror for every other setting, and the
 *  worst case for a user with two machines is that the picture is missing on the
 *  one it was not uploaded to, rather than that nothing syncs at all. */
const WALLPAPER_KEY = "ixiNewtabWallpaper";

/** The uploaded image's data URL, or `""`. Read through the cache below so the
 *  panel's preview and the page's own paint do not each hit storage. */
let wallpaperCache = null;

async function getWallpaperUpload() {
  if (wallpaperCache !== null) return wallpaperCache;
  try {
    const stored = (await chrome.storage.local.get(WALLPAPER_KEY))[WALLPAPER_KEY];
    wallpaperCache = typeof stored === "string" ? stored : "";
  } catch {
    // A storage read that fails is not a reason to fail a paint — the page
    // simply shows the URL or pattern instead.
    wallpaperCache = "";
  }
  return wallpaperCache;
}

/** Store an uploaded image. Flips `wallpaperUpload` on in the same write, so a
 *  successful upload is visible immediately rather than needing a second step. */
async function setWallpaperUpload(dataUrl) {
  const image = typeof dataUrl === "string" ? dataUrl : "";
  wallpaperCache = image;
  await chrome.storage.local.set({ [WALLPAPER_KEY]: image });
  // The flag is derived from the local `image`, not re-read from the cache: the
  // `onChanged` listener above runs on this very write, and anything that
  // cleared the cache across the `await` would otherwise turn a successful
  // upload into `wallpaperUpload: false`.
  return writeSettings({ wallpaperUpload: Boolean(image) });
}

/** Forget the uploaded image and fall back to whatever URL or pattern is set. */
async function clearWallpaperUpload() {
  wallpaperCache = "";
  await chrome.storage.local.remove(WALLPAPER_KEY);
  return writeSettings({ wallpaperUpload: false });
}

/** One pinned site, hardened. Anything that survives has a usable URL, because
 *  a shortcut with nothing to open is a row that does nothing when clicked —
 *  worse than no row, since it looks like a broken link. The label falls back
 *  to the host so a site added by pasting only a URL still has a name. */
function shortcutOf(entry) {
  if (!entry || typeof entry !== "object") return null;
  const raw = String(entry.url ?? "").trim();
  if (!raw) return null;
  // A bare `example.com` is what people type; https is the assumption that
  // makes it a link. The stored string keeps whatever they typed so the field
  // does not rewrite itself under them, and only the *href* is normalised —
  // see `shortcutHref`, which the renderer uses.
  const withScheme = raw.includes("://") ? raw : `https://${raw}`;
  let href;
  try {
    href = new URL(withScheme);
  } catch {
    return null;
  }
  if (href.protocol !== "http:" && href.protocol !== "https:") return null;
  const label = String(entry.label ?? "").trim().slice(0, 60);
  // A position is both-or-neither. The page only draws a shortcut on the page
  // when both are numbers, so a half pair would be a shortcut that claims to be
  // placed and then renders nowhere; normalising it to `null` sends it back to
  // the panel, which is the visible, recoverable state.
  const x = Number.isFinite(entry.x) ? Math.round(entry.x) : null;
  const y = Number.isFinite(entry.y) ? Math.round(entry.y) : null;
  const placed = x != null && y != null;
  return {
    id: typeof entry.id === "string" && entry.id ? entry.id : `s-${Math.random().toString(36).slice(2, 9)}`,
    label: label || hostOfUrl(raw) || raw,
    url: raw,
    x: placed ? x : null,
    y: placed ? y : null,
    icon: normaliseShortcutIcon(entry.icon),
  };
}

/** One shortcut's icon choice, hardened.
 *
 *  Three modes, and `null` means "no choice" — the tile then falls through the
 *  same chain it always did (the site's favicon, then its first letter). The
 *  upload is the only mode that carries bytes, and they are capped hard: these
 *  live inside the settings blob, which the account mirror sends with a 256 KB
 *  budget, and an icon is 40px on screen. Anything larger than the cap is
 *  rejected outright rather than silently truncated, because a truncated data
 *  URL is an image that fails to decode — worse than no icon, since the tile
 *  would show a broken-image glyph instead of its letter. */
const SHORTCUT_ICON_MAX_BYTES = 64 * 1024;

/** The pictures a shortcut tile can wear instead of its site's favicon.
 *
 *  A stone set, not a picture book: a site with no favicon, or a site whose
 *  favicon is a grey square with a letter in it, reads as nothing at all in a
 *  grid. These are the handful of categories most pinned links fall into —
 *  the ones a user is already sorting sites by in their head.
 *
 *  Each is a `body` of the 24-unit stroke grid the page's own tool glyphs are
 *  drawn on (`currentColor`, `stroke-width: 1.5`, round caps), so a chosen
 *  picture weighs the same as every other stroke on the page rather than
 *  looking like a pasted-in bitmap. The markup is a constant in this file, not
 *  anything a profile can supply — which is what makes it safe to parse. */
const SHORTCUT_ICON_GLYPHS = {
  star: '<path d="M12 3.5l2.6 5.4 5.9.8-4.3 4.1 1 5.9-5.2-2.8-5.2 2.8 1-5.9L3.5 9.7l5.9-.8z"/>',
  heart: '<path d="M12 20s-7.5-4.6-7.5-9.6A4.4 4.4 0 0 1 12 7.2a4.4 4.4 0 0 1 7.5 3.2C19.5 15.4 12 20 12 20z"/>',
  home: '<path d="M4 10.5L12 4l8 6.5"/><path d="M6 9.5V20h12V9.5"/><path d="M10 20v-5h4v5"/>',
  work: '<rect x="3" y="7.5" width="18" height="12" rx="2"/><path d="M9 7.5V5.5a1.5 1.5 0 0 1 1.5-1.5h3A1.5 1.5 0 0 1 15 5.5v2"/>',
  mail: '<rect x="3" y="5.5" width="18" height="13" rx="2"/><path d="M3.5 7l8.5 6 8.5-6"/>',
  chat: '<path d="M20 15a2 2 0 0 1-2 2H8l-4 3.5V7a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2z"/>',
  code: '<path d="M9 7l-5 5 5 5"/><path d="M15 7l5 5-5 5"/>',
  video: '<rect x="3" y="5.5" width="18" height="13" rx="2.5"/><path d="M10.5 9.5v5l4.5-2.5z"/>',
  music: '<path d="M9 18V6.5l10-2V16"/><circle cx="6.5" cy="18" r="2.5"/><circle cx="16.5" cy="16" r="2.5"/>',
  book: '<path d="M5 4.5h11a3 3 0 0 1 3 3V20H8a3 3 0 0 1-3-3z"/><path d="M8 4.5V17a3 3 0 0 0 3 3"/>',
  news: '<path d="M4 5.5h12a2 2 0 0 1 2 2v11H6a2 2 0 0 1-2-2z"/><path d="M18 9h2v7.5a2 2 0 0 1-2 2"/><path d="M7.5 9.5h7M7.5 13h7M7.5 16.5h4"/>',
  cart: '<path d="M3.5 4.5h2l2.2 10.5h9.8l2-7.5H6.5"/><circle cx="9" cy="19" r="1.4"/><circle cx="17" cy="19" r="1.4"/>',
  cloud: '<path d="M7 18.5a4 4 0 0 1-.4-8A5.5 5.5 0 0 1 17.3 9a4.8 4.8 0 0 1 .7 9.5z"/>',
  bolt: '<path d="M13 3.5L5.5 13.5H11l-1 7 8-10.5H12.5z"/>',
  calendar: '<rect x="3.5" y="5.5" width="17" height="15" rx="2"/><path d="M3.5 10h17M8 3.5v4M16 3.5v4"/>',
  globe: '<circle cx="12" cy="12" r="8.5"/><path d="M3.5 12h17"/><path d="M12 3.5c2.6 2.4 4 5.2 4 8.5s-1.4 6.1-4 8.5c-2.6-2.4-4-5.2-4-8.5s1.4-6.1 4-8.5z"/>',
  flag: '<path d="M6 21V4"/><path d="M6 4.5h11l-2.5 4 2.5 4H6"/>',
  pin: '<path d="M12 21s6-5.7 6-10.4A6 6 0 0 0 6 10.6C6 15.3 12 21 12 21z"/><circle cx="12" cy="10.5" r="2.2"/>',
  game: '<rect x="2.5" y="7" width="19" height="10.5" rx="4"/><path d="M7.5 10.5v3.5M5.75 12.25h3.5"/><circle cx="16" cy="11" r="1"/><circle cx="18" cy="13.5" r="1"/>',
  user: '<circle cx="12" cy="8.5" r="3.8"/><path d="M4.5 20.5a7.5 7.5 0 0 1 15 0"/>',
  // The second set. Same 24-unit grid, same 1.5 stroke, round caps — a stone
  // from either half sits beside one from the other without looking like it
  // came from another pack.
  folder: '<path d="M3.5 6.5a1.5 1.5 0 0 1 1.5-1.5h4l2 2.5h8a1.5 1.5 0 0 1 1.5 1.5v9a1.5 1.5 0 0 1-1.5 1.5H5a1.5 1.5 0 0 1-1.5-1.5z"/>',
  file: '<path d="M13.5 3.5H7a1.5 1.5 0 0 0-1.5 1.5v14A1.5 1.5 0 0 0 7 20.5h10a1.5 1.5 0 0 0 1.5-1.5V8.5z"/><path d="M13.5 3.5v5h5"/>',
  image: '<rect x="3.5" y="5" width="17" height="14" rx="2"/><circle cx="8.5" cy="10" r="1.5"/><path d="M4.5 17l4.5-4.5 3.5 3.5 2.5-2.5 4.5 4.5"/>',
  camera: '<path d="M3.5 8.5a1.5 1.5 0 0 1 1.5-1.5h3l1.5-2h5L16 7h3a1.5 1.5 0 0 1 1.5 1.5V18a1.5 1.5 0 0 1-1.5 1.5H5A1.5 1.5 0 0 1 3.5 18z"/><circle cx="12" cy="13" r="3.2"/>',
  terminal: '<rect x="3" y="4.5" width="18" height="15" rx="2"/><path d="M7 10l2.5 2.5L7 15"/><path d="M12.5 15h4.5"/>',
  database: '<ellipse cx="12" cy="6.5" rx="7" ry="2.8"/><path d="M5 6.5v11c0 1.5 3.1 2.8 7 2.8s7-1.3 7-2.8v-11"/><path d="M5 12c0 1.5 3.1 2.8 7 2.8s7-1.3 7-2.8"/>',
  server: '<rect x="3.5" y="4.5" width="17" height="6" rx="1.5"/><rect x="3.5" y="13.5" width="17" height="6" rx="1.5"/><path d="M7 7.5h.01M7 16.5h.01"/>',
  wifi: '<path d="M4 9.5a12 12 0 0 1 16 0"/><path d="M7 12.8a7.5 7.5 0 0 1 10 0"/><path d="M10 16a3 3 0 0 1 4 0"/><path d="M12 19h.01"/>',
  phone: '<rect x="7" y="2.5" width="10" height="19" rx="2"/><path d="M11 18.5h2"/>',
  laptop: '<rect x="4" y="5" width="16" height="10.5" rx="1.5"/><path d="M2.5 18.5h19"/>',
  headset: '<path d="M4.5 15v-3a7.5 7.5 0 0 1 15 0v3"/><rect x="3" y="13.5" width="3.5" height="6" rx="1.2"/><rect x="17.5" y="13.5" width="3.5" height="6" rx="1.2"/>',
  mic: '<rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5.5 11.5a6.5 6.5 0 0 0 13 0"/><path d="M12 18v3"/>',
  palette: '<path d="M12 3.5a8.5 8.5 0 0 0 0 17c1.4 0 2-1 2-2 0-2.2 3.5-.8 5-2.4a8.5 8.5 0 0 0-7-12.6z"/><circle cx="8" cy="10" r="1"/><circle cx="12" cy="7.5" r="1"/><circle cx="15.8" cy="10" r="1"/>',
  scissors: '<circle cx="6.5" cy="6.5" r="2.5"/><circle cx="6.5" cy="17.5" r="2.5"/><path d="M8.5 8.2L19 18"/><path d="M8.5 15.8L19 6"/>',
  pen: '<path d="M4 20l1-4L16.5 4.5a2.1 2.1 0 0 1 3 3L8 19z"/><path d="M14.5 6.5l3 3"/>',
  tag: '<path d="M4 4h7l9 9-7 7-9-9z"/><circle cx="8.5" cy="8.5" r="1.3"/>',
  clock: '<circle cx="12" cy="12" r="8.5"/><path d="M12 7v5.3l3.2 2"/>',
  hourglass: '<path d="M7 3.5h10"/><path d="M7 20.5h10"/><path d="M8 3.5v3c0 3 4 4 4 5.5 0-1.5 4-2.5 4-5.5v-3"/><path d="M8 20.5v-3c0-3 4-4 4-5.5 0 1.5 4 2.5 4 5.5v3"/>',
  sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2.5v2.5M12 19v2.5M2.5 12H5M19 12h2.5M5.3 5.3l1.8 1.8M16.9 16.9l1.8 1.8M18.7 5.3l-1.8 1.8M7.1 16.9l-1.8 1.8"/>',
  moon: '<path d="M19.5 14.5A8 8 0 0 1 9.5 4.5a8 8 0 1 0 10 10z"/>',
  umbrella: '<path d="M3.8 12.2a8.2 8.2 0 0 1 16.4 0"/><path d="M3.8 12.2c1.4 0 1.4 1.4 2.8 1.4s1.4-1.4 2.8-1.4 1.4 1.4 2.6 1.4 1.4-1.4 2.8-1.4 1.4 1.4 2.8 1.4 1.4-1.4 2.6-1.4"/><path d="M12 12.2v6.3a1.9 1.9 0 0 0 3.8 0"/>',
  coffee: '<path d="M4.5 7.5h12v6a4 4 0 0 1-4 4h-4a4 4 0 0 1-4-4z"/><path d="M16.5 9h1.5a2.5 2.5 0 0 1 0 5h-1.5"/><path d="M4 20.5h13"/>',
  map: '<path d="M3.5 6.5l5.5-2 6 2 5.5-2v13l-5.5 2-6-2-5.5 2z"/><path d="M9 4.5v13M15 6.5v13"/>',
  compass: '<circle cx="12" cy="12" r="8.5"/><path d="M15.5 8.5l-2 5-5 2 2-5z"/>',
  train: '<rect x="5" y="3.5" width="14" height="13" rx="3"/><path d="M5 10.5h14"/><path d="M8.5 20.5l1.5-3M15.5 20.5L14 17.5"/><path d="M9.5 7h5"/>',
  rocket: '<path d="M12 3.5c2.6 2.2 3.8 5 3.8 8.4V15h-7.6v-3.1c0-3.4 1.2-6.2 3.8-8.4z"/><path d="M8.2 11.4L5 15.2v3.6l3.2-2M15.8 11.4l3.2 3.8v3.6l-3.2-2"/><circle cx="12" cy="9" r="1.4"/><path d="M10.4 18.8h3.2"/>',
  gift: '<rect x="3.5" y="9" width="17" height="4" rx="1"/><path d="M5 13v7.5h14V13"/><path d="M12 9v11.5"/><path d="M12 9c-1.5 0-4.5-.5-4.5-3a2 2 0 0 1 4.5 0c0 2.5 3 3 4.5 3a2 2 0 0 0 0-3"/>',
  bell: '<path d="M6.5 10a5.5 5.5 0 0 1 11 0c0 4 1.5 5.5 1.5 5.5H5s1.5-1.5 1.5-5.5z"/><path d="M10.5 19a1.6 1.6 0 0 0 3 0"/>',
  lock: '<rect x="5" y="10.5" width="14" height="9.5" rx="1.5"/><path d="M8 10.5V7.5a4 4 0 0 1 8 0v3"/><circle cx="12" cy="15.2" r="1.1"/>',
  key: '<circle cx="7.5" cy="16.5" r="3.5"/><path d="M10 14L19.5 4.5"/><path d="M16.5 7.5l2.5 2.5M14 10l1.5 1.5"/>',
  shield: '<path d="M12 3.5l7.5 3v5.5c0 4.5-3.2 7.8-7.5 9-4.3-1.2-7.5-4.5-7.5-9V6.5z"/>',
  scale: '<path d="M12 4v16"/><path d="M6.5 6.5h11"/><path d="M6.5 6.5L3.5 14h6z"/><path d="M17.5 6.5L14.5 14h6z"/><path d="M9 20h6"/>',
  truck: '<path d="M3.5 6.5h10v9.5h-10z"/><path d="M13.5 9.5H18l3 3.5v3h-7.5"/><circle cx="7" cy="18" r="1.8"/><circle cx="17" cy="18" r="1.8"/>',
  flask: '<path d="M9.5 3.5h5"/><path d="M10.5 3.5v5.5L5.5 18a2 2 0 0 0 1.7 3h9.6a2 2 0 0 0 1.7-3l-5-9V3.5"/><path d="M7.8 14h8.4"/>',
  atom: '<circle cx="12" cy="12" r="1.6"/><ellipse cx="12" cy="12" rx="9" ry="3.8"/><ellipse cx="12" cy="12" rx="9" ry="3.8" transform="rotate(60 12 12)"/><ellipse cx="12" cy="12" rx="9" ry="3.8" transform="rotate(120 12 12)"/>',
  cpu: '<rect x="6.5" y="6.5" width="11" height="11" rx="1.5"/><rect x="9.5" y="9.5" width="5" height="5" rx="0.8"/><path d="M9.5 3v3.5M14.5 3v3.5M9.5 17.5V21M14.5 17.5V21M3 9.5h3.5M3 14.5h3.5M17.5 9.5H21M17.5 14.5H21"/>',
  browser: '<rect x="3" y="4.5" width="18" height="15" rx="2"/><path d="M3 9h18"/><circle cx="6.2" cy="6.8" r="0.7"/><circle cx="8.6" cy="6.8" r="0.7"/>',
  link: '<path d="M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1.5 1.5"/><path d="M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1.5-1.5"/>',
  download: '<path d="M12 4v11"/><path d="M7.5 10.5L12 15l4.5-4.5"/><path d="M4.5 19.5h15"/>',
  upload: '<path d="M12 15V4"/><path d="M7.5 8.5L12 4l4.5 4.5"/><path d="M4.5 19.5h15"/>',
  sparkles: '<path d="M12 3.5l1.7 4.8L18.5 10l-4.8 1.7L12 16.5l-1.7-4.8L5.5 10l4.8-1.7z"/><path d="M18 15.5l.8 2.2 2.2.8-2.2.8-.8 2.2-.8-2.2-2.2-.8 2.2-.8z"/>',
};

const SHORTCUT_ICONS = [
  { id: "star", label: "Star" },
  { id: "heart", label: "Heart" },
  { id: "home", label: "Home" },
  { id: "work", label: "Work" },
  { id: "mail", label: "Mail" },
  { id: "chat", label: "Chat" },
  { id: "code", label: "Code" },
  { id: "video", label: "Video" },
  { id: "music", label: "Music" },
  { id: "book", label: "Book" },
  { id: "news", label: "News" },
  { id: "cart", label: "Shop" },
  { id: "cloud", label: "Cloud" },
  { id: "bolt", label: "Fast" },
  { id: "calendar", label: "Calendar" },
  { id: "globe", label: "Web" },
  { id: "flag", label: "Flag" },
  { id: "pin", label: "Pin" },
  { id: "game", label: "Game" },
  { id: "user", label: "Person" },
  { id: "folder", label: "Folder" },
  { id: "file", label: "File" },
  { id: "image", label: "Image" },
  { id: "camera", label: "Camera" },
  { id: "terminal", label: "Terminal" },
  { id: "database", label: "Database" },
  { id: "server", label: "Server" },
  { id: "wifi", label: "Wi-Fi" },
  { id: "phone", label: "Phone" },
  { id: "laptop", label: "Laptop" },
  { id: "headset", label: "Audio" },
  { id: "mic", label: "Podcast" },
  { id: "palette", label: "Design" },
  { id: "scissors", label: "Tools" },
  { id: "pen", label: "Notes" },
  { id: "tag", label: "Tag" },
  { id: "clock", label: "Clock" },
  { id: "hourglass", label: "Deadline" },
  { id: "sun", label: "Sun" },
  { id: "moon", label: "Night" },
  { id: "umbrella", label: "Rain" },
  { id: "coffee", label: "Coffee" },
  { id: "map", label: "Map" },
  { id: "compass", label: "Explore" },
  { id: "train", label: "Travel" },
  { id: "rocket", label: "Launch" },
  { id: "gift", label: "Gift" },
  { id: "bell", label: "Bell" },
  { id: "lock", label: "Lock" },
  { id: "key", label: "Key" },
  { id: "shield", label: "Security" },
  { id: "scale", label: "Law" },
  { id: "truck", label: "Shipping" },
  { id: "flask", label: "Lab" },
  { id: "atom", label: "Science" },
  { id: "cpu", label: "Hardware" },
  { id: "browser", label: "Browser" },
  { id: "link", label: "Link" },
  { id: "download", label: "Download" },
  { id: "upload", label: "Upload" },
  { id: "sparkles", label: "AI" },
];

function normaliseShortcutIcon(icon) {
  if (!icon || typeof icon !== "object") return null;
  if (icon.mode === "auto") return { mode: "auto" };
  if (icon.mode === "favicon") return { mode: "favicon" };
  // A picture from the bundled set, named rather than embedded: the name is
  // checked against the catalog and the markup is looked up from this file, so
  // a profile can only ever choose one of the stones that ship.
  if (icon.mode === "set") {
    return SHORTCUT_ICONS.some((s) => s.id === icon.name) ? { mode: "set", name: icon.name } : null;
  }
  if (icon.mode !== "upload") return null;
  const src = typeof icon.src === "string" ? icon.src : "";
  // Only the inline image types the editor can produce. An `http(s)` src would
  // be a remote image the extension would have to fetch with no host permission
  // for it, and an `svg` data URL can carry script — both are refused here.
  if (!/^data:image\/(png|jpeg|webp|gif);base64,[A-Za-z0-9+/=]+$/.test(src)) return null;
  if (src.length > SHORTCUT_ICON_MAX_BYTES) return null;
  return { mode: "upload", src };
}

/** One widget's stored contents, hardened for this kind. Two kinds carry any —
 *  `shortcuts` its own pinned sites, `tasks` a link to a shared todo page; every
 *  other kind's `data` is dropped rather than round-tripped, so a stray field on
 *  the account blob cannot become something a renderer later reads by accident.
 *
 *  Only the *extras* go through here (`mergeStored`). The shipped singletons take
 *  the stored blob whole, which is deliberate — see the note there — so this is a
 *  filter for the path the user's own added widgets travel, not a guarantee about
 *  every entry. `todoLinkOf` is written to be safe on anything for that reason. */
function sanitiseWidgetData(spec) {
  const kind = widgetKindOf(spec);
  if (kind === "tasks") {
    const link = todoLinkOf(spec.data);
    return link ? { todoLink: link } : null;
  }
  if (kind !== "shortcuts") return null;
  const raw = spec.data && typeof spec.data === "object" ? spec.data : {};
  const links = (Array.isArray(raw.links) ? raw.links : []).map(shortcutOf).filter(Boolean);
  return { links: links.slice(0, SHORTCUT_MAX) };
}

/** Normalise a shortcuts widget's links wherever the widget came from.
 *
 *  `sanitiseWidgetData` above only reaches the *extras* — the singletons take
 *  their stored blob whole, by design (see `mergeStored`). That was harmless
 *  while a link was only a url and a label, because every reader could cope with
 *  a missing field. It stopped being harmless when a link gained an `icon` and a
 *  placement: a singleton whose blob carries `icon: "<img onerror=...>"` or an
 *  `x` with no `y` would reach the page unfiltered, and those are exactly the
 *  shapes `shortcutOf` exists to refuse. So this runs over every widget after
 *  the merge, normalising links *in place* and leaving every other kind alone.
 *
 *  A link that `shortcutOf` rejects is dropped rather than kept as-is: it has no
 *  usable URL, so there is nothing to draw. */
function normaliseShortcutLinks(spec) {
  if (widgetKindOf(spec) !== "shortcuts") return spec;
  const raw = spec.data && typeof spec.data === "object" ? spec.data : {};
  const links = (Array.isArray(raw.links) ? raw.links : []).map(shortcutOf).filter(Boolean);
  return { ...spec, data: { ...raw, links: links.slice(0, SHORTCUT_MAX) } };
}

/** The host of a URL-ish string, for a default label and the tile's fallback
 *  letter. Kept tolerant because this runs on half-typed values. */
function hostOfUrl(value) {
  const raw = String(value ?? "").trim();
  if (!raw) return "";
  try {
    return new URL(raw.includes("://") ? raw : `https://${raw}`).hostname.replace(/^www\./, "");
  } catch {
    return "";
  }
}

// ── a shared todo page, reached from a widget ─────────────────────────────
// The extension can point one "Open tasks" panel at a shared todo page by its
// link. Everything on the server is addressed by the single path segment of
// `/todo/<token>`, which is either a slug the owner chose or a random legacy
// share token — so the token, not the URL, is what gets stored and used.

/** A chosen slug, matching `TODO_SLUG_PATTERN` in `lib/todo-view.ts`. */
const TODO_SLUG_RE = /^[a-z0-9][a-z0-9_-]{2,59}$/;
/** A legacy share token — `crypto.randomBytes(24).toString("base64url")`. The
 *  range is generous because the only thing this decides is "is this the shape
 *  of a token"; the server is what actually says no. */
const TODO_TOKEN_RE = /^[A-Za-z0-9_-]{32,64}$/;

/** The token out of a pasted shared-todo link, or null.
 *
 *  **The token is never lowercased.** `getTodoPageByToken` matches with `eq()`
 *  on a text column — a case-sensitive comparison — and a base64url token is
 *  full of capitals, so lowercasing one would turn a working link into a silent
 *  404. Slugs are already stored lowercase, so taking the segment as typed is
 *  right for both shapes. */
function todoTokenFromUrl(value) {
  const raw = String(value ?? "").trim();
  if (!raw) return null;
  let url;
  try {
    // The same tolerant scheme assumption `hostOfUrl` and `shortcutOf` make: a
    // bare `host/todo/name` is what people paste from an address bar.
    url = new URL(raw.includes("://") ? raw : `https://${raw}`);
  } catch {
    return null;
  }
  if (url.protocol !== "http:" && url.protocol !== "https:") return null;
  // One segment only, optional trailing slash. A second segment or a query is a
  // different address than the one this feature knows how to read.
  const match = url.pathname.match(/^\/todo\/([^/?#]+)\/?$/);
  if (!match) return null;
  let token;
  try {
    token = decodeURIComponent(match[1]);
  } catch {
    return null;
  }
  if (!TODO_SLUG_RE.test(token) && !TODO_TOKEN_RE.test(token)) return null;
  return { token, url: `${url.origin}/todo/${token}` };
}

/** The connection a tasks widget carries, or null. The one reader — the body,
 *  the header's tab switcher and the context menu all come through here, never
 *  through `spec.data.todoLink` directly.
 *
 *  Defensive on purpose. The shipped `tasks` singleton is *not* re-sanitised by
 *  `mergeStored`, so this can be handed whatever the account blob happened to
 *  hold; anything that does not resolve to a token reads as "not connected"
 *  rather than reaching a renderer as a half-built link. A bare string is
 *  accepted too, because a hand-edited blob is a thing that really happens. */
function todoLinkOf(data) {
  if (!data || typeof data !== "object") return null;
  const raw = data.todoLink;
  const source = typeof raw === "string" ? { url: raw } : raw && typeof raw === "object" ? raw : null;
  if (!source) return null;
  // The link is the source of truth, and a stored `token` is only ever used for
  // the menu's label. Re-parsing the URL here rather than trusting the pair is
  // what stops a tinkered-with blob from pointing the widget at a token no link
  // could have produced.
  const parsed = todoTokenFromUrl(source.url);
  if (!parsed) return null;
  return {
    token: parsed.token,
    url: parsed.url,
    title: String(source.title ?? "").trim().slice(0, 160),
    tab: source.tab === "own" ? "own" : "shared",
  };
}

/** A stored site address as a link the browser will follow. The same tolerant
 *  scheme assumption as `shortcutOf`, applied at the point of use so the field
 *  the user typed into keeps their own text. */
function shortcutHref(url) {
  const raw = String(url ?? "").trim();
  if (!raw) return "#";
  return raw.includes("://") ? raw : `https://${raw}`;
}

/** Run migrations from the blob's schema version up to SCHEMA_VERSION.
 *  Idempotent and must never drop user widgets/positions. */
function migrateSettings(stored) {
  if (!stored || typeof stored !== "object" || Array.isArray(stored)) return stored;
  const blob = { ...stored };
  let v = Number(blob.schemaVersion);
  if (!Number.isFinite(v) || v < 1) v = 1;
  if (v >= SCHEMA_VERSION) {
    blob.schemaVersion = SCHEMA_VERSION;
    return blob;
  }
  if (v < 2) {
    if (Array.isArray(blob.widgets)) {
      blob.widgets = blob.widgets.map((w) => {
        if (!w || typeof w !== "object") return w;
        const nw = { ...w };
        if (!nw.kind && nw.id) nw.kind = nw.id;
        return nw;
      });
    }
    v = 2;
  }
  blob.schemaVersion = SCHEMA_VERSION;
  return blob;
}

function mergeStored(stored) {
  const blob = migrateSettings(stored) || stored;
  // The shipped singletons, one per kind, each taking whatever the stored blob
  // had for it. `kind` is written as `saved.kind ?? fallback.id` because a blob
  // from before that field existed has no kind and must still resolve to the
  // right renderer.
  const singletons = defaultWidgets().map((fallback) => {
    const saved = Array.isArray(blob.widgets)
      ? blob.widgets.find((w) => w && w.id === fallback.id)
      : null;
    if (!saved) return fallback;
    return { ...fallback, ...saved, kind: widgetKindOf(saved) };
  });
  // Every extra instance — the widgets the user added — carried over as they
  // are. The render path already skips a kind this build has no renderer for
  // (`renderWidgets` filters on `WIDGET_RENDERERS[widgetKindOf(w)]`), so a
  // widget whose kind a newer build withdrew is *kept*, not dropped.
  const extras = (Array.isArray(blob.widgets) ? blob.widgets : [])
    .filter((w) => w && typeof w.id === "string" && !singletons.some((s) => s.id === w.id))
    .map((w) => {
      const kind = widgetKindOf(w);
      return {
        ...w,
        kind,
        multiple: Boolean(w.multiple),
        data: WIDGET_KINDS.some((k) => k.id === kind) ? sanitiseWidgetData(w) : w.data,
      };
    });
  const widgets = [...singletons, ...extras].map(normaliseShortcutLinks).map((w) => {
    // The two page-furniture entries report the flag their switch actually
    // writes, so a switched-off search bar or clock does not keep its card
    // sitting in the list saying it is on.
    if (w.id === "search") return { ...w, visible: blob.searchShown !== false };
    if (w.id === "clock") return { ...w, visible: blob.clockShown !== false };
    return w;
  });
  const decor = (Array.isArray(blob.decor) ? blob.decor : [])
    .filter((d) => d && typeof d.asset === "string" && typeof d.id === "string")
    .map((d) => ({ ...d, scale: decorScaleOf(d) }));
  const searchBangs = Array.isArray(blob.searchBangs) ? sanitiseBangs(blob.searchBangs) : DEFAULTS.searchBangs;
  const customAccent = sanitiseAccentHex(blob.customAccent);
  const merged = { ...DEFAULTS, ...blob, widgets, decor, searchBangs, customAccent, schemaVersion: SCHEMA_VERSION };
  return merged;
}

/** The stored settings merged over the defaults, field by field.
 *
 *  Reads storage only, and returns immediately: a new tab must paint on the
 *  first frame, so this never waits on the network. The account copy is pulled
 *  alongside (see `hydrateFromAccount`) and repaints the page a moment later if
 *  it turns out to differ. */
async function readSettings() {
  if (settingsCache) return settingsCache;
  const stored = (await chrome.storage.local.get(SETTINGS_KEY))[SETTINGS_KEY] ?? {};
  const merged = mergeStored(stored);
  settingsCache = merged;
  // Started after the cache is populated and deliberately not awaited — see
  // above. `accountHydrated` flips before the first await, so the several
  // `get()` calls a single paint makes still produce exactly one pull.
  if (!accountHydrated) {
    accountHydrated = true;
    hydrateFromAccount().catch(() => {});
  }
  return merged;
}

/** Merge a patch into the stored settings and return the new full set. */
async function writeSettings(patch) {
  // Claimed before the first await, and that ordering is load-bearing: a drag
  // that lands while the first pull is still in flight must not then be
  // overwritten by the account's older copy a few milliseconds later.
  accountDirty = true;
  const current = await readSettings();
  // Stamped on every local write, and it is what decides which copy wins on the
  // next load (see `hydrateFromAccount`). The account blob arrives with whatever
  // stamp the machine that pushed it held, so "local is newer" has to survive
  // the round trip — which is why this is part of the blob and not a local-only
  // counter.
  const next = { ...current, ...patch, rev: nextRev(current.rev) };
  settingsCache = next;
  // Only the patch is written, so two tabs changing different fields do not
  // race each other into a lost update on the fields they did not touch.
  await chrome.storage.local.set({ [SETTINGS_KEY]: next });
  // Every change funnels through here, so this is the one place that has to
  // remember to mirror the blob to the account. Not notified locally: every
  // caller already repaints the thing it changed, and a notify here would
  // repaint the whole page once per pixel of a slider drag.
  scheduleRemotePush();
  return next;
}

/** Add another instance of an addable kind. Returns the new widget's id, so the
 *  caller can scroll to it or hand it straight back to the user.
 *
 *  Validated against `addableWidgetKinds` rather than trusted, because the
 *  request comes from a button and the kinds list is the only thing that knows
 *  which kinds are safe to duplicate. */
async function addWidget(kindId) {
  const kind = addableWidgetKinds().find((k) => k.id === kindId);
  if (!kind) return null;
  const current = await readSettings();
  const spec = newWidgetInstance(kind, current.widgets, current.widgets);
  await writeSettings({ widgets: [...current.widgets, spec] });
  return spec.id;
}

/** Place a single-icon block — one site, drawn large, no title bar.
 *
 *  This is not a kind of its own: it is the `shortcuts` kind wearing its
 *  `single` variant, which is why it goes through `newWidgetInstance` like any
 *  other added panel. Keeping it a variant means the two layouts stay one list
 *  read two ways — a grid block and a single block share their pinned-site
 *  storage, their menu, and their drag gesture — instead of becoming a second
 *  renderer that has to be kept in step with the first.
 *
 *  `url` fills the block in as it is created, which is the whole point of the
 *  paste gesture: the user copied a link somewhere and does not want a form
 *  asking them to type it again. An empty `url` makes the block's own "+" tile,
 *  so the same call serves the panel's Add button and the paste.
 *
 *  `x`/`y` are page coordinates for where it should land. Left `null` it takes
 *  the page's usual cascade, which is what the panel's button wants — it has no
 *  pointer to place the block at.
 *
 *  Returns the new widget's id, or `null` when the address is not one. */
async function addSingleIconWidget({ url = "", label = "", x = null, y = null } = {}) {
  const raw = String(url ?? "").trim();
  // Two filters, and the second is not redundant. `shortcutOf` is the gate the
  // stored list uses, and it is deliberately permissive — it accepts anything
  // `new URL` will parse, which includes `https://hello%20there/`. That is fine
  // behind a form, where a person typed the address and can see what they
  // typed; it is not fine behind a paste, where the string is whatever was on
  // the clipboard a moment ago. So a bare `https://` with no host, or a host
  // carrying an encoded space, is refused here rather than becoming a block
  // that opens nothing.
  const link = raw ? shortcutOf({ url: raw, label }) : null;
  if (raw && !link) return null;
  if (link && (!hostOfUrl(link.url) || /\s|%20/i.test(hostOfUrl(link.url)))) return null;

  const kind = WIDGET_KINDS.find((k) => k.id === "shortcuts");
  if (!kind) return null;
  const current = await readSettings();
  const spec = newWidgetInstance(kind, current.widgets, current.widgets);
  spec.variant = "single";
  // The name under the icon, and the row's name in the Widgets list. The
  // minted label ("Shortcuts 4") says nothing about *this* block; the site it
  // opens does, and it is the only name the user would recognise.
  spec.label = link ? link.label : spec.label;
  spec.data = { links: link ? [link] : [] };
  // Explicitly placed only when the caller knows where the pointer was. Left
  // null, `renderWidgets` cascades it and saves the result, which is the same
  // treatment a second shortcuts block from the panel gets.
  if (Number.isFinite(x) && Number.isFinite(y)) {
    spec.x = x;
    spec.y = y;
  }
  await writeSettings({ widgets: [...current.widgets, spec] });
  return spec.id;
}

function shortcutsShelfOf(widgets) {
  const grids = widgets.filter(
    (w) => widgetKindOf(w) === "shortcuts" && widgetVariantFor({ widgets }, w.id) === "grid",
  );
  const shown = grids.filter((w) => w.visible !== false);
  return shown.find((w) => w.id === "shortcuts") ?? shown[0] ?? grids[0] ?? null;
}

async function addPageShortcut({ url = "", label = "", x = null, y = null } = {}) {
  const raw = String(url ?? "").trim();
  const link = raw ? shortcutOf({ url: raw, label }) : null;
  if (!link) return { ok: false, reason: "address" };
  const host = hostOfUrl(link.url);
  if (!host || /\s|%20/i.test(host)) return { ok: false, reason: "address" };
  if (!Number.isFinite(x) || !Number.isFinite(y)) return { ok: false, reason: "spot" };

  const current = await readSettings();
  const kind = WIDGET_KINDS.find((k) => k.id === "shortcuts");
  if (!kind) return { ok: false, reason: "full" };
  let widgets = current.widgets;
  const owner = shortcutsShelfOf(widgets) ?? newWidgetInstance(kind, widgets, widgets);
  if (!widgets.some((w) => w.id === owner.id)) widgets = [...widgets, owner];
  const links = Array.isArray(owner.data?.links) ? owner.data.links : [];
  if (links.length >= SHORTCUT_MAX) return { ok: false, reason: "full" };

  const placed = { ...link, x: Math.round(x), y: Math.round(y) };
  const next = widgets.map((w) =>
    w.id === owner.id ? { ...w, visible: true, data: { ...w.data, links: [...links, placed] } } : w,
  );
  await writeSettings({ widgets: next });
  return { ok: true, specId: owner.id, linkId: placed.id };
}

/** Take one instance off the page for good.
 *
 *  Removes the entry rather than hiding it: a hidden multi-instance widget
 *  would come back the next time the kind was switched on globally, and the
 *  user who removed it meant it. Refuses to touch a singleton — see
 *  `isRemovableWidget` for why that split exists. */
async function removeWidget(id) {
  const current = await readSettings();
  const target = current.widgets.find((w) => w.id === id);
  if (!isRemovableWidget(target)) return current;
  // Removing the page's own furniture is the same write its switch makes:
  // `mergeStored` rebuilds the entry on every load, so a deleted one would come
  // straight back — the flag is what actually takes it off the page.
  const kind = widgetKindOf(target);
  if (kind === "search") return writeSettings({ searchShown: false });
  if (kind === "clock") return writeSettings({ clockShown: false });
  return writeSettings({ widgets: current.widgets.filter((w) => w.id !== id) });
}

/** Replace one instance's own contents (its pinned sites, for a shortcuts
 *  widget). Written whole rather than field by field because the only writer is
 *  this widget's own body, which always holds the full new list. */
async function setWidgetData(id, data) {
  const current = await readSettings();
  const widgets = current.widgets.map((w) => (w.id === id ? { ...w, data } : w));
  return writeSettings({ widgets });
}

/** One shortcut's position on the page, or `null` to send it back to its
 *  panel.
 *
 *  Written by id, never by index. A grid tile and a floating icon can both be
 *  acting on the same list — a delete in the panel shifts every index after it —
 *  so the link's `id` is the only address that survives a concurrent write.
 *  Same both-or-neither rule as `setSearchPosition`: half a coordinate is not a
 *  placement, and `shortcutOf` would null it on the next read anyway.
 *
 *  Returns the settings as written, so a caller holding an older snapshot can
 *  repaint from the authoritative list instead of guessing what changed. */
async function setShortcutPlacement(specId, linkId, x, y) {
  const placed = x != null && y != null;
  const nextX = placed ? Math.round(x) : null;
  const nextY = placed ? Math.round(y) : null;
  return mapShortcutLinks(specId, (link) =>
    link.id === linkId ? { ...link, x: nextX, y: nextY } : link,
  );
}

/** One shortcut's icon choice, or `null` for the default chain (favicon, then
 *  the host's first letter). Hardened through `normaliseShortcutIcon` on the way
 *  in *and* on the way out, because this is also the path a restored backup
 *  takes. */
async function setShortcutIcon(specId, linkId, icon) {
  const clean = normaliseShortcutIcon(icon);
  return mapShortcutLinks(specId, (link) =>
    link.id === linkId ? { ...link, icon: clean } : link,
  );
}

/** Delete several shortcuts in one write.
 *
 *  One write matters: a bulk delete over twenty ids that wrote per id would
 *  offer the account mirror twenty blobs and leave the page repainting against
 *  a list that changes underneath it. Ids that no longer exist are simply not
 *  found — a stale selection from a list edited elsewhere is not an error. */
async function removeShortcuts(specId, ids) {
  const drop = new Set(Array.isArray(ids) ? ids : [ids]);
  if (!drop.size) return readSettings();
  return mapShortcutLinks(specId, (link) => (drop.has(link.id) ? null : link));
}

/** Read-modify-write one widget's `links`, dropping the entries `fn` returns
 *  `null` for. The shared spine of the three setters above: they differ only in
 *  what they do to the link they find. */
async function mapShortcutLinks(specId, fn) {
  const current = await readSettings();
  const widgets = current.widgets.map((w) => {
    if (w.id !== specId) return w;
    const links = Array.isArray(w?.data?.links) ? w.data.links : [];
    return { ...w, data: { ...w.data, links: links.map(fn).filter(Boolean) } };
  });
  return writeSettings({ widgets });
}

/** Rename one instance, so two shortcuts panels are told apart in the list and
 *  on the page. A blank name clears back to the kind's own label rather than
 *  leaving an unnamed panel with a header nobody can read. */
async function setWidgetLabel(id, label) {
  const current = await readSettings();
  const clean = String(label ?? "").trim().slice(0, 40);
  const widgets = current.widgets.map((w) =>
    w.id === id ? { ...w, label: clean || null } : w,
  );
  return writeSettings({ widgets });
}

/** The name one widget shows in its header and its row in the settings list.
 *  Its own label if it has one, else the kind's declared label — so a plain
 *  singleton needs nothing stored to be named. */
function widgetLabelOf(spec) {
  if (typeof spec?.label === "string" && spec.label.trim()) return spec.label.trim();
  const kind = WIDGET_KINDS.find((k) => k.id === widgetKindOf(spec));
  return kind?.label ?? "Widget";
}

/** Move one widget to a position, in page coordinates. */
async function setWidgetPosition(id, x, y) {
  const current = await readSettings();
  const widgets = current.widgets.map((w) => (w.id === id ? { ...w, x, y } : w));
  return writeSettings({ widgets });
}

async function setWidgetVisible(id, visible) {
  const current = await readSettings();
  // The search bar and the clock are the page's own furniture, not panels: their
  // switch is the flag `placeSearch` and `applyClock` read, and the entry in
  // `widgets` carries it so the panel list has one row per thing on the page
  // rather than a second section with its own switches.
  if (id === "search") return writeSettings({ searchShown: visible });
  if (id === "clock") return writeSettings({ clockShown: visible });
  const widgets = current.widgets.map((w) => (w.id === id ? { ...w, visible } : w));
  return writeSettings({ widgets });
}

/** Give one widget its own style. `null` clears it back to "follow the page",
 *  which is a different state from picking the style the page currently has:
 *  changing the page's style afterwards moves the inherited widgets with it. */
async function setWidgetStyle(id, style) {
  const current = await readSettings();
  const widgets = current.widgets.map((w) => (w.id === id ? { ...w, style } : w));
  return writeSettings({ widgets });
}

/** Resize one widget. Clamped here rather than only at the slider, so a value
 *  that arrives from the account blob — which the user can edit, and which an
 *  older version of this code might have written — cannot render a widget
 *  enormous or invisible. */
async function setWidgetScale(id, scale) {
  const current = await readSettings();
  const clamped = Math.min(2, Math.max(0.6, Number(scale) || 1));
  const widgets = current.widgets.map((w) => (w.id === id ? { ...w, scale: clamped } : w));
  return writeSettings({ widgets });
}

/** Set or clear one widget's own width. `null` restores the kind's width.
 *
 *  Clamped here rather than only at the menu, for the reason `setWidgetScale`
 *  gives: this value arrives from the account blob too, and an older or
 *  hand-edited profile must not be able to render a panel wider than the screen
 *  or thinner than its own header. */
async function setWidgetWidth(id, width) {
  const current = await readSettings();
  if (width == null) {
    const widgets = current.widgets.map((w) => (w.id === id ? { ...w, width: null } : w));
    return writeSettings({ widgets });
  }
  const clamped = Math.min(WIDGET_WIDTH_MAX, Math.max(WIDGET_WIDTH_MIN, Number(width) || WIDGET_WIDTH_MIN));
  const widgets = current.widgets.map((w) => (w.id === id ? { ...w, width: Math.round(clamped) } : w));
  return writeSettings({ widgets });
}

/** The place one weather panel asks its forecast for. Per widget, like the
 *  calendar system, because two panels on one page may be two cities — a home
 *  and wherever you are working from. Blank clears it back to the kind's own
 *  default rather than storing an empty string, so a panel that never chose a
 *  city stays distinguishable from one that chose to clear it. */
async function setWidgetCity(id, city) {
  const current = await readSettings();
  const clean = String(city ?? "").trim().slice(0, 80);
  const widgets = current.widgets.map((w) => (w.id === id ? { ...w, city: clean || null } : w));
  return writeSettings({ widgets });
}

/** Whether one widget's title bar is drawn. Per widget rather than page-wide:
 *  a settled shortcuts panel reads better bare, while a bookmarks panel of the
 *  same profile still needs its name. */
async function setWidgetHeaderHidden(id, hidden) {
  const current = await readSettings();
  const widgets = current.widgets.map((w) => (w.id === id ? { ...w, hideHeader: Boolean(hidden) } : w));
  return writeSettings({ widgets });
}

/** One widget's header visibility, read through a function for the same reason
 *  every other accessor here is: the value arrives from storage, from the
 *  account blob, and from an older build, and every one of those has to read as
 *  the shipped default rather than as `undefined`. */
function widgetHeaderHidden(settings, id) {
  return settings?.widgets?.find((w) => w.id === id)?.hideHeader === true;
}

/** Whether a shortcuts tile draws its name. The sibling of
 *  `setWidgetHeaderHidden` in every respect — same per-widget key, same
 *  collapsed-not-removed contract read by the renderer. */
async function setWidgetLabelHidden(id, hidden) {
  const current = await readSettings();
  const widgets = current.widgets.map((w) => (w.id === id ? { ...w, hideLabel: Boolean(hidden) } : w));
  return writeSettings({ widgets });
}

/** One widget's tile-label visibility, read through the same veil as the rest:
 *  a value that never arrived reads as the shipped default. */
function widgetLabelHidden(settings, id) {
  return settings?.widgets?.find((w) => w.id === id)?.hideLabel === true;
}

/** Choose which layout one widget draws inside its panel. `null` clears it back
 *  to the kind's own default — see `defaultWidgets` for why that is a distinct
 *  state rather than simply storing today's default id. */
async function setWidgetVariant(id, variant) {
  const current = await readSettings();
  // Resolved through the entry's kind, not the id — see `widgetVariantFor`.
  const known = WIDGET_VARIANTS[widgetKindOf(current.widgets.find((w) => w.id === id)) ?? id];
  // Validated here, not only at the picker: the value can arrive from the
  // account blob, which the user can edit and an older build may have written.
  // An unrecognised id would otherwise be stored and then render as a blank
  // widget, since no renderer would match it.
  const next = known && known.some((v) => v.id === variant) ? variant : null;
  const widgets = current.widgets.map((w) => (w.id === id ? { ...w, variant: next } : w));
  return writeSettings({ widgets });
}

/** Choose which calendar one widget counts in. `null` clears it back to
 *  Gregorian, the same "unset means the shipped default" shape `variant` uses.
 *
 *  Validated here as well as on read: the value can arrive from the account
 *  blob, which the user can edit and an older build may have written, and an
 *  unrecognised id would reach `Intl.DateTimeFormat` and throw there. */
async function setWidgetCalendar(id, system) {
  const current = await readSettings();
  const next = CALENDAR_SYSTEMS.some((s) => s.id === system) ? system : null;
  const widgets = current.widgets.map((w) => (w.id === id ? { ...w, calendar: next } : w));
  return writeSettings({ widgets });
}

/** Choose which face one widget's dates and numerals wear. `null` clears it
 *  back to the page's own mono, the same "unset means the shipped default"
 *  shape `variant` uses.
 *
 *  `calendarFont` is written as well as `font`, and the reader accepts either —
 *  the field used to be calendar-only. Without that, a profile that had picked
 *  Vazirmatn before this build would lose the choice on the next write here,
 *  since the old key is the only place the id was ever stored. The old key is
 *  not cleared: an older build sharing the account blob still reads it. */
async function setWidgetFont(id, font) {
  const current = await readSettings();
  const next = WIDGET_FONTS.some((f) => f.id === font) ? font : null;
  const widgets = current.widgets.map((w) =>
    w.id === id ? { ...w, font: next, calendarFont: next } : w,
  );
  return writeSettings({ widgets });
}

/** Bring one widget to the front or send it to the back.
 *
 *  Computed against the current spread rather than by incrementing a counter
 *  forever: a widget sent to the front gets `max + 1` and one sent to the back
 *  gets `min - 1`, which is the whole operation. The numbers drift apart over a
 *  long session, but they stay small enough to stay exact in a double for any
 *  number of presses a person could make. */
async function setWidgetLayer(id, direction) {
  const current = await readSettings();
  const zs = current.widgets.map((w) => Number(w.z)).filter(Number.isFinite);
  const target = direction === "back" ? Math.min(...zs, 0) - 1 : Math.max(...zs, 0) + 1;
  const widgets = current.widgets.map((w) => (w.id === id ? { ...w, z: target } : w));
  return writeSettings({ widgets });
}

async function resetWidgets() {
  return writeSettings({ widgets: defaultWidgets() });
}

/** Add or remove one bookmark id in `pins`. Toggling here rather than setting
 *  the whole array lets the widget's pin button and the panel's pin row share
 *  one write path and stay consistent whichever one was pressed last. */
async function setBookmarkPinned(id, pinned) {
  const current = await readSettings();
  const pins = current.pins.filter((p) => p !== id);
  if (pinned) pins.push(id);
  return writeSettings({ pins });
}

/** Open or close one folder group in the bookmarks widget. */
/** Move the search box to a free position, or back to the centred stage.
 *
 *  `x: null` clears both ends rather than storing a half-set pair: the two
 *  coordinates are one decision — "the user placed this somewhere" — and a
 *  blob carrying an `x` with no `y` would have to be special-cased by whoever
 *  reads it. */
async function setSearchPosition(x, y) {
  if (x == null || y == null) return writeSettings({ searchX: null, searchY: null });
  return writeSettings({ searchX: Math.round(x), searchY: Math.round(y) });
}

/** Move the clock to a free position, or back to the centred stage. Same shape
 *  and same reasoning as `setSearchPosition` above. */
async function setClockPosition(x, y) {
  if (x == null || y == null) return writeSettings({ clockX: null, clockY: null });
  return writeSettings({ clockX: Math.round(x), clockY: Math.round(y) });
}

async function setClockDocked(docked) {
  return writeSettings({ clockDocked: Boolean(docked) });
}

/** The search box's width once dragged, or back to the stylesheet's own max.
 *  Clamped to the same range the grip clamps to, so a stored blob from a future
 *  build cannot land the box at a width with no way back. */
async function setSearchWidth(width) {
  if (width == null) return writeSettings({ searchWidth: null });
  const n = Math.round(Number(width));
  if (!Number.isFinite(n)) return writeSettings({ searchWidth: null });
  return writeSettings({ searchWidth: Math.min(SEARCH_WIDTH_MAX, Math.max(SEARCH_WIDTH_MIN, n)) });
}

/** The clock's face size, written by its resize grip. The panel's slider sets
 *  the same key; this is the free-form half of that control, the way the widget
 *  grip is the free-form half of the Width submenu. */
async function setClockSize(size) {
  const n = Math.round(Number(size));
  if (!Number.isFinite(n)) return;
  return writeSettings({ clockSize: Math.min(CLOCK_SIZE_MAX, Math.max(CLOCK_SIZE_MIN, n)) });
}

/** Remember the theme choice, and mirror it where the head script can reach it.
 *
 *  The mirror is the point: `chrome.storage.local` is a promise, and the page
 *  must know its theme before the first paint or it flashes. `localStorage` is
 *  synchronous and available to an extension page, so the <head> script reads
 *  this one key and sets `data-theme` while the stylesheet is still loading.
 *  A failed write (private mode, a quota) is not fatal — the page then paints
 *  the default for one frame and corrects itself when settings land. */
async function setTheme(theme) {
  const next = theme === "light" || theme === "dark" ? theme : "system";
  try {
    localStorage.setItem(THEME_MIRROR_KEY, next);
  } catch {
    /* the mirror is an optimisation for first paint, never the source of truth */
  }
  return writeSettings({ theme: next });
}

async function setGroupCollapsed(folder, collapsed) {
  const current = await readSettings();
  const collapsedFolders = current.collapsedFolders.filter((f) => f !== folder);
  if (collapsed) collapsedFolders.push(folder);
  return writeSettings({ collapsedFolders });
}

// ── decorations ───────────────────────────────────────────────────────────

/** A placement's own identity, distinct from the art it shows. `crypto.randomUUID`
 *  is available in an extension page and needs no dependency; the fallback keeps
 *  this working under a test harness that has no `crypto`. */
function decorUid() {
  try {
    return crypto.randomUUID();
  } catch {
    return `d${Date.now().toString(36)}${Math.random().toString(36).slice(2, 8)}`;
  }
}

/** Drop one piece of art onto the page. `x`/`y` are the drop point, and the
 *  placement is centred on the cursor by the caller so the art lands where the
 *  user pointed rather than with its corner there.
 *
 *  `scale: 1` is a height, not a raw pixel size: the page renders every
 *  placement at the same base height and lets the aspect ratio decide the width.
 *  A fixed pixel width would make the 1400×594 hero and the 460×690 statue
 *  different sizes at the same setting, which is not what "the same size" means
 *  to someone looking at the two of them. See `DECOR_BASE_HEIGHT`. */
async function addDecor(assetId, x, y) {
  const art = decorById(assetId);
  if (!art) return null;
  const current = await readSettings();
  const placement = {
    id: decorUid(),
    asset: assetId,
    x: Math.round(x),
    y: Math.round(y),
    scale: 1,
  };
  await writeSettings({ decor: [...current.decor, placement] });
  return placement;
}

async function updateDecor(id, patch) {
  const current = await readSettings();
  const decor = current.decor.map((d) => (d.id === id ? { ...d, ...patch, id: d.id } : d));
  return writeSettings({ decor });
}

async function removeDecor(id) {
  const current = await readSettings();
  return writeSettings({ decor: current.decor.filter((d) => d.id !== id) });
}

async function clearDecor() {
  return writeSettings({ decor: [] });
}

// ── search bangs ──────────────────────────────────────────────────────────
// A bang is a typed prefix that picks where one search goes: `yt car` searches
// YouTube for car, `yt` alone opens YouTube. The catalogue above is what the
// modal offers; these are the rules and the ways in.

const BANG_MAX = 48;
const BANG_TRIGGER_MAX = 16;
const BANG_LABEL_MAX = 40;
const BANG_URL_MAX = 2048;

function bangUid() {
  try {
    return crypto.randomUUID();
  } catch {
    return `b${Date.now().toString(36)}${Math.random().toString(36).slice(2, 8)}`;
  }
}

function isHttpUrl(value) {
  try {
    const url = new URL(value);
    return url.protocol === "http:" || url.protocol === "https:";
  } catch {
    return false;
  }
}

/** The home page implied by a template: the origin it points at.
 *
 *  Only a fallback for a blank Home field, and a rough one — a Maps template
 *  derives `https://www.google.com/` rather than `/maps`, which is why the
 *  catalogue carries its `home` explicitly and why the form's placeholder says
 *  what the derived value will be before it is saved. */
function bangHomeFromUrl(template) {
  try {
    return `${new URL(String(template).replace("%s", "")).origin}/`;
  } catch {
    return "";
  }
}

/** Check one draft bang. `others` is the list it will join and `selfId` the id
 *  being edited, so a rename that keeps its own trigger is not a collision.
 *
 *  Returns `{ ok: true, entry }` with a fully normalised entry, or
 *  `{ ok: false, error }` with a line for the `.wg-search-status` field. The
 *  same rules run on the way out of storage — see `sanitiseBangs` — so a value
 *  the form would refuse cannot get in through the account mirror either. */
function validateBang(draft, others = [], selfId = null) {
  const trigger = String(draft?.trigger ?? "")
    .trim()
    .toLowerCase();
  // Alphanumeric at both ends, dash and underscore allowed inside. A trigger
  // containing whitespace, a dot, a slash or a `%` is refused rather than
  // stored, because the matcher splits on whitespace: the token it would never
  // equal is the half of itself before the first space, so such a bang could
  // only ever sit in the list looking like it worked.
  if (!/^[a-z0-9](?:[a-z0-9_-]{0,14}[a-z0-9])?$/.test(trigger)) {
    return { ok: false, error: "A trigger is 1–16 letters, digits, dashes or underscores." };
  }
  if (others.some((b) => b.id !== selfId && String(b.trigger).toLowerCase() === trigger)) {
    return { ok: false, error: `“${trigger}” is already a bang.` };
  }

  const url = String(draft?.url ?? "")
    .trim()
    .slice(0, BANG_URL_MAX);
  if (!url.includes("%s")) {
    return { ok: false, error: "The address needs a %s where the search words go." };
  }
  // Probed with the placeholder substituted, because a template is not itself a
  // parseable URL — `%s` is not a legal host character.
  if (!isHttpUrl(url.replace("%s", "x"))) {
    return { ok: false, error: "That is not a valid http(s) address." };
  }

  const label = String(draft?.label ?? "")
    .trim()
    .slice(0, BANG_LABEL_MAX);
  const home = String(draft?.home ?? "").trim() || bangHomeFromUrl(url);
  if (!isHttpUrl(home)) {
    return { ok: false, error: "The home page is not a valid http(s) address." };
  }

  return { ok: true, entry: { trigger, label: label || trigger, url, home } };
}

/** Everything read back out of storage, filtered to what could actually work.
 *
 *  A stored list has three sources this code does not control: an older build,
 *  the storage of a profile that has been edited by hand, and the account blob
 *  a signed-in profile pulls down. An entry that fails validation is dropped
 *  rather than kept — a bang whose template has nothing to substitute has
 *  nothing to open, the same reason `decor` drops an entry with no asset. An
 *  entry whose id collides is re-minted, because two rows sharing an id would
 *  make `updateBang` write to whichever it found first. */
function sanitiseBangs(list) {
  const out = [];
  const triggers = new Set();
  const ids = new Set();
  for (const raw of Array.isArray(list) ? list : []) {
    if (!raw || typeof raw !== "object" || Array.isArray(raw)) continue;
    const checked = validateBang(raw, [], null);
    if (!checked.ok) continue;
    const { trigger } = checked.entry;
    if (triggers.has(trigger)) continue;
    let id = typeof raw.id === "string" && raw.id ? raw.id : bangUid();
    if (ids.has(id)) id = bangUid();
    triggers.add(trigger);
    ids.add(id);
    out.push({ id, ...checked.entry });
    if (out.length >= BANG_MAX) break;
  }
  return out;
}

/** Add a bang. Returns the stored entry, or `null` when the draft is refused —
 *  `validateBang` is the shared surface, so the caller can run it first and show
 *  the reason rather than repeating the rules here. */
async function addBang(draft) {
  const current = await readSettings();
  if (current.searchBangs.length >= BANG_MAX) return null;
  const checked = validateBang(draft, current.searchBangs, null);
  if (!checked.ok) return null;
  const entry = { id: bangUid(), ...checked.entry };
  await writeSettings({ searchBangs: [...current.searchBangs, entry] });
  return entry;
}

async function updateBang(id, draft) {
  const current = await readSettings();
  const checked = validateBang(draft, current.searchBangs, id);
  if (!checked.ok) return null;
  const searchBangs = current.searchBangs.map((b) => (b.id === id ? { id, ...checked.entry } : b));
  await writeSettings({ searchBangs });
  return searchBangs.find((b) => b.id === id) ?? null;
}

async function removeBang(id) {
  const current = await readSettings();
  return writeSettings({ searchBangs: current.searchBangs.filter((b) => b.id !== id) });
}

/** Put the shipped starter set back. The modal's reset, and the way out of
 *  having removed every bang by accident. */
async function resetBangs() {
  return writeSettings({ searchBangs: DEFAULT_BANGS });
}

/** Where a typed query should go, or `null` for "an ordinary search".
 *
 *  The first whitespace-delimited token is compared to each trigger by whole
 *  equality, case-insensitively. That equality is the entire defence against a
 *  prefix collision: `yellow` is the token `yellow`, which equals no trigger, so
 *  a one-letter `y` can never be woken up by a longer word. There is no prefix
 *  matching in here, deliberately.
 *
 *  The caller runs this before deciding the text is a host, so a bang always
 *  wins. The one case that matters resolves itself either way — `yt car` is the
 *  token `yt` plus words, while `yt.com` is the token `yt.com`, which equals no
 *  trigger and opens as the host it looks like. */
function parseBang(value, bangs) {
  const raw = String(value ?? "").trim();
  if (!raw || !Array.isArray(bangs)) return null;
  const parts = raw.match(/^(\S+)(?:\s+([\s\S]*))?$/);
  if (!parts) return null;
  const token = parts[1].toLowerCase();
  const bang = bangs.find((b) => String(b.trigger).toLowerCase() === token);
  if (!bang) return null;
  const words = (parts[2] ?? "").trim();
  // A bare trigger opens the platform itself. A bang with no home and no words
  // resolves to nothing rather than to a URL built from an empty query.
  if (!words) return bang.home || null;
  return bang.url.replace("%s", encodeURIComponent(words));
}

/** Re-read from storage and drop the cache. Called when another page of the
 *  extension changes settings, so an open new tab picks the change up. */
async function invalidate() {
  settingsCache = null;
  return readSettings();
}

function engineById(id) {
  return SEARCH_ENGINES.find((e) => e.id === id) ?? SEARCH_ENGINES[0];
}

/** The record shape a `"custom"` accent wears, built from an already-validated
 *  hex. Split out so `resolveAccent` and `accentById` describe the custom
 *  accent identically — two ways of building it that disagreed on the label or
 *  the derived light would show in the swatch and in the page at once. */
function customAccentRecord(hex) {
  return { id: "custom", label: "Custom", value: hex, light: deriveAccentLight(hex) };
}

/** One preset by id, or the first preset for anything unrecognised.
 *
 *  The literal `"custom"` is not a row in `ACCENTS` — its hue lives in
 *  `customAccent`, which only the settings blob knows. `applySettings` in
 *  newtab.js resolves the accent through this function, and that file is not
 *  part of this change, so the one custom case is answered from the settings
 *  cache here rather than by rewriting its caller. Every other id is a plain
 *  lookup, and an unresolvable one still falls back to the first preset, so no
 *  path can return `undefined`. */
function accentById(id) {
  if (id === "custom") {
    const hex = sanitiseAccentHex(settingsCache?.customAccent);
    if (hex) return customAccentRecord(hex);
  }
  return ACCENTS.find((a) => a.id === id) ?? ACCENTS[0];
}

/** A stored custom hex, or `null` when it is not one.
 *
 *  The value arrives from storage, from the account blob a signed-in profile
 *  pulls down, and from an imported backup file — three sources this code does
 *  not control, and one of them is a colour input whose value a hand-edited
 *  file can set to anything. A hex that is not exactly six lowercased digits
 *  could not be painted at all, so it is dropped rather than coerced: `null`
 *  makes `resolveAccent` fall back to a preset, where a half-valid string would
 *  paint `--accent` as an invalid value the browser discards, leaving the page
 *  with no accent. */
function sanitiseAccentHex(value) {
  if (typeof value !== "string") return null;
  return /^#[0-9a-f]{6}$/i.test(value) ? value.toLowerCase() : null;
}

/** The paper-theme twin of a custom hex.
 *
 *  `ACCENTS` carries a hand-tuned `light` per preset rather than deriving one,
 *  but a custom hue has no such value, so it is derived here. The same hue
 *  cannot clear contrast on both a black page and a paper one (see the note
 *  beside `ACCENTS`), and paper is the harder of the two: a mid-tone that reads
 *  on black is nearly invisible on bone.
 *
 *  A flat darken is not enough on its own. Measured against the panel's paper
 *  (`#f2eee7`), the presets' tuned variants all clear a contrast ratio of about
 *  5:1 — but 30% toward black, which matches `#ce5e32 → #a34420` and
 *  `#6b8f5e → #456b39` almost exactly, drops `#cdc4ba` to 3:1, because bone is
 *  already near the top of the range and the pale custom hues are the ones a
 *  user is most likely to pick. So the darken is the starting point and the
 *  floor is enforced: the mix deepens until the result clears 4.5:1, which is
 *  what keeps a pale pick readable instead of merely darker than before. */
function deriveAccentLight(hex) {
  const rgb = [1, 3, 5].map((i) => parseInt(hex.slice(i, i + 2), 16));
  const luminance = (c) => {
    const v = c / 255;
    return v <= 0.04045 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4;
  };
  const lum = (rgb) => 0.2126 * luminance(rgb[0]) + 0.7152 * luminance(rgb[1]) + 0.0722 * luminance(rgb[2]);
  // The paper the light theme actually paints, from theme.css.
  const paper = lum([0xf2, 0xee, 0xe7]);
  const contrast = (a, b) => (Math.max(a, b) + 0.05) / (Math.min(a, b) + 0.05);
  let mix = 0.3;
  let dark = rgb.map((c) => Math.round(c * (1 - mix)));
  while (contrast(lum(dark), paper) < 4.5 && mix < 0.9) {
    mix += 0.05;
    dark = rgb.map((c) => Math.round(c * (1 - mix)));
  }
  return `#${dark.map((c) => c.toString(16).padStart(2, "0")).join("")}`;
}

/** The accent record the page should paint, resolved from the whole settings
 *  blob.
 *
 *  The one place `"custom"` turns into a real hue, and the return shape is the
 *  same `{ id, label, value, light }` record `ACCENTS` carries, so a caller can
 *  hand it to `accentValueFor` and to the swatch row unchanged. `accentById`
 *  cannot do this on its own — it takes an id and knows only the five presets —
 *  so every painter that has the blob in hand goes through here, and the
 *  fallback is centralised: an accent of `"custom"` with no usable hex (never
 *  chosen, or a stored value that failed `sanitiseAccentHex`) resolves to the
 *  first preset rather than to an undefined colour. */
function resolveAccent(settings) {
  if (settings?.accent === "custom") {
    const hex = sanitiseAccentHex(settings.customAccent);
    if (hex) return customAccentRecord(hex);
  }
  return accentById(settings?.accent);
}

/** The hex one accent should paint with on a given page.
 *
 *  Two entries rather than one because the same hue cannot clear contrast on
 *  both a black page and a paper one — see the note beside `ACCENTS`. Kept as a
 *  helper rather than folded into `accentById` so every existing caller keeps
 *  receiving the whole record (the swatch picker needs both hexes to draw a
 *  swatch that does not lie about what it will apply). */
function accentValueFor(accent, light) {
  return light ? accent.light ?? accent.value : accent.value;
}

/** Which theme the page is actually painting, resolving `system` against the
 *  device. The head script makes the same call synchronously before paint, so
 *  this is the runtime half of one rule rather than a second opinion. */
function themeIsLight(settings) {
  const theme = settings?.theme;
  if (theme === "light") return true;
  if (theme === "dark") return false;
  try {
    return window.matchMedia("(prefers-color-scheme: light)").matches;
  } catch {
    return false;
  }
}

function clockFontById(id) {
  return CLOCK_FONTS.find((f) => f.id === id) ?? CLOCK_FONTS[0];
}

/** The style one widget should wear: its own if it has one, else the page's.
 *  Kept here rather than in `widgets.js` so the settings panel's miniature
 *  previews resolve the same inheritance the real panels do — a preview that
 *  disagreed with the page would be worse than no preview. */
function widgetStyleFor(settings, id) {
  const own = settings.widgets.find((w) => w.id === id)?.style;
  return own ?? settings.widgetStyle ?? "glass";
}

/** Which calendar one widget counts in.
 *
 *  Resolved against the *widget*, not the kind, for the same reason the variant
 *  is: two calendars side by side is a supported layout and a common one — the
 *  whole point of a lunar panel is to sit beside the Gregorian one — so reading
 *  the kind here would draw the first panel's system inside the second.
 *
 *  Validated on read as well as on write. The value ends up in an
 *  `Intl.DateTimeFormat` call, and an unrecognised id there would throw inside
 *  the renderer; falling back to Gregorian keeps a blob written by a future
 *  build, or edited by hand, drawing something rather than nothing. */
function calendarSystemFor(settings, id) {
  const own = settings?.widgets?.find((w) => w.id === id)?.calendar;
  return CALENDAR_SYSTEMS.some((s) => s.id === own) ? own : CALENDAR_SYSTEMS[0].id;
}

function widgetFontFor(settings, id) {
  const spec = settings?.widgets?.find((w) => w.id === id);
  const own = spec?.font ?? spec?.calendarFont;
  return WIDGET_FONTS.some((f) => f.id === own) ? own : WIDGET_FONTS[0].id;
}

function widgetFontById(id) {
  return WIDGET_FONTS.find((f) => f.id === id) ?? WIDGET_FONTS[0];
}

/** The place one weather panel forecasts, defaulting to the kind's own city. A
 *  stored value is trimmed again on read so a hand-edited or imported profile —
 *  which `mergeStored` cannot check against a list, because there is no list —
 *  cannot put a blank into a URL.
 *
 *  Also readable with no settings and no id (`weatherCityOf({ widgets: [] })`),
 *  which is how the menu's City field asks what a panel would read with nothing
 *  chosen — the panel's face and the field have to start from one answer, or
 *  editing a panel that already reads Tehran opens onto a blank. */
const WEATHER_DEFAULT_CITY = "Tehran";
function weatherCityOf(settings, id) {
  const spec = settings?.widgets?.find((w) => w.id === id);
  const own = String(spec?.city ?? "").trim();
  return own || WEATHER_DEFAULT_CITY;
}

/** The `Intl` locale a widget's dates and numerals are drawn in, or `null` for
 *  the page's own. Derived from the face rather than stored beside it so the
 *  two cannot disagree: a profile written before this field existed carries no
 *  locale, and picking a Persian face is what turns the widget Persian. */
function widgetLocaleFor(settings, id) {
  return widgetFontById(widgetFontFor(settings, id)).locale ?? null;
}

/** One widget's size multiplier, clamped the same way `setWidgetScale` clamps.
 *
 *  Read through a function rather than straight off the blob because the value
 *  is written by a slider, arrives from the account, and is restored by a reset
 *  — and a `NaN` or a missing field has to render as "size it normally" rather
 *  than as `zoom: NaN`, which the browser drops, leaving a widget the user
 *  cannot resize back without a manual reset. */
function widgetScaleFor(settings, id) {
  const own = Number(settings.widgets.find((w) => w.id === id)?.scale);
  return Number.isFinite(own) ? Math.min(2, Math.max(0.6, own)) : 1;
}

/** How wide one widget is, in px, or `null` for "its kind's own width".
 *
 *  Distinct from `widgetScaleFor`, and deliberately so. Scale multiplies the
 *  whole panel — type, padding and icons together — so it makes a widget
 *  *bigger*; width moves only the box, which is what a panel of pinned sites
 *  wants, since a wider one fits more tiles per row without their names growing
 *  with it. `null` rather than a number when nothing has been chosen, so the
 *  stylesheet's per-kind width still stands: a calendar starts narrower than
 *  everything else and this file does not have to restate that. */
function widgetWidthFor(settings, id) {
  const raw = settings.widgets.find((w) => w.id === id)?.width;
  // `null` is checked before `Number`, not through it: `Number(null)` is `0`,
  // which is finite, so the clamp below would answer `WIDGET_WIDTH_MIN` for
  // every widget that has never been given a width — and `0` would read as a
  // perfectly good stored value. The default is `null` for exactly this reason.
  if (raw == null) return null;
  const own = Number(raw);
  return Number.isFinite(own) ? Math.min(WIDGET_WIDTH_MAX, Math.max(WIDGET_WIDTH_MIN, own)) : null;
}

/** Which layout one widget draws, resolved the same way the style is: its own if
 *  it has one, else the kind's default. Returns `null` for a kind with no
 *  variants, which is every kind except calendar and bookmarks.
 *
 *  Validated on read as well as on write, because this value reaches the DOM as
 *  a `data-variant` attribute the stylesheet matches — an id that is in no
 *  `WIDGET_VARIANTS` entry has no rule behind it and would render the widget
 *  unstyled rather than in its default. */
function widgetVariantFor(settings, id) {
  // The variants belong to the *kind*, and so does the id they are looked up
  // by. For a singleton the two are the same string; for an added instance the
  // id is minted and would miss the map entirely, leaving it with no variant —
  // and so with a renderer that has to guess which layout to draw.
  const spec = settings.widgets.find((w) => w.id === id);
  const kind = widgetKindOf(spec) ?? id;
  const options = WIDGET_VARIANTS[kind];
  if (!options) return null;
  const own = spec?.variant;
  if (own && options.some((v) => v.id === own)) return own;
  return WIDGET_VARIANT_DEFAULTS[kind] ?? options[0].id;
}

/** One widget's stacking order. Missing or unreadable values fall back to the
 *  widget's own declaration index rather than to 0, so a blob written before
 *  layering existed — or by a version that stored no `z` — still keeps the
 *  sensible default order instead of collapsing every panel to one layer. */
function widgetZFor(settings, id) {
  const own = Number(settings.widgets.find((w) => w.id === id)?.z);
  if (Number.isFinite(own)) return own;
  const index = WIDGET_KINDS.findIndex((k) => k.id === id);
  return index < 0 ? 0 : index;
}

/** Whether a dragged widget is allowed to land on top of another one. Read
 *  through a function for the same reason `widgetScaleFor` is: the value comes
 *  from the switch, from a blob written before the switch existed, and from the
 *  account, and every one of those has to read as the shipped default rather
 *  than as `undefined`. Anything that is not an explicit `false` means the
 *  restriction is on, because that is what a profile with no opinion gets. */
function widgetOverlapAllowed(settings) {
  return settings?.widgetNoOverlap === false;
}

// `chrome.storage.onChanged` fires in every extension page when any of them
// writes. Without this the settings panel and the widgets would each hold their
// own stale cache after the other saved.
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "local") return;
  if (changes[SETTINGS_KEY]) settingsCache = null;
  // The uploaded wallpaper lives under its own key, so a second tab's upload
  // has to drop this cache too or the page would keep painting the old image.
  //
  // Only when the value actually differs, though. This page is itself a writer
  // — `setWallpaperUpload` fills the cache and *then* writes it — and the event
  // for that write arrives during the `await` inside `writeSettings`, after the
  // cache is already filled. Nulling unconditionally there throws away the very
  // image just stored, and `Boolean(wallpaperCache)` then writes
  // `wallpaperUpload: false` over the flag that says one exists: the bytes land,
  // the page never paints them, and the panel reports nothing uploaded.
  // Comparing first means another tab's upload (a different string) still
  // invalidates, while a write of the value already held does not.
  if (changes[WALLPAPER_KEY] && changes[WALLPAPER_KEY].newValue !== wallpaperCache) wallpaperCache = null;
});

// ── the account mirror ────────────────────────────────────────────────────
// Storage is per browser profile; the account is what makes a layout survive a
// new machine. Everything below is best-effort by design — the page is fully
// usable from local storage alone, so a signed-out user, an unreachable server
// or a not-yet-migrated database must all degrade to "local only" rather than
// throwing. Every failure path here is silent for that reason: there is no
// useful thing to tell a new tab about a background sync.

// Declared after the accessors above that reach for them; `let` is hoisted but
// in its temporal dead zone until this line, and nothing calls those accessors
// before the page's own boot runs.
let accountDirty = false;
let accountHydrated = false;
let settingsPushTimer = null;
const settingsSubscribers = new Set();

// ── which copy is newer ───────────────────────────────────────────────────
// The bug this exists to kill: the account copy is pulled on every load and,
// with no way to compare the two, it simply replaces local storage. So a change
// whose push did not land — the debounce cut short by a reload, the 256 KB cap,
// a signed-out or offline session — is reverted by the *older* account blob on
// the very next load, and an empty account copy resets the whole page.
//
// The fix is one number carried inside the blob: `rev`. It is stamped on every
// local write (never on a read or a merge — that would make local always look
// newest and break adopting a genuinely newer copy from another machine) and
// rides along to the account with the rest of the payload. A load may then only
// adopt the account's copy when it is at least as new as local, and local stays
// put when it is ahead. Both sides are tolerant of a missing/absent stamp,
// which is what an older build's blob looks like: it reads as revision 0, so a
// stamped local copy always wins over a legacy account one.

/** The revision a blob carries, or 0 when it has none. */
function revOf(blob) {
  const n = Number(blob && blob.rev);
  return Number.isFinite(n) && n > 0 ? Math.floor(n) : 0;
}

/** The revision the next write takes.
 *
 *  One past the current stamp, floored at the wall clock. The two halves cover
 *  different machines: the counter keeps a single profile's writes ordered even
 *  if its clock is wrong, and the clock keeps a *second* profile's writes ahead
 *  of an account copy this one has not seen yet — otherwise a fresh install
 *  whose counter happens to sit below the account's would call its own pending
 *  edit older and discard it. Whichever is larger is the safer floor, so a
 *  change this machine just made can never read as old. */
function nextRev(rev) {
  return Math.max(revOf({ rev }) + 1, Date.now());
}

/** The blob as it goes over the wire. `widgets` and `pins` are the two fields
 *  whose shape the account copy has to carry faithfully; everything else is a
 *  primitive. `rev` rides along inside it, which is the whole point — it is
 *  what lets the next load tell whose copy is newer. */
function syncPayload() {
  return { ...settingsCache };
}

async function pullRemoteSettings() {
  const token = await window.ixiAuth.readToken();
  if (!token) return null;
  const base = await window.ixiAuth.baseUrl();
  const res = await fetch(`${base}${SYNC_PATH}`, {
    headers: { Authorization: `Bearer ${token}` },
  });
  // A 404 means a deployment that predates this route, not a missing document —
  // treat it exactly like "no account copy yet" rather than surfacing an error.
  if (!res.ok) return null;
  const data = await res.json().catch(() => null);
  const config = data && typeof data.config === "object" && data.config !== null ? data.config : null;
  return config;
}

async function pushRemoteSettings() {
  const token = await window.ixiAuth.readToken();
  // Signed out: keep the local copy and try again on the next change, which is
  // the point at which `accountDirty` should be re-set rather than cleared.
  if (!token) return false;
  const payload = syncPayload();
  if (new TextEncoder().encode(JSON.stringify(payload)).length > SYNC_MAX_BYTES) return false;
  const base = await window.ixiAuth.baseUrl();
  const res = await fetch(`${base}${SYNC_PATH}`, {
    method: "PUT",
    headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
    body: JSON.stringify({ value: payload }),
  });
  return res.ok;
}

/** Adopt the account's copy if it is at least as new as the local one.
 *
 *  Two rules decide the winner, and neither is about who wrote last *in time*:
 *
 *  - `accountDirty` is set the moment the user touches a setting, so a pull that
 *    lands mid-edit loses to the edit. Without it, the first slider drag after a
 *    fresh profile would be reverted by the account blob arriving behind it.
 *  - `rev` decides the rest. A local copy that is *ahead* of the account's is a
 *    change whose push has not landed yet — the reload that cut the debounce
 *    short, a 256 KB payload the server refused, a session that was signed out.
 *    Replacing it with the older account copy is exactly the bug this guards
 *    against. Only when the account is level or ahead is adopting it safe, and
 *    only then can another machine's newer layout come across. */
async function hydrateFromAccount() {
  const remote = await pullRemoteSettings();
  if (!remote || accountDirty) return;
  // The merged local view, read through `readSettings` rather than straight off
  // `settingsCache`: a storage event from this machine's own last write nulls
  // the cache, and comparing against `null` would read as revision 0 and let the
  // account copy win — the exact revert this guards against. `readSettings`
  // re-reads storage in that case, and `accountHydrated` is already true here so
  // it will not recurse into a second pull.
  const local = await readSettings();
  const localRev = revOf(local);
  const remoteRev = revOf(remote);
  if (remoteRev < localRev) {
    // Local is ahead, so the change it holds never reached the account. Keep it
    // and try the push again rather than discarding the user's work.
    accountDirty = true;
    scheduleRemotePush();
    return;
  }
  const merged = mergeStored(remote);
  // Compared field by field rather than by identity — a repaint on an identical
  // blob would restart the clock and re-render every widget for no reason.
  if (JSON.stringify(merged) === JSON.stringify(local)) return;
  settingsCache = merged;
  await chrome.storage.local.set({ [SETTINGS_KEY]: merged });
  notifySettingsChange();
}

/** Queue a push, collapsing a burst of writes into one request. */
function scheduleRemotePush() {
  clearTimeout(settingsPushTimer);
  settingsPushTimer = setTimeout(async () => {
    settingsPushTimer = null;
    if (!accountDirty) return;
    const ok = await pushRemoteSettings().catch(() => false);
    // Cleared only on success, so a change made offline is still pending and
    // goes out with the next one instead of being silently lost.
    if (ok) accountDirty = false;
  }, SYNC_PUSH_DELAY_MS);
}

/** Tell listeners the store changed under them. The page uses this to repaint
 *  after a pull; nothing calls it for local edits, which repaint themselves. */
function notifySettingsChange() {
  for (const fn of settingsSubscribers) {
    try {
      fn();
    } catch {
      // One bad subscriber must not stop the rest, and must not escape into the
      // push timer's rejection path where nothing would report it.
    }
  }
}

/** Force the account's copy to replace the local one. Not part of the automatic
 *  path — it is for a caller that has decided local state is wrong. */
async function resetToAccount() {
  accountDirty = false;
  settingsCache = null;
  accountHydrated = true;
  const remote = await pullRemoteSettings();
  if (!remote) return false;
  const merged = mergeStored(remote);
  settingsCache = merged;
  await chrome.storage.local.set({ [SETTINGS_KEY]: merged });
  notifySettingsChange();
  return true;
}

/** Push immediately, for a caller that cannot wait out the debounce — a sign-in
 *  that has just made the account reachable. */
async function flushRemotePush() {
  clearTimeout(settingsPushTimer);
  settingsPushTimer = null;
  const ok = await pushRemoteSettings().catch(() => false);
  if (ok) accountDirty = false;
  return ok;
}

/** The height every decoration is drawn at before its own scale multiplies it.
 *  Named here rather than in `newtab.css` because the drag math and the panel's
 *  slider both need the number, and three copies of it would be three things to
 *  keep in step. 160px is around a third of the stage's height: big enough to
 *  read as artwork, small enough that several fit without burying the clock. */
const DECOR_BASE_HEIGHT = 160;

/** The scale bounds. The floor keeps a shrunken piece clickable — below about a
 *  third of 160px a decoration is a few pixels across and its own drag handle is
 *  unreachable, which is a piece of art the user cannot get rid of. */
const DECOR_MIN_SCALE = 0.35;
const DECOR_MAX_SCALE = 4;

/** Clamp a stored scale the same way the slider does, so a hand-edited blob or
 *  an older version cannot place art at a size with no way back. */
function decorScaleOf(placement) {
  const raw = Number(placement?.scale);
  return Number.isFinite(raw) ? Math.min(DECOR_MAX_SCALE, Math.max(DECOR_MIN_SCALE, raw)) : 1;
}

window.ixiNewtabSettings = {
  SEARCH_ENGINES,
  WIDGET_KINDS,
  ACCENTS,
  CLOCK_FONTS,
  WIDGET_STYLES,
  CALENDAR_STYLES,
  BOOKMARK_STYLES,
  TASK_STYLES,
  TIMER_STYLES,
  SHORTCUT_STYLES,
  WIDGET_VARIANTS,
  WALLPAPER_PATTERNS,
  DECOR_CATALOG,
  DECOR_BASE_HEIGHT,
  DECOR_MIN_SCALE,
  DECOR_MAX_SCALE,
  decorById,
  decorScaleOf,
  addDecor,
  updateDecor,
  removeDecor,
  clearDecor,
  BANG_CATALOG,
  STARTER_BANGS,
  DEFAULT_BANGS,
  BANG_MAX,
  bangFromCatalog,
  validateBang,
  parseBang,
  addBang,
  updateBang,
  removeBang,
  resetBangs,
  DEFAULTS,
  defaultWidgets,
  // The hardening pass every stored blob goes through, exposed for `backup.js`:
  // an imported file is a fourth source of settings — hand-edited, truncated by
  // a bad download, written by an older build — and it has to be normalised by
  // exactly the code that normalises storage, or a restore could produce a
  // layout the page would never have made.
  normaliseStored: mergeStored,
  SHORTCUT_MAX,
  SHORTCUT_ICONS,
  SHORTCUT_ICON_GLYPHS,
  addableWidgetKinds,
  isRemovableWidget,
  widgetKindOf,
  widgetLabelOf,
  hostOfUrl,
  shortcutHref,
  todoTokenFromUrl,
  todoLinkOf,
  get: readSettings,
  set: writeSettings,
  addWidget,
  addSingleIconWidget,
  addPageShortcut,
  removeWidget,
  setWidgetData,
  setWidgetLabel,
  setWidgetPosition,
  setWidgetVisible,
  setWidgetStyle,
  setWidgetScale,
  setWidgetWidth,
  setWidgetVariant,
  setWidgetCity,
  setWidgetCalendar,
  setWidgetFont,
  calendarSystemFor,
  widgetFontFor,
  widgetFontById,
  weatherCityOf,
  widgetLocaleFor,
  CALENDAR_SYSTEMS,
  WIDGET_FONTS,
  setWidgetHeaderHidden,
  setWidgetLabelHidden,
  widgetLabelHidden,
  widgetHeaderHidden,
  setWidgetLayer,
  resetWidgets,
  WALLPAPER_KEY,
  getWallpaperUpload,
  setWallpaperUpload,
  clearWallpaperUpload,
  setBookmarkPinned,
  setGroupCollapsed,
  setSearchPosition,
  setClockPosition,
  setClockDocked,
  setSearchWidth,
  setClockSize,
  setTheme,
  SEARCH_WIDTH_MIN,
  SEARCH_WIDTH_MAX,
  CLOCK_SIZE_MIN,
  CLOCK_SIZE_MAX,
  THEME_MIRROR_KEY,
  setShortcutPlacement,
  setShortcutIcon,
  removeShortcuts,
  normaliseShortcutIcon,
  SHORTCUT_ICON_MAX_BYTES,
  invalidate,
  // The account mirror. `subscribe` is how the page learns that a pull replaced
  // the blob under it; `flushRemotePush` is for the moment a sign-in makes the
  // account reachable and any pending local change should go out at once.
  subscribe: (fn) => {
    settingsSubscribers.add(fn);
    return () => settingsSubscribers.delete(fn);
  },
  hydrateFromAccount,
  flushRemotePush,
  resetToAccount,
  engineById,
  accentById,
  accentValueFor,
  resolveAccent,
  sanitiseAccentHex,
  deriveAccentLight,
  themeIsLight,
  clockFontById,
  widgetStyleFor,
  widgetScaleFor,
  widgetWidthFor,
  WIDGET_WIDTH_MIN,
  WIDGET_WIDTH_MAX,
  widgetVariantFor,
  widgetZFor,
  widgetOverlapAllowed,
};
