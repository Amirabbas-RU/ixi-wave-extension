// Session handling for the ixi-wave extension.
//
// The portfolio authenticates the admin with an httpOnly `ixi_admin_token`
// cookie. An extension page cannot read or set that cookie, and the site sends
// no CORS headers at all — so instead of a cookie the extension holds the same
// signed JWT and replays it as `Authorization: Bearer`. `lib/auth.ts` and
// `middleware.ts` accept it there, which makes the whole owner surface
// (`/api/admin/*` and `/api/v1/*`) reachable without a single new endpoint.
//
// Requests still go out through the manifest's `host_permissions`, which is the
// one path that reaches the site without it needing CORS headers.

const SITE_ORIGIN = "https://ixiflower.vercel.app";

// Local development against `next dev`. Detected at call time rather than
// hardcoded, so a packaged build always talks to production.
async function baseUrl() {
  const stored = await chrome.storage.local.get("apiBase");
  if (stored.apiBase) return stored.apiBase;
  return SITE_ORIGIN;
}

const SESSION_KEY = "ixiSession";

async function readSession() {
  const stored = await chrome.storage.local.get(SESSION_KEY);
  return stored[SESSION_KEY] ?? null;
}

async function writeSession(session) {
  await chrome.storage.local.set({ [SESSION_KEY]: session });
}

async function clearSession() {
  await chrome.storage.local.remove(SESSION_KEY);
}

/**
 * POST JSON to the site and normalise the response.
 *
 * Returns `{ ok, status, data }` rather than throwing on a non-2xx: the auth
 * routes use 4xx for ordinary outcomes (wrong password, signup disabled), and
 * those are messages to show the user, not exceptional failures. Only a
 * transport error throws.
 */
async function postJson(path, body) {
  const base = await baseUrl();
  let res;
  try {
    res = await fetch(`${base}${path}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
  } catch (e) {
    const msg = e instanceof Error ? e.message : "Network error";
    throw new Error(`Could not reach ${base} — ${msg}`);
  }
  const data = await res.json().catch(() => ({}));
  return { ok: res.ok, status: res.status, data };
}

/** Sign in and persist the session. Returns the session on success, throws otherwise. */
async function login(identifier, password) {
  const { ok, data } = await postJson("/api/admin/auth/login", { identifier, password });
  if (!ok) throw new Error(data.error || "Sign in failed");
  const session = {
    email: data.email ?? identifier,
    token: data.token ?? null,
    // Only `owner` unlocks the owner-only Tools tab. Anything else — including a
    // deployment that predates roles and sends nothing — is treated as a plain
    // user, which is the safe default: the server enforces the same rule.
    role: data.role === "owner" ? "owner" : "user",
    signedInAt: Date.now(),
  };
  if (!session.token) {
    // The route has always set the cookie, so a missing body token means the
    // deployment predates this. Say so here rather than letting every Tools
    // request fail later with an unexplained 401.
    throw new Error("Signed in, but this deployment does not issue an extension token yet.");
  }
  await writeSession(session);
  return session;
}

/** Create an account, then sign in. The endpoint is gated server-side. */
async function signup(email, username, password) {
  const payload = { email, password };
  if (username) payload.username = username;
  const { ok, data } = await postJson("/api/admin/auth/signup", payload);
  if (!ok) throw new Error(data.error || "Signup failed");
  // Signup signs the account in server-side, but only via the cookie, so sign
  // in again to obtain the body token this extension needs. This also picks up
  // the `role` the account was created with (always `user`).
  return await login(email, password);
}

/** Whether the stored session belongs to the owner (and so may use Tools). */
async function isOwner() {
  const session = await readSession();
  return session?.role === "owner";
}

/**
 * The stored session JWT, or null. Read from storage on every call rather than
 * cached in a module variable — a sign-out elsewhere would otherwise leave this
 * popup holding a token that no longer resolves.
 */
async function readToken() {
  const session = await readSession();
  return session?.token ?? null;
}

async function logout() {
  await clearSession();
}

/** Exposed as a global for popup.js — both are plain scripts, no bundler. */
window.ixiAuth = {
  SITE_ORIGIN,
  baseUrl,
  readSession,
  writeSession,
  clearSession,
  readToken,
  login,
  signup,
  logout,
  isOwner,
};