// MV3 requires a service worker to be declared, but this extension does its
// work in the popup. The worker exists so the manifest is valid and so there is
// an obvious place to add background behaviour (badge counts, sync) later.
//
// It deliberately reads and writes no settings. The walkthrough for the Tools
// switch that turns the new tab page off *disables the extension* — the only way
// to let Chrome have its own new tab back — and a service worker is stopped when
// the extension is disabled. Anything here that depended on `chrome.storage`
// would therefore be left half-done at exactly the moment it mattered. The
// handoff is read back in the popup instead, which is guaranteed to run.

chrome.runtime.onInstalled.addListener(() => {
  // Nothing to schedule yet — the popup owns all state.
});
