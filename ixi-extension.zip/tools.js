// The Tools panel: timer, bookmarks, vault and todos, inside the popup.
//
// Every tool renders into one shared `tool-body` host rather than each owning a
// hidden panel. A tool gets a `render(host)` function and registers a teardown
// through `onTeardown` for anything that has to tick or listen, so switching
// tools releases the previous one from a single place.
//
// Nothing from the network is ever built into markup — a bookmark title or a
// vault entry name is untrusted text, and interpolating it into innerHTML is
// the one way this popup could be made to run something. Nodes are built with
// textContent throughout.

const toolEls = {
  menu: document.getElementById("tool-menu"),
  list: document.getElementById("tool-list"),
  view: document.getElementById("tool-view"),
  body: document.getElementById("tool-body"),
  back: document.getElementById("tool-back"),
  title: document.getElementById("tool-title"),
};

/** Every tool: menu label, one-line hint, icon, and its renderer.
 *
 *  The new tab page is deliberately not in this list. It is not a tool that
 *  renders into the popup — it is a page the browser opens — so its row is the
 *  switch built by `buildNewtabGroup`, not a menu entry. */
const TOOLS = [
  { key: "timer", label: "Timer", hint: "stopwatch · countdown", icon: "timer", render: renderTimer },
  { key: "bookmarks", label: "Bookmarks", hint: "saved links", icon: "bookmarks", render: renderBookmarks },
  { key: "vault", label: "Vault", hint: "passwords", icon: "vault", render: renderVault },
  { key: "todos", label: "Todos", hint: "shared lists", icon: "todos", render: renderTodos },
];

/** The mask each tool row draws, as a custom-property name in `theme.css`.
 *  `newtab` is here without being in `TOOLS` because the icon opens the page
 *  from the switch row rather than labelling a tool. */
const TOOL_ICONS = {
  timer: "--icon-timer",
  bookmarks: "--icon-bookmarks",
  vault: "--icon-vault",
  todos: "--icon-todos",
  newtab: "--icon-newtab",
};

/** One icon box, masked to the tool's drawing. Falls back to the accent-free
 *  bullet the menu used before if a tool is added without an icon. */
function toolIcon(icon) {
  const name = TOOL_ICONS[icon];
  if (!name) return el("span", "glyph", "▸");
  const node = el("span", "tool-icon");
  node.style.setProperty("--icon", `var(${name})`);
  node.setAttribute("aria-hidden", "true");
  return node;
}

// Released when the current view unmounts — a timer interval, mostly. Without
// this a closed view would keep ticking against removed nodes.
let teardown = null;

function onTeardown(fn) {
  teardown = fn;
}

// Every tool is a stack of views, bottom being the tool itself. A Vault entry's
// detail and its edit form are pushed on top of the list, so Back steps up one
// level at a time instead of throwing the whole tool away. Only the top view is
// ever in the DOM.
let viewStack = [];

/** Clear the whole stack and release whatever the top view registered.
 *  Every discarded frame's `onReturn` runs too, which is how a menu row that
 *  caches state learns the view it opened has gone. */
function resetToolView() {
  if (teardown) {
    teardown();
    teardown = null;
  }
  leaveFrames(viewStack);
  viewStack = [];
  toolEls.body.replaceChildren();
}

/** Fire the `onReturn` of each frame being thrown away. Separate from the loop
 *  that clears the stack so the two callers below cannot each half-do it. */
function leaveFrames(frames) {
  for (const frame of frames) {
    try {
      frame.onReturn?.();
    } catch {
      // A repaint of something already on screen is never worth failing a
      // navigation over.
    }
  }
}

/** Re-render the top of the stack. Returns false when there is nothing left. */
function paintView() {
  const top = viewStack[viewStack.length - 1];
  if (!top) return false;
  if (teardown) {
    teardown();
    teardown = null;
  }
  toolEls.body.replaceChildren();
  toolEls.title.textContent = top.title;
  top.render(toolEls.body);
  return true;
}

/**
 * Open a view on top of the current one — a detail page, a form. `render`
 * receives the body host exactly as a tool's own renderer does, so the two
 * levels are written the same way.
 *
 * `onReturn` fires when this frame leaves the stack, however it leaves, so a
 * view that changed something the level below displays can repaint it. The
 * tool menu reads the new tab page's on/off state once when it is built, and
 * this is what keeps its row from going stale behind a switch flipped a level
 * deeper.
 */
function pushView(title, render, onReturn) {
  viewStack.push({ title, render, onReturn });
  paintView();
}

/** Step back one level. False when already at the bottom, so Back can leave. */
function popView() {
  if (!viewStack.length) return false;
  leaveFrames([viewStack.pop()]);
  return paintView();
}

/**
 * Drop every view above the tool's own and repaint it. Anything a pushed view
 * wrote has changed the list underneath, so returning to a list one level up
 * would be returning to one built from stale data — this goes all the way back
 * and lets the tool fetch again.
 */
function popToBase() {
  if (viewStack.length <= 1) return paintView();
  viewStack = viewStack.slice(0, 1);
  return paintView();
}

/**
 * A message for the tool to show once it has finished the reload it is about to
 * start. `popToBase` re-runs the tool's renderer, which builds fresh closures —
 * so a pushed view cannot hand its result to the list's own `refresh` (that
 * belongs to the render being thrown away) and has to leave it here instead.
 *
 * The reload clears the status line when it succeeds, which is why this is
 * consumed by the *new* render's load rather than set after the old one.
 */
let pendingNotice = null;

/** Leave a notice for the next render of the tool, then return to its base view. */
function returnToBase(message, kind = "ok") {
  pendingNotice = { message, kind };
  popToBase();
}

/** Claim the pending notice, if any. Cleared on read so it shows exactly once. */
function takeNotice() {
  const notice = pendingNotice;
  pendingNotice = null;
  return notice;
}

function openTool(tool) {
  resetToolView();
  toolEls.menu.classList.add("hidden");
  toolEls.view.classList.remove("hidden");
  viewStack.push({ title: tool.label, render: tool.render });
  paintView();
}

/** Show the tool chooser, releasing whatever view was open. */
function closeTool() {
  resetToolView();
  toolEls.view.classList.add("hidden");
  toolEls.menu.classList.remove("hidden");
}

// ── small DOM helpers ─────────────────────────────────────────────────────

function el(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  // A third argument that is already a node is appended rather than stringified
  // — `textContent = node` renders "[object HTMLSpanElement]" into the DOM,
  // which is silent and reads as a styling bug rather than a coding one.
  if (text instanceof Node) node.append(text);
  else if (text !== undefined) node.textContent = text;
  return node;
}

/** An inline status line, in the three tones the popup already uses.
 *
 *  `container` may be either the status node itself or a host that holds one.
 *  The older callers pass a whole tool host and let this find the line inside
 *  it; the newer ones already know which node they wrote. Accepting both is
 *  load-bearing: handed the line itself, the old body looked for a
 *  `.tool-status` *inside* it, found none and returned, so the message the
 *  caller had just composed was silently dropped. */
function status(container, text, kind = "") {
  const box = container.classList?.contains("tool-status")
    ? container
    : container.querySelector(".tool-status");
  if (!box) return;
  box.textContent = text || "";
  box.className = `tool-status${text ? (kind ? ` ${kind}` : "") : " hidden"}`;
}

// ── todos: "new since you last looked" ────────────────────────────────────
// The site keeps this in localStorage, which an extension page shares with the
// site only when it is a page on that origin — the popup is `chrome-extension://`
// and gets its own store. So the popup keeps its own baseline in chrome.storage:
// the task count each page had when this list was last opened here. A page must
// be recorded once before a later task counts as new, which is what keeps the
// first run from lighting up every row at once.

const TODO_SEEN_KEY = "ixiTodoSeen";

/** Bumped when the user turns the new page off, and read back by the service
 *  worker when it is next enabled — the one thing an extension can say to its
 *  own future self across a disable/enable cycle. `chrome.storage` outlives the
 *  extension being switched off; nothing else here does, because a disabled
 *  extension runs no code. */
const DISABLE_KEY = "ixiNewtabDisabledAt";

async function readTodoSeen() {
  const stored = await chrome.storage.local.get(TODO_SEEN_KEY);
  const map = stored[TODO_SEEN_KEY];
  return map && typeof map === "object" ? map : {};
}

async function markTodoSeen(pageId, total) {
  if (!pageId || !Number.isFinite(total)) return;
  const map = await readTodoSeen();
  if (map[pageId] === total) return;
  map[pageId] = total;
  await chrome.storage.local.set({ [TODO_SEEN_KEY]: map });
}

/** A muted centred line — loading, empty, and similar. */
function placeholder(text) {
  return el("p", "tool-empty", text);
}

/** Drop the placeholder once real content exists. */
function clearPlaceholder(host) {
  const node = host.querySelector(".tool-empty");
  if (node) node.remove();
}

/**
 * Show a centred message in a list that has no rows. The list keeps its frame
 * for real content, but an empty one is only holding a sentence — leaving the
 * border on would draw a box around the message, so it is dropped here and
 * restored the moment a row is appended.
 */
function showEmpty(list, text) {
  list.classList.add("is-empty");
  list.append(placeholder(text));
}

/** Put the frame back on a list that is about to receive rows. */
function clearList(list) {
  list.classList.remove("is-empty");
  list.replaceChildren();
}

function actionButton(label, onClick, className = "btn-ghost") {
  const b = el("button", className, label);
  b.type = "button";
  b.addEventListener("click", onClick);
  return b;
}

/**
 * Run an async load with a status line on failure. `button` may be null when
 * the trigger is not a button (the initial load).
 *
 * `notice`, when given, is a `{ message, kind }` shown once the load succeeds.
 * It has to be applied here rather than at the end of `fn` because a load that
 * finishes cleanly clears the status line, and anything `fn` set would be
 * wiped a line later.
 */
async function load(button, box, fn, failPrefix, notice) {
  if (button) button.disabled = true;
  status(box, "Loading...", "note");
  try {
    await fn();
    if (notice) status(box, notice.message, notice.kind);
    else status(box, "");
  } catch (e) {
    status(box, `${failPrefix}: ${e instanceof Error ? e.message : "failed"}`, "error");
  } finally {
    if (button) button.disabled = false;
  }
}

/**
 * One row in a scrolling list: a title line over a muted second line. `icon`,
 * when given, is prepended and only then are the two lines wrapped — the row
 * turns into a flex row (icon beside the stack) instead of the plain column the
 * Vault and Todos lists keep.
 */
function listRow(title, sub, icon) {
  const row = el("div", "tool-row");
  const titleEl = el("span", "tool-row-title", title);
  const subEl = el("span", "tool-row-sub", sub);
  if (!icon) {
    row.append(titleEl, subEl);
    return row;
  }
  row.classList.add("has-icon");
  const text = el("div", "tool-row-text");
  text.append(titleEl, subEl);
  row.append(icon, text);
  return row;
}

// ── overlays ──────────────────────────────────────────────────────────────
// Both the row menu and the delete confirm are fixed overlays on <body> rather
// than children of the row that opened them: a list scrolls inside
// `overflow-y: auto`, which would clip a dropdown sitting below the last row,
// and a confirm drawn inside the tool body would be erased by the re-render
// that follows the action it is confirming.

let openMenuNode = null;

function closeMenu() {
  if (!openMenuNode) return;
  openMenuNode.remove();
  openMenuNode = null;
  document.removeEventListener("mousedown", onMenuOutside, true);
  document.removeEventListener("keydown", onMenuKey, true);
  window.removeEventListener("scroll", closeMenu, true);
}

function onMenuOutside(e) {
  if (openMenuNode && !openMenuNode.contains(e.target)) closeMenu();
}

function onMenuKey(e) {
  if (e.key === "Escape") closeMenu();
}

/**
 * The row's ⋯ menu. `items` are `{ label, onSelect, danger? }`; the menu closes
 * before the handler runs, so a handler that re-renders the list is not
 * fighting an overlay that is still listening for its own dismissal.
 */
function rowMenu(anchor, items) {
  const wasOpen = openMenuNode != null;
  closeMenu();
  if (wasOpen) return; // a second press on the same ⋯ closes rather than reopens

  const menu = el("div", "pop-menu");
  for (const item of items) {
    const b = el("button", `pop-menu-item${item.danger ? " is-danger" : ""}`, item.label);
    b.type = "button";
    b.addEventListener("click", () => {
      closeMenu();
      item.onSelect();
    });
    menu.append(b);
  }
  document.body.append(menu);

  // Anchor to the button's right edge, then pull the menu back inside the
  // viewport if that would push it off either side.
  const rect = anchor.getBoundingClientRect();
  const width = menu.offsetWidth;
  const left = Math.min(Math.max(6, rect.right - width), window.innerWidth - width - 6);
  const below = rect.bottom + 4;
  const top = below + menu.offsetHeight > window.innerHeight - 6
    ? Math.max(6, rect.top - menu.offsetHeight - 4)
    : below;
  menu.style.left = `${left}px`;
  menu.style.top = `${top}px`;

  openMenuNode = menu;
  document.addEventListener("mousedown", onMenuOutside, true);
  document.addEventListener("keydown", onMenuKey, true);
  // Capture, so scrolling the inner list dismisses the menu too — a menu left
  // floating over the wrong row is worse than no menu.
  window.addEventListener("scroll", closeMenu, true);
}

/**
 * A themed confirm, resolving true only on the confirm button. Replaces
 * `window.confirm`, which MV3 popups render as an unstyled browser dialog that
 * blocks the whole popup.
 */
function confirmAction({ title, message, confirmLabel = "Confirm", danger = false }) {
  return new Promise((resolve) => {
    const overlay = el("div", "overlay");
    const box = el("div", "dialog");
    box.append(el("div", "dialog-title", title));
    if (message) box.append(el("p", "dialog-text", message));

    const actions = el("div", "row");
    let done = false;
    const finish = (value) => {
      if (done) return;
      done = true;
      overlay.remove();
      document.removeEventListener("keydown", onKey, true);
      resolve(value);
    };
    function onKey(e) {
      if (e.key === "Escape") finish(false);
    }

    const cancel = el("button", "btn-mini btn-mini-quiet", "Cancel");
    cancel.type = "button";
    cancel.addEventListener("click", () => finish(false));
    const confirm = el("button", `btn-mini${danger ? " is-danger" : ""}`, confirmLabel);
    confirm.type = "button";
    confirm.addEventListener("click", () => finish(true));
    actions.append(cancel, confirm);
    box.append(actions);

    // The backdrop cancels, but clicks inside the box must not bubble to it.
    overlay.addEventListener("click", () => finish(false));
    box.addEventListener("click", (e) => e.stopPropagation());
    overlay.append(box);
    document.body.append(overlay);
    document.addEventListener("keydown", onKey, true);
    // Put the cursor on the safe choice, not the destructive one.
    cancel.focus();
  });
}

// ── detail + form vocabulary ──────────────────────────────────────────────

/** One labelled line in a detail view. `value` may be a string or a node. */
function detailRow(label, value) {
  const row = el("div", "detail-row");
  row.append(el("span", "micro", label));
  if (value instanceof Node) {
    const holder = el("div", "detail-value");
    holder.append(value);
    row.append(holder);
  } else {
    row.append(el("div", "detail-value", value || "—"));
  }
  return row;
}

/** A labelled form control, matching the auth form's field idiom. */
function formField(label, control) {
  const wrap = el("div", "field");
  const micro = el("span", "micro", label);
  wrap.append(micro, control);
  return wrap;
}

/** A read-only line whose text can be copied to the clipboard in one press. */
function copyLine(text, host, label = "Copy") {
  const row = el("div", "copy-line");
  row.append(el("span", "copy-text", text));
  const b = el("button", "btn-mini shrink", label);
  b.type = "button";
  b.addEventListener("click", () => {
    navigator.clipboard
      .writeText(text)
      .then(() => status(host, "Copied to clipboard", "ok"))
      .catch(() => status(host, "Could not copy", "error"));
  });
  row.append(b);
  return row;
}

/** A text input with the popup's standard styling. */
function input(placeholder, value = "", type = "text") {
  const node = el("input", "input");
  node.type = type;
  node.placeholder = placeholder;
  node.value = value ?? "";
  return node;
}

/** A textarea — notes and descriptions are multi-line on the site too. */
function textarea(placeholder, value = "") {
  const node = el("textarea", "input textarea");
  node.placeholder = placeholder;
  node.value = value ?? "";
  node.rows = 3;
  return node;
}

/**
 * The ⋯ button every row in a list carries, with the menu behind it. The button
 * stops the click from reaching the row, so opening the menu never also
 * triggers whatever the row itself does.
 *
 * `handlers` are named rather than positional, because a list row and a vault
 * detail view need different subsets and a caller passing `undefined` for the
 * one it lacks is easy to misread.
 */
function rowActions(record, handlers) {
  const more = el("button", "row-more", "⋯");
  more.type = "button";
  const name = record.title || record.url || "this row";
  more.title = `Actions for ${name}`;
  more.setAttribute("aria-label", `Actions for ${name}`);
  more.addEventListener("click", (e) => {
    e.stopPropagation();
    const items = [];
    if (handlers.open) items.push({ label: "Open", onSelect: handlers.open });
    if (handlers.edit) items.push({ label: "Edit", onSelect: handlers.edit });
    if (handlers.remove) items.push({ label: "Delete", onSelect: handlers.remove, danger: true });
    rowMenu(more, items);
  });
  return more;
}

/** A stored timestamp in the site's own detail-view format. */
function formatVaultDate(iso) {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return String(iso);
  return d.toLocaleString(undefined, {
    month: "short",
    day: "numeric",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

// ── timer ─────────────────────────────────────────────────────────────────

const pad = (n) => String(n).padStart(2, "0");

/** ms → `1h 02m 03s`, or `02m 03s` below an hour. */
function formatDuration(ms) {
  const total = Math.max(0, Math.floor(ms / 1000));
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  const s = total % 60;
  return h > 0 ? `${h}h ${pad(m)}m ${pad(s)}s` : `${pad(m)}m ${pad(s)}s`;
}

/** ms → `MM:SS` for the clock face; hours fold into minutes. */
function formatClock(ms) {
  const total = Math.max(0, Math.floor(ms / 1000));
  return `${pad(Math.floor(total / 60))}:${pad(total % 60)}`;
}

function formatSeconds(total) {
  const s = Math.max(0, Math.round(total));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  return h > 0 ? `${h}h ${m}m` : `${m}m ${s % 60}s`;
}

/**
 * `25`, `25:00` or `1:30:00` → seconds, or 0 when it does not parse. The site's
 * own parser (app/admin/timer/page.tsx:104) only accepts the colon forms; a bare
 * number is read as minutes here, because a popup field is typed into far more
 * casually than the composer on the site.
 */
function parseClockText(value) {
  const parts = String(value)
    .trim()
    .split(":")
    .map((p) => Number(p.trim()));
  if (!parts.length) return 0;
  if (parts.some((n) => !Number.isFinite(n) || n < 0)) return 0;
  if (parts.length === 1) return Math.round(parts[0] * 60);
  if (parts.length === 2) return parts[0] * 60 + parts[1];
  if (parts.length === 3) return parts[0] * 3600 + parts[1] * 60 + parts[2];
  return 0;
}

// `createElement` alone makes HTML elements, which cannot be SVGs at all — the
// ring would silently not render. Every shape below needs the SVG namespace.
const SVG_NS = "http://www.w3.org/2000/svg";

function svgEl(tag, attrs) {
  const node = document.createElementNS(SVG_NS, tag);
  for (const [k, v] of Object.entries(attrs)) node.setAttribute(k, v);
  return node;
}

/**
 * The site's `ProgressRing` (app/admin/timer/page.tsx:117), rebuilt in plain
 * DOM: a faint track circle with a round-capped arc that drains as the countdown
 * runs. Same geometry — radius inset by half the thickness so the ring fills its
 * box exactly — the same start at twelve o'clock (the SVG is rotated by CSS, as
 * the site's `-rotate-90` does), and the same linear transition on the offset so
 * the sweep reads as continuous rather than stepped.
 */
function createRing({ size = 140, thickness = 8, stroke = "var(--sun)" } = {}) {
  const r = (size - thickness) / 2;
  const circumference = 2 * Math.PI * r;
  const common = { cx: size / 2, cy: size / 2, r, fill: "none", "stroke-width": thickness };

  const svg = svgEl("svg", { width: size, height: size, class: "ring-svg" });
  svg.append(svgEl("circle", { ...common, stroke: "rgba(205, 196, 186, 0.08)" }));
  const arc = svgEl("circle", {
    ...common,
    stroke,
    "stroke-linecap": "round",
    "stroke-dasharray": circumference,
    "stroke-dashoffset": 0,
    class: "ring-arc",
  });
  svg.append(arc);

  const wrap = el("div", "ring");
  wrap.style.width = `${size}px`;
  wrap.style.height = `${size}px`;
  const face = el("div", "ring-face");
  wrap.append(svg, face);

  return {
    wrap,
    face,
    /** `fraction` is 0..1 where 1 is a full ring; the arc shortens below that. */
    setFraction(fraction) {
      const clamped = Math.min(1, Math.max(0, fraction));
      arc.setAttribute("stroke-dashoffset", String(circumference * (1 - clamped)));
    },
    /** Restroke both circles, for a colour chosen after the ring was built. */
    setStroke(next) {
      arc.setAttribute("stroke", next);
    },
  };
}

const COUNTDOWN_PRESETS = [5, 15, 25, 45, 60];

// The five accents the site's composer offers
// (app/admin/timer/page.tsx:74 `COLORS`). The key is what the API stores in
// `color`; the hex is what the ring is stroked with, so a clock keeps the
// colour it was started with on both the site and here.
const TIMER_COLORS = [
  { key: "emerald", stroke: "#34d399" },
  { key: "amber", stroke: "#fbbf24" },
  { key: "sky", stroke: "#38bdf8" },
  { key: "rose", stroke: "#fb7185" },
  { key: "violet", stroke: "#a78bfa" },
];

const DEFAULT_TIMER_COLOR = "emerald";

/** The stroke hex for a stored colour key, falling back to the default. */
function strokeFor(colorKey) {
  const found = TIMER_COLORS.find((c) => c.key === colorKey);
  return (found ?? TIMER_COLORS[0]).stroke;
}

function renderTimer(host) {
  host.append(el("div", "tool-status hidden"));

  // ── the composer's door ─────────────────────────────────────────────────
  // The composer is the tallest thing in the popup — the switch, the ring, the
  // chips, the duration field, the metadata row and the start button come to
  // ~225px of a 580px budget — so leaving it standing permanently pushed every
  // live clock below the fold. It now starts collapsed behind this row and is
  // revealed on demand, then closed again the moment a clock is started.
  //
  // The glyph and label are separate nodes rather than one text node because
  // both change together with the state, and a single string would mean
  // rebuilding the button's contents on every toggle.
  const newGlyph = el("span", "glyph", "+");
  const newLabel = el("span", "new-toggle-label", "New timer");
  const newToggle = el("button", "new-toggle");
  newToggle.type = "button";
  newToggle.setAttribute("aria-expanded", "false");
  newToggle.append(newGlyph, newLabel);

  // ── composer ────────────────────────────────────────────────────────────
  // The ring stands on top, then the kind switch, then whatever that kind
  // needs. Both kinds share the same optional metadata, so it lives once at the
  // bottom behind a `+` rather than doubling the panel for every mode.
  const composer = el("div", "composer hidden");

  /** Open or close the composer, keeping the toggle's label and `aria-expanded`
   *  in step with what is actually on screen. */
  function setComposerOpen(open) {
    composer.classList.toggle("hidden", !open);
    newToggle.setAttribute("aria-expanded", String(open));
    newGlyph.textContent = open ? "−" : "+";
    newLabel.textContent = open ? "Close" : "New timer";
  }

  newToggle.addEventListener("click", () => setComposerOpen(composer.classList.contains("hidden")));

  // The preview stands at fraction 1 ("ready"), exactly like the site's
  // composer; the ring only drains once a countdown is actually running. It is
  // gauge-sized and sits beside the mode switch rather than above it — a
  // full-width ring costs ~140px of popup height on its own, which is most of
  // what made the composer the tallest thing on screen.
  const preview = createRing({ size: 58, thickness: 6, stroke: strokeFor(DEFAULT_TIMER_COLOR) });
  preview.setFraction(1);
  preview.face.append(el("div", "ring-clock", "25:00"));
  const previewWrap = el("div", "ring-wrap");
  previewWrap.append(preview.wrap);
  const composerHead = el("div", "composer-head");

  const kindRow = el("div", "seg");
  const kindButtons = {};
  for (const [key, label] of [
    ["stopwatch", "Stopwatch"],
    ["countdown", "Countdown"],
  ]) {
    const b = el("button", "seg-btn", label);
    b.type = "button";
    b.addEventListener("click", () => setMode(key));
    kindButtons[key] = b;
    kindRow.append(b);
  }

  const timeInput = el("input", "input input-clock");
  timeInput.type = "text";
  timeInput.inputMode = "numeric";
  timeInput.value = "25:00";
  timeInput.placeholder = "25:00";
  timeInput.setAttribute("aria-label", "Countdown duration");

  const chips = el("div", "chips");
  const chipButtons = [];
  for (const minutes of COUNTDOWN_PRESETS) {
    const chip = el("button", "chip", minutes >= 60 ? `${minutes / 60}h` : `${minutes}m`);
    chip.type = "button";
    chip.dataset.seconds = String(minutes * 60);
    chip.addEventListener("click", () => {
      timeInput.value = formatClock(minutes * 60 * 1000);
      syncPreview();
    });
    chipButtons.push(chip);
    chips.append(chip);
  }

  // ── metadata, behind the + ──────────────────────────────────────────────
  // Collapsed by default: most clocks are started bare, and an always-open
  // label field would double the height of the panel for the common case.
  const meta = el("div", "meta hidden");

  const labelInput = el("input", "input input-meta");
  labelInput.type = "text";
  labelInput.maxLength = 200;
  labelInput.placeholder = "Deep work, workout...";
  labelInput.setAttribute("aria-label", "Timer label");

  const tagsInput = el("input", "input input-meta");
  tagsInput.type = "text";
  tagsInput.placeholder = "deep-work, morning";
  tagsInput.setAttribute("aria-label", "Timer tags, comma separated");

  const colorRow = el("div", "swatches");
  const colorButtons = [];
  for (const c of TIMER_COLORS) {
    const swatch = el("button", "swatch");
    swatch.type = "button";
    swatch.dataset.color = c.key;
    swatch.style.background = c.stroke;
    swatch.setAttribute("aria-label", c.key);
    swatch.title = c.key;
    swatch.addEventListener("click", () => setColor(c.key));
    colorButtons.push(swatch);
    colorRow.append(swatch);
  }

  /** A labelled row, matching the popup's `TAG / value` micro-label idiom. */
  function miniField(name, control) {
    const wrap = el("div", "field-mini");
    wrap.append(el("span", "micro", name), control);
    return wrap;
  }
  meta.append(miniField("Label", labelInput), miniField("Tags", tagsInput), miniField("Color", colorRow));

  let mode = "stopwatch";
  let color = DEFAULT_TIMER_COLOR;

  /** Pick a colour: highlight the swatch and restroke the stand-by ring, so the
   *  choice is visible before the clock starts rather than only after. */
  function setColor(key) {
    color = key;
    for (const b of colorButtons) b.classList.toggle("is-active", b.dataset.color === key);
    preview.setStroke(strokeFor(key));
  }

  const metaToggle = el("button", "meta-toggle");
  metaToggle.type = "button";
  metaToggle.setAttribute("aria-expanded", "false");
  metaToggle.addEventListener("click", () => {
    const open = meta.classList.toggle("hidden");
    metaToggle.setAttribute("aria-expanded", String(!open));
    metaToggle.textContent = open ? "+ Label, tags & color" : "− Label, tags & color";
  });

  /** Everything the start call needs, read from the live controls. */
  function readOptions() {
    const label = labelInput.value.trim();
    const tags = tagsInput.value
      .split(",")
      .map((t) => t.trim())
      .filter(Boolean);
    return {
      color,
      ...(label ? { label } : {}),
      ...(tags.length ? { tags } : {}),
    };
  }

  /** Reset after a clock starts, ready for the next one — usually a bare clock,
   *  so the metadata collapses again rather than staying open with stale text.
   *  The whole composer closes with it: starting a clock is the end of the task
   *  the panel was opened for, and leaving it open would keep the list of live
   *  clocks pushed down behind it. */
  function resetComposer() {
    labelInput.value = "";
    tagsInput.value = "";
    setColor(DEFAULT_TIMER_COLOR);
    meta.classList.add("hidden");
    metaToggle.setAttribute("aria-expanded", "false");
    metaToggle.textContent = "+ Label, tags & color";
    setComposerOpen(false);
  }

  const startButton = el("button", "btn-mini btn-start");
  startButton.type = "button";
  startButton.addEventListener("click", () => {
    const opts = readOptions();
    if (mode === "countdown") {
      const seconds = parseClockText(timeInput.value);
      // The API caps a countdown at 86400s (24h); reject here so the caller
      // gets a field-level message instead of a round trip and a 400.
      if (!seconds || seconds > 86400) {
        status(host, "Enter a duration like 25:00 (max 24h)", "error");
        return;
      }
      opts.durationSeconds = seconds;
    }
    load(
      startButton,
      host,
      async () => {
        await window.ixiApi.timers.start(mode, opts);
        resetComposer();
        await refresh();
      },
      "Could not start",
    );
  });

  // Mode switch and preview share the top line: the ring previews the chosen
  // colour, so it belongs with the controls that choose it.
  composerHead.append(kindRow, previewWrap);
  composer.append(composerHead, chips, timeInput, meta, metaToggle, startButton);
  host.append(newToggle, composer);

  /** Keep the ring face, and the highlight on the matching chip, on the typed value. */
  function syncPreview() {
    const seconds = parseClockText(timeInput.value);
    preview.face.replaceChildren();
    if (!seconds) {
      preview.face.append(el("div", "ring-clock is-invalid", "--:--"));
      for (const c of chipButtons) c.classList.remove("is-active");
      return;
    }
    preview.face.append(el("div", "ring-clock", formatClock(seconds * 1000)));
    for (const c of chipButtons) {
      c.classList.toggle("is-active", Number(c.dataset.seconds) === seconds);
    }
  }
  timeInput.addEventListener("input", syncPreview);

  /** Swap the duration controls only — the metadata below is common to both
   *  kinds and must not be torn down when the switch moves. */
  function setMode(next) {
    mode = next;
    const isCountdown = next === "countdown";
    for (const [key, b] of Object.entries(kindButtons)) {
      const on = key === next;
      b.classList.toggle("is-active", on);
      b.setAttribute("aria-selected", String(on));
    }
    // A stopwatch counts up from zero: it has no duration to set and no ring to
    // drain. The ring stays on screen, dimmed, so the panel keeps its height and
    // the colour choice stays previewable in both modes.
    chips.classList.toggle("hidden", !isCountdown);
    timeInput.classList.toggle("hidden", !isCountdown);
    preview.wrap.classList.toggle("dim", !isCountdown);
    syncPreview();
    startButton.textContent = isCountdown ? "Start countdown" : "Start stopwatch";
  }

  setMode("stopwatch");
  resetComposer();

  const list = el("div", "tool-list");
  host.append(list, placeholder("Loading timers…"));

  // A finished clock is written to history, but the history itself is a section
  // of the admin timer page (with the chart and the period tabs), not a popup
  // view — so this opens that page rather than reimplementing it at 360px.
  const historyLink = el("button", "btn-ghost mt");
  historyLink.type = "button";
  historyLink.textContent = "Open history in admin ↗";
  historyLink.addEventListener("click", async () => {
    const site = await window.ixiAuth.baseUrl();
    chrome.tabs.create({ url: `${site}/admin/timer` });
  });
  host.append(historyLink);

  let ticker = null;

  async function refresh() {
    const { timers, serverNow } = await window.ixiApi.timers.list();
    // The server returns its own clock. Every face is derived from that one
    // reference plus the local delta, so a popup left open does not drift and
    // two windows cannot disagree about elapsed time.
    const fetchedAt = Date.now();
    const base = typeof serverNow === "number" ? serverNow : fetchedAt;

    clearList(list);
    clearPlaceholder(host);

    const clocks = [];
    // No clocks means no message and no frame: the composer above already says
    // what to do, and an empty box (or a sentence inside it) would only draw
    // attention to the absence. `is-empty` is dropped again the moment a row
    // is appended by the loop below.
    if (!timers.length) list.classList.add("is-empty");

    for (const t of timers) {
      const isCountdown = t.kind === "countdown" && t.remainingMs != null;

      // One running clock is a card, not a page. The popup has to hold the
      // composer *and* every live clock in 360px, and the 132px ring that reads
      // well with one timer on screen costs ~300px per row — so three clocks
      // push the composer out of reach. The ring stays, at gauge size, beside
      // the time rather than wrapped around it: the same fraction in an eighth
      // of the height.
      //
      // The card is a colour-spined row: the clock's colour runs down its left
      // edge, the gauge and the time share a line, and the actions sit across
      // from them. That colour is the one thing on the card that says *which*
      // clock this is at a glance, and until now it lived entirely inside the
      // gauge — so a stopwatch, which drew no gauge, was colourless.
      //
      // Both kinds now draw the gauge. A countdown's arc is the fraction of its
      // duration left; a stopwatch has no total to be a fraction *of*, so its
      // arc is the current minute — the same seconds dial a watch face has. It
      // costs nothing to compute and it gives the two kinds one silhouette, so
      // a mixed list of clocks stays a column of consistent cards.
      const card = el("div", "clock-card");
      const stroke = strokeFor(t.color);
      card.style.setProperty("--tc", stroke);
      if (t.status !== "running") card.classList.add("is-paused");

      const head = el("div", "timer-head");
      const identity = el("div", "clock-identity");
      identity.append(
        el("span", "timer-label", t.label || (isCountdown ? "Countdown" : "Stopwatch")),
        el("span", t.status === "running" ? "timer-kind is-running" : "timer-kind", t.isBreak ? "break" : t.status),
      );
      head.append(identity);

      const clock = createRing({ size: 44, thickness: 4, stroke });
      const face = el("span", "clock-time");
      const meta = el("span", "timer-meta");
      // Time over meta, rather than three things competing for one line: the
      // elapsed caption is the least important text on the card, and giving it
      // its own row means it never has to ellipsise to save the buttons.
      const stack = el("div", "clock-stack");
      stack.append(face, meta);
      const body = el("div", "clock-body");
      body.append(clock.wrap, stack);
      // The actions are the card's last row, not part of the line above it: the
      // earlier one-line layout had four things competing for 324px and the
      // caption was sacrificed to ellipsis to buy the buttons their room. On its
      // own row it is the width of the card and nothing has to give.
      const controls = el("div", "row row-tight clock-actions");
      controls.append(
        actionButton(
          t.status === "running" ? "Pause" : "Resume",
          () => {
            load(
              null,
              host,
              async () => {
                if (t.status === "running") await window.ixiApi.timers.pause(t.id);
                else await window.ixiApi.timers.resume(t.id);
                await refresh();
              },
              "Could not update",
            );
          },
          "btn-mini",
        ),
        actionButton(
          "Finish",
          () => {
            load(
              null,
              host,
              async () => {
                await window.ixiApi.timers.finish(t.id, true);
                await refresh();
              },
              "Could not finish",
            );
          },
          "btn-mini",
        ),
        actionButton(
          "Drop",
          () => {
            load(
              null,
              host,
              async () => {
                await window.ixiApi.timers.discard(t.id);
                await refresh();
              },
              "Could not drop",
            );
          },
          "btn-mini btn-mini-quiet",
        ),
      );
      card.append(head, body, controls);
      list.append(card);
      // The countdown rows carry their ring out of the loop so the tick can
      // drive both the face and the drained arc from one paint.
      clocks.push({ timer: t, face, meta, ring: clock });
    }

    if (ticker) clearInterval(ticker);
    ticker = null;
    if (!clocks.length) return;

    const paint = () => {
      const since = Date.now() - fetchedAt;
      for (const { timer: t, face, meta, ring } of clocks) {
        const isCountdown = t.kind === "countdown" && t.remainingMs != null;
        // A paused clock does not advance with wall time; its snapshot stands.
        const elapsed = t.status === "running" ? t.elapsedMs + since : t.elapsedMs;
        if (isCountdown) {
          const total = t.durationSeconds * 1000;
          const remaining = Math.max(0, total - elapsed);
          face.textContent = formatClock(remaining);
          face.classList.toggle("is-done", remaining === 0);
          // Site convention: the ring measures the *remaining* fraction, so it
          // starts full and drains toward zero (app/admin/timer/page.tsx:282).
          ring.setFraction(remaining / total);
          meta.textContent = `${formatDuration(elapsed)} elapsed of ${formatSeconds(t.durationSeconds)}`;
        } else {
          face.textContent = formatClock(elapsed);
          // A stopwatch has no total to be a fraction *of*, so its arc is the
          // current minute: the same seconds dial a watch face has, full every
          // :00 and empty on the :59. A paused clock keeps whatever it stopped
          // on, which is the same stillness `face` has.
          ring.setFraction((elapsed % 60000) / 60000);
          meta.textContent = `${formatDuration(elapsed)} elapsed`;
        }
      }
      void base;
    };
    paint();
    ticker = setInterval(paint, 1000);
  }
  onTeardown(() => {
    if (ticker) clearInterval(ticker);
    ticker = null;
  });

  load(null, host, refresh, "Could not load timers");
}

// ── site icons ────────────────────────────────────────────────────────────

/**
 * The host of a stored URL or site string, with or without a scheme. Vault
 * entries are free text — the site never validated the field — so a bare
 * `example.com` has to work as well as a full URL. "" when nothing parses.
 */
function hostOf(value) {
  const raw = String(value ?? "").trim();
  if (!raw) return "";
  try {
    return new URL(raw.includes("://") ? raw : `https://${raw}`).hostname;
  } catch {
    return "";
  }
}

/**
 * An absolute http(s) URL for a stored site, or null. `new URL` happily parses
 * `file:` and `javascript:`, and a stored value is only ever meant to be a web
 * address — a vault `site` is rendered as a clickable link, so the protocol is
 * checked rather than assumed. This is what keeps that link safe.
 */
function siteHref(value) {
  const raw = String(value ?? "").trim();
  if (!raw) return null;
  try {
    const url = new URL(raw.includes("://") ? raw : `https://${raw}`);
    return url.protocol === "http:" || url.protocol === "https:" ? url.toString() : null;
  } catch {
    return null;
  }
}

/**
 * Hosts that cannot serve a meaningful public favicon. IP literals are mostly
 * internal services — a router panel, a NAS, a VPS — so asking a favicon
 * service about them paints the same generic globe next to every row, and a
 * letter reads better. Mirrors the site's own `isLocalHost` suppression
 * (app/admin/vault/page.tsx:120).
 */
function isLocalHost(host) {
  const h = host.toLowerCase();
  if (!h) return true;
  if (h === "localhost" || h.endsWith(".localhost") || h.endsWith(".local") || h.endsWith(".internal")) return true;
  if (/^\d{1,3}(\.\d{1,3}){3}$/.test(h)) return true; // any IPv4 literal
  if (h.startsWith("[") || h.includes(":")) return true; // any IPv6 literal
  return false;
}

/**
 * The letter shown when there is no icon, or when every source we were given
 * failed. A glyph from the host reads better than a generic dot and says
 * nothing about which site the row is for — the same reasoning as the site's
 * lock fallback, with a letter because there is no icon set to draw from.
 */
function hostLetter(value) {
  const host = hostOf(value).replace(/^www\./, "");
  if (!host) return "?";
  const ch = host.match(/[a-z0-9]/i);
  return ch ? ch[0].toUpperCase() : "?";
}

/**
 * A 16px site icon for a list row. `srcs` are tried in order — the stored
 * favicon first for a bookmark, then the site's own `/favicon.ico` and Google's
 * proxy for a vault entry — and the host's letter is the last resort, which
 * always renders. Remote images need no host permission and no CSP change:
 * this page's policy leaves `img-src` unset.
 *
 * The colour fills live on `.tool-row-icon` rather than on the image, so the
 * box survives every swap instead of collapsing and shifting the text lines.
 */
function siteIcon(srcs, letter) {
  const box = el("span", "tool-row-icon");
  const sources = srcs.filter(Boolean);
  const fallback = () => {
    box.classList.add("is-fallback");
    box.textContent = letter;
  };
  if (!sources.length) {
    fallback();
    return box;
  }
  const img = document.createElement("img");
  img.className = "tool-row-favicon";
  // A long list must not fire every icon request at once, and a slow decode
  // should not hold up the row painting.
  img.loading = "lazy";
  img.decoding = "async";
  img.alt = "";
  // The favicon host has no business seeing the popup URL as a referrer.
  img.referrerPolicy = "no-referrer";
  let next = 0;
  img.addEventListener("error", () => {
    next += 1;
    if (next < sources.length) {
      img.src = sources[next];
      return;
    }
    // Out of sources. Removing the <img> rather than hiding it lets the letter
    // sit on the box's own background instead of on a transparent pixel.
    img.remove();
    fallback();
  });
  img.src = sources[0];
  box.append(img);
  return box;
}

/** The row icon for one bookmark: what was stored, else the site's own file. */
function bookmarkIcon(b) {
  const host = hostOf(b.url);
  const derived = host && !isLocalHost(host) ? `https://${host}/favicon.ico` : null;
  return siteIcon([b.favicon, derived], hostLetter(b.url));
}

/**
 * The row icon for one vault entry. Nothing is stored: the site derives it from
 * `site` at render time and so does this, with the same two sources in the same
 * order as the site's `Favicon` component (app/admin/vault/page.tsx:134).
 */
function vaultIcon(entry) {
  const host = hostOf(entry.site);
  const letter = hostLetter(entry.site);
  if (!host || isLocalHost(host)) return siteIcon([], letter);
  return siteIcon(
    [
      `https://${host}/favicon.ico`,
      `https://www.google.com/s2/favicons?sz=64&domain=${encodeURIComponent(host)}`,
    ],
    letter,
  );
}

/** The site's tag split: `folder` holds a comma-separated string, not a list. */
function tagsOf(b) {
  return String(b.folder ?? "")
    .split(",")
    .map((t) => t.trim())
    .filter(Boolean);
}

/** What the site stores in `favicon` when a bookmark is written. */
function faviconFor(url) {
  try {
    return `${new URL(url).origin}/favicon.ico`;
  } catch {
    return null;
  }
}

/**
 * The site's password generator (app/admin/vault/page.tsx:38), ported whole so
 * a password made here is made the same way as one made there — including the
 * `requireEach` overwrite, which is what guarantees the result actually
 * contains a character from every selected set rather than merely allowing it.
 *
 * `b % charset.length` introduces a small modulo bias. That is the site's
 * behaviour, and matching it matters more here than the last fraction of a bit
 * of entropy, because a password generated on the site and one generated here
 * should be indistinguishable.
 */
function genPasswordWithCfg(cfg) {
  const AMBIGUOUS = new Set("Il1O0o".split(""));
  let upper = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
  let lower = "abcdefghijklmnopqrstuvwxyz";
  let digits = "0123456789";
  let symbols = cfg.symbolSet || "!@#$%_+-=";
  if (cfg.excludeAmbiguous) {
    const strip = (s) => [...s].filter((c) => !AMBIGUOUS.has(c)).join("");
    upper = strip(upper);
    lower = strip(lower);
    digits = strip(digits);
    symbols = strip(symbols);
  }
  const pools = [];
  if (cfg.upper) pools.push(upper);
  if (cfg.lower) pools.push(lower);
  if (cfg.digits) pools.push(digits);
  if (cfg.symbols) pools.push(symbols);
  // Every set switched off still has to produce something, so the fallback is
  // the conservative pool rather than an empty charset and a crash.
  if (!pools.length) pools.push(upper + lower + digits);
  const charset = pools.join("");
  const len = Math.max(4, Math.min(128, Number(cfg.length) | 0));
  const random = new Uint8Array(len);
  crypto.getRandomValues(random);
  const out = Array.from(random, (b) => charset[b % charset.length]);
  if (cfg.requireEach && pools.length > 1 && len >= pools.length) {
    for (let i = 0; i < pools.length; i++) {
      const pool = pools[i];
      const pos = random[i] % len;
      out[pos] = pool[crypto.getRandomValues(new Uint8Array(1))[0] % pool.length];
    }
  }
  return out.join("");
}

// ── bookmarks ─────────────────────────────────────────────────────────────

/** How long a stored list is trusted without a request, for the Tools views.
 *  The popup is opened for a moment and often on the way somewhere else, so the
 *  first paint comes from the store and a live read only runs behind it once the
 *  copy has aged past this. Ten seconds covers the double-open a double-click
 *  causes without leaving a list the user just changed on the site stale for
 *  long. */
const TOOL_CACHE_FRESH_MS = 10 * 1000;

/**
 * The New/Edit form, as a pushed view rather than a modal — it is the size of
 * the popup, and the popup has no room to draw a dialog inside a dialog. On
 * save it pops itself and runs `after`, which is how the list refreshes
 * without the form needing to know what opened it.
 */
function bookmarkForm(entry, after) {
  const editing = Boolean(entry);
  pushView(editing ? "Edit bookmark" : "New bookmark", (host) => {
    host.append(el("div", "tool-status hidden"));

    const title = input("My cool site", entry?.title);
    const url = input("https://example.com", entry?.url, "url");
    const folder = input("ai, design, tools", entry?.folder);
    const description = textarea("what is it for?", entry?.description);

    // Fill from the page itself. The scrape runs server-side through the admin
    // route, so the popup never loads a third-party page of its own.
    const meta = el("button", "btn-mini mt", "Fetch title & description");
    meta.type = "button";
    let fetchedFor = "";
    meta.addEventListener("click", () => {
      const value = url.value.trim();
      try {
        new URL(value);
      } catch {
        status(host, "Enter a full URL first", "error");
        return;
      }
      if (fetchedFor === value) return;
      load(
        meta,
        host,
        async () => {
          const found = await window.ixiApi.bookmarks.meta(value);
          fetchedFor = value;
          // Only ever fill a blank field: overwriting a title the user typed
          // would look like the button ate their work.
          if (found.title && !title.value.trim()) title.value = found.title;
          if (found.description && !description.value.trim()) description.value = found.description;
          const any = Boolean(found.title || found.description);
          status(host, any ? "Filled from the page" : "The page had no title or description", any ? "ok" : "error");
        },
        "Could not fetch metadata",
      );
    });

    const save = el("button", "btn-primary", editing ? "Save changes" : "Add bookmark");
    save.type = "button";
    save.addEventListener("click", () => {
      const t = title.value.trim();
      const u = url.value.trim();
      if (!t || !u) {
        status(host, "Title and URL are both required", "error");
        return;
      }
      load(
        save,
        host,
        async () => {
          const patch = {
            title: t,
            url: u,
            folder: folder.value.trim() || null,
            description: description.value.trim() || null,
            // The site stores the origin's own favicon on every write, so a URL
            // edited here updates the icon too instead of leaving the previous
            // site's icon beside a new address.
            favicon: faviconFor(u),
          };
          if (editing) await window.ixiApi.bookmarks.update(entry.id, patch);
          else await window.ixiApi.bookmarks.create(patch);
          after(editing ? "Bookmark updated" : "Bookmark added");
        },
        editing ? "Could not save" : "Could not add",
      );
    });

    host.append(
      formField("title", title),
      formField("url", url),
      formField("tags", folder),
      formField("description", description),
      meta,
      save,
    );
  });
}

function renderBookmarks(host) {
  host.append(el("div", "tool-status hidden"));

  const search = el("input", "input");
  search.type = "search";
  search.placeholder = "filter bookmarks...";
  search.setAttribute("aria-label", "Filter bookmarks");
  host.append(search);

  const actions = el("div", "row");
  const add = el("button", "btn-mini", "+ New bookmark");
  add.type = "button";
  const sync = el("button", "btn-mini", "Sync");
  sync.type = "button";
  sync.title = "Reconcile with Storipalorium";
  actions.append(add, sync);
  host.append(actions);

  const list = el("div", "tool-list list-flush");
  host.append(list, placeholder("Loading bookmarks..."));

  let all = [];
  // The refresh started on the first paint, so a second one from the same view
  // shares it rather than making a second round trip.
  let refreshPromise = null;

  /** A list to paint: the stored copy when there is a recent one, otherwise the
   *  live read. Resolves the read as `refresh` so the caller can repaint when it
   *  arrives — the `stale` half of stale-while-revalidate. */
  async function readList() {
    const { value, refresh } = await window.ixiApi.cache.stale(
      window.ixiApi.cache.KEYS.bookmarks,
      () => window.ixiApi.bookmarks.list(),
      TOOL_CACHE_FRESH_MS,
    );
    return { value, refresh };
  }

  /** Repaint from a list payload. */
  function show(data) {
    all = data?.bookmarks ?? [];
    clearPlaceholder(host);
    paint();
  }

  /** Load, painting what is stored first and repainting if the read lands with
   *  something newer. Returns the same promise to a second caller. */
  function refresh() {
    if (refreshPromise) return refreshPromise;
    refreshPromise = (async () => {
      const { value, refresh: live } = await readList();
      show(value);
      live
        ?.then((fresh) => show(fresh ?? value))
        // A failed read leaves the stored list on screen rather than blanking
        // it — the same rule the new tab's widgets follow.
        .catch(() => {});
    })().finally(() => {
      refreshPromise = null;
    });
    return refreshPromise;
  }

  /** A write has landed, so the stored list is a lie: drop it and re-read. */
  async function reload() {
    await window.ixiApi.cache.drop(window.ixiApi.cache.KEYS.bookmarks);
    refreshPromise = null;
    await refresh();
  }

  /** Called by a pushed form once it has written something. */
  function changed(message) {
    // Back to the list first. The render that lands there fetches again on its
    // own — `popToBase` re-runs it from scratch — and shows `message` once it
    // has, which is why this does not also call `refresh` itself.
    returnToBase(message);
  }

  async function remove(b) {
    const ok = await confirmAction({
      title: "Delete bookmark?",
      message: `“${b.title}” — this cannot be undone.`,
      confirmLabel: "Delete",
      danger: true,
    });
    if (!ok) return;
    load(
      null,
      host,
      async () => {
        await window.ixiApi.bookmarks.remove(b.id);
        await reload();
      },
      "Could not delete",
      { message: "Bookmark deleted", kind: "ok" },
    );
  }

  add.addEventListener("click", () => bookmarkForm(null, changed));

  // ── sync ────────────────────────────────────────────────────────────────
  // The site's "Sync with Storipalorium" is two steps: pull everything that
  // exists there and not here, then offer what only exists here to push back.
  // Both are the same admin endpoint, and its Storipalorium token stays on the
  // server — the popup only ever sees counts and URL lists.

  /** Show the diff and let the user choose what to send. */
  function openSync(result, message) {
    const missing = result.missingOnStori ?? [];
    pushView("Sync with Storipalorium", (view) => {
      view.append(el("div", "tool-status hidden"));

      const summary = el("div", "kv-block");
      summary.append(
        detailRow("here", String(result.localTotal ?? all.length)),
        detailRow("storipalorium", String(result.storiTotal ?? "—")),
      );
      view.append(summary);

      if (message) {
        view.append(el("div", `tool-status${message.kind ? ` ${message.kind}` : ""}`, message.text));
      }

      if (!missing.length) {
        view.append(placeholder("Everything is in sync — nothing to push."));
        return;
      }

      view.append(
        el(
          "p",
          "note",
          `${missing.length} bookmark${missing.length === 1 ? " exists" : "s exist"} here but not on Storipalorium. Pick the ones to add there.`,
        ),
      );

      // Every row starts selected, matching the site, which pre-checks all of
      // them and lets the user deselect.
      const selected = new Set(missing.map((m) => m.url));
      const rows = [];

      const selectAll = el("button", "btn-mini", "");
      selectAll.type = "button";
      const count = el("span", "micro", "");
      function paintCount() {
        selectAll.textContent = selected.size === missing.length ? "Deselect all" : "Select all";
        count.textContent = `${selected.size} selected`;
      }
      const selectRow = el("div", "row");
      selectRow.append(selectAll, count);
      view.append(selectRow);

      const box = el("div", "tool-list");
      for (const m of missing) {
        const row = listRow(m.title, m.tags ? `${m.tags} · ${m.url}` : m.url, bookmarkIcon(m));
        row.classList.add("is-clickable");
        const tick = el("input", "tick");
        tick.type = "checkbox";
        tick.checked = true;
        tick.setAttribute("aria-label", `Push ${m.title}`);
        tick.addEventListener("change", () => {
          if (tick.checked) selected.add(m.url);
          else selected.delete(m.url);
          paintCount();
        });
        // Clicking the row toggles rather than opening the site: this list
        // exists to be chosen from, not visited.
        row.addEventListener("click", (e) => {
          if (e.target === tick) return;
          tick.checked = !tick.checked;
          tick.dispatchEvent(new Event("change"));
        });
        row.append(tick);
        rows.push(row);
        box.append(row);
      }
      selectAll.addEventListener("click", () => {
        const take = selected.size !== missing.length;
        for (const [i, m] of missing.entries()) {
          if (take) selected.add(m.url);
          else selected.delete(m.url);
          const tick = rows[i].querySelector(".tick");
          if (tick) tick.checked = take;
        }
        paintCount();
      });
      paintCount();
      view.append(box);

      const push = el("button", "btn-primary", "Push to Storipalorium");
      push.type = "button";
      push.addEventListener("click", () => {
        if (!selected.size) {
          status(view, "Select at least one bookmark", "error");
          return;
        }
        load(
          push,
          view,
          async () => {
            const items = missing.filter((m) => selected.has(m.url)).map((m) => ({ url: m.url }));
            const res = await window.ixiApi.bookmarks.sync("push", items);
            await reload();
            const failed = res.failed?.length ?? 0;
            // Re-diff and re-open, so a partial push leaves a retryable list
            // rather than one claiming work that already landed.
            popView();
            const next = await window.ixiApi.bookmarks.sync("diff");
            openSync(
              next,
              failed
                ? { kind: "error", text: `Pushed ${res.pushed} · ${failed} failed — the rest are still here.` }
                : { kind: "ok", text: `Pushed ${res.pushed} to Storipalorium.` },
            );
          },
          "Could not push",
        );
      });
      view.append(push);
    });
  }

  sync.addEventListener("click", () => {
    load(
      sync,
      host,
      async () => {
        // `pull` imports whatever is missing here and reports both directions
        // in one round trip, which is what the site's button does.
        const res = await window.ixiApi.bookmarks.sync("pull");
        await reload();
        const bits = [];
        if (res.imported) bits.push(`imported ${res.imported}`);
        bits.push(`${res.localTotal} here`);
        bits.push(`${res.storiTotal} on Storipalorium`);
        const onlyHere = res.missingOnStori?.length ?? 0;
        if (onlyHere) bits.push(`${onlyHere} only here`);
        const line = `Sync ✓ — ${bits.join(" · ")}`;
        status(host, line, "ok");
        if (onlyHere) openSync(res, { kind: "ok", text: line });
      },
      "Could not sync",
    );
  });

  function paint() {
    const q = search.value.trim().toLowerCase();
    const rows = q
      ? all.filter((b) =>
          [b.title, b.url, b.folder, b.description].some((v) =>
            String(v || "").toLowerCase().includes(q),
          ),
        )
      : all;
    clearList(list);
    if (!rows.length) {
      showEmpty(
        list,
        q ? `Nothing matches “${search.value.trim()}”` : "No bookmarks yet — add one above.",
      );
      return;
    }
    for (const b of rows) {
      const tags = tagsOf(b);
      const row = listRow(
        b.title || b.url,
        tags.length ? `${tags.join(", ")} · ${b.url}` : b.url,
        bookmarkIcon(b),
      );
      row.classList.add("is-clickable");
      // The same call the Account buttons make, so an explicit URL needs no
      // extra manifest permission.
      row.addEventListener("click", () => chrome.tabs.create({ url: b.url }));
      row.append(rowActions(b, {
        open: () => chrome.tabs.create({ url: b.url }),
        edit: () => bookmarkForm(b, changed),
        remove: () => remove(b),
      }));
      list.append(row);
    }
  }

  search.addEventListener("input", paint);

  load(
    null,
    host,
    refresh,
    "Could not load bookmarks",
    // A pushed form may have left word of what it did. Shown on the way out of
    // this load, because this render is the one that reflects it.
    takeNotice(),
  );
}

// ── vault ─────────────────────────────────────────────────────────────────

// Where the generator's settings live between popups. Deliberately the same
// key the site uses, so the two write the same shape — though they are separate
// storages (a popup's localStorage is its own), so the settings do not actually
// travel between them.
const GEN_CFG_KEY = "ixi_vault_gen_cfg";

const DEFAULT_GEN_CFG = {
  length: 20,
  upper: true,
  lower: true,
  digits: true,
  symbols: true,
  symbolSet: "!@#$%_+-=",
  excludeAmbiguous: false,
  requireEach: true,
};

function readGenCfg() {
  try {
    const raw = localStorage.getItem(GEN_CFG_KEY);
    if (!raw) return { ...DEFAULT_GEN_CFG };
    const parsed = JSON.parse(raw);
    return { ...DEFAULT_GEN_CFG, ...parsed };
  } catch {
    return { ...DEFAULT_GEN_CFG };
  }
}

function writeGenCfg(cfg) {
  try {
    localStorage.setItem(GEN_CFG_KEY, JSON.stringify(cfg));
  } catch {
    /* storage full or blocked — the generator still works, it just forgets */
  }
}

/** Rough strength read-out, matching the site's scorer so the two agree. */
function passwordStrength(pw) {
  if (!pw) return { label: "—", pct: 0 };
  let s = 0;
  if (pw.length >= 12) s += 2;
  else if (pw.length >= 8) s += 1;
  if (/[a-z]/.test(pw) && /[A-Z]/.test(pw)) s += 1;
  if (/\d/.test(pw)) s += 1;
  if (/[^a-zA-Z0-9]/.test(pw)) s += 1;
  if (pw.length >= 16 && s >= 4) s += 1;
  if (s <= 1) return { label: "weak", pct: 25 };
  if (s === 2) return { label: "fair", pct: 45 };
  if (s === 3) return { label: "good", pct: 70 };
  return { label: "strong", pct: 100 };
}

/**
 * The generator panel: a live preview, the config behind it, and a button to
 * roll again. The password is written into whichever input it was given, so the
 * same panel serves a new entry and a password change on an existing one.
 */
function generatorPanel(target, host) {
  let cfg = readGenCfg();
  const panel = el("div", "generator");

  const preview = el("input", "input input-gen");
  preview.type = "text";
  preview.spellcheck = false;
  preview.setAttribute("aria-label", "Generated password");
  const meter = el("span", "gen-meter-fill");

  function roll() {
    const pw = genPasswordWithCfg(cfg);
    preview.value = pw;
    target.value = pw;
    const { label, pct } = passwordStrength(pw);
    meter.style.width = `${pct}%`;
    meter.className = `gen-meter-fill is-${label}`;
  }

  const head = el("div", "row gen-actions");
  // Each control is coloured by what it does: generate is the accent action,
  // copy is the neutral one that just moves what is already there, and options
  // is a disclosure. The chevron marks it as one — a button that opens rather
  // than acts needs to look like it opens.
  const rollBtn = el("button", "btn-mini gen-btn is-generate", "Generate");
  rollBtn.type = "button";
  rollBtn.addEventListener("click", roll);
  const copyBtn = el("button", "btn-mini gen-btn is-copy", "Copy");
  copyBtn.type = "button";
  copyBtn.addEventListener("click", () => {
    navigator.clipboard
      .writeText(preview.value)
      .then(() => status(host, "Generated password copied", "ok"))
      .catch(() => status(host, "Could not copy", "error"));
  });
  const cfgBtn = el("button", "btn-mini gen-btn is-options");
  cfgBtn.type = "button";
  cfgBtn.setAttribute("aria-expanded", "false");
  const cfgLabel = el("span", "gen-btn-label", "Options");
  const cfgChevron = el("span", "chevron", "▾");
  cfgChevron.setAttribute("aria-hidden", "true");
  cfgBtn.append(cfgLabel, cfgChevron);
  head.append(rollBtn, copyBtn, cfgBtn);
  panel.append(preview, el("div", "gen-meter", meter), head);

  // ── options, folded away by default ──
  const options = el("div", "gen-options hidden");

  // 4–128 is too wide a span for a number spinner to be pleasant — the useful
  // values cluster in a narrow band and stepping to them one click at a time is
  // tedious. A slider puts the whole range under the pointer and shows the
  // value beside it, which is also what the strength meter below is reacting to.
  const length = el("input", "range");
  length.type = "range";
  length.min = "4";
  length.max = "128";
  length.step = "1";
  length.value = String(cfg.length);
  length.setAttribute("aria-label", "Password length");
  const lengthValue = el("span", "range-value", String(cfg.length));

  /** Paint the readout and the filled portion of the track. */
  function paintLength() {
    const min = Number(length.min);
    const max = Number(length.max);
    length.style.setProperty("--fill", `${((cfg.length - min) / (max - min)) * 100}%`);
    lengthValue.textContent = String(cfg.length);
  }
  function commitLength() {
    cfg.length = Math.max(4, Math.min(128, Number(length.value) || 20));
    length.value = String(cfg.length);
    paintLength();
    writeGenCfg(cfg);
    roll();
  }
  // `input` rather than `change`: the whole point of a slider is watching the
  // password and the meter follow the thumb.
  length.addEventListener("input", commitLength);

  const lengthRow = el("div", "length-field");
  const lengthHead = el("div", "range-head");
  lengthHead.append(el("span", "micro", "length"), lengthValue);
  lengthRow.append(lengthHead, length);

  const sets = [
    ["upper", "A–Z"],
    ["lower", "a–z"],
    ["digits", "0–9"],
    ["symbols", "symbols"],
  ];
  const setRow = el("div", "toggles");
  for (const [key, label] of sets) {
    const box = el("label", "toggle");
    const tick = el("input", "tick");
    tick.type = "checkbox";
    tick.checked = cfg[key];
    tick.addEventListener("change", () => {
      cfg[key] = tick.checked;
      writeGenCfg(cfg);
      symbols.disabled = !cfg.symbols;
      roll();
    });
    box.append(tick, el("span", "toggle-label", label));
    setRow.append(box);
  }

  const symbols = el("input", "input input-gen");
  symbols.value = cfg.symbolSet;
  symbols.placeholder = "!@#$%_+-=";
  symbols.disabled = !cfg.symbols;
  symbols.setAttribute("aria-label", "Symbol set");
  symbols.addEventListener("change", () => {
    cfg.symbolSet = symbols.value;
    writeGenCfg(cfg);
    roll();
  });

  const flags = [
    ["excludeAmbiguous", "exclude ambiguous Il1O0o"],
    ["requireEach", "require each selected set"],
  ];
  const flagRow = el("div", "toggles");
  for (const [key, label] of flags) {
    const box = el("label", "toggle");
    const tick = el("input", "tick");
    tick.type = "checkbox";
    tick.checked = cfg[key];
    tick.addEventListener("change", () => {
      cfg[key] = tick.checked;
      writeGenCfg(cfg);
      roll();
    });
    box.append(tick, el("span", "toggle-label", label));
    flagRow.append(box);
  }

  options.append(lengthRow, setRow, formField("symbol set", symbols), flagRow);
  // The track fill is a percentage of the current value, so it has to be
  // painted once after the element is in the document and sized.
  paintLength();

  cfgBtn.addEventListener("click", () => {
    const open = !options.classList.contains("hidden");
    options.classList.toggle("hidden", open);
    cfgBtn.setAttribute("aria-expanded", String(!open));
    // The chevron points the way the panel will move: down when it is shut,
    // up when it is open.
    cfgChevron.textContent = open ? "▾" : "▴";
  });

  panel.append(options);
  roll();
  return panel;
}

/**
 * One entry, opened. This is where the password actually lives: a bulk list
 * never carries one, so revealing is a request for this entry alone. The
 * revealed value clears itself after 20s, the same timeout the site uses
 * (app/admin/vault/page.tsx:338), because a password left on screen in an open
 * popup is the one thing this tool could do that the site will not.
 */
function vaultDetail(entry, after) {
  pushView(entry.title || "Entry", (host) => {
    host.append(el("div", "tool-status hidden"));

    const head = el("div", "detail-head");
    head.append(vaultIcon(entry));
    const heading = el("div", "detail-heading");
    heading.append(el("div", "detail-title", entry.title || "Untitled"));
    if (entry.username) heading.append(el("div", "tool-row-sub", entry.username));
    head.append(heading);
    host.append(head);

    // ── password ──
    const secretBox = el("div", "detail-secret");
    const secret = el("span", "copy-text is-hidden", "");
    const revealBtn = el("button", "btn-mini", "Reveal");
    revealBtn.type = "button";
    const copyBtn = el("button", "btn-mini btn-mini-quiet hidden", "Copy");
    copyBtn.type = "button";
    secretBox.append(secret, revealBtn, copyBtn);
    host.append(secretBox);

    let hideTimer = null;
    let value = null;

    function conceal() {
      if (hideTimer) clearTimeout(hideTimer);
      hideTimer = null;
      value = null;
      secret.textContent = "••••••••••••";
      secret.classList.add("is-hidden");
      secret.classList.remove("selectable");
      revealBtn.textContent = "Reveal";
      copyBtn.classList.add("hidden");
    }

    function concealLater() {
      if (hideTimer) clearTimeout(hideTimer);
      hideTimer = setTimeout(() => {
        conceal();
        // Re-render just the status line's tool: say why it disappeared, so a
        // password vanishing mid-read does not look like a bug.
        status(host, "Hidden again after 20s", "note");
      }, 20000);
    }
    // A closed view must not leave a timer behind holding a password.
    onTeardown(() => {
      if (hideTimer) clearTimeout(hideTimer);
    });

    revealBtn.addEventListener("click", () => {
      // Pressing Reveal again hides immediately, so the 20s wait is never
      // something the user has to sit through.
      if (value != null) {
        conceal();
        status(host, "", "");
        return;
      }
      load(
        revealBtn,
        host,
        async () => {
          const { entry: full } = await window.ixiApi.vault.reveal(entry.id);
          value = full.password ?? "";
          secret.textContent = value || "(this entry could not be decrypted)";
          secret.classList.remove("is-hidden");
          secret.classList.add("selectable");
          revealBtn.textContent = "Hide";
          copyBtn.classList.remove("hidden");
          if (value) concealLater();
        },
        "Could not reveal",
      );
    });

    copyBtn.addEventListener("click", () => {
      navigator.clipboard
        .writeText(value ?? "")
        .then(() => status(host, "Password copied — hides in 20s", "ok"))
        .catch(() => status(host, "Could not copy", "error"));
    });

    conceal();

    // ── metadata ──
    const body = el("div", "kv-block");
    if (entry.site) {
      const href = siteHref(entry.site);
      // A site that does not parse or is not http(s) still belongs on screen —
      // it is just not a link, so it cannot be clicked into something else.
      body.append(
        detailRow(
          "site",
          href
            ? (() => {
                const a = el("a", "detail-link", entry.site);
                a.href = href;
                a.target = "_blank";
                a.rel = "noopener noreferrer";
                return a;
              })()
            : entry.site,
        ),
      );
    }
    if (entry.username) body.append(detailRow("username", entry.username));
    if (entry.notes) body.append(detailRow("notes", entry.notes));
    if (entry.updatedAt) body.append(detailRow("updated", formatVaultDate(entry.updatedAt)));
    host.append(body);

    // ── actions ──
    const actions = el("div", "row mt");
    const edit = el("button", "btn-mini", "Edit");
    edit.type = "button";
    edit.addEventListener("click", () => vaultForm(entry, after));
    const remove = el("button", "btn-mini btn-mini-quiet", "Delete");
    remove.type = "button";
    remove.addEventListener("click", async () => {
      const ok = await confirmAction({
        title: "Delete entry?",
        message: `“${entry.title}” — this cannot be undone.`,
        confirmLabel: "Delete",
        danger: true,
      });
      if (!ok) return;
      load(
        remove,
        host,
        async () => {
          await window.ixiApi.vault.remove(entry.id);
          // The entry is gone, so its detail view is too — step back to the
          // list and rebuild it there.
          popView();
          after("Entry deleted");
        },
        "Could not delete",
      );
    });
    actions.append(edit, remove);
    host.append(actions);
  });
}

/** The New/Edit form for an entry, with the generator attached. */
function vaultForm(entry, after) {
  const editing = Boolean(entry);
  pushView(editing ? "Edit entry" : "New entry", (host) => {
    host.append(el("div", "tool-status hidden"));

    const title = input("GitHub", entry?.title);
    const site = input("https://github.com", entry?.site);
    const username = input("you@example.com", entry?.username);
    const notes = textarea("recovery codes, 2FA backup...", entry?.notes);

    // On an edit the existing password is not loaded — the form has no way to
    // know it without a reveal — so this field is a *replacement*, and leaving
    // it alone must not blank the stored one. The API treats an empty password
    // as "keep what is there", which is exactly the behaviour wanted here.
    const password = input(editing ? "leave blank to keep the current one" : "password", "");
    password.type = "text";

    const generator = generatorPanel(password, host);

    const save = el("button", "btn-primary", editing ? "Save changes" : "Add entry");
    save.type = "button";
    save.addEventListener("click", () => {
      const t = title.value.trim();
      if (!t) {
        status(host, "A title is required", "error");
        return;
      }
      const pw = password.value;
      if (!editing && !pw) {
        status(host, "A password is required — use Generate if you need one", "error");
        return;
      }
      load(
        save,
        host,
        async () => {
          const patch = {
            title: t,
            site: site.value.trim() || null,
            username: username.value.trim() || null,
            notes: notes.value.trim() || null,
          };
          // Sent only when there is one: an empty `password` means "keep", and
          // a created entry is rejected by the API without it anyway.
          if (pw) patch.password = pw;
          if (editing) await window.ixiApi.vault.update(entry.id, patch);
          else await window.ixiApi.vault.create(patch);
          after(editing ? "Entry updated" : "Entry added");
        },
        editing ? "Could not save" : "Could not add",
      );
    });

    host.append(
      formField("title", title),
      formField("site", site),
      formField("username", username),
      formField("password", password),
      generator,
      formField("notes", notes),
      save,
    );
  });
}

function renderVault(host) {
  host.append(el("div", "tool-status hidden"));

  const search = el("input", "input");
  search.type = "search";
  search.placeholder = "filter entries...";
  search.setAttribute("aria-label", "Filter vault entries");
  host.append(search);

  const actions = el("div", "row");
  const add = el("button", "btn-mini", "+ New entry");
  add.type = "button";
  actions.append(add);
  host.append(actions);

  const list = el("div", "tool-list list-flush");
  host.append(list, placeholder("Loading vault..."));

  let all = [];

  async function refresh() {
    const { entries } = await window.ixiApi.vault.list();
    all = entries ?? [];
    clearPlaceholder(host);
    paint();
  }

  /**
   * Called by a detail or form view once the list it was opened from changed.
   * The whole stack above the list is dropped, including the detail page an
   * edit was started from — it describes an entry that no longer says what it
   * said when it was drawn.
   */
  function changed(message) {
    returnToBase(message);
  }

  async function remove(entry) {
    const ok = await confirmAction({
      title: "Delete entry?",
      message: `“${entry.title}” — this cannot be undone.`,
      confirmLabel: "Delete",
      danger: true,
    });
    if (!ok) return;
    load(
      null,
      host,
      async () => {
        await window.ixiApi.vault.remove(entry.id);
        await refresh();
      },
      "Could not delete",
      { message: "Entry deleted", kind: "ok" },
    );
  }

  add.addEventListener("click", () => vaultForm(null, changed));

  function paint() {
    const q = search.value.trim().toLowerCase();
    const rows = q
      ? all.filter((e) =>
          [e.title, e.site, e.username].some((v) => String(v || "").toLowerCase().includes(q)),
        )
      : all;
    clearList(list);
    if (!rows.length) {
      showEmpty(
        list,
        q ? `Nothing matches “${search.value.trim()}”` : "No entries yet — add one above.",
      );
      return;
    }
    for (const entry of rows) {
      // No password is requested here and none is shown: nothing but a title,
      // who it belongs to, and where. Opening the row is what asks for the
      // secret, one entry at a time.
      const row = listRow(
        entry.title,
        [entry.username, entry.site].filter(Boolean).join(" · ") || "no username or site",
        vaultIcon(entry),
      );
      row.classList.add("is-clickable");
      row.addEventListener("click", () => vaultDetail(entry, changed));
      row.append(rowActions(entry, {
        edit: () => vaultForm(entry, changed),
        remove: () => remove(entry),
      }));
      list.append(row);
    }
  }

  search.addEventListener("input", paint);

  load(
    null,
    host,
    refresh,
    "Could not load vault",
    // A pushed form may have left word of what it did; see `pendingNotice`.
    takeNotice(),
  );
}

// ── todos ─────────────────────────────────────────────────────────────────

function renderTodos(host) {
  host.append(el("div", "tool-status hidden"));
  const list = el("div", "tool-list list-flush");
  host.append(list, placeholder("Loading lists…"));

  // The share pages live on the site itself, not on the API origin — when the
  // owner has overridden `apiBase` (development), the tab still points at the
  // real site.
  const site = window.ixiAuth.baseUrl();

  /** Draw the rows from a `{ pages }` payload. Split out so the stored copy and
   *  a live refresh behind it paint through the same code. */
  async function show(data) {
    clearList(list);
    clearPlaceholder(host);
    const active = (data?.pages ?? []).filter((p) => !p.archived);
    if (!active.length) {
      showEmpty(list, "No shared lists yet. Create one on the site and it appears here.");
      return;
    }
    const seen = await readTodoSeen();
    const siteOrigin = await site;
    for (const page of active) {
      const row = listRow(page.title, `${page.doneCount}/${page.totalCount} done`);
      row.classList.add("is-clickable");
      const bar = el("span", "progress");
      const fill = el("span", "progress-fill");
      fill.style.width = `${page.totalCount ? Math.round((page.doneCount / page.totalCount) * 100) : 0}%`;
      bar.append(fill);
      row.append(bar);

      // "New since you last looked", the popup's half of the site's `+N`
      // badge. The baseline is the count recorded the last time this page
      // list was rendered here, so it means "tasks added since you last
      // checked the extension" rather than "tasks you have never opened".
      const count = page.totalCount ?? 0;
      const before = Object.prototype.hasOwnProperty.call(seen, page.id) ? seen[page.id] : null;
      const fresh = before != null && count > before ? count - before : 0;
      if (fresh > 0) {
        const badge = el("span", "new-badge", `+${fresh}`);
        badge.title = `${fresh} new task${fresh === 1 ? "" : "s"} since you last opened this`;
        row.append(badge);
      }

      // The share page is a full page — open it in a tab, like the site link
      // buttons, rather than cramming an editable list into the popup. A slug
      // the owner set beats the random share token when one exists.
      const href = page.customSlug ? `/todo/${page.customSlug}` : `/todo/${page.shareToken}`;
      row.addEventListener("click", async () => {
        // Opening the list clears its badge: the same gesture the site treats
        // as having read it. Recorded before the tab opens so a slow page load
        // cannot resurrect the count.
        await markTodoSeen(page.id, count);
        chrome.tabs.create({ url: `${siteOrigin}${href}` });
      });
      list.append(row);
    }
    // First visit to the extension: record the counts without lighting up
    // every page at once. A page must have been seen once before a later
    // task can count as new, so without this the whole list flashes `+N`.
    for (const page of active) {
      if (!Object.prototype.hasOwnProperty.call(seen, page.id)) {
        await markTodoSeen(page.id, page.totalCount ?? 0);
      }
    }
  }

  load(
    null,
    host,
    async () => {
      // Paint the stored copy at once when there is one, and repaint if the
      // live read lands with something newer — the same contract the new tab's
      // list widgets use, through the same primitive.
      const { value, refresh: live } = await window.ixiApi.cache.stale(
        window.ixiApi.cache.KEYS.todos,
        () => window.ixiApi.todos.pages(),
        TOOL_CACHE_FRESH_MS,
      );
      await show(value);
      live
        ?.then((fresh) => show(fresh ?? value))
        // A failed read leaves the stored list on screen rather than blanking
        // it — the same rule the new tab's widgets follow.
        .catch(() => {});
    },
    "Could not load lists",
  );
}

// ── wiring ────────────────────────────────────────────────────────────────

/** A framed group of menu rows — the tools that render into the panel. */
function menuGroup(tools) {
  const group = el("div", "nav-list");
  for (const tool of tools) {
    const row = el("button", "nav-item");
    row.type = "button";
    row.append(toolIcon(tool.icon), el("span", "nav-item-label", tool.label));
    row.append(el("span", "nav-item-hint", tool.hint));
    row.addEventListener("click", () => openTool(tool));
    group.append(row);
  }
  return group;
}

/** The last group of the menu: the new tab page's switch, and the icon that
 *  opens the page.
 *
 *  One row, two controls. Pressing the label flips the switch in place — the
 *  same `readNewtabOn`/`writeNewtabOn` pair `newtab.js` reads, so the switch and
 *  the page itself can never disagree — and the icon at the right end opens the
 *  page. They are siblings rather than nested because a button inside a button
 *  is invalid HTML and swallows the inner click in some engines. */
function buildNewtabGroup() {
  const group = el("div", "nav-list");

  const row = el("div", "nav-item nav-item-split");
  row.setAttribute("role", "group");

  const toggle = el("button", "nav-split-toggle");
  toggle.type = "button";
  toggle.setAttribute("role", "switch");
  const glyph = el("span", "glyph", "●");
  // Not `nav-item-hint`: that is a muted description of where a row leads. This
  // is the switch's own state, and it gets a filled chip so the answer is
  // visible at a glance instead of being read as another grey label.
  const hint = el("span", "nav-status", "on");
  toggle.append(glyph, el("span", "nav-item-label", "New tab page"), hint);

  // The row carries the state, not just the destination. Repainted after every
  // flip, so the glyph, the word and the tooltip always agree with storage
  // rather than each other's memory of what they were.
  const paint = () => paintNewtabToggle(glyph, hint, row, toggle);
  paint().catch(() => {});
  toggle.addEventListener("click", async () => {
    try {
      const wasOn = await readNewtabOn();
      await writeNewtabOn(!wasOn);
      await paint();
    } catch {
      // Storage being unreadable is the one way this switch can fail, and the
      // page's own read makes the same call — there is nothing useful to say
      // beyond leaving the row showing whatever storage last agreed with.
    }
  });

  const open = el("button", "nav-split-open");
  open.type = "button";
  open.title = "Open the new tab page";
  open.setAttribute("aria-label", "Open the new tab page");
  open.append(toolIcon("newtab"));
  open.addEventListener("click", () =>
    chrome.tabs.create({ url: chrome.runtime.getURL("newtab.html") }),
  );

  row.append(toggle, open);
  group.append(row);

  return group;
}

/** Two frames, not one list: the four tools swap the panel in place, while the
 *  new tab switch is a preference about the browser itself. Drawn as the fifth
 *  row of one frame it read as another tool of the same kind, so it gets its
 *  own frame and a gap — the same break the sidebar makes between navigation
 *  and the things that are not navigation. */
function buildMenu() {
  toolEls.list.replaceChildren(menuGroup(TOOLS), buildNewtabGroup());
}

// ── new tab: on / off ─────────────────────────────────────────────────────
// Chrome will not let an extension detach `chrome_url_overrides.newtab` while it
// is loaded, so the override itself is permanent and "off" cannot mean "stop
// overriding". It means what the *page* does when it opens: with the preference
// off, `newtab.js` hands the tab straight back to the browser's own new tab and
// paints nothing. The extension stays loaded, the popup and every tool keep
// working, and nothing has to be uninstalled to get the browser's new tab back.
//
// The URL chain that hand-back uses — and the one case it cannot cover — lives
// in `newtab.js`, next to the code that runs it.

/** The new tab page's on/off preference, where "unset" means **on**. A profile
 *  that has never touched the switch and one that turned the page back on are
 *  therefore the same state, and a fresh install is on without writing
 *  anything.
 *
 *  `newtab.js` reads this key too, from a different page that does not load this
 *  file. The literal is written out in both — keep the two `NEWTAB_OFF_KEY`
 *  definitions equal. Sharing it would have meant loading `settings.js` and its
 *  account hydration into the popup for the sake of one string. */
const NEWTAB_OFF_KEY = "ixiNewtabOff";

async function readNewtabOn() {
  try {
    const stored = await chrome.storage.local.get(NEWTAB_OFF_KEY);
    return stored[NEWTAB_OFF_KEY] !== true;
  } catch {
    // Storage being unreadable is not a reason to claim the page is off. The
    // page's own read makes the same call, and the two have to agree.
    return true;
  }
}

async function writeNewtabOn(on) {
  // Removed rather than written as `false`, so "on" has exactly one
  // representation in storage and a stale `false` cannot disagree with the
  // default.
  if (on) await chrome.storage.local.remove(NEWTAB_OFF_KEY);
  else await chrome.storage.local.set({ [NEWTAB_OFF_KEY]: true });
}

/** Paint a switch row's glyph, hint and state attribute from storage.
 *
 *  `control` is the element that owns the switch semantics — the menu row is a
 *  container with two controls in it, so the `aria-checked` belongs on the
 *  button inside, not on the row. */
async function paintNewtabToggle(glyph, hint, row, control) {
  const on = await readNewtabOn();
  glyph.textContent = on ? "●" : "○";
  hint.textContent = on ? "on" : "off";
  row.classList.toggle("is-on", on);
  control.setAttribute("aria-checked", String(on));
  // The row is the whole explanation now that there is no page behind it: the
  // switch flips what new tabs do, and `title` is where that sentence lives for
  // anyone who hovers. `aria-checked` carries it for assistive tech.
  control.title = on
    ? "New tabs open ixi-wave. Click to hand new tabs back to the browser."
    : "New tabs open the browser's own page. Click to open ixi-wave on new tabs.";
}

// ── handing the extension to Chrome ───────────────────────────────────────
// Kept apart from the switch above because it is a different act with a
// different cost: `management.setEnabled(id, false)` stops the extension dead.
// No popup, no new tab page, no tools until the user enables it again in
// `chrome://extensions` — which is the only reason to reach for this rather
// than the switch, and why it sits behind a confirmation.

/** Turn the extension off entirely.
 *
 *  `management.setEnabled` needs the `management` permission, which is
 *  `optional_permissions` rather than a declared one — so it is asked for at
 *  the moment the user confirms, in the same click gesture the API insists on,
 *  and an install that never uses this never sees the warning. */
async function disableExtension() {
  // Already granted on a previous use? Then there is no prompt to raise.
  const granted = await chrome.permissions.contains({ permissions: ["management"] });
  if (!granted) {
    const ok = await chrome.permissions.request({ permissions: ["management"] });
    if (!ok) {
      throw new Error("Permission was declined, so nothing was turned off.");
    }
  }
  // Both writes land before the switch, because once Chrome disables the
  // extension nothing here runs again. `DISABLE_KEY` is what the popup reads on
  // the next enable to know the disable was deliberate and worth explaining;
  // `NEWTAB_OFF_KEY` records the page as off, which it genuinely is — an
  // extension that is not loaded cannot open its own new tab. Leaving the
  // switch saying "on" while the page is demonstrably gone is the one thing
  // that would make it untrustworthy.
  await chrome.storage.local.set({ [DISABLE_KEY]: Date.now() });
  await writeNewtabOn(false);
  await chrome.management.setEnabled(chrome.runtime.id, false);
}

/** The confirm-and-switch-off act, independent of where it was triggered from.
 *  Returns `true` when the extension was actually turned off (in which case the
 *  caller is already gone), `false` when the user cancelled, and throws when
 *  Chrome refused — so a caller outside the Tools panel can report it in a line
 *  of its own.
 *
 *  The consequences are spelled out in the dialog itself rather than on a page
 *  one level deeper: the Account panel is the only way in now, and a warning the
 *  user reaches after a second click is a warning half of them never read. */
async function confirmTurnOff() {
  const sure = await confirmAction({
    title: "Turn ixi-wave off completely?",
    message:
      "The new tab page, this popup and every tool stop until you enable the extension " +
      "again in chrome://extensions. Your saved settings, layout and account are kept. " +
      "Chrome will ask you to confirm.",
    confirmLabel: "Turn off",
    danger: true,
  });
  if (!sure) return false;
  await disableExtension();
  return true;
}

// Back steps up one level of the tool — a detail page or a form returns to the
// list it was opened from. At the bottom of the stack it leaves the tool for the
// menu, which is what it used to always do.
toolEls.back.addEventListener("click", () => {
  if (!popView()) closeTool();
});

buildMenu();

/** Open the "turn the extension off" confirmation from outside the Tools
 *  panel — the Account panel's footer is where that act lives now. No view is
 *  pushed: the confirm is a dialog over whatever is on screen, and the caller
 *  reports the failure in the line it already owns. */
async function turnOffExtension() {
  await confirmTurnOff();
}

window.ixiTools = { openTool, closeTool, turnOffExtension, TOOLS };

// The run that follows the user re-enabling the extension after a full
// switch-off. `DISABLE_KEY` is the note the disable left behind, and finding it
// means this popup is the first thing to open since — so it says what happened
// once and clears the note. Read here rather than in the service worker, which
// is not guaranteed to have started before the popup opens.
//
// The note needs the Tools panel showing, so it is only painted there; when
// nobody is signed in there is no Tools tab, and the note is dropped rather than
// forced into a view that does not exist.
(async () => {
  try {
    const stored = await chrome.storage.local.get(DISABLE_KEY);
    if (!stored[DISABLE_KEY]) return;
    await chrome.storage.local.remove(DISABLE_KEY);
    window.ixiPopup?.showPanel("tools");
    pushView("New tab page", (host) => {
      host.append(
        el(
          "p",
          "tool-empty",
          "ixi-wave is back on, but the new tab page is still switched off — so new tabs " +
            "still open your browser's own page.",
        ),
        el(
          "p",
          "note",
          "It stays off until you turn it back on from the switch in the menu behind this " +
            "note. That is deliberate: re-enabling the extension should not quietly take the " +
            "new tab over again.",
        ),
        actionButton("Back to the switch", () => closeTool()),
      );
    });
  } catch {
    // Storage being unavailable is not worth a screen over — the page works
    // either way.
  }
})();

// The manifest overrides Chrome's new tab with this page, but a tab that is
// already open keeps the old one — and while developing there is no other way
// to reach it. This is that entry point, and it stays useful either way.