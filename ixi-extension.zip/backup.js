// Backup and restore for the new tab page.
//
// A layout on this page is a lot of small decisions — where every panel sits,
// which accent, which face, which pinned sites, which icons — and until now all
// of it lived in one profile's `chrome.storage.local` with no way out. A profile
// reset, a browser reinstall or a second machine all meant building it again.
//
// This file is the way out and the way back. It is deliberately *not* an
// importer that trusts its input: a backup file is the one thing this page reads
// that a person can hand-edit, a half-finished download can truncate, and an
// older build can write in a shape the current one no longer produces. So the
// file is parsed, version-checked, and then run through the very same
// `normaliseStored` that guards storage — with the local stores getting their
// own equivalent here, because they have no such pass of their own.
//
// The two halves are separate on purpose:
//
//   inspect(file)  →  { ok, summary, doc, dropped }   (reads, writes nothing)
//   restore(doc)   →  { ok }                          (writes everything)
//
// The panel shows the summary and asks for the second half only if the user
// presses Restore. A single-step import that replaced the layout on file-pick
// would make "I clicked Import to see what was in the file" a destructive
// gesture.
//
// Everything at the top level is `bk`-prefixed. These are classic scripts
// sharing one global lexical scope, so a bare `const` here would be a redeclaration
// the moment it collided with a name in another file.

const BK_SAFE = window.ixiNewtabSettings;

/** Identifies the file as ours, and the shape it was written in. The pair is
 *  checked before anything else is read: a JSON file that happens to parse is
 *  not a backup, and treating one as such is how a restore wipes a layout. */
const BK_FORMAT = "ixi-newtab-backup";
const BK_VERSION = 1;

/** A wallpaper is a re-encoded WebP with a 2560px long edge — comfortably under
 *  a megabyte in practice. This cap is not a target, it is a refusal: a file
 *  larger than this is not a wallpaper this build produced, and the storage
 *  quota it would eat is the whole profile's. */
const BK_MAX_WALLPAPER_BYTES = 8 * 1024 * 1024;

/** The whole file. A backup is settings plus a picture plus two small lists, so
 *  anything past this is not one. */
const BK_MAX_FILE_BYTES = 16 * 1024 * 1024;

/** The local stores' keys, read off the module that owns them rather than
 *  repeated here — `widgets.js` is loaded before this file in both pages, and
 *  two literals that must stay equal is exactly the kind of pair that drifts. */
const BK_TODOS_KEY = window.ixiNewtabWidgets?.LOCAL_TODOS_KEY ?? "ixiLocalTodos";
const BK_TIMERS_KEY = window.ixiNewtabWidgets?.LOCAL_TIMERS_KEY ?? "ixiLocalTimers";

async function bkReadKey(key) {
  try {
    return (await chrome.storage.local.get(key))[key] ?? null;
  } catch {
    return null;
  }
}

async function bkWriteKey(key, value) {
  await chrome.storage.local.set({ [key]: value });
}

// ── building the file ─────────────────────────────────────────────────────

/** The whole of this profile's new-tab state, as the document that gets saved.
 *
 *  Settings are read through `get()` rather than straight out of storage, so the
 *  file holds the merged, hardened blob the page is actually painting with
 *  rather than whatever half-migrated text happens to be at rest. */
async function bkBuild() {
  const settings = await BK_SAFE.get();
  const wallpaper = await BK_SAFE.getWallpaperUpload();
  return {
    format: BK_FORMAT,
    version: BK_VERSION,
    app: "ixi-wave",
    exportedAt: new Date().toISOString(),
    settings,
    wallpaper: wallpaper || null,
    localTodos: await bkReadKey(BK_TODOS_KEY),
    localTimers: await bkReadKey(BK_TIMERS_KEY),
  };
}

/** `ixi-wave-newtab-2026-10-28.json` — dated rather than numbered, because the
 *  point of keeping several is to tell them apart by when they were taken. */
function bkFileName(now = new Date()) {
  const pad = (n) => String(n).padStart(2, "0");
  return `ixi-wave-newtab-${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())}.json`;
}

/** Save the backup to disk. Returns the file name so the panel can say what it
 *  did — a download that lands in a folder the user is not looking at is
 *  otherwise indistinguishable from a button that did nothing. */
async function bkDownload() {
  const doc = await bkBuild();
  const text = JSON.stringify(doc, null, 2);
  const blob = new Blob([text], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = bkFileName();
  document.body.append(a);
  a.click();
  a.remove();
  // Revoked on the next turn of the loop, not straight after `click()`: some
  // browsers have not started reading the blob yet when `click` returns.
  setTimeout(() => URL.revokeObjectURL(url), 0);
  return { ok: true, name: a.download, bytes: blob.size };
}

// ── hardening an incoming file ────────────────────────────────────────────

/** A finite, non-negative number, or `fallback`. */
function bkMs(value, fallback = 0) {
  const n = Number(value);
  return Number.isFinite(n) && n >= 0 ? Math.round(n) : fallback;
}

/** One non-empty short string, or `""`. */
function bkText(value, max = 200) {
  return typeof value === "string" ? value.trim().slice(0, max) : "";
}

/** The local todo store, hardened. The shape mirrors `LOCAL_TODOS` in
 *  `widgets.js`: `{ lists: [{ id, title, items: [{ id, text, done }] }] }`.
 *
 *  Returns the store plus how many lists and items were dropped, because a
 *  restore that silently loses half a list is worse than one that says so. */
function bkNormaliseTodos(raw) {
  const lists = Array.isArray(raw?.lists) ? raw.lists : [];
  const dropped = { lists: 0, items: 0 };
  const out = [];
  for (const list of lists) {
    if (!list || typeof list !== "object") {
      dropped.lists += 1;
      continue;
    }
    const id = bkText(list.id, 120);
    if (!id) {
      dropped.lists += 1;
      continue;
    }
    const items = [];
    for (const item of Array.isArray(list.items) ? list.items : []) {
      if (!item || typeof item !== "object") {
        dropped.items += 1;
        continue;
      }
      const itemId = bkText(item.id, 120);
      const text = bkText(item.text, 500);
      if (!itemId || !text) {
        dropped.items += 1;
        continue;
      }
      items.push({ id: itemId, text, done: Boolean(item.done) });
    }
    out.push({ id, title: bkText(list.title, 120) || "Untitled", items });
  }
  return { store: { lists: out }, dropped };
}

/** The local timer store, hardened — and *re-anchored*.
 *
 *  This is the one place a restore has to differ from a copy. A running timer
 *  stores an absolute epoch (`endsAt` for a countdown, `startedAt` for a
 *  stopwatch), which is right for a reload a second later and wrong for a file
 *  taken last week: a stopwatch would come back claiming nine days elapsed, and
 *  a countdown would come back already finished.
 *
 *  So a restored stopwatch keeps its banked time and starts counting from now,
 *  and a restored countdown that would already have run out comes back paused at
 *  zero — visible and restartable, rather than a finished timer nobody watched. */
function bkNormaliseTimers(raw, now = Date.now()) {
  const timers = Array.isArray(raw?.timers) ? raw.timers : [];
  const dropped = { timers: 0 };
  const out = [];
  for (const t of timers) {
    if (!t || typeof t !== "object") {
      dropped.timers += 1;
      continue;
    }
    const id = bkText(t.id, 120);
    const kind = t.kind === "countdown" ? "countdown" : t.kind === "stopwatch" ? "stopwatch" : null;
    if (!id || !kind) {
      dropped.timers += 1;
      continue;
    }
    const running = t.status === "running";
    const label = bkText(t.label, 120) || null;
    const color = bkText(t.color, 40) || null;
    if (kind === "countdown") {
      const remaining = bkMs(t.remainingMs);
      const endsAt = Number.isFinite(Number(t.endsAt)) ? Number(t.endsAt) : null;
      const left = running && endsAt != null ? Math.max(0, endsAt - now) : remaining;
      out.push({
        id,
        kind,
        // Anything already at zero is paused rather than "running to nothing".
        status: running && left > 0 ? "running" : "paused",
        label,
        endsAt: running && left > 0 ? now + left : null,
        remainingMs: left,
        color,
      });
      continue;
    }
    out.push({
      id,
      kind,
      status: running ? "running" : "paused",
      label,
      // The banked number is kept; only the anchor moves. That is what makes a
      // restored stopwatch resume at the time it was showing.
      startedAt: running ? now : null,
      elapsedMs: bkMs(t.elapsedMs),
      color,
    });
  }
  return { store: { timers: out }, dropped };
}

/** A wallpaper, or `""`. Only the inline image types this build writes are
 *  accepted — an `http` URL is not a backup of an upload, it is a remote image
 *  the extension has no permission to fetch and would draw as nothing. */
function bkNormaliseWallpaper(value) {
  if (typeof value !== "string") return { image: "", dropped: false };
  if (!value.startsWith("data:image/")) return { image: "", dropped: Boolean(value) };
  if (value.length > BK_MAX_WALLPAPER_BYTES) return { image: "", dropped: true };
  return { image: value, dropped: false };
}

/** Count what the settings sanitiser threw away, so the summary can mention it.
 *  It compares the incoming arrays against the normalised ones by id — the count
 *  is what a user cares about ("2 shortcuts dropped"), not which pass dropped
 *  them. */
function bkCountSettingsLoss(raw, normalised) {
  const inWidgets = Array.isArray(raw?.widgets) ? raw.widgets : [];
  const outWidgets = normalised.widgets;
  const droppedWidgets = Math.max(0, inWidgets.length - outWidgets.length);

  const linksIn = inWidgets.reduce(
    (sum, w) => sum + (Array.isArray(w?.data?.links) ? w.data.links.length : 0),
    0,
  );
  const linksOut = outWidgets.reduce((sum, w) => sum + (Array.isArray(w?.data?.links) ? w.data.links.length : 0), 0);
  const droppedShortcuts = Math.max(0, linksIn - linksOut);

  const decorIn = Array.isArray(raw?.decor) ? raw.decor.length : 0;
  const droppedDecor = Math.max(0, decorIn - normalised.decor.length);

  return droppedWidgets + droppedShortcuts + droppedDecor;
}

/** Read a picked file into a validated document. Writes nothing.
 *
 *  Every failure answers with a sentence rather than an exception, because the
 *  only caller is a panel status line. */
async function bkInspect(file) {
  if (!file) return { ok: false, reason: "No file chosen." };
  if (file.size > BK_MAX_FILE_BYTES) {
    return { ok: false, reason: "That file is too large to be a new tab backup." };
  }
  let text;
  try {
    text = await file.text();
  } catch {
    return { ok: false, reason: "That file could not be read." };
  }
  let parsed;
  try {
    parsed = JSON.parse(text);
  } catch {
    return { ok: false, reason: "That file is not JSON — it may be truncated or not a backup." };
  }
  if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) {
    return { ok: false, reason: "That file is not a new tab backup." };
  }
  if (parsed.format !== BK_FORMAT) {
    return { ok: false, reason: "That file was not written by this extension." };
  }
  const version = Number(parsed.version);
  if (!Number.isFinite(version) || version < 1) {
    return { ok: false, reason: "That backup has no readable version." };
  }
  // A newer file may carry settings this build has no code for. Refusing is the
  // safe answer: a half-understood restore is a layout with holes in it.
  if (version > BK_VERSION) {
    return {
      ok: false,
      reason: `That backup is from a newer version of the extension (format ${version}, this build reads ${BK_VERSION}).`,
    };
  }

  const settingsIn = parsed.settings && typeof parsed.settings === "object" ? parsed.settings : {};
  const settings = BK_SAFE.normaliseStored(settingsIn);
  const wallpaper = bkNormaliseWallpaper(parsed.wallpaper);
  const todos = bkNormaliseTodos(parsed.localTodos);
  const timers = bkNormaliseTimers(parsed.localTimers);

  const droppedSettings = bkCountSettingsLoss(settingsIn, settings);
  const dropped =
    droppedSettings +
    todos.dropped.lists +
    todos.dropped.items +
    timers.dropped.timers +
    (wallpaper.dropped ? 1 : 0);

  const placed = settings.widgets.reduce(
    (sum, w) => sum + (Array.isArray(w.data?.links) ? w.data.links.filter((l) => l.x != null).length : 0),
    0,
  );
  const plural = (n, one, many = `${one}s`) => `${n} ${n === 1 ? one : many}`;
  const parts = [
    `${plural(settings.widgets.filter((w) => w.visible).length, "widget")} on`,
    plural(settings.decor.length, "decor piece"),
    `${plural(placed, "placed shortcut")}`,
    wallpaper.image ? "wallpaper" : null,
    plural(todos.store.lists.length, "local list"),
    plural(timers.store.timers.length, "local timer"),
    `theme ${settings.theme}`,
  ].filter(Boolean);

  return {
    ok: true,
    doc: {
      settings,
      wallpaper: wallpaper.image,
      localTodos: todos.store,
      localTimers: timers.store,
    },
    summary: parts.join(" · "),
    dropped,
    exportedAt: typeof parsed.exportedAt === "string" ? parsed.exportedAt : null,
  };
}

// ── writing it back ───────────────────────────────────────────────────────

/** Put a validated document back. Everything below only ever runs on the output
 *  of `bkInspect`, so the shapes are already the ones the page stores. */
async function bkRestore(doc) {
  // Settings go through `set()` rather than a raw write so the account mirror
  // hears about it: a restore made on one machine should reach the other, the
  // same way every other change on this page does.
  await BK_SAFE.set(doc.settings);

  // The head script reads the theme before the first paint from `localStorage`,
  // and a restore that only wrote `chrome.storage` would flash the old theme on
  // the next new tab.
  try {
    localStorage.setItem(BK_SAFE.THEME_MIRROR_KEY, doc.settings.theme);
  } catch {
    /* the mirror is an optimisation; the blob above is the source of truth */
  }

  // Through the module's own setter, so its cache agrees with storage — a raw
  // write would leave the panel previewing the old wallpaper until a reload.
  if (doc.wallpaper) await BK_SAFE.setWallpaperUpload(doc.wallpaper);
  else await BK_SAFE.clearWallpaperUpload();

  await bkWriteKey(BK_TODOS_KEY, doc.localTodos);
  await bkWriteKey(BK_TIMERS_KEY, doc.localTimers);

  // The account reads are cached per paint; a restore can change which lists a
  // widget is pointed at, so the cache goes before anything repaints.
  window.ixiNewtabWidgets?.refreshWidgetData?.();
  await window.ixiNewtabPage?.applySettings?.();
  // `applySettings` repaints the page behind the panel but leaves the panel
  // itself alone — and the panel is where most of a restored layout is visible.
  await window.ixiNewtabPanel?.paint?.();
  return { ok: true };
}

window.ixiNewtabBackup = {
  build: bkBuild,
  download: bkDownload,
  inspect: bkInspect,
  restore: bkRestore,
  fileName: bkFileName,
  FORMAT: BK_FORMAT,
  VERSION: BK_VERSION,
};