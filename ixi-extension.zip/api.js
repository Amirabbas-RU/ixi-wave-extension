// Thin client over the portfolio's owner API.
//
// Every call goes out with the session JWT from auth.js as a Bearer header. The
// site's middleware and `requireOwner` both accept that, so these hit the same
// routes the admin panel itself uses — `/api/admin/timer/*` for the clock,
// `/api/admin/todo/*` for pages, `/api/v1/bookmarks` and `/api/v1/vault` for
// the rest. Nothing here needs the site to add CORS headers, because the
// manifest's host_permissions already cover the origin.

const API = {};

async function request(method, path, body) {
  const base = await window.ixiAuth.baseUrl();
  const token = await window.ixiAuth.readToken();
  if (!token) throw new Error("Not signed in");

  let res;
  try {
    res = await fetch(`${base}${path}`, {
      method,
      headers: {
        Authorization: `Bearer ${token}`,
        ...(body === undefined ? {} : { "Content-Type": "application/json" }),
      },
      ...(body === undefined ? {} : { body: JSON.stringify(body) }),
    });
  } catch (e) {
    const msg = e instanceof Error ? e.message : "Network error";
    throw new Error(`Could not reach ${base} — ${msg}`);
  }

  if (res.status === 401 || res.status === 403) {
    throw new Error("Session expired — sign in again");
  }

  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || `${method} ${path} failed (${res.status})`);
  return data;
}

API.get = (path) => request("GET", path);
API.post = (path, body) => request("POST", path, body ?? {});
API.patch = (path, body) => request("PATCH", path, body ?? {});
API.del = (path) => request("DELETE", path);

// ── local cache ───────────────────────────────────────────────────────────
// The reads below are a read-mostly view of something the account changes
// rarely, but every surface used to fetch them again before it could draw
// anything — and a new tab is opened constantly. So the last answer to each
// read is kept in `chrome.storage.local` and served first, with the live call
// running behind it. Local-only by design: the settings blob is the thing that
// mirrors to the account, and a cache has no business travelling there.
//
// `at` is when the value was stored, which is what lets a caller decide
// whether a hit is still worth painting or should be treated as a miss.

const CACHE_KEY = "ixiApiCache";

/** The schema of the stored entries. Bumped when an entry's shape changes, so
 *  a cache written by an older build is discarded rather than fed to a reader
 *  that no longer understands it. */
const CACHE_SCHEMA = 1;

/** Drop every entry not written by this schema. Called on each read, which is
 *  cheap: the comparison is one number against the blob's own. */
function cacheIsCurrent(blob) {
  return Number(blob?.schema) === CACHE_SCHEMA;
}

/** The whole blob, `{ schema, [name]: { value, at } }`, read once per page and
 *  kept in step with our own writes. Another document writing under us — the
 *  popup saving a bookmark while a new tab sits open — is caught by the change
 *  listener at the bottom of this section, which drops the memo. */
let cacheBlob = null;

async function readCacheBlob() {
  if (cacheBlob) return cacheBlob;
  try {
    const stored = (await chrome.storage.local.get(CACHE_KEY))[CACHE_KEY];
    cacheBlob = cacheIsCurrent(stored) ? stored : {};
  } catch {
    // Storage unreadable. An empty blob is a miss for every read, which is the
    // behaviour every surface had before this existed.
    cacheBlob = {};
  }
  return cacheBlob;
}

/** Serialises read-modify-write of the blob. Two widgets finishing their
 *  fetches together would otherwise each write a blob read before the other's
 *  landed, and the loser's entry would vanish. */
let cacheQueue = Promise.resolve();

/** How many times each entry has been dropped. A read that started before a
 *  drop is answering a question the write has already settled, so its result is
 *  discarded rather than stored back — otherwise the new-tab refresh racing a
 *  bookmark create would resurrect the list the create just invalidated. */
const cacheDrops = Object.create(null);

function mutateCache(fn) {
  cacheQueue = cacheQueue.then(async () => {
    const blob = { schema: CACHE_SCHEMA, ...(await readCacheBlob()) };
    fn(blob);
    cacheBlob = blob;
    try {
      await chrome.storage.local.set({ [CACHE_KEY]: blob });
    } catch {
      /* A cache that cannot be written is still a correct cache: this page
         keeps the value in memory, and the next page simply misses. */
    }
  });
  return cacheQueue;
}

/** Reads that have a request already in flight, keyed by entry. Two widgets
 *  asking for the same list at the same moment — a bookmarks panel and the
 *  page's own add form — share one round trip rather than making two. */
const cacheInflight = Object.create(null);

/** One live read behind the cache, shared with any other caller waiting on the
 *  same entry. `drops` is the counter captured at the call: the answer is only
 *  stored when nothing dropped the entry while it ran.
 *
 *  Rejects with the loader's own error, and every caller joined to the read
 *  sees the same rejection. That matters most on a miss: there is nothing
 *  stored to paint, so swallowing the error would turn "your session expired"
 *  into an empty successful read, and the widgets' auth-vs-offline split is
 *  decided by exactly that error. */
function startRefresh(name, loader) {
  const existing = cacheInflight[name];
  // A read already in flight is only shared when nothing has dropped the entry
  // since it started. After a write, its answer predates the write and would
  // paint the very list the write replaced, so a fresh call starts its own.
  if (existing && existing.drops === (cacheDrops[name] ?? 0)) return existing.promise;
  const drops = cacheDrops[name] ?? 0;
  const run = {
    drops,
    promise: null,
  };
  run.promise = loader()
    .then(async (value) => {
      if ((cacheDrops[name] ?? 0) === drops) await API.cache.set(name, value);
      return value;
    })
    .finally(() => {
      if (cacheInflight[name] === run) delete cacheInflight[name];
    });
  cacheInflight[name] = run;
  return run.promise;
}

API.cache = {
  /** The keys the account's list reads travel under. Named once here so the two
   *  surfaces that read through this cache — the new tab and the popup — and the
   *  write paths that invalidate it cannot drift apart. */
  KEYS: { bookmarks: "bookmarks", todos: "todos" },

  /** The stored entry for `name` as `{ value, at }`, or null. `maxAgeMs` of 0
   *  accepts any age; anything else is a miss past the window. */
  async entry(name, maxAgeMs = 0) {
    const blob = await readCacheBlob();
    const hit = blob[name];
    if (!hit || !("value" in hit)) return null;
    if (maxAgeMs > 0 && Date.now() - Number(hit.at ?? 0) > maxAgeMs) return null;
    return hit;
  },

  /** Store `value` under `name`, stamped now. */
  set(name, value) {
    return mutateCache((blob) => {
      blob[name] = { value, at: Date.now() };
    });
  },

  /** Forget one entry, so the next read goes to the account. What a write
   *  calls when it has changed the thing being cached. The drop is counted so a
   *  read already in flight cannot store its now-superseded answer back. */
  drop(name) {
    cacheDrops[name] = (cacheDrops[name] ?? 0) + 1;
    return mutateCache((blob) => {
      delete blob[name];
    });
  },

  /** A list to paint now, with a live read running behind it when the stored
   *  copy is no longer fresh.
   *
   *  Resolves `{ value, refresh }`: `value` is what to draw — the stored copy,
   *  or the read's own answer when there was nothing stored — and `refresh` is a
   *  promise for the live value once it lands, or null when no read was started
   *  because the stored copy was still fresh. `refresh` rejects when the live
   *  read fails, so a caller can react; a caller that only wants a newer paint
   *  attaches a catch and leaves the stored copy on screen. The caller decides
   *  what "fresh" means and what to do when `refresh` settles; this layer only
   *  moves bytes, so one primitive serves both the new tab and the popup.
   *
   *  `freshMs` is the window in which a hit is trusted alone — no request at all,
   *  which is what makes a burst of new tabs cost one fetch rather than one each.
   *  `maxAgeMs` is how old a hit may be and still be worth painting; past it the
   *  read is awaited like a miss, because a copy that old is a worse guess than
   *  no copy at all. */
  async stale(name, loader, freshMs, maxAgeMs = 24 * 60 * 60 * 1000) {
    const hit = await API.cache.entry(name, maxAgeMs);
    const cached = hit ? hit.value : null;
    if (hit && Date.now() - Number(hit.at ?? 0) < freshMs) {
      return { value: cached, refresh: null };
    }
    const refresh = startRefresh(name, loader);
    // Nothing stored: the read is the paint, exactly as before this cache
    // existed. Awaiting it is the only honest thing to show.
    if (cached === null) return { value: await refresh, refresh: null };
    return { value: cached, refresh };
  },
};

// A write from another document — the popup during an open new tab — is only
// visible here through storage, because each document memoises its own read.
// Dropping the memo is enough: the next read re-fetches the blob.
try {
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "local" && changes[CACHE_KEY]) cacheBlob = null;
  });
} catch {
  /* No change events (an unexpected context): the memo simply lasts the page. */
}

// ── session ───────────────────────────────────────────────────────────────

/**
 * Whether the stored token still resolves, as `{ ok, authenticated, email? }`.
 *
 * `ok: false` means the check itself could not be completed (offline, server
 * unreachable) and says nothing about the token — the caller must not sign
 * anyone out on that. `ok: true, authenticated: false` is the server saying the
 * session is genuinely gone, which is the only case that clears stored state.
 */
API.checkSession = async () => {
  const base = await window.ixiAuth.baseUrl();
  const token = await window.ixiAuth.readToken();
  if (!token) return { ok: true, authenticated: false };
  try {
    const res = await fetch(`${base}/api/admin/auth/me`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    if (!res.ok) return { ok: true, authenticated: false };
    const data = await res.json().catch(() => ({}));
    // `role` is kept for display only. Every Tools view is now per-account data,
    // so a `user` token reaches the same routes as the owner — scoped to its own
    // rows server-side (see `lib/caller.ts`). It is not a UI gate any more.
    return {
      ok: true,
      authenticated: Boolean(data.authenticated),
      email: data.email,
      role: data.role === "owner" ? "owner" : "user",
    };
  } catch {
    return { ok: false, authenticated: false };
  }
};

// ── timer ─────────────────────────────────────────────────────────────────
// A running clock lives in a database row rather than in this popup, which is
// what lets it survive the popup closing and show the same time on the site.

API.timers = {
  /** `{ timers, serverNow, maxActive }` — also settles countdowns that expired unseen. */
  list: () => API.get("/api/admin/timer/active"),
  start: (kind, opts = {}) =>
    API.post("/api/admin/timer/active", {
      kind,
      ...(kind === "countdown" ? { durationSeconds: opts.durationSeconds } : {}),
      ...(opts.label ? { label: opts.label } : {}),
      ...(opts.tags && opts.tags.length ? { tags: opts.tags } : {}),
      ...(opts.color ? { color: opts.color } : {}),
    }),
  pause: (id) => API.patch(`/api/admin/timer/active/${id}`, { action: "pause" }),
  resume: (id) => API.patch(`/api/admin/timer/active/${id}`, { action: "resume" }),
  /** `{ breakTimer, parent }` — the server's own break: the parent is paused
   *  and a countdown for the break is started beside it, so the break reads the
   *  same on every device and restarts the parent when it ends. */
  break: (id) => API.patch(`/api/admin/timer/active/${id}`, { action: "break" }),
  finish: (id, save = true) => API.post(`/api/admin/timer/active/${id}/finish`, { save }),
  discard: (id) => API.del(`/api/admin/timer/active/${id}`),
  /** `{ sessions }` — the finished history, newest first. */
  history: () => API.get("/api/admin/timer"),
  /** `{ templates }` — the reusable presets the site's own timer page manages,
   *  oldest first. The new-tab modal reads these for its chip row and writes
   *  new ones through `createTemplate`, so the two share one list. */
  templates: () => API.get("/api/admin/timer/templates"),
  /** `{ template }` — a new preset. `name` and a positive `durationSeconds`
   *  are the route's own requirements; the rest is optional metadata, which is
   *  why every other field is sent only when it has a value. */
  createTemplate: (t) =>
    API.post("/api/admin/timer/templates", {
      name: t.name,
      durationSeconds: t.durationSeconds,
      ...(t.label ? { label: t.label } : {}),
      ...(t.tags && t.tags.length ? { tags: t.tags } : {}),
      ...(t.color ? { color: t.color } : {}),
    }),
};

// ── todos ─────────────────────────────────────────────────────────────────
// The admin routes, not the public share-token ones: those live under
// `/api/todo/:token` and are reachable without signing in at all.

/** An item write settles the counts the cached list answers, so the list is
 *  dropped rather than left to age out — the same rule `invalidateBookmarks`
 *  follows. Hung off these three writes rather than left to each caller: a tick
 *  moves `doneCount` as surely as an add moves `totalCount`, and a caller that
 *  forgot would leave the new tab's summary one edit behind. */
function invalidateTodos() {
  API.cache.drop(API.cache.KEYS.todos);
}

API.todos = {
  /** `{ pages }` — every page with done/total counts, newest-updated first.
   *  A live read; a caller that wants to paint first wraps it in
   *  `API.cache.stale` under `API.cache.KEYS.todos`. */
  pages: () => API.get("/api/admin/todo"),
  /** `{ page }` — one page with its items, categories and shareToken. */
  page: (id) => API.get(`/api/admin/todo/${id}`),
  // Item edits have no admin route: `/api/admin/todo/:id` only manages the page
  // itself. Items are written through the public share-token routes, which is
  // why every helper below takes the page's `shareToken` — the caller has
  // already loaded the page, so it always has one to hand.
  addItem: (shareToken, text) => API.post(`/api/todo/${shareToken}`, { text }).then(invalidateTodos),
  toggleItem: (shareToken, itemId, done) =>
    API.patch(`/api/todo/${shareToken}/${itemId}`, { done }).then(invalidateTodos),
  removeItem: (shareToken, itemId) =>
    API.del(`/api/todo/${shareToken}/${itemId}`).then(invalidateTodos),
};

// ── public todos ──────────────────────────────────────────────────────────
// The same `/api/todo/:token` routes, reached with no session at all. A widget
// pointed at a shared link must work signed out — that is the whole point of a
// share link — but `request` above cannot: it reads the token first and throws
// "Not signed in" before it ever builds a URL. So this is its own fetch, and
// the only thing it shares with `request` is the base it talks to.

/** One unauthenticated call. `baseUrl()` is reused so a dev `apiBase` of
 *  `http://localhost:3000` talks to localhost and a packaged build talks to
 *  production — the same origin every other request uses.
 *
 *  Unlike `request`, the thrown error carries `.status`, because the callers
 *  here have to tell "this page is gone" (404) from "the server is unreachable"
 *  (0): one is a message about the link, the other about the network.
 *
 *  `password` unlocks a password-protected page. The site reads it from the
 *  `x-todo-password` header, hashes it server-side and answers 401 until it
 *  matches — so a protected page behaves exactly like a missing one until a
 *  password rides along on this call. It is sent on writes too, because the
 *  same gate guards `POST`/`PATCH`/`DELETE`. */
async function publicRequest(method, path, body, password) {
  const base = await window.ixiAuth.baseUrl();
  const headers = {};
  if (body !== undefined) headers["Content-Type"] = "application/json";
  if (password) headers["x-todo-password"] = password;
  let res;
  try {
    res = await fetch(`${base}${path}`, {
      method,
      headers,
      ...(body === undefined ? {} : { body: JSON.stringify(body) }),
    });
  } catch (e) {
    const msg = e instanceof Error ? e.message : "Network error";
    const err = new Error(`Could not reach ${base} — ${msg}`);
    err.status = 0;
    throw err;
  }
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const err = new Error(data.error || `${method} ${path} failed (${res.status})`);
    err.status = res.status;
    throw err;
  }
  return data;
}

API.publicTodos = {
  /** `{ page }` — one shared page with its items, by slug or share token.
   *  A locked page answers 401; pass its password to unlock it. */
  page: (token, password) => publicRequest("GET", `/api/todo/${encodeURIComponent(token)}`, undefined, password),
  addItem: (token, text, password) =>
    publicRequest("POST", `/api/todo/${encodeURIComponent(token)}`, { text }, password),
  toggleItem: (token, itemId, done, password) =>
    publicRequest("PATCH", `/api/todo/${encodeURIComponent(token)}/${encodeURIComponent(itemId)}`, { done }, password),
  removeItem: (token, itemId, password) =>
    publicRequest("DELETE", `/api/todo/${encodeURIComponent(token)}/${encodeURIComponent(itemId)}`, undefined, password),
};

// ── bookmarks ─────────────────────────────────────────────────────────────
// `folder` is labelled "Tags" on the site and holds a comma-separated string;
// there is no separate tags column. `favicon` is a stored URL, not a live
// lookup — the site writes `origin + '/favicon.ico'` on create and edit.

/** A bookmark write settles the question the cached list answers, so the list
 *  is dropped rather than left to age out. Every write path calls this — the
 *  row-level ones through a `.then` on their own request, `sync` after its
 *  result is in hand. */
function invalidateBookmarks() {
  API.cache.drop(API.cache.KEYS.bookmarks);
}

API.bookmarks = {
  /** `{ bookmarks }` — a live read; a caller that wants to paint first wraps it
   *  in `API.cache.stale` under `API.cache.KEYS.bookmarks`. */
  list: () => API.get("/api/v1/bookmarks"),
  create: (b) => API.post("/api/v1/bookmarks", b).then(invalidateBookmarks),
  /** Partial patch: only the keys present are touched. */
  update: (id, patch) => API.patch(`/api/v1/bookmarks/${id}`, patch).then(invalidateBookmarks),
  remove: (id) => API.del(`/api/v1/bookmarks/${id}`).then(invalidateBookmarks),
  /**
   * The site's "Sync with Storipalorium" — a two-way reconcile against an
   * external service. `mode: "diff"` reports without writing, `"pull"` imports
   * what is missing here, `"push"` sends the given `items: [{url}]` outward.
   *
   * There is no `/api/v1` equivalent: this is an admin route, so it only works
   * for a session JWT (which is what this client always sends). The service's
   * bearer token lives server-side and is never part of the request or response
   * — the extension neither needs nor sees it.
   */
  sync: (mode, items) =>
    API.post("/api/admin/bookmarks/sync", {
      mode,
      ...(items && items.length ? { items } : {}),
    }).then((res) => {
      // Every mode can change what is stored here — `pull` and `push` both
      // write — so the cached list is dropped and left to be re-read. The
      // result is passed through untouched: the caller still wants its counts.
      invalidateBookmarks();
      return res;
    }),
  /**
   * Scrapes a page for its title and description, to prefill the form. Admin
   * route, like sync; the fetch happens server-side, so the popup never loads
   * an arbitrary third-party page itself.
   */
  meta: (url) => API.get(`/api/admin/bookmarks/meta?url=${encodeURIComponent(url)}`),
};

// ── vault ─────────────────────────────────────────────────────────────────
// The bulk list never returns passwords; revealing one is a separate request
// per entry so a plain list can never leak them by accident. Entries have no
// stored icon — the site derives one from `site` at render time.

API.vault = {
  list: () => API.get("/api/v1/vault"),
  /** `{ entry }` with a decrypted `password`. */
  reveal: (id) => API.get(`/api/v1/vault/${id}?reveal=1`),
  create: (entry) => API.post("/api/v1/vault", entry),
  /**
   * Partial patch. An omitted `password` keeps the existing one; unlike the
   * admin route, an *empty* password is silently ignored here too, so callers
   * must simply leave the key out rather than sending "".
   */
  update: (id, patch) => API.patch(`/api/v1/vault/${id}`, patch),
  remove: (id) => API.del(`/api/v1/vault/${id}`),
};

window.ixiApi = API;