// Floating widgets for the new tab page.
//
// A widget is a small panel pinned anywhere on the page, dragged by its header
// and remembered per browser profile. The data behind most of them is the same
// account data the popup's Tools read — same `api.js`, same endpoints, same
// session in `chrome.storage.local` — so signing in once in the popup feeds all
// of this with no second login and no server change.
//
// The clock widget is the one exception: it is local and needs no session,
// which also means the page is still useful with nobody signed in.
//
// Tasks and timers are the other half of that idea. Both keep their account
// paths — the site is still where an account's data lives — but each also has a
// local store of its own, used whenever there is no session to read from. A new
// tab is a place to write a shopping list or start a countdown without first
// having an account on some website.

const NEWTAB_SAFE = window.ixiNewtabSettings;
const NEWTAB_API = window.ixiApi;
const NEWTAB_AUTH = window.ixiAuth;

// The two local stores. Keys of their own rather than fields inside
// `SETTINGS_KEY`: the settings blob is mirrored to the account under a size cap,
// and a local list must never be pushed there — it belongs to this browser.
const LOCAL_TODOS_KEY = "ixiLocalTodos";
const LOCAL_TIMERS_KEY = "ixiLocalTimers";
// The presets the new-timer modal offers as chips. A third local store for the
// same reason as the other two: a signed-out profile has nowhere else to keep
// one, and the settings blob is mirrored to the account under a size cap.
const LOCAL_TIMER_TEMPLATES_KEY = "ixiLocalTimerTemplates";
// The bookmarks a profile without an account files. Same window keys the new
// tab's own gestures write; the shape is `{ bookmarks: [...] }` with the rows
// the account list uses, so one renderer reads both.
const LOCAL_BOOKMARKS_KEY = "ixiLocalBookmarks";
// The password a connected tasks widget was unlocked with, keyed by widget id:
// `{ [widgetId]: "…" }`. Local and never synced, because it is the secret itself
// rather than a hash — the site hashes it server-side and never sends the hash
// back, so there is nothing else to store. Kept out of the settings blob for the
// same reason: that blob is mirrored to the account under a size cap and is the
// last place a shared-list password should travel.
const TODO_PASSWORD_KEY = "ixiTodoPasswords";

/** Remembers the fetch promises so re-rendering a widget does not re-request
 *  within a page. Cleared by `refreshWidgetData()`, which every write path
 *  calls when it has moved the thing being read. */
let widgetData = null;

function loadWidgetData() {
  if (widgetData) return widgetData;
  // Checked before the call, not after a failure: with no session the API has
  // nothing to say, and the stub used by the preview harness would happily
  // answer anyway. Asking the token first keeps the local path and the account
  // path from ever disagreeing about which one is live.
  const signedIn = NEWTAB_AUTH.readToken().then(Boolean).catch(() => false);
  // Timers are read live every time and never stored. This widget does not
  // derive an account timer's number itself — the payload's `remainingMs` /
  // `elapsedMs` *are* the display, refreshed when the list is next read — so a
  // stored copy would freeze a running clock until the background refresh
  // landed, and silently show the wrong second if that read failed. Todos are a
  // list, so a stored copy is a correct picture of them a moment ago. */
  widgetData = {
    signedIn,
    timers: signedIn.then((on) => (on ? readAccountLive(() => NEWTAB_API.timers.list()) : null)).catch(() => null),
    todoPages: signedIn.then((on) => (on ? readAccount(NEWTAB_API.cache.KEYS.todos, () => NEWTAB_API.todos.pages()) : null)).catch(() => null),
  };
  return widgetData;
}

/** A failed account read that means "no usable session" — a token the server has
 *  stopped accepting. That is a case the local stores cover; being offline is
 *  not, and must not swap a signed-in user onto another list. */
function isAuthFailure(err) {
  const message = err instanceof Error ? err.message : "";
  return /not signed in|sign in again|session expired/i.test(message);
}

/** An account read as `{ ok: true, data }` or `{ ok: false, auth }`. The tag is
 *  what lets a caller tell "the session is gone, use local" from "the server is
 *  unreachable, show nothing" without matching error text twice.
 *
 *  The value is painted from `api.js`'s store when one is recent, with a live
 *  read behind it — see `readWithRefresh`. The stored entry is the payload
 *  itself, not this wrapper: the `ok`/`auth` tag describes *this* call, and a
 *  remembered success is not a licence to pretend a later failure went well. */
async function readAccount(key, loader) {
  try {
    const data = await readWithRefresh(key, loader);
    return { ok: true, data };
  } catch (err) {
    return { ok: false, auth: isAuthFailure(err) };
  }
}

/** An account read that is never stored, for a payload the display reads as a
 *  live value rather than as a list snapshot — the timer list, whose
 *  `remainingMs`/`elapsedMs` become the clock on screen. Sharing the call shape
 *  with `readAccount` is what lets `taskSource` and `timerSource` stay
 *  identical apart from which helper they call. */
async function readAccountLive(loader) {
  try {
    return { ok: true, data: await loader() };
  } catch (err) {
    return { ok: false, auth: isAuthFailure(err) };
  }
}

/** One local store key, read as a whole. A malformed or absent blob is an empty
 *  store, not an error: a new tab has to draw something. */
async function readLocalStore(key) {
  try {
    return (await chrome.storage.local.get(key))[key] ?? null;
  } catch {
    return null;
  }
}

async function writeLocalStore(key, value) {
  await chrome.storage.local.set({ [key]: value });
}

/** Drop the per-page memo so the next render re-reads the account. The stored
 *  list is dropped by the write itself (`api.js` invalidates on every todo
 *  change), not here: this is called from timer paths too — including the
 *  timer dialog's one-second reflow — and dropping the todos entry there would
 *  mean an open timer invalidating the list cache every second. */
function refreshWidgetData() {
  widgetData = null;
}

/** A stored list older than this is still painted, with a live read started
 *  behind it — so the worst case is data one visit old rather than a blank
 *  panel. */
const WIDGET_CACHE_MAX_AGE_MS = 24 * 60 * 60 * 1000;

/** Inside this window a stored list is taken as the truth and no request is
 *  made at all. This is the window a burst of new tabs lands in: the first tab
 *  fetches, the rest paint from what it stored. */
const WIDGET_CACHE_FRESH_MS = 30 * 1000;

/** One repaint per settled refresh, however many widgets were waiting on one:
 *  the bodies are rebuilt together, so a second rebuild would repeat the work.
 *
 *  The memo is cleared first. It still holds the promise that resolved to the
 *  stale copy, so leaving it would repaint the very value the refresh just
 *  replaced — the bodies read through it, and it is the one thing standing
 *  between them and the fresh copy `api.js` has already stored.
 *
 *  Only the account-backed panels are rebuilt, and in place. `paintWidgetBodies`
 *  would put a loading dot on every panel first and pass `entering: true`,
 *  which re-opens a locked task list; neither is right for a refresh that is
 *  topping up a body already on screen. The calendar, clock and shortcuts read
 *  nothing from the account, so redrawing them would be pure flicker. */
let staleRepaintTimer = null;
function scheduleStaleRepaint() {
  if (staleRepaintTimer) return;
  staleRepaintTimer = setTimeout(() => {
    staleRepaintTimer = null;
    widgetData = null;
    for (const spec of layoutState) {
      const kind = NEWTAB_SAFE.widgetKindOf(spec);
      if (kind === "bookmarks") repaintBookmarksWidget(spec);
      else if (kind === "tasks") repaintTasksWidget(spec);
    }
  }, 0);
}

/** Account data to paint now, refreshing behind the paint when it is old.
 *
 *  The account is the source of truth, but a new tab is not the place to make
 *  the user wait for it: whatever was last seen is drawn immediately, and when
 *  it is no longer fresh a live read runs behind it and repaints the bodies
 *  once, so an edit made on another device still arrives without a reload. */
async function readWithRefresh(key, loader) {
  const { value, refresh } = await NEWTAB_API.cache.stale(
    key,
    loader,
    WIDGET_CACHE_FRESH_MS,
    WIDGET_CACHE_MAX_AGE_MS,
  );
  // A failed read rejects and leaves the stale body in place rather than
  // blanking it — the server being down is not news this page can act on.
  refresh?.then(() => scheduleStaleRepaint()).catch(() => {});
  return value;
}

// ── small DOM helpers ─────────────────────────────────────────────────────
// Matches the idiom in tools.js: build nodes, never innerHTML, because several
// of these strings are user-supplied (bookmark titles, task text) and innerHTML
// would make every one of them a script injection.

function node(tag, className, text) {
  const n = document.createElement(tag);
  if (className) n.className = className;
  if (text != null) n.textContent = text;
  return n;
}

/** A scrollable list body with the standard empty-state line. */
function widgetList(items, emptyText, render) {
  if (!items || !items.length) {
    const box = node("div", "wg-empty");
    box.textContent = emptyText;
    return box;
  }
  const list = node("div", "wg-list");
  for (const item of items) list.append(render(item));
  return list;
}

/** `2h 14m` / `48m 03s` / `12s` — the same compaction the popup's timer uses.
 *  `locale` prints the digits in the widget's own script; the units stay the
 *  page's, because they are labels rather than a reading. */
function formatElapsed(ms, locale) {
  const total = Math.max(0, Math.floor(ms / 1000));
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  const s = total % 60;
  if (h) return `${calCount(h, locale)}h ${calCount(String(m).padStart(2, "0"), locale)}m`;
  if (m) return `${calCount(m, locale)}m ${calCount(String(s).padStart(2, "0"), locale)}s`;
  return `${calCount(s, locale)}s`;
}

function hostOfNewtab(value) {
  const raw = String(value ?? "").trim();
  if (!raw) return "";
  try {
    return new URL(raw.includes("://") ? raw : `https://${raw}`).hostname.replace(/^www\./, "");
  } catch {
    return "";
  }
}

// ── bookmarks: folders and pins ───────────────────────────────────────────
// The bookmarks widget is the only one with structure inside its body: rows are
// grouped by folder tag and a pinned row is lifted out of its group. Both the
// grouping and the pin set are view state, so the helpers here read them from
// `settings.js` and never from the bookmark payload itself.

/** The 16px icon box for one bookmark: the stored favicon, else the site's own
 *  file, else the host's letter. The same two-source order the popup's
 *  `bookmarkIcon` uses, so a row looks the same in both places.
 *
 *  Chrome's own `_favicon` service comes first when it is available: it answers
 *  from a local cache, so a list of bookmark rows no longer each fire a live
 *  `https://host/favicon.ico` request (200–780ms apiece in practice) that the
 *  page then has to wait on to draw an icon. The stored and guessed URLs stay
 *  behind it as the fallback chain, so a page opened outside the extension — or
 *  a host Chrome has no cached icon for — still resolves. */
function bookmarkFaviconBox(b) {
  const host = hostOfNewtab(b.url);
  const icon = node("span", "wg-row-icon");
  const service = window.ixiNewtabShortcuts?.faviconServiceUrl?.(b.url) ?? null;
  const sources = [service, b.favicon, host ? `https://${host}/favicon.ico` : null].filter(Boolean);
  const letter = () => {
    icon.textContent = (host.match(/[a-z0-9]/i) || ["?"])[0].toUpperCase();
  };
  if (!sources.length) {
    letter();
    return icon;
  }
  const img = node("img", "wg-favicon");
  img.alt = "";
  img.loading = "lazy";
  img.referrerPolicy = "no-referrer";
  let i = 0;
  img.addEventListener("error", () => {
    i += 1;
    if (i < sources.length) img.src = sources[i];
    else {
      img.remove();
      letter();
    }
  });
  img.src = sources[0];
  icon.append(img);
  return icon;
}

/** The site's tag split, ported from the popup's `tagsOf`: `folder` holds a
 *  comma-separated string, not a list. Kept identical so the extension and the
 *  site agree on what a bookmark's folders are. */
function folderTags(b) {
  return String(b.folder ?? "")
    .split(",")
    .map((t) => t.trim())
    .filter(Boolean);
}

/** The key a group is remembered under. Real folders key by their own name;
 *  the unsorted group keys by `""`, which no real tag can be because empty
 *  tags are filtered out above. */
const BOOKMARK_UNSORTED_LABEL = "Unsorted";

/** How many rows one group renders before it is truncated. The body is
 *  240px tall and scrolls, so this is only a cap on how much DOM a folder with
 *  two hundred bookmarks builds — the widget's own footer link stays the way
 *  to the full list. */
const BOOKMARK_GROUP_CAP = 8;

/** One bookmark row: the link, plus a pin button beside it.
 *
 *  The pin button is a *sibling* of the `<a>`, not a child. A `<button>` inside
 *  an anchor is invalid content and a click on it would be an ambiguous gesture
 *  the anchor also wants; separating them means pinning can never be mistaken
 *  for navigation. The click is stopped anyway, because the row is inside the
 *  scrollable body and a stray handler higher up must not see it either. */
function bookmarkRow(b, pinned, onTogglePin) {
  const wrap = node("div", "wg-bm-row");
  const a = node("a", "wg-row is-link");
  a.href = b.url;
  const host = hostOfNewtab(b.url);
  const stack = node("div", "wg-row-stack");
  stack.append(node("div", "wg-row-title", b.title || host || b.url), node("div", "wg-row-sub", host));
  a.append(bookmarkFaviconBox(b), stack);

  const pin = node("button", pinned ? "wg-pin is-on" : "wg-pin", pinned ? "◆" : "◇");
  pin.type = "button";
  pin.title = pinned ? "Unpin bookmark" : "Pin bookmark";
  pin.setAttribute("aria-label", `${pinned ? "Unpin" : "Pin"} ${b.title || host || b.url}`);
  pin.setAttribute("aria-pressed", String(pinned));
  pin.addEventListener("click", (e) => {
    e.preventDefault();
    e.stopPropagation();
    onTogglePin(!pinned);
  });

  wrap.append(a, pin);
  return wrap;
}

/** One collapsible folder group: its header toggle over its rows. `total` is
 *  the folder's real size, which is what the count shows — a group capped at
 *  `BOOKMARK_GROUP_CAP` rows must not claim that cap is all there is. */
function bookmarkGroup(key, label, total, rows, collapsed, onToggle, locale) {
  const group = node("section", "wg-bm-group");
  group.dataset.group = key;

  const head = node("button", "wg-bm-head");
  head.type = "button";
  head.setAttribute("aria-expanded", String(!collapsed));
  head.append(
    node("span", "wg-bm-caret", collapsed ? "▸" : "▾"),
    node("span", "wg-bm-name", label),
    node("span", "wg-bm-count", String(total)),
  );
  head.addEventListener("click", () => onToggle(key, !collapsed));
  group.append(head);

  if (!collapsed) {
    const list = node("div", "wg-list");
    list.append(...rows);
    group.append(list);
  }
  return group;
}

/** The whole bookmarks widget body: a Pinned section over one group per tag.
 *
 *  A bookmark with several tags appears under its **first** tag only. Listing
 *  it under each would be the truer reading of the tag string, but this widget
 *  is 240px of scrolling and a two-tag bookmark appearing twice reads as a
 *  duplicate rather than as a filing. Pinned bookmarks are lifted out of their
 *  groups entirely, so a pin never shows twice either. */
function renderBookmarkGroups(bookmarks, pinnedSet, collapsedSet, spec, locale) {
  const pinned = bookmarks.filter((b) => pinnedSet.has(b.id));
  const rest = bookmarks.filter((b) => !pinnedSet.has(b.id));

  const wrap = node("div", "wg-bm");

  // Pinned first, above every folder, and never collapsed — the point of a pin
  // is that it is always in view. `collapsedSet` therefore has no key for it.
  if (pinned.length) {
    const section = node("section", "wg-bm-group is-pinned");
    const head = node("div", "wg-bm-head is-static");
    head.append(node("span", "wg-bm-caret", "◆"), node("span", "wg-bm-name", "Pinned"), node("span", "wg-bm-count", calCount(pinned.length, locale)));
    const list = node("div", "wg-list");
    for (const b of pinned.slice(0, BOOKMARK_GROUP_CAP)) {
      list.append(bookmarkRow(b, true, (want) => toggleBookmarkPin(b.id, want, spec)));
    }
    section.append(head, list);
    wrap.append(section);
  }

  if (!bookmarks.length) {
    // The line points at the add control the caller appends below: an empty
    // list must not be a dead end, which is why the body still renders rather
    // than being replaced by a bare "nothing here".
    wrap.append(node("div", "wg-empty", "No bookmarks yet — add one below."));
  } else {
    // Group by the first tag; untagged rows fall to a trailing "Unsorted" group
    // so a folder-less bookmark is still reachable rather than dropped.
    const groups = new Map();
    for (const b of rest) {
      const key = folderTags(b)[0] ?? "";
      if (!groups.has(key)) groups.set(key, []);
      groups.get(key).push(b);
    }
    const keys = [...groups.keys()].sort((a, b) => {
      if (a === "") return 1; // Unsorted always last
      if (b === "") return -1;
      return a.localeCompare(b);
    });

    for (const key of keys) {
      const all = groups.get(key);
      const rows = all.slice(0, BOOKMARK_GROUP_CAP);
      wrap.append(
        bookmarkGroup(
          key,
          key === "" ? BOOKMARK_UNSORTED_LABEL : key,
          all.length,
          rows.map((b) => bookmarkRow(b, false, (want) => toggleBookmarkPin(b.id, want, spec))),
          collapsedSet.has(key),
          (k, collapsed) => repaintGroupToggle(k, collapsed, spec),
          locale,
        ),
      );
    }
  }

  return wrap;
}

/** Flip one bookmark's pin, then repaint the widget in place. Every caller
 *  here is a press on this widget's own rows, so the repaint is local — the
 *  panel's pin rows write through `setBookmarkPinned` and re-render the whole
 *  page instead, which is the right amount of work for a control outside the
 *  panel's own DOM. */
async function toggleBookmarkPin(id, wanted, spec) {
  await NEWTAB_SAFE.setBookmarkPinned(id, wanted);
  await repaintBookmarksWidget(spec);
}

/** Open or close one folder group, then repaint in place. */
async function repaintGroupToggle(key, collapsed, spec) {
  await NEWTAB_SAFE.setGroupCollapsed(key, collapsed);
  await repaintBookmarksWidget(spec);
}

/** Re-render just the bookmarks panel's body, in place — a pin or a fold must
 *  not tear down the panels, which would lose their dragged positions.
 *
 *  Takes the spec, not the bare id: a second bookmarks panel is a third
 *  instance of the same renderer, and repainting "bookmarks" by name would
 *  refresh the first one while the panel the click actually came from stayed
 *  unchanged. */
async function repaintBookmarksWidget(spec) {
  const entry = widgetPanels.get(spec?.id);
  if (!entry) return;
  try {
    entry.body.replaceChildren(await WIDGET_RENDERERS.bookmarks.body(spec));
  } catch {
    entry.body.replaceChildren(node("div", "wg-empty", "Sign in from the extension to see this."));
  }
}

/** Save one bookmark to whichever list the account uses, and report it.
 *
 *  Lifted out of the panel's own add form so the page's "Add bookmark icon"
 *  writes the same way, through the same route, with the same favicon. The
 *  account list is the one that exists when signed in; a local list is what a
 *  profile without an account files into, and it is kept in the same store the
 *  pin and fold flags use.
 *
 *  A duplicate address is not an error here: the widgets are often about a
 *  site the user already keeps, and the answer to "add this" is "it is there".
 *  `ok: false` with `duplicate: true` says that so a caller can word it. */
async function saveBookmark({ title, url }) {
  const clean = String(url ?? "").trim();
  const entry = { title: String(title ?? "").trim() || clean, url: clean };
  if (!clean) return { ok: false, duplicate: false };
  const data = loadWidgetData();
  if (await data.signedIn) {
    try {
      // A live read, not the cached one: this is a write path, and the point of
      // the check is to catch a duplicate the account already holds — a stale
      // list is exactly the list that could be missing it.
      const list = await NEWTAB_API.bookmarks.list().catch(() => null);
      if (list?.bookmarks?.some((b) => b.url === clean)) return { ok: true, duplicate: true };
      await NEWTAB_API.bookmarks.create({
        title: entry.title,
        url: clean,
        folder: null,
        description: null,
        favicon: faviconForUrl(clean),
      });
      return { ok: true, duplicate: false };
    } catch (err) {
      return { ok: false, duplicate: false, error: err };
    }
  }
  const store = await readLocalStore(LOCAL_BOOKMARKS_KEY);
  const list = Array.isArray(store?.bookmarks) ? store.bookmarks : [];
  if (list.some((b) => b.url === clean)) return { ok: true, duplicate: true };
  const next = [
    ...list,
    { id: crypto.randomUUID(), ...entry, folder: null, description: null, favicon: faviconForUrl(clean) },
  ];
  await writeLocalStore(LOCAL_BOOKMARKS_KEY, { ...store, bookmarks: next });
  // No memo to drop and no stored entry to invalidate: the local list is read
  // straight from this store each time the body is built, and the account's
  // cached list is not the one that just changed. The caller repaints.
  return { ok: true, duplicate: false };
}

/** The favicon URL the site stores on create: the origin's own `/favicon.ico`.
 *  Written here rather than shared with the popup's `faviconFor`, because
 *  `tools.js` is popup-only and is not loaded on this page. */
function faviconForUrl(value) {
  const raw = String(value ?? "").trim();
  if (!raw) return null;
  try {
    const url = new URL(raw.includes("://") ? raw : `https://${raw}`);
    return `${url.origin}/favicon.ico`;
  } catch {
    return null;
  }
}

/** The add-a-bookmark control, shared by every bookmarks layout so there is one
 *  save path rather than one per variant.
 *
 *  The three nodes are returned separately instead of as one wrapper: the
 *  `search` variant puts the toggle above its result list and the `folders`
 *  variant puts it at the foot of the body, so the caller has to own the order.
 *  The status line is returned with them because it reports on this form and
 *  nowhere else; a caller that appends only the toggle and form would save
 *  silently, with the required-fields message nowhere to land. */
function buildBookmarkAddForm(spec) {
  const form = node("form", "wg-add is-hidden");
  const titleInput = node("input", "wg-search-input");
  titleInput.placeholder = "Title";
  titleInput.setAttribute("aria-label", "Bookmark title");
  const urlInput = node("input", "wg-search-input");
  // `type=text`, not `type=url`, for the reason `buildShortcutForm` gives at
  // length: the browser's own URL validation rejects a bare host, and a bare
  // host is exactly what people type. Worse than a rejection here, `type=url`
  // fails it *silently* — the form never submits and nothing is drawn to say
  // why, so Save simply looks broken. The address is normalised on the way in
  // by `faviconForUrl` and by the server, which is where the checking belongs.
  urlInput.type = "text";
  urlInput.placeholder = "example.com";
  urlInput.setAttribute("aria-label", "Bookmark URL");
  const save = node("button", "wg-add-save", "Save");
  save.type = "submit";
  form.append(titleInput, urlInput, save);

  const toggle = node("button", "wg-add-toggle", "+ Add bookmark");
  toggle.type = "button";
  toggle.setAttribute("aria-expanded", "false");

  const status = node("div", "wg-search-status is-hidden");

  const reset = () => {
    titleInput.value = "";
    urlInput.value = "";
    form.classList.add("is-hidden");
    toggle.setAttribute("aria-expanded", "false");
  };

  toggle.addEventListener("click", () => {
    form.classList.toggle("is-hidden");
    const open = !form.classList.contains("is-hidden");
    toggle.setAttribute("aria-expanded", String(open));
    if (open) titleInput.focus();
  });

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const title = titleInput.value.trim();
    const url = urlInput.value.trim();
    if (!title || !url) {
      status.textContent = "Title and URL are both required.";
      status.classList.remove("is-hidden");
      return;
    }
    save.disabled = true;
    status.classList.add("is-hidden");
    try {
      // The same shape the popup's form sends. The server derives nothing, so
      // the favicon is written here from the URL's own origin.
      // One write, the same one the page's "Add bookmark icon" makes: it picks
      // the account's list or the browser's own. An account create drops the
      // cached bookmarks entry in `api.js`, so the repaint below re-reads rather
      // than redrawing the rows it already had.
      const saved = await saveBookmark({ title, url });
      if (!saved.ok) throw saved.error ?? new Error("Could not add the bookmark.");
      reset();
      await repaintBookmarksWidget(spec);
      // The repaint drew a *new* body, so `status` is detached now — the message
      // has to land on the one the fresh body built, or the save reads as silent
      // even though the row did appear.
      const fresh = widgetPanels.get(spec?.id)?.body.querySelector(".wg-search-status");
      if (fresh) {
        fresh.textContent = "Bookmark added.";
        fresh.classList.remove("is-hidden");
      }
    } catch (err) {
      status.textContent = err instanceof Error ? err.message : "Could not add the bookmark.";
      status.classList.remove("is-hidden");
    } finally {
      save.disabled = false;
    }
  });

  return { toggle, form, status };
}

/** A flat list of bookmark rows — the body behind the `compact` and `pinned`
 *  variants. `pinnedOnly` marks the rows as already pinned; `withPin` decides
 *  whether a row carries the pin button at all (the "pinned only" layout has no
 *  unpinned state to flip to, so its rows carry none); `subtitle` is the host
 *  line, which `compact` drops because it is what makes the full list tall. */
function renderBookmarkFlat(bookmarks, spec, { pinnedOnly = false, withPin = false, subtitle = true, empty }) {
  const rows = bookmarks.slice(0, BOOKMARK_GROUP_CAP * 3);
  if (!rows.length) return node("div", "wg-empty", empty);
  const list = node("div", "wg-list is-flat");
  for (const b of rows) {
    if (withPin) {
      list.append(bookmarkRow(b, pinnedOnly, (want) => toggleBookmarkPin(b.id, want, spec)));
      continue;
    }
    const a = node("a", "wg-row is-link");
    a.href = b.url;
    const host = hostOfNewtab(b.url);
    const stack = node("div", "wg-row-stack");
    stack.append(node("div", "wg-row-title", b.title || host || b.url));
    if (subtitle) stack.append(node("div", "wg-row-sub", host));
    a.append(bookmarkFaviconBox(b), stack);
    list.append(a);
  }
  return list;
}

/** Wrap a non-search layout's body so it carries the add-a-bookmark control at
 *  its foot. The body is its own node — a `.wg-bm` group list, a flat list, a
 *  pinned-only list — so the toggle and its form are stacked under it rather
 *  than inside it, keeping the list's own padding and dividers intact. */
function bookmarkBodyWithAdd(body, spec) {
  const add = buildBookmarkAddForm(spec);
  const foot = node("div", "wg-bm-add");
  foot.append(add.toggle, add.form, add.status);
  const wrap = node("div", "wg-bm-add-wrap");
  wrap.append(body, foot);
  return wrap;
}

/** The `search` variant: a filter field over the rows, plus an inline form that
 *  saves a new bookmark without leaving the new tab.
 *
 *  Filtering is client-side over the payload already in hand — there is no
 *  server search endpoint (`/api/v1/bookmarks` returns the whole list) and none
 *  is needed for the handful of rows this widget holds. The match runs over the
 *  same four fields the popup's own filter uses, so the two agree on what counts
 *  as a hit. */
function renderBookmarkSearch(bookmarks, spec) {
  const wrap = node("div", "wg-bm-search");
  const search = node("input", "wg-search-input");
  search.type = "search";
  search.placeholder = "filter bookmarks...";
  search.setAttribute("aria-label", "Filter bookmarks");
  const listWrap = node("div", "wg-search-list");

  const paint = () => {
    const q = search.value.trim().toLowerCase();
    const matched = q
      ? bookmarks.filter((b) =>
          [b.title, b.url, b.folder, b.description].some((v) => String(v ?? "").toLowerCase().includes(q)),
        )
      : bookmarks;
    listWrap.replaceChildren(
      renderBookmarkFlat(matched, spec, {
        withPin: true,
        empty: q ? "Nothing matches." : "No bookmarks yet — add one below.",
      }),
    );
  };

  search.addEventListener("input", paint);

  const { toggle, form, status } = buildBookmarkAddForm(spec);
  paint();
  wrap.append(search, toggle, form, status, listWrap);
  return wrap;
}

// ── calendar: systems and variants ────────────────────────────────────────
// The grid the widget has always drawn is one of eight layouts
// (`CALENDAR_STYLES` in settings.js), and any of them can count in any of three
// calendars (`CALENDAR_SYSTEMS`). The two axes are independent on purpose: which
// month you are looking at and how the month is drawn are different questions,
// and a user who wants a Hijri agenda should not have to give up the agenda.
//
// Everything numeric here comes from `Intl`, never from arithmetic on the
// Gregorian date. `Date` has no notion of a Hijri month, and adding 30 days to a
// lunar month does not land on the next one — the two calendars drift by about a
// day every 33 years. So the month's shape is *measured*: find the Gregorian day
// the local month starts on, then walk forward until `Intl` says the month
// changed. That is a handful of conversions per repaint (a 365-day sweep benches
// at under 1 ms) and it is correct for every year, including ones this build has
// never seen.
//
// `grid` is the one layout still drawn by `newtab.js`, because the page's own
// minute tick repaints it. Everything else is built here and left alone.

/** Formatters, cached by system, locale and option set.
 *
 *  A `DateTimeFormat` is expensive to construct and is the same object every
 *  time, so a repaint that builds thirty cells reuses one. The key is the triple
 *  rather than a map per system, because the layouts ask for different field
 *  sets (a caption wants month + year, a cell wants the day number alone) and
 *  two panels may count in the same calendar in different languages. */
const CAL_FORMATTERS = new Map();

function calFormatter(system, options, locale) {
  const key = `${system}|${locale ?? ""}|${JSON.stringify(options)}`;
  let fmt = CAL_FORMATTERS.get(key);
  if (!fmt) {
    // A system `Intl` does not recognise would throw here and leave the whole
    // panel blank, so the fallback is Gregorian rather than nothing. The settings
    // layer validates too; this is the second fence, for a value that arrived
    // some other way. The locale is dropped last because an unknown *tag* throws
    // for the same reason an unknown calendar does.
    const tag = locale ?? undefined;
    try {
      fmt = new Intl.DateTimeFormat(tag, { calendar: system, ...options });
    } catch {
      try {
        fmt = new Intl.DateTimeFormat(tag, { calendar: "gregory", ...options });
      } catch {
        fmt = new Intl.DateTimeFormat(undefined, { calendar: "gregory", ...options });
      }
    }
    CAL_FORMATTERS.set(key, fmt);
  }
  return fmt;
}

/** A number as `Intl` printed it, whatever script its digits were in. Persian
 *  and Arabic-Indic digits are not `Number`-parseable, and the layouts compare
 *  the numbers `formatToParts` hands back, so they are folded to Latin here. */
function calLatinNumber(text) {
  return Number(
    String(text).replace(/[٠-٩۰-۹]/g, (d) => {
      const code = d.codePointAt(0);
      return String(code >= 0x06f0 ? code - 0x06f0 : code - 0x0660);
    }),
  );
}

/** The calendar date a `Date` falls on: `{ year, month, day }`, all numbers.
 *  `month` is 1–12, not the 0–11 `Date` uses, because every call site compares
 *  it against a month number it just read from the same formatter.
 *
 *  Latin digits are asked for explicitly: this is arithmetic, not display, and
 *  a locale-aware formatter would hand back digits the comparisons below cannot
 *  read. The names a panel *shows* are formatted elsewhere, in the widget's own
 *  locale. */
function calYmd(date, system) {
  const parts = calFormatter(system, { year: "numeric", month: "numeric", day: "numeric", numberingSystem: "latn" })
    .formatToParts(date);
  const read = (type) => calLatinNumber(parts.find((p) => p.type === type)?.value);
  return { year: read("year"), month: read("month"), day: read("day") };
}

/** The shape of the month `now` falls in, in `system`.
 *
 *  `day` is its day number within that month; `daysInMonth`, `lead` and `first`
 *  are what a grid needs, `first` being the Gregorian `Date` on which local day 1
 *  sits. `lead` counts Monday-first blanks, the convention every layout in this
 *  file uses.
 *
 *  Works on any date, not only today — the year view calls it once per month.
 *
 *  The start of the month is found by subtracting `day - 1` *Gregorian* days,
 *  which is exact: whatever the calendar, the day numbered `n` is exactly `n - 1`
 *  days after day 1. Constructed at noon so a DST boundary cannot round the date
 *  backwards into the previous day. */
function calendarFacts(now, system) {
  const at = calYmd(now, system);
  // `setDate` on a copy rather than `new Date(y, m, d - n)`: the latter re-reads
  // month lengths through `Date`'s own Gregorian arithmetic, which is fine, but
  // the copy states the intent more plainly.
  const first = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 12);
  first.setDate(first.getDate() - (at.day - 1));

  const lead = (first.getDay() + 6) % 7;

  // Walk forward until the month changes. Bounded at 32 so a formatter that
  // somehow never rolls over cannot hang the renderer in a loop.
  let daysInMonth = 0;
  for (let n = 0; n < 32; n += 1) {
    const probe = new Date(first.getFullYear(), first.getMonth(), first.getDate() + n, 12);
    const probeAt = calYmd(probe, system);
    if (probeAt.month !== at.month || probeAt.year !== at.year) break;
    daysInMonth = n + 1;
  }

  return { ...at, daysInMonth, lead, first };
}

/** The seven weekday letters, Monday-first — anchored on `2024-01-01`, which is
 *  a Monday, so the locale names the right day without a lookup table.
 *
 *  Weekday names are the same in every calendar system (a Thursday is a
 *  Thursday), so this takes no system; only the *numbers* under them change.
 *  It does take a locale, because the same Thursday is `T` in English and `پ`
 *  in Persian — the letter is the one thing about the grid a font choice
 *  visibly moves. */
function weekdayLetters(locale) {
  const out = [];
  for (let i = 0; i < 7; i += 1) {
    out.push(calWeekday(new Date(2024, 0, 1 + i), "narrow", locale));
  }
  return out;
}

/** The "October 2026" line every calendar layout carries, in its own calendar —
 *  `Jumada I 1448 AH`, `Aban 1405 AP`. Sits *outside* the grid so the tick's
 *  `replaceChildren` on the cells never reaches it. */
function calendarCaption(now, system, locale) {
  return node("div", "cal-caption", calFormatter(system, { month: "long", year: "numeric" }, locale).format(now));
}

/** The date a year view is standing on, as a month and a day — `November 1`,
 *  `9 Jumada I`, `10 Aban`. The centre of the dial carries the day-of-year and
 *  the percentage, and both are counts: neither says *which* day today is
 *  without the reader doing the arithmetic the layout already did. The caption
 *  above names the year, so the month and day are the only fields still
 *  missing, and they are printed in the widget's own calendar and locale so a
 *  Hijri panel does not fall back to a Gregorian date in the middle of it. */
function calMonthDay(date, system, locale) {
  return calFormatter(system, { month: "long", day: "numeric" }, locale).format(date);
}

/** The year alone, for the layout that is a year — `2026`, `1448 AH`, `1405 AP`.
 *  A year view headed with the month it happens to be in reads as a month view
 *  that lost its grid. */
function calendarYearCaption(now, system, locale) {
  return node("div", "cal-caption", calFormatter(system, { year: "numeric" }, locale).format(now));
}

/** The day number as a string in `system`.
 *
 *  `Intl` can render digits in their own script — Persian panels counting in
 *  Arabic-Indic numerals — and a widget wearing a Persian face is exactly a
 *  Persian panel, so the digits follow the locale it was given. A widget with
 *  no locale keeps the page's Latin numerals, so its dates still match the
 *  clock beside it. Latin is therefore requested only when there is no locale
 *  to inherit digits from. */
function calDayNumber(date, system, locale) {
  const options = { day: "numeric" };
  if (!locale) options.numberingSystem = "latn";
  return calFormatter(system, options, locale).format(date);
}

/** One day's worth of what a layout needs: its number, whether it is today, and
 *  the `Date` it sits on. */
function calCells(system, facts, locale) {
  const cells = [];
  for (let i = 0; i < facts.daysInMonth; i += 1) {
    const date = new Date(facts.first.getFullYear(), facts.first.getMonth(), facts.first.getDate() + i, 12);
    cells.push({
      date,
      label: calDayNumber(date, system, locale),
      isToday: i + 1 === facts.day,
    });
  }
  return cells;
}

/** A run of digits in the script the widget's locale uses, one character for
 *  one. `Intl.NumberFormat` on a *string* would parse it as a number and drop
 *  the leading zero a clock's minutes column is padded to, so a padded run is
 *  transcribed digit by digit instead. Falls back to the input unchanged when
 *  there is no locale, or when the tag throws.
 *
 *  The ten digits are formatted once per locale and kept: a clock tick and a
 *  timer's every-second repaint both come through here. */
const CAL_DIGITS = new Map();

function calDigits(text, locale) {
  const ascii = String(text);
  if (!locale) return ascii;
  let digits = CAL_DIGITS.get(locale);
  if (digits === undefined) {
    try {
      const fmt = new Intl.NumberFormat(locale, { useGrouping: false });
      digits = Array.from({ length: 10 }, (_, i) => fmt.format(i));
    } catch {
      digits = null;
    }
    CAL_DIGITS.set(locale, digits);
  }
  if (!digits) return ascii;
  return ascii.replace(/[0-9]/g, (d) => digits[Number(d)]);
}

/** A plain count — a day-of-year, a fraction — in the digits the widget's
 *  locale uses. Not a date, so `Intl.NumberFormat` rather than the calendar
 *  formatter; with no locale it is the `String(n)` the page has always printed,
 *  grouping and all. A *string* is transcribed rather than parsed, so a padded
 *  `"09"` keeps its zero — see `calDigits`. */
function calCount(n, locale) {
  if (typeof n === "string") return calDigits(n, locale);
  if (!locale) return String(n);
  try {
    return new Intl.NumberFormat(locale, { useGrouping: false }).format(n);
  } catch {
    return String(n);
  }
}

/** The weekday name a locale gives one date, at the width asked for.
 *
 *  The one `toLocaleDateString` wrapper in the file, so every weekday a layout
 *  prints reads the same locale the rest of that panel does. */
function calWeekday(date, width, locale) {
  return date.toLocaleDateString(locale ?? undefined, { weekday: width });
}

/** Build one of the eight calendar layouts, in one of the three calendars.
 *
 *  `grid` delegates to `buildCalendar` (newtab.js), which is idempotent and is
 *  also what the clock's tick calls — passing the fresh node here keeps the
 *  not-yet-in-the-document lookup bug that function documents from firing. That
 *  function is Gregorian-only, so a grid counting in another calendar is drawn
 *  here instead, from the same `calCells` the other layouts use.
 */
function renderCalendarBody(variant, now, system, locale) {
  const facts = calendarFacts(now, system);
  const wrap = node("div");
  wrap.dataset.system = system;
  // The year layout is headed with the year; every other layout is headed with
  // the month, because that is what it is showing. `focus` is the exception: its
  // hero *is* a heading, so a caption above it would say October twice.
  if (variant !== "focus") {
    wrap.append(variant === "year" ? calendarYearCaption(now, system, locale) : calendarCaption(now, system, locale));
  }

  // `newtab.js`'s grid is Gregorian and English-only, so a widget that asked for
  // another calendar or language is drawn below from the same cells the other
  // layouts use. The page's own grid stays delegated because the minute tick
  // repaints it, which is why that path is kept for the plain case.
  if (variant === "grid" && system === "gregory" && !locale) {
    const grid = node("div", "cal-grid");
    // `data-cal-grid` is the tick's finder, not an id: calendars are multiple,
    // so two Gregorian grids are a supported layout and both must repaint.
    grid.dataset.calGrid = "";
    if (typeof buildCalendar === "function") buildCalendar(now, grid);
    wrap.append(grid);
    return wrap;
  }

  const cells = calCells(system, facts, locale);

  if (variant === "grid") {
    const grid = node("div", "cal-grid");
    for (const letter of weekdayLetters(locale)) grid.append(node("span", "cal-dow", letter));
    for (let i = 0; i < facts.lead; i += 1) {
      const blank = node("span", "cal-day");
      blank.dataset.empty = "true";
      grid.append(blank);
    }
    for (const cell of cells) {
      grid.append(node("span", cell.isToday ? "cal-day is-today" : "cal-day", cell.label));
    }
    wrap.append(grid);
    return wrap;
  }

  if (variant === "dots") {
    const grid = node("div", "cal-grid cal-dots");
    for (const letter of weekdayLetters(locale)) grid.append(node("span", "cal-dot-dow", letter));
    for (let i = 0; i < facts.lead; i += 1) {
      const blank = node("span", "cal-dot", "");
      blank.dataset.empty = "true";
      grid.append(blank);
    }
    for (const cell of cells) {
      const dot = node("span", cell.isToday ? "cal-dot is-today" : "cal-dot", "");
      if (cell.isToday) dot.setAttribute("aria-label", `Today, ${cell.label}`);
      grid.append(dot);
    }
    wrap.append(grid);
    return wrap;
  }

  if (variant === "outline") {
    const grid = node("div", "cal-grid is-outline");
    for (const letter of weekdayLetters(locale)) grid.append(node("span", "cal-dow", letter));
    for (let i = 0; i < facts.lead; i += 1) {
      const blank = node("span", "cal-day cal-box");
      blank.dataset.empty = "true";
      grid.append(blank);
    }
    for (const cell of cells) {
      grid.append(node("span", cell.isToday ? "cal-day cal-box is-today" : "cal-day cal-box", cell.label));
    }
    wrap.append(grid);
    return wrap;
  }

  if (variant === "week") {
    const weeks = node("div", "cal-weeks");
    const letters = weekdayLetters(locale);
    for (let wd = 0; wd < 7; wd += 1) {
      const row = node("div", "cal-wk-row");
      const datesWrap = node("span", "cal-wk-dates");
      // The first date landing on this weekday: day 1 of the month sits at
      // column `lead` (Monday-first), so weekday `wd` first occurs `wd - lead`
      // days later, wrapped back into week one.
      for (let n = (wd - facts.lead + 7) % 7; n < cells.length; n += 7) {
        const cell = cells[n];
        datesWrap.append(node("span", cell.isToday ? "cal-wk-date is-today" : "cal-wk-date", cell.label));
      }
      row.append(node("span", "cal-wk-label", letters[wd]), datesWrap);
      weeks.append(row);
    }
    wrap.append(weeks);
    return wrap;
  }

  if (variant === "focus") {
    wrap.append(buildCalendarFocus(cells, now, system, facts, locale));
    return wrap;
  }

  if (variant === "timeline") {
    wrap.append(buildCalendarTimeline(cells, now, system, locale));
    return wrap;
  }

  if (variant === "year") {
    wrap.append(buildCalendarYear(now, system, locale));
    return wrap;
  }

  // agenda: the rest of the month, today first, each row a weekday + date.
  const agenda = node("div", "cal-agenda");
  for (const cell of cells.slice(facts.day - 1)) {
    const row = node("div", cell.isToday ? "cal-ag-row is-today" : "cal-ag-row");
    row.append(
      node("span", "cal-ag-day", calWeekday(cell.date, "short", locale)),
      node("span", "cal-ag-date", cell.label),
    );
    agenda.append(row);
  }
  wrap.append(agenda);
  return wrap;
}

/** The modern headline layout: today, large, with the month beneath it as a
 *  strip of cells that still reads as a month.
 *
 *  This is the layout for a panel that exists to answer "what day is it" rather
 *  than "what is the shape of October". A thirty-one-cell grid in a 168px panel
 *  spends most of its area on days that are not today; this spends it on the one
 *  that is, and leaves the grid as a reference underneath. */
function buildCalendarFocus(cells, now, system, facts, locale) {
  const wrap = node("div", "cal-focus");

  const hero = node("div", "cal-focus-hero");
  const dow = node("div", "cal-focus-dow", calWeekday(now, "long", locale));
  const num = node("div", "cal-focus-num", cells[facts.day - 1]?.label ?? calCount(facts.day, locale));
  // The month and year, standing in for the caption the other layouts carry.
  const meta = node("div", "cal-focus-meta");
  meta.append(
    node("span", "cal-focus-month", calFormatter(system, { month: "long", year: "numeric" }, locale).format(now)),
    node("span", "cal-focus-doy", `${calCount(facts.day, locale)} / ${calCount(facts.daysInMonth, locale)}`),
  );
  hero.append(dow, num, meta);

  // The grid, small: seven columns, today marked. Same cells, no numbers except
  // today's, so it is a map of where this day sits in its month rather than a
  // second full calendar under the first.
  const strip = node("div", "cal-focus-strip");
  for (const letter of weekdayLetters(locale)) strip.append(node("span", "cal-focus-dow-letter", letter));
  for (let i = 0; i < facts.lead; i += 1) {
    strip.append(node("span", "cal-focus-cell is-empty"));
  }
  for (const cell of cells) {
    strip.append(node("span", cell.isToday ? "cal-focus-cell is-today" : "cal-focus-cell"));
  }

  wrap.append(hero, strip);
  return wrap;
}

/** The current week as a vertical timeline: the seven days around today, each a
 *  rule, a weekday, a number, and the one that is today marked solid.
 *
 *  A week is the unit a new tab is actually used in — "where am I in this week" —
 *  and it is the one reading the month grid cannot give without counting.
 *
 *  The window walks Gregorian days into the weeks either side of today, so it can
 *  cross a month boundary; each date's number is therefore read from the
 *  formatter rather than taken from the month's cells. */
function buildCalendarTimeline(cells, now, system, locale) {
  const wrap = node("div", "cal-timeline");
  const todayCell = cells.find((c) => c.isToday);
  // `getDay()` is Sunday-first; Monday-first puts Sunday at index 6.
  const offset = todayCell ? (todayCell.date.getDay() + 6) % 7 : 0;
  const start = todayCell
    ? new Date(todayCell.date.getFullYear(), todayCell.date.getMonth(), todayCell.date.getDate() - offset, 12)
    : new Date(now.getFullYear(), now.getMonth(), now.getDate(), 12);

  for (let i = 0; i < 7; i += 1) {
    const date = new Date(start.getFullYear(), start.getMonth(), start.getDate() + i, 12);
    const isToday = date.toDateString() === now.toDateString();
    const row = node("div", isToday ? "cal-tl-row is-today" : "cal-tl-row");
    // The month is drawn only where it changes — the first row, and again if the
    // week crosses into another month. Repeated on all seven it is seven lines
    // of the same word, which is noise rather than information.
    const month = calFormatter(system, { month: "short" }, locale).format(date);
    const changed = i === 0 || month !== calFormatter(system, { month: "short" }, locale).format(
      new Date(start.getFullYear(), start.getMonth(), start.getDate() + i - 1, 12),
    );
    row.append(
      node("span", "cal-tl-dow", calWeekday(date, "short", locale)),
      node("span", "cal-tl-num", calDayNumber(date, system, locale)),
      node("span", changed ? "cal-tl-month" : "cal-tl-month is-same", changed ? month : ""),
    );
    wrap.append(row);
  }
  return wrap;
}

/** The first day of the month before `monthStart`, which must itself be day 1.
 *
 *  Stepping back a Gregorian month would land in the wrong place in a lunar
 *  calendar, so the previous month is found by asking `Intl` where it ended:
 *  the day before day 1 is that month's last day, and its day *number* is the
 *  distance back to its own first. */
function calPrevMonthStart(monthStart, system) {
  const lastDay = new Date(monthStart.getFullYear(), monthStart.getMonth(), monthStart.getDate() - 1, 12);
  const at = calYmd(lastDay, system);
  return new Date(lastDay.getFullYear(), lastDay.getMonth(), lastDay.getDate() - (at.day - 1), 12);
}

/** The first day of the month after `monthStart` — its own first day plus the
 *  length of that month, which is what `calendarFacts` measures. */
function calNextMonthStart(monthStart, system) {
  const facts = calendarFacts(monthStart, system);
  return new Date(monthStart.getFullYear(), monthStart.getMonth(), monthStart.getDate() + facts.daysInMonth, 12);
}

function buildCalendarYear(now, system, locale) {
  const wrap = node("div", "cal-year");
  const today = calYmd(now, system);

  let monthStart = calendarFacts(now, system).first;
  for (let guard = 0; guard < 24; guard += 1) {
    const prev = calPrevMonthStart(monthStart, system);
    if (calYmd(prev, system).year !== today.year) break;
    monthStart = prev;
  }

  const monthFmt = calFormatter(system, { month: "long" }, locale);
  const months = [];
  for (let i = 0; i < 12; i += 1) {
    const at = calYmd(monthStart, system);
    months.push({ start: monthStart, at, facts: calendarFacts(monthStart, system) });
    monthStart = calNextMonthStart(monthStart, system);
  }

  const total = months.reduce((sum, m) => sum + m.facts.daysInMonth, 0);

  let elapsed = 0;
  for (const m of months) {
    if (m.at.year < today.year || (m.at.year === today.year && m.at.month < today.month)) {
      elapsed += m.facts.daysInMonth;
    }
  }
  elapsed += today.day;

  const NS = "http://www.w3.org/2000/svg";
  const R = 42;
  const GAP = 1.4;
  const arc = (from, to) => {
    const at = (deg) => {
      const a = ((deg - 90) * Math.PI) / 180;
      return [50 + R * Math.cos(a), 50 + R * Math.sin(a)];
    };
    const [x1, y1] = at(from);
    const [x2, y2] = at(to);
    const large = to - from > 180 ? 1 : 0;
    return `M ${x1.toFixed(2)} ${y1.toFixed(2)} A ${R} ${R} 0 ${large} 1 ${x2.toFixed(2)} ${y2.toFixed(2)}`;
  };

  const svg = document.createElementNS(NS, "svg");
  svg.setAttribute("class", "cal-year-dial");
  svg.setAttribute("viewBox", "0 0 100 100");

  let cursor = 0;
  months.forEach(({ start, at, facts }) => {
    const span = (facts.daysInMonth / total) * 360;
    const isCurrent = at.month === today.month && at.year === today.year;
    const past = at.year < today.year || (at.year === today.year && at.month < today.month);
    const from = cursor + GAP / 2;
    const to = cursor + span - GAP / 2;
    cursor += span;

    const track = document.createElementNS(NS, "path");
    track.setAttribute("d", arc(from, to));
    track.setAttribute("class", isCurrent ? "cal-year-seg is-current" : "cal-year-seg");
    track.append(document.createElementNS(NS, "title"));
    track.lastChild.textContent = monthFmt.format(start);
    svg.append(track);

    if (!past && !isCurrent) return;
    const frac = isCurrent ? today.day / facts.daysInMonth : 1;
    const filled = document.createElementNS(NS, "path");
    filled.setAttribute("d", arc(from, from + (to - from) * frac));
    filled.setAttribute("class", isCurrent ? "cal-year-seg is-current is-done" : "cal-year-seg is-done");
    svg.append(filled);
  });

  const center = node("div", "cal-year-center");
  center.append(node("span", "cal-year-month", calMonthDay(now, system, locale)));
  center.append(node("span", "cal-year-doy", calCount(elapsed, locale)));
  center.append(node("span", "cal-year-pct", `${calCount(Math.round((elapsed / total) * 100), locale)}%`));

  wrap.append(svg, center);
  return wrap;
}

// ── the floating clock ────────────────────────────────────────────────────
// A clock panel is the page clock's smaller sibling: same face, same 12/24-hour
// switch, its own panel. It exists because the big block at the top belongs to
// the page and cannot be in two places at once — a second time zone, or simply
// a clock down beside the timers, needs a panel of its own.
//
// Its size is *not* the page clock's size slider. That slider is stated in px
// for a 68px-plus face, and 68px of digits inside a 268px panel is not a clock,
// it is a headline. A floating clock draws at a size the panel can hold and is
// resized the way every other widget is, with the standard size control.

/** Draw a clock body's time and date. Split out of the renderer because the
 *  page's minute tick repaints these in place rather than rebuilding the panel —
 *  a rebuild would drop the body's scroll position and, worse, fight a drag.
 *
 *  `locale` is the face's own language, so a clock wearing Vazirmatn reads its
 *  date and its digits in Persian. The time is drawn here rather than through
 *  `Intl` so the 12/24-hour switch and the ` am`/` pm` suffix stay under this
 *  file's control; only the digits are localised, and only when a locale asks. */
function paintClockWidget(wrap, clock24, now = new Date(), locale = null) {
  const time = wrap.querySelector(".wg-clock-time");
  const date = wrap.querySelector(".wg-clock-date");
  if (!time || !date) return;

  let hours = now.getHours();
  let suffix = "";
  if (!clock24) {
    suffix = hours < 12 ? " am" : " pm";
    hours = hours % 12 || 12;
  }
  // `padStart` inline rather than a `pad` helper: `newtab.js` already declares a
  // top-level `pad`, and the extension's classic scripts share one lexical
  // scope, so a second one would be a load-time SyntaxError for the whole page.
  const hh = clock24 ? String(hours).padStart(2, "0") : String(hours);
  const mm = String(now.getMinutes()).padStart(2, "0");
  time.textContent = `${calCount(hh, locale)}:${calCount(mm, locale)}${suffix}`;
  date.textContent = calFormatter("gregory", { weekday: "long", day: "numeric", month: "long" }, locale).format(now);
}

/** Repaint every clock panel that is on the page. Called from the page's own
 *  minute tick, which is why it takes the hour format rather than re-reading
 *  the settings twenty times a minute. */
function refreshClockBodies(clock24, now) {
  for (const spec of layoutState) {
    if (NEWTAB_SAFE.widgetKindOf(spec) !== "clock") continue;
    // An added clock's id is minted, so the shipped switch entry — which has no
    // panel — simply misses and is skipped.
    const entry = widgetPanels.get(spec.id);
    const wrap = entry?.body.querySelector(".wg-clock");
    // The locale is read off the panel rather than out of settings: the attribute
    // is what the stylesheet is already matching, and this runs twenty-four
    // times an hour on a path that must not await storage.
    if (wrap) paintClockWidget(wrap, clock24, now, NEWTAB_SAFE.widgetFontById(entry.panel.dataset.font).locale);
  }
}

// ── the widget kinds ──────────────────────────────────────────────────────
// Each `body` returns a node; `title` is the header text and `href`, when
// present, is the admin page the widget's own footer links to.

/** Which glyph a wttr.in `weatherCode` draws, and whether a halo sits behind it.
 *
 *  WorldWeatherOnline's codes are not ordered — 350 is ice pellets, 353 is rain,
 *  368 is snow and 386 is thunder — so there is no range to sweep and the table
 *  is written out. Grouping it here rather than testing the number in the
 *  builder means a code the service adds later falls to "cloud" instead of to a
 *  lucky guess, and the mapping can be checked against the service's own list in
 *  one place.
 *
 *  `halo` is the one place colour appears: a clear or part-cloudy sky draws a
 *  disc of accent behind the sun, and everything else is ink. One tint is what
 *  keeps a forecast panel from turning into the usual weather-app slab of
 *  blues — and the page keeps one accent on purpose, so a second hue here would
 *  be the only object on the page not following it. */
const WEATHER_CODE_GLYPHS = {
  113: { glyph: "sun", halo: true },
  116: { glyph: "partly", halo: true },
  119: { glyph: "cloud", halo: false },
  122: { glyph: "cloud", halo: false },
  143: { glyph: "fog", halo: false },
  248: { glyph: "fog", halo: false },
  260: { glyph: "fog", halo: false },
  // Thunder, in every form the service reports it.
  200: { glyph: "storm", halo: false },
  386: { glyph: "storm", halo: false },
  389: { glyph: "storm", halo: false },
  392: { glyph: "storm", halo: false },
  395: { glyph: "storm", halo: false },
  // Snow — falling, blowing, showers, and the pellets that read as snow.
  179: { glyph: "snow", halo: false },
  227: { glyph: "snow", halo: false },
  230: { glyph: "snow", halo: false },
  323: { glyph: "snow", halo: false },
  326: { glyph: "snow", halo: false },
  329: { glyph: "snow", halo: false },
  332: { glyph: "snow", halo: false },
  335: { glyph: "snow", halo: false },
  338: { glyph: "snow", halo: false },
  350: { glyph: "snow", halo: false },
  368: { glyph: "snow", halo: false },
  371: { glyph: "snow", halo: false },
  374: { glyph: "snow", halo: false },
  377: { glyph: "snow", halo: false },
  // Sleet is rain with snow in it; the rain glyph carries the idea without
  // needing a picture nobody reads at 44px.
  182: { glyph: "rain", halo: false },
  185: { glyph: "rain", halo: false },
  281: { glyph: "rain", halo: false },
  284: { glyph: "rain", halo: false },
  311: { glyph: "rain", halo: false },
  314: { glyph: "rain", halo: false },
  317: { glyph: "rain", halo: false },
  320: { glyph: "rain", halo: false },
  362: { glyph: "rain", halo: false },
  365: { glyph: "rain", halo: false },
  // Rain, the rest of it.
  176: { glyph: "rain", halo: false },
  263: { glyph: "rain", halo: false },
  266: { glyph: "rain", halo: false },
  293: { glyph: "rain", halo: false },
  296: { glyph: "rain", halo: false },
  299: { glyph: "rain", halo: false },
  302: { glyph: "rain", halo: false },
  305: { glyph: "rain", halo: false },
  308: { glyph: "rain", halo: false },
  353: { glyph: "rain", halo: false },
  356: { glyph: "rain", halo: false },
  359: { glyph: "rain", halo: false },
};

function weatherGlyph(code) {
  // An unknown code is not nothing: a panel with no picture reads as broken, so
  // it gets the neutral cloud rather than an empty box.
  return WEATHER_CODE_GLYPHS[Number(code)] ?? { glyph: "cloud", halo: false };
}

/** The paths for each glyph, on a 24-unit grid at the page's 1.6 stroke —
 *  the same grid and stroke the tool icons in `theme.css` use, so a weather
 *  panel's picture reads as part of the page rather than as an illustration
 *  dropped into it. Every glyph is stroke-only and inherits `currentColor`;
 *  the one filled shape is the sun's disc, which is the accent.
 *
 *  Each entry is a list of `[tag, attrs]` pairs rather than markup: the node
 *  builder in this file cannot parse an SVG string, and building them as data
 *  keeps the grid readable as a drawing. */
const WEATHER_GLYPHS = {
  sun: [
    ["circle", { cx: 12, cy: 12, r: 4.4, fill: "var(--accent)", stroke: "none" }],
    ["circle", { cx: 12, cy: 12, r: 4.4 }],
    ["path", { d: "M12 2.2v2.6M12 19.2v2.6M2.2 12h2.6M19.2 12h2.6M5 5l1.9 1.9M17.1 17.1L19 19M19 5l-1.9 1.9M6.9 17.1L5 19" }],
  ],
  partly: [
    ["circle", { cx: 9.4, cy: 8.6, r: 3.1, fill: "var(--accent)", stroke: "none" }],
    ["circle", { cx: 9.4, cy: 8.6, r: 3.1 }],
    ["path", { d: "M9.4 2.4v1.9M3.2 8.6h1.9M4.9 4.1l1.3 1.3M13.9 4.1l-1.3 1.3" }],
    ["path", { d: "M9.6 19.5h8.1a3.2 3.2 0 0 0 .4-6.4 4.6 4.6 0 0 0-8.7-1.2 3.6 3.6 0 0 0 .2 7.6Z" }],
  ],
  cloud: [
    ["path", { d: "M7.2 18.6h9.6a3.5 3.5 0 0 0 .4-7 5.2 5.2 0 0 0-9.8-1.4 3.9 3.9 0 0 0-.2 8.4Z" }],
  ],
  rain: [
    ["path", { d: "M7.4 14.4h9.4a3.3 3.3 0 0 0 .4-6.6 5 5 0 0 0-9.4-1.3 3.7 3.7 0 0 0-.4 7.9Z" }],
    ["path", { d: "M8.6 17.4l-1 3M12 17.4l-1 3M15.4 17.4l-1 3" }],
  ],
  storm: [
    ["path", { d: "M7.4 14h9.4a3.3 3.3 0 0 0 .4-6.6 5 5 0 0 0-9.4-1.3 3.7 3.7 0 0 0-.4 7.9Z" }],
    ["path", { d: "M13 15.6l-2.8 4.6h2.4l-1.2 3.8" }],
  ],
  // Snow is three dots rather than a comb of strokes: at 20px in the day strip
  // a comb closes into a fence, while dots still read as flakes falling — and
  // the staggers keep it apart from rain, whose marks are slanted dashes.
  snow: [
    ["path", { d: "M7.4 13.6h9.4a3.3 3.3 0 0 0 .4-6.6 5 5 0 0 0-9.4-1.3 3.7 3.7 0 0 0-.4 7.9Z" }],
    ["circle", { cx: 8.6, cy: 17.6, r: 0.95, fill: "currentColor", stroke: "none" }],
    ["circle", { cx: 12, cy: 19.4, r: 0.95, fill: "currentColor", stroke: "none" }],
    ["circle", { cx: 15.4, cy: 17.6, r: 0.95, fill: "currentColor", stroke: "none" }],
  ],
  fog: [
    ["path", { d: "M7.6 12.4h8.8a3 3 0 0 0 .4-6 4.6 4.6 0 0 0-8.6-1.2 3.4 3.4 0 0 0-.6 7.2Z" }],
    ["path", { d: "M4.6 15.4h14.8M6.8 18.4h10.4M9.4 21.2h5.2" }],
  ],
};

/** One condition glyph as an SVG node.
 *
 *  It carries no size of its own: the box it is put in sets that in `em`, so the
 *  same glyph draws at the panel's 44px and at the settings panel's miniature
 *  without either number living here. The `viewBox` is the 24-unit grid the
 *  drawing is written on, which is what lets one node fill any box. */
function buildWeatherIcon(code) {
  const { glyph, halo } = weatherGlyph(code);
  const art = WEATHER_GLYPHS[glyph] ?? WEATHER_GLYPHS.cloud;
  const svg = wgSvg("svg", {
    viewBox: "0 0 24 24",
    class: `wg-wx-icon is-${glyph}`,
    fill: "none",
    stroke: "currentColor",
    "stroke-width": "1.6",
    "stroke-linecap": "round",
    "stroke-linejoin": "round",
    "aria-hidden": "true",
    focusable: "false",
  });
  // A clear sky gets a disc of accent behind it — the sun is the subject, and
  // the disc is what says so. Under cloud or rain the glyph is the whole
  // picture, so one there would only be a coloured hole behind a line drawing.
  // Drawn as an element rather than a CSS background because it is a disc: a
  // background would be a square behind something that is not.
  if (halo) {
    svg.append(wgSvg("circle", { cx: 12, cy: 12, r: 9.6, class: "wg-wx-halo", stroke: "none" }));
  }
  for (const [tag, attrs] of art) {
    svg.append(wgSvg(tag, { ...attrs, "stroke-width": attrs.fill ? "0" : "1.6" }));
  }
  return svg;
}

/** The bare frame the panel shows before the request lands: the city, and the
 *  shape of what is coming. Not a spinner — a three-line skeleton in the ink's
 *  own low alpha reads as "this is loading" without a moving part on a page
 *  that is otherwise still. */
function buildWeatherSkeleton(city) {
  const wrap = node("div", "wg-wx is-loading");
  const top = node("div", "wg-wx-top");
  const icon = node("div", "wg-wx-icon-box");
  icon.append(buildWeatherIcon(116));
  const stack = node("div", "wg-wx-stack");
  const title = node("div", "wg-wx-city", city);
  const temp = node("div", "wg-wx-temp");
  temp.append(node("span", "wg-wx-deg", "—"), node("span", "wg-wx-unit", "°"));
  const desc = node("div", "wg-wx-desc", "loading…");
  stack.append(title, temp, desc);
  top.append(icon, stack);
  wrap.append(top);
  return wrap;
}

function buildWeatherError(city, message) {
  const wrap = node("div", "wg-wx is-error");
  const top = node("div", "wg-wx-top");
  const icon = node("div", "wg-wx-icon-box");
  icon.append(buildWeatherIcon(143));
  const stack = node("div", "wg-wx-stack");
  stack.append(node("div", "wg-wx-city", city), node("div", "wg-wx-desc", message));
  top.append(icon, stack);
  wrap.append(top);
  return wrap;
}

/** One of the small facts under the temperature: a label over a value, laid
 *  out as two columns so the row reads as a table of readings rather than as a
 *  sentence of prose. */
/** One wttr.in reading as the widget's own digits. The service sends numbers as
 *  strings (`"21"`, `"14"`), so a value is passed through `calCount` only when it
 *  reads as a number — an em dash for a missing reading must stay an em dash
 *  rather than become `NaN`. */
function wxNumber(value, locale) {
  const n = Number(value);
  return Number.isFinite(n) ? calCount(n, locale) : String(value ?? "—");
}

function buildWeatherFact(label, value) {
  const cell = node("div", "wg-wx-fact");
  cell.append(node("div", "wg-wx-fact-label", label), node("div", "wg-wx-fact-value", value));
  return cell;
}

/** The three-day strip, if the response has forecasts. wttr.in returns
 *  `weather` as today plus two, so this draws whatever it was given rather than
 *  assuming a length — a response with one day is a one-day strip. */
function buildWeatherDays(days, locale) {
  const list = Array.isArray(days) ? days : [];
  if (!list.length) return null;
  const strip = node("div", "wg-wx-days");
  for (const day of list.slice(0, 3)) {
    const cell = node("div", "wg-wx-day");
    // `date` is an ISO day; Intl reads it as UTC midnight, which is the day it
    // names in every timezone west of Greenwich too — parsing it with `new
    // Date()` would shift it a day for anyone east of it.
    const when = new Date(`${day.date}T12:00:00`);
    const label = Number.isNaN(when.getTime()) ? "" : calWeekday(when, "short", locale);
    const code = day.hourly?.[4]?.weatherCode ?? day.hourly?.[0]?.weatherCode;
    cell.append(
      node("div", "wg-wx-day-name", label),
      buildWeatherIcon(code),
      node("div", "wg-wx-day-hi", `${wxNumber(day.maxtempC, locale)}°`),
      node("div", "wg-wx-day-lo", `${wxNumber(day.mintempC, locale)}°`),
    );
    strip.append(cell);
  }
  return strip;
}

/** The full body, once the reading is in.
 *
 *  Laid out in two bands: a large condition glyph beside the temperature and
 *  the place, then a hairline rule and a row of facts. The bands are separated
 *  by a rule rather than by spacing alone, because the facts are a different
 *  *kind* of information — readings, not the headline — and a rule says that
 *  the way a wider gap cannot. */
function buildWeatherBody(city, cur, data, locale) {
  const wrap = node("div", "wg-wx");

  const top = node("div", "wg-wx-top");
  const icon = node("div", "wg-wx-icon-box");
  icon.append(buildWeatherIcon(cur.weatherCode));

  const stack = node("div", "wg-wx-stack");
  const cityLine = node("div", "wg-wx-city");
  // `nearest_area` carries the name the service resolved the query to, which is
  // what "where is this reading from" actually means. The typed query is the
  // fallback for a response that omits it.
  const resolved = data?.nearest_area?.[0]?.areaName?.[0]?.value || city;
  cityLine.textContent = resolved;

  const tempLine = node("div", "wg-wx-temp");
  tempLine.append(
    node("span", "wg-wx-deg", wxNumber(cur.temp_C, locale)),
    node("span", "wg-wx-unit", "°"),
  );

  const desc = node("div", "wg-wx-desc", (cur.weatherDesc?.[0]?.value || "").trim());
  stack.append(cityLine, tempLine, desc);
  top.append(icon, stack);
  wrap.append(top);

  const facts = node("div", "wg-wx-facts");
  facts.append(
    buildWeatherFact("Feels", `${wxNumber(cur.FeelsLikeC, locale)}°`),
    buildWeatherFact("Wind", `${wxNumber(cur.windspeedKmph, locale)} km/h ${cur.winddir16Point ?? ""}`.trim()),
    buildWeatherFact("Humidity", `${wxNumber(cur.humidity, locale)}%`),
  );
  wrap.append(node("div", "wg-wx-rule"), facts);

  const days = buildWeatherDays(data?.weather, locale);
  if (days) wrap.append(days);
  return wrap;
}

const WIDGET_RENDERERS = {
  clock: {
    title: "Clock",
    // Two different things wear this renderer. The *shipped* clock entry (id
    // "clock") is the switch for the big block at the top of the page and never
    // becomes a panel; every *added* clock is a real floating clock, drawn here.
    //
    // The body carries the time, so it has to be repainted on the page's minute
    // tick rather than only when its panel is built — see `refreshClockBodies`.
    // The face and weight come from the same settings the page's own clock
    // reads, so a face chosen once dresses both.
    async body(spec) {
      // The shipped entry is the switch for the block at the top of the page,
      // and never becomes a panel — in the editor's list it says where the thing
      // it controls lives rather than drawing a second copy of it.
      // The entry's own `visible` says whether it is drawing at all, which is
      // the one thing this card exists to report now that the clock is added and
      // removed like every other widget.
      if (spec?.id === "clock") {
        const on = spec?.visible !== false;
        return node("div", on ? "wg-empty is-on" : "wg-empty", on ? "On the page." : "Hidden — switch it on to show it.");
      }

      const settings = await NEWTAB_SAFE.get();
      const font = NEWTAB_SAFE.clockFontById(settings.clockFont);
      const locale = NEWTAB_SAFE.widgetLocaleFor(settings, spec.id);

      const time = node("div", "wg-clock-time");
      // A locale means the digits are Persian, and the clock faces are display
      // cuts that carry no Persian numerals — setting one inline would leave the
      // digits to whatever font the browser falls back to. The widget's own face
      // is the one that was chosen knowing it would be read in this script, so
      // the inline face steps aside and `data-font` on the panel dresses the
      // time along with the date beneath it.
      if (!locale) {
        time.style.fontFamily = font.stack;
        // Weight and slant travel with the family for the same reason they do on
        // the page clock: asking for a cut a family does not ship makes the
        // browser synthesise one, which smears a pixel face into neither.
        time.style.fontWeight = String(font.weight ?? 400);
        time.style.fontStyle = font.style ?? "normal";
        time.classList.toggle("is-outline", font.effect === "outline");
        time.classList.toggle("is-glow", font.effect === "glow");
      }

      const wrap = node("div", "wg-clock");
      wrap.append(time, node("div", "wg-clock-date"));
      // Filled straight away rather than left blank until the next minute tick:
      // a clock that reads empty for up to fifty-nine seconds is a broken one.
      paintClockWidget(wrap, settings.clock24, new Date(), locale);
      return wrap;
    },
  },

  weather: {
    title: "Weather",
    async body(spec) {
      const settings = await NEWTAB_SAFE.get();
      const city = NEWTAB_SAFE.weatherCityOf(settings, spec?.id);
      const locale = NEWTAB_SAFE.widgetLocaleFor(settings, spec?.id);
      const wrap = node("div", "wg-weather");
      wrap.append(buildWeatherSkeleton(city));

      (async () => {
        try {
          const res = await fetch(`https://wttr.in/${encodeURIComponent(city)}?format=j1`);
          const data = await res.json();
          const cur = data?.current_condition?.[0];
          if (!cur) {
            wrap.replaceChildren(buildWeatherError(city, "No data for this place."));
            return;
          }
          wrap.replaceChildren(buildWeatherBody(city, cur, data, locale));
        } catch {
          wrap.replaceChildren(buildWeatherError(city, "Couldn't reach the forecast."));
        }
      })();
      return wrap;
    },
  },
  calendar: {
    title: "Calendar",
    // Which layout is drawn is read from the settings at render time, so the
    // one `data-variant` attribute on the panel and the body built here can
    // never disagree. Which *calendar* it counts in is a second, independent
    // setting: any layout can count in any system. `grid` in Gregorian defers to
    // `newtab.js`'s `buildCalendar`, which the clock's minute tick also calls —
    // every other combination is built from `calCells` and is not touched by the
    // tick, so a Hijri panel only redraws when the page itself rebuilds.
    //
    // Both are resolved against this widget's own *id*, not against the kind:
    // once every kind can be placed twice there can be a second calendar, and
    // reading "calendar" here regardless would draw the first one's layout inside
    // the second one's panel. Every body that resolves a variant takes the spec
    // for exactly this reason — and the calendar needs it twice over, since the
    // lunar-beside-Gregorian pair is the reason the system is per-widget at all.
    async body(spec) {
      const settings = await NEWTAB_SAFE.get();
      return renderCalendarBody(
        NEWTAB_SAFE.widgetVariantFor(settings, spec?.id),
        new Date(),
        NEWTAB_SAFE.calendarSystemFor(settings, spec?.id),
        NEWTAB_SAFE.widgetLocaleFor(settings, spec?.id),
      );
    },
  },

  timers: {
    title: "Running timers",
    href: "/admin/timer",
    async body(spec) {
      const settings = await NEWTAB_SAFE.get();
      // A repaint replaces this body, so anything still ticking against the old
      // one has to stop first — whichever branch draws next.
      stopTimerTicks(spec);
      const source = await timerSource();
      if (!source) return node("div", "wg-empty", "Could not load timers.");
      // `local` on each record, so the display and the actions can tell which
      // store a timer lives in without being handed the flag separately.
      const list = source.list.map((t) => ({ ...t, local: source.local }));
      const { local } = source;
      // The chosen layout is honoured for both stores now: the widget's header
      // carries its own "+" (see `buildTimersHeaderAdd`), so the read-only
      // display is no longer a dead end locally the way it was when the only
      // way to start a timer was a button inside the controls body. "Controls"
      // is still there for a profile that prefers the row list with its buttons.
      const locale = NEWTAB_SAFE.widgetLocaleFor(settings, spec?.id);
      if (NEWTAB_SAFE.widgetVariantFor(settings, spec?.id) === "studio") {
        return renderTimerStudio(list, spec, local, locale);
      }
      return renderTimersPanel(list, spec, local, locale);
    },
  },

  tasks: {
    title: "Open tasks",
    href: "/admin/todo",
    async body(spec, render = {}) {
      const settings = await NEWTAB_SAFE.get();
      // A connected panel draws its shared list instead of the account's or the
      // local one — unless the header's own tab switcher has the other tab
      // active. The entry is read out of a fresh `settings` rather than off
      // `spec`: `spec` is the stale `layoutState` entry, and `setWidgetData`
      // writes storage, not that array, so `spec.data` would be one write
      // behind. This runs before `taskSource()` on purpose — a connected panel
      // works signed out, so it must not depend on the account read at all.
      const link = NEWTAB_SAFE.todoLinkOf(settings.widgets.find((w) => w.id === spec?.id)?.data);
      if (link && link.tab !== "own") {
        // A user-initiated render may surface the unlock prompt; see
        // `repaintTasksWidget`.
        link.entering = render.entering === true;
        return renderConnectedTasks(spec, link);
      }
      const source = await taskSource();
      // A signed-in read that failed for a non-auth reason has nothing to show,
      // and must not fall back to the local lists — see `taskSource`.
      if (!source) return node("div", "wg-empty", "Could not load tasks.");
      const { pages, local } = source;

      // Locally the summary has nothing to summarise and nowhere to add a list,
      // so the working surface is the only useful shape of this widget. With a
      // session the chosen variant still wins, exactly as before.
      if (local || NEWTAB_SAFE.widgetVariantFor(settings, spec?.id) === "picker") {
        return renderTaskPicker(pages, settings, spec, local);
      }

      const withWork = pages.filter((p) => (p.totalCount ?? 0) - (p.doneCount ?? 0) > 0);
      // Summaries carry counts, not items, so each page with work left needs its
      // own detail read. Capped at three: beyond that the widget is a wall of
      // text and its own footer link is the better answer. Only an account ever
      // reaches this point — the local branch above always takes the picker —
      // which is why there is no second source here.
      const details = await Promise.all(withWork.slice(0, 3).map((p) => NEWTAB_API.todos.page(p.id).catch(() => null)));
      const open = details
        .flatMap((d) => (d?.page?.items ?? []).filter((i) => !i.done).map((i) => ({ text: i.text, list: d.page.title })))
        .slice(0, 8);
      return widgetList(open, "Nothing open.", (i) => {
        const row = node("div", "wg-row");
        const box = node("span", "wg-check");
        const stack = node("div", "wg-row-stack");
        stack.append(node("div", "wg-row-title", i.text), node("div", "wg-row-sub", i.list));
        row.append(box, stack);
        return row;
      });
    },
  },

  shortcuts: {
    title: "Shortcuts",
    // One instance's own pinned sites. `spec` is the widget entry itself, which
    // is why this renderer — alone among them — takes an argument: every other
    // kind draws the same thing in every panel, where a shortcuts panel draws
    // whatever its own instance was given.
    async body(spec) {
      const settings = await NEWTAB_SAFE.get();
      const entry = settings.widgets.find((w) => w.id === spec?.id);
      const links = entry?.data?.links ?? [];
      if (NEWTAB_SAFE.widgetVariantFor(settings, spec?.id) === "single") {
        return shortcutsSingle(spec, links[0] ?? null);
      }
      // An empty panel is the same grid with nothing in it yet, which is what
      // makes the + tile the one thing there is to press. It is deliberately not
      // a different "no sites yet" body: the way to add the first site and the
      // way to add the tenth should not be two different controls.
      return shortcutsGrid(spec, links);
    },
  },

  bookmarks: {
    title: "Bookmarks",
    href: "/admin/bookmarks",
    async body(spec) {
      const { signedIn } = loadWidgetData();
      // A profile without an account files into the browser's own list. The
      // two are not merged: signing in moves the page onto the account list,
      // which is where every write after that goes too.
      //
      // The account list is cached like the todos list, and asked for only once
      // there is a session: a signed-out tab has no account list to fetch, and
      // asking for one anyway was a round trip whose answer was thrown away
      // every time. A cache hit paints at once and a stale one refreshes behind
      // the paint, through the same `readWithRefresh` the other lists use.
      const data = (await signedIn)
        ? await readAccount(NEWTAB_API.cache.KEYS.bookmarks, () => NEWTAB_API.bookmarks.list()).catch(() => null)
        : { ok: true, data: { bookmarks: (await readLocalStore(LOCAL_BOOKMARKS_KEY))?.bookmarks ?? [] } };
      const bookmarks = data?.ok ? data.data : null;
      // Pins and collapsed groups are view preferences of this profile, so they
      // come from `settings.js` rather than from the bookmark payload — the
      // server has no idea which rows this browser lifted to the top.
      const settings = await NEWTAB_SAFE.get();
      const list = bookmarks?.bookmarks ?? [];
      const variant = NEWTAB_SAFE.widgetVariantFor(settings, spec?.id);
      const pinnedSet = new Set(settings.pins ?? []);

      // Every layout carries the same add control, so a link can be saved from
      // whichever variant this panel happens to wear. `search` builds its own
      // because it also owns the filter field; the rest take the shared foot.
      if (variant === "pinned") {
        return bookmarkBodyWithAdd(
          renderBookmarkFlat(
            list.filter((b) => pinnedSet.has(b.id)),
            spec,
            { pinnedOnly: true, empty: "No pinned bookmarks. Pin one from the full list." },
          ),
          spec,
        );
      }
      if (variant === "compact") {
        return bookmarkBodyWithAdd(
          renderBookmarkFlat(list, spec, { subtitle: false, empty: "No bookmarks yet." }),
          spec,
        );
      }
      if (variant === "search") {
        return renderBookmarkSearch(list, spec);
      }
      return bookmarkBodyWithAdd(
        renderBookmarkGroups(list, pinnedSet, new Set(settings.collapsedFolders ?? []), spec, NEWTAB_SAFE.widgetLocaleFor(settings, spec?.id)),
        spec,
      );
    },
  },

};

// ── shortcuts: one panel of pinned sites ──────────────────────────────────
// The only widget the user fills in themselves, and the only kind that can be
// placed more than once. Both of those facts live here: the body is built from
// the instance's own stored list rather than from the account, and it is the
// only body that takes the widget entry as an argument.

/** A tile's icon box. Delegated to `shortcuts.js`'s `scIconEl` so the tile and
 *  the page's floating icon cannot disagree about what a site looks like — the
 *  fallback chain (an upload, then Chrome's favicon service, then
 *  `/favicon.ico`, then the host's first letter) lives in exactly one place. */
function shortcutIcon(link, size = 20) {
  const box = window.ixiNewtabShortcuts?.iconEl?.(link, size);
  if (box) return box;
  // The page's shortcuts module is loaded before this file, so this is only
  // reached if it failed to load — in which case a letter is still better than
  // an empty box.
  const fallback = node("span", "wg-tile-icon");
  fallback.style.setProperty("--tile-icon", `${size}px`);
  fallback.textContent = (NEWTAB_SAFE.hostOfUrl(link.url).match(/[a-z0-9]/i) || ["?"])[0].toUpperCase();
  return fallback;
}

/** The tile grid: one click, one site. A `<a>` rather than a button so the
 *  browser's own "open in new tab" and "copy address" work on it, and so a
 *  middle-click does what it does everywhere else.
 *
 *  Only *unplaced* sites are drawn here. A site that has been dragged onto the
 *  page is drawn there instead, and showing it in both places would be two
 *  things to keep in step — the panel is the shelf, the page is the desk. */
function shortcutsGrid(spec, links) {
  const wrap = node("div", "wg-shortcuts");
  const grid = node("div", "wg-tiles");
  for (const link of links) {
    if (link.x != null && link.y != null) continue;
    const a = node("a", "wg-tile");
    a.href = NEWTAB_SAFE.shortcutHref(link.url);
    a.title = `${link.url} — drag onto the page, or right-click to change`;
    a.draggable = false; // the pointer drag below owns the gesture
    // The native drag is refused outright as well, not merely discouraged: it
    // begins on the first move of the gesture and cancels the pointer stream,
    // so the tile could never be dragged onto the page while the browser was
    // busy dragging its picture.
    a.addEventListener("dragstart", (e) => e.preventDefault());
    a.append(shortcutIcon(link, 20), node("span", "wg-tile-label", link.label));
    // Dragging a tile out of the panel is how a site gets onto the page. A
    // press that never crosses the slop stays a click and still opens the link.
    a.addEventListener("pointerdown", (e) => {
      if (window.ixiNewtabShortcuts?.startTileDrag) {
        window.ixiNewtabShortcuts.startTileDrag(e, a, spec, link);
      }
    });
    a.addEventListener("contextmenu", (e) => {
      e.preventDefault();
      e.stopPropagation();
      window.ixiNewtabShortcuts?.openMenu?.(e, spec, link);
    });
    grid.append(a);
  }
  const add = node("button", "wg-tile wg-tile-add", "+");
  add.type = "button";
  add.title = "Pin a site";
  add.setAttribute("aria-label", "Pin a site");
  add.addEventListener("click", () => openShortcutEditor(spec));
  grid.append(add);
  wrap.append(grid);
  return wrap;
}

/** One site, drawn large — the whole panel as a single button, and never more
 *  than one. `null` (nothing pinned yet) is the add control, so a fresh
 *  single-icon panel is still a way to put a site in it rather than an empty
 *  box; once a site is in, the add control is *gone* rather than merely full,
 *  because the cap is the point of this variant.
 *
 *  There is no × and no ⋮ on the block: at 92px they would be most of what is
 *  drawn. The whole control surface is the widget menu on right-click, which
 *  reaches "Edit site..." for changing or removing the pinned site and "Move"
 *  for putting the block somewhere else. A left-click has to stay a left-click —
 *  it is a link, and the panel's whole job is to be the fastest way to that
 *  site. */
async function shortcutsSingle(spec, link) {
  const wrap = node("div", "wg-shortcuts is-single");
  // The header is not drawn in this variant, so the panel has nowhere to hang
  // its drag handle. The tile is the whole panel, so it takes the gesture
  // instead — the same one `startDrag` gives the header elsewhere. A drag that
  // moves the pointer is a move; a press that does not is a click, which the
  // browser still delivers to the link, so the two coexist without a timer.
  const draggable = (el) => {
    el.addEventListener("pointerdown", (e) => {
      if (e.button !== 0) return;
      const panel = widgetPanels.get(spec.id)?.panel;
      if (panel) startDrag(e, panel, spec.id);
    });
  };
  if (!link) {
    const add = node("button", "wg-tile wg-tile-add is-single", "+");
    add.type = "button";
    add.title = "Pin a site";
    add.setAttribute("aria-label", "Pin a site");
    add.dataset.role = "menu";
    // The modal, not the inline editor: this block has no panel body to take
    // over — it is 92px of icon — so the form has to go over the page.
    add.addEventListener("click", () => openShortcutModal(spec));
    draggable(add);
    wrap.append(add);
    return wrap;
  }
  const a = node("a", "wg-tile is-single");
  a.href = NEWTAB_SAFE.shortcutHref(link.url);
  a.title = `${link.url} — right-click to change`;
  a.dataset.role = "menu";
  a.append(shortcutIcon(link, 52));
  // The name is opt-out, not always-off: the same tile is what a single-icon
  // panel draws, and an icon alone is a guess for anyone who does not
  // recognise it. `hideLabel` is where the user answers that, from the menu.
  const settings = await NEWTAB_SAFE.get();
  if (!NEWTAB_SAFE.widgetLabelHidden(settings, spec.id)) {
    a.append(node("span", "wg-tile-label", link.label));
  } else {
    a.classList.add("is-labelless");
  }
  // A right-click on the tile gets the widget menu like everywhere else — moving,
  // hiding, resizing all live there — and the menu offers "Edit site..." as the
  // way into the name and address. The old behaviour opened the form directly
  // here, which read as the right-click having done two things at once: the form
  // appeared *and* the menu opened over it. One gesture, one surface.
  draggable(a);
  wrap.append(a);
  return wrap;
}

/** The name-and-address form, as DOM rather than as a placed panel, so the two
 *  surfaces that need it can share one implementation: the inline editor that
 *  replaces a grid panel's body, and the page-level modal the single-icon block
 *  opens. Two fields and one button, because a name and an address is the whole
 *  of what a pinned site is.
 *
 *  `edit` reopens it on a site already in the list — `{ index, link }`. Without
 *  it the form appends. `onDone` is called once the write has landed, and is the
 *  only thing the two callers disagree about: the inline editor repaints the
 *  panel it is sitting in, the modal closes itself. */
function buildShortcutForm(spec, edit, onDone) {
  const form = node("form", "wg-add wg-shortcut-form");

  const label = node("input", "wg-search-input");
  label.placeholder = "Name";
  label.setAttribute("aria-label", "Site name");
  label.value = edit?.link?.label ?? "";
  const url = node("input", "wg-search-input");
  url.placeholder = "example.com";
  url.setAttribute("aria-label", "Site address");
  url.value = edit?.link?.url ?? "";
  // `type=url` would refuse a bare host, which is exactly what people type.
  url.type = "text";

  const row = node("div", "wg-shortcut-actions");
  const save = node("button", "wg-add-save", edit ? "Save" : "Pin");
  save.type = "submit";
  const cancel = node("button", "wg-add-toggle", "Cancel");
  cancel.type = "button";
  row.append(save, cancel);
  form.append(label, url, row);

  // Only reachable when there is a site to remove, so the button is never a
  // dead end: on a fresh panel the way to have no site is to press Cancel.
  if (edit) {
    const remove = node("button", "wg-add-toggle is-remove", "Remove");
    remove.type = "button";
    remove.addEventListener("click", async () => {
      remove.disabled = true;
      await NEWTAB_SAFE.setWidgetData(spec.id, { links: [] });
      await onDone();
    });
    row.append(remove);
  }

  const status = node("div", "wg-search-status");
  form.append(status);

  cancel.addEventListener("click", () => onDone(true));
  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const raw = url.value.trim();
    if (!raw) {
      status.textContent = "An address is needed.";
      status.className = "wg-search-status is-error";
      return;
    }
    const settings = await NEWTAB_SAFE.get();
    const current = settings.widgets.find((w) => w.id === spec.id)?.data?.links ?? [];
    if (edit) {
      const next = current.map((l, i) => (i === edit.index ? { label: label.value.trim(), url: raw } : l));
      save.disabled = true;
      await NEWTAB_SAFE.setWidgetData(spec.id, { links: next });
      await onDone();
      return;
    }
    if (current.length >= NEWTAB_SAFE.SHORTCUT_MAX) {
      status.textContent = `A panel holds ${NEWTAB_SAFE.SHORTCUT_MAX} sites.`;
      status.className = "wg-search-status is-error";
      return;
    }
    const next = [...current, { label: label.value.trim(), url: raw }];
    save.disabled = true;
    // Written through the settings store, which sanitises the list — an entry
    // it rejects simply does not appear, which is the honest outcome for an
    // address that is not one.
    await NEWTAB_SAFE.setWidgetData(spec.id, { links: next });
    await onDone();
  });

  return { form, focus: () => label.focus() };
}

/** The editor, shown in place of the grid — the `+` tile's and a grid tile's
 *  own right-click, both of which have a panel body to take over. */
function openShortcutEditor(spec, edit = null) {
  const entry = widgetPanels.get(spec.id);
  if (!entry) return;
  const { form, focus } = buildShortcutForm(spec, edit, () => repaintShortcutsWidget(spec));
  const wrap = node("div", "wg-shortcuts");
  wrap.append(form);
  entry.body.replaceChildren(wrap);
  focus();
}

/** The site form as a page-level modal.
 *
 *  The single-icon block cannot host the inline editor: it *is* its tile, so
 *  replacing the body would replace the very thing the user right-clicked, and
 *  the block is 92px — far too narrow for two fields. A centered dialog also
 *  keeps the block at its own size while the form is open, which is what "do not
 *  scale the header, just the box" asks for one level up.
 *
 *  Built on demand and torn down on close rather than kept hidden in the
 *  document: it is opened rarely, and a stray `Escape` handler on a hidden
 *  element is the kind of thing that outlives its usefulness. */
function openShortcutModal(spec, edit = null) {
  const scrim = node("div", "wg-modal-scrim");
  const dialog = node("div", "wg-modal");
  dialog.setAttribute("role", "dialog");
  dialog.setAttribute("aria-modal", "true");
  dialog.setAttribute("aria-label", edit ? "Edit site" : "Add a site");

  const head = node("div", "wg-modal-head");
  head.append(node("span", "wg-modal-title", edit ? "Edit site" : "Add a site"));
  const close = node("button", "wg-modal-close", "×");
  close.type = "button";
  close.setAttribute("aria-label", "Close");
  head.append(close);
  dialog.append(head);

  // The dialog closes and the panel repaints, in that order: the write has
  // already landed by the time `onDone` runs, so the repaint is reading the new
  // list either way, and closing first means the form is gone before the body
  // it was drawn over is replaced.
  const dismiss = () => {
    document.removeEventListener("keydown", onKey, true);
    scrim.remove();
    repaintShortcutsWidget(spec);
  };
  const { form, focus } = buildShortcutForm(spec, edit, dismiss);
  dialog.append(form);

  const onKey = (e) => {
    if (e.key === "Escape") {
      e.preventDefault();
      dismiss();
    }
  };
  // A click on the backdrop closes; a click inside the dialog must not, which is
  // what the identity check is for — the scrim is the dialog's parent, so a
  // click that started inside bubbles up through it.
  scrim.addEventListener("mousedown", (e) => {
    if (e.target === scrim) dismiss();
  });
  close.addEventListener("click", dismiss);
  document.addEventListener("keydown", onKey, true);

  scrim.append(dialog);
  document.body.append(scrim);
  focus();
}

/** Rebuild one shortcuts panel's body from its stored list. Targeted at the one
 *  widget rather than `renderWidgets()`, so pinning a site does not tear down
 *  and re-place every panel on the page. */
async function repaintShortcutsWidget(spec) {
  const entry = widgetPanels.get(spec.id);
  if (!entry) return;
  try {
    entry.body.replaceChildren(await WIDGET_RENDERERS.shortcuts.body(spec));
  } catch {
    entry.body.replaceChildren(node("div", "wg-empty", "Could not draw this panel."));
  }
}

// ── tasks: the local store ────────────────────────────────────────────────
// A small todo store for the no-account path. Records deliberately mirror the
// shapes `api.todos.pages()` / `api.todos.page()` return — same ids, same
// `items[{id,text,done}]`, same counts — so the picker below does not need a
// second renderer for the local case. `shareToken` is null because there is no
// page to share.

/** A list record with the counts the picker and summary read. */
function localTodoSummary(list) {
  const items = Array.isArray(list.items) ? list.items : [];
  return {
    id: list.id,
    title: list.title,
    shareToken: null,
    archived: false,
    totalCount: items.length,
    doneCount: items.filter((i) => i.done).length,
    items,
  };
}

/** Read-modify-write the whole store. `fn` gets the raw lists array and returns
 *  it changed; the callback shape keeps every mutation in one place so a future
 *  field addition cannot leave one writer behind. */
async function updateLocalTodos(fn) {
  const stored = (await readLocalStore(LOCAL_TODOS_KEY)) ?? {};
  const lists = Array.isArray(stored.lists) ? stored.lists : [];
  const next = fn(lists) ?? lists;
  await writeLocalStore(LOCAL_TODOS_KEY, { lists: next });
  return next.map(localTodoSummary);
}

const LOCAL_TODOS = {
  async pages() {
    const stored = (await readLocalStore(LOCAL_TODOS_KEY)) ?? {};
    const lists = Array.isArray(stored.lists) ? stored.lists : [];
    return lists.map(localTodoSummary);
  },

  async page(id) {
    const pages = await this.pages();
    return pages.find((p) => p.id === id) ?? null;
  },

  async create(title) {
    const list = { id: crypto.randomUUID(), title, items: [] };
    await updateLocalTodos((lists) => [...lists, list]);
    return localTodoSummary(list);
  },

  async addItem(listId, text) {
    await updateLocalTodos((lists) =>
      lists.map((l) =>
        l.id === listId ? { ...l, items: [...(l.items ?? []), { id: crypto.randomUUID(), text, done: false }] } : l,
      ),
    );
  },

  async toggleItem(listId, itemId, done) {
    await updateLocalTodos((lists) =>
      lists.map((l) =>
        l.id === listId
          ? { ...l, items: (l.items ?? []).map((i) => (i.id === itemId ? { ...i, done: Boolean(done) } : i)) }
          : l,
      ),
    );
  },

  async removeItem(listId, itemId) {
    await updateLocalTodos((lists) =>
      lists.map((l) => (l.id === listId ? { ...l, items: (l.items ?? []).filter((i) => i.id !== itemId) } : l)),
    );
  },

  async removeList(listId) {
    await updateLocalTodos((lists) => lists.filter((l) => l.id !== listId));
  },
};

/** Which store the tasks widget should read. A session that resolves is the
 *  account path exactly as before; no session — or a read that came back empty
 *  because the session had expired — falls through to the local store. */
async function taskSource() {
  const { signedIn, todoPages } = loadWidgetData();
  if (await signedIn) {
    const read = await todoPages;
    // A signed-in user whose read merely failed is offline, not accountless:
    // showing the local lists there would look like their data vanished. Only a
    // rejected session falls through, which is what `auth` marks.
    if (read?.ok) return { pages: (read.data.pages ?? []).filter((p) => !p.archived), local: false };
    if (!read?.auth) return null;
  }
  return { pages: await LOCAL_TODOS.pages(), local: true };
}

/** The account backend needs the page's share token for every item write —
 *  there is no admin route for items — while the local backend keys on the list
 *  id. This wrapper is what lets the picker's controls stay one implementation. */
function taskBackend(local) {
  if (!local) {
    return {
      page: (id) => NEWTAB_API.todos.page(id),
      addItem: (page, text) => NEWTAB_API.todos.addItem(page.shareToken, text),
      toggleItem: (page, itemId, done) => NEWTAB_API.todos.toggleItem(page.shareToken, itemId, done),
      removeItem: (page, itemId) => NEWTAB_API.todos.removeItem(page.shareToken, itemId),
      canAddList: false,
    };
  }
  return {
    page: async (id) => {
      const page = await LOCAL_TODOS.page(id);
      return page ? { page } : null;
    },
    addItem: (page, text) => LOCAL_TODOS.addItem(page.id, text),
    toggleItem: (page, itemId, done) => LOCAL_TODOS.toggleItem(page.id, itemId, done),
    removeItem: (page, itemId) => LOCAL_TODOS.removeItem(page.id, itemId),
    canAddList: true,
  };
}

function chosenTaskPage(pages, settings) {
  return (
    pages.find((p) => p.id === settings.taskPageId) ??
    pages.find((p) => (p.totalCount ?? 0) - (p.doneCount ?? 0) > 0) ??
    pages[0]
  );
}

async function openTaskDeleteModal(spec) {
  const settings = await NEWTAB_SAFE.get();
  const source = await taskSource();
  if (!source?.local || !source.pages.length) return;
  const page = chosenTaskPage(source.pages, settings);

  const scrim = node("div", "wg-modal-scrim");
  const dialog = node("div", "wg-modal");
  dialog.setAttribute("role", "dialog");
  dialog.setAttribute("aria-modal", "true");
  dialog.setAttribute("aria-label", "Delete list");

  const head = node("div", "wg-modal-head");
  head.append(node("span", "wg-modal-title", "Delete list"));
  const close = node("button", "wg-modal-close", "×");
  close.type = "button";
  close.setAttribute("aria-label", "Close");
  head.append(close);
  dialog.append(head);

  const body = node("div", "wg-task-delete");
  body.append(
    node("p", "wg-task-delete-text", `Delete “${page.title}” and every task in it? This cannot be undone.`),
  );
  const row = node("div", "wg-shortcut-actions");
  const remove = node("button", "wg-add-save wg-task-delete-confirm", "Delete list");
  remove.type = "button";
  const cancel = node("button", "wg-add-toggle", "Cancel");
  cancel.type = "button";
  row.append(remove, cancel);
  body.append(row);
  dialog.append(body);

  const onKey = (e) => {
    if (e.key !== "Escape") return;
    e.preventDefault();
    e.stopPropagation();
    dismiss();
  };
  const dismiss = () => {
    document.removeEventListener("keydown", onKey, true);
    scrim.remove();
  };

  cancel.addEventListener("click", dismiss);
  close.addEventListener("click", dismiss);
  scrim.addEventListener("mousedown", (e) => {
    if (e.target === scrim) dismiss();
  });
  document.addEventListener("keydown", onKey, true);

  remove.addEventListener("click", async () => {
    remove.disabled = true;
    try {
      await LOCAL_TODOS.removeList(page.id);
      if (settings.taskPageId === page.id) await NEWTAB_SAFE.set({ taskPageId: null });
      dismiss();
      refreshWidgetData();
      await repaintTasksWidget(spec);
    } catch {
      remove.disabled = false;
    }
  });

  scrim.append(dialog);
  document.body.append(scrim);
  remove.focus();
}

/** The new-list form as a page-level modal.
 *
 *  Same construction as `openTimerModal` and `openTaskConnectModal`: built on
 *  demand, torn down on close, dismissed by Escape, the ×, or a press on the
 *  backdrop. The one field and the two buttons are the ones the inline form
 *  used, unchanged — what moved is where they are drawn, not what adding a list
 *  does.
 *
 *  A new list is local, so it is only reachable with no session; the entry in
 *  the panel's settings menu (`buildTasksHeaderSettings`) is offered there only
 *  when `taskSource` says the local store is the one in use. */
function openTaskListModal(spec) {
  const scrim = node("div", "wg-modal-scrim");
  const dialog = node("div", "wg-modal");
  dialog.setAttribute("role", "dialog");
  dialog.setAttribute("aria-modal", "true");
  dialog.setAttribute("aria-label", "New list");

  const head = node("div", "wg-modal-head");
  head.append(node("span", "wg-modal-title", "New list"));
  const close = node("button", "wg-modal-close", "×");
  close.type = "button";
  close.setAttribute("aria-label", "Close");
  head.append(close);
  dialog.append(head);

  const form = node("form", "wg-add wg-shortcut-form");
  const input = node("input", "wg-search-input");
  input.placeholder = "List name";
  input.setAttribute("aria-label", "New list name");

  const status = node("div", "wg-search-status");
  const row = node("div", "wg-shortcut-actions");
  const save = node("button", "wg-add-save", "Add list");
  save.type = "submit";
  const cancel = node("button", "wg-add-toggle", "Cancel");
  cancel.type = "button";
  row.append(save, cancel);
  form.append(input, row, status);
  dialog.append(form);

  // Closes first, then reads: the write has already landed by the time `dismiss`
  // runs, so the repaint behind it is reading the new list either way, and
  // taking the dialog away first means the form is gone before the body under
  // it is replaced.
  const dismiss = () => {
    document.removeEventListener("keydown", onKey, true);
    scrim.remove();
  };
  // Escape belongs to the dialog while it is up. Stopped here in the capture
  // phase so `panel.js`'s own document-level Escape listener — which runs in
  // the bubble phase — does not also close the settings panel behind it, the
  // same one-key-two-surfaces guard `openTaskConnectModal` applies.
  const onKey = (e) => {
    if (e.key !== "Escape") return;
    e.preventDefault();
    e.stopPropagation();
    dismiss();
  };

  cancel.addEventListener("click", dismiss);
  close.addEventListener("click", dismiss);
  // A press on the backdrop closes; a press inside the dialog must not, which
  // is what the identity check is for — the scrim is the dialog's parent.
  scrim.addEventListener("mousedown", (e) => {
    if (e.target === scrim) dismiss();
  });
  document.addEventListener("keydown", onKey, true);

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const title = input.value.trim();
    // An empty name leaves the dialog up: there is nothing to write, and a
    // close on a gesture that made nothing reads as a failure.
    if (!title) return;
    // Disabled for the length of the write so a second press cannot create a
    // second list.
    save.disabled = true;
    try {
      const list = await LOCAL_TODOS.create(title);
      // Show the list that was just made: creating one and being left on
      // another would read as the button having done nothing.
      await NEWTAB_SAFE.set({ taskPageId: list.id });
      dismiss();
      refreshWidgetData();
      await repaintTasksWidget(spec);
    } catch (err) {
      status.textContent = err instanceof Error ? err.message : "Could not create the list.";
      save.disabled = false;
    }
  });

  scrim.append(dialog);
  document.body.append(scrim);
  input.focus();
}

// ── tasks: the picker variant ─────────────────────────────────────────────
// The `summary` layout reads the first few lists and shows what is open across
// them. This one is a working surface instead: it shows one chosen list, lets
// items be ticked off, and adds new ones — all without leaving the new tab.

/** The item rows, as a flat list. Shared by the picker and the connected view,
 *  which differ only in which store they write through — both take the same
 *  `{ toggleItem, removeItem }` shape `taskBackend` returns.
 *
 *  `afterChange(kind)` is told which gesture happened, for a caller that
 *  cares: the picker repaints for every one of them now, because the write has
 *  already dropped the stored account list (`api.js` invalidates on every todo
 *  change, a tick included) and the repaint is what turns that into a re-read. */
function buildTaskRows(items, page, store, spec, afterChange) {
  const list = node("div", "wg-list is-flat");
  if (!items.length) list.append(node("div", "wg-empty", "Nothing here yet — add one below."));
  for (const item of items) {
    // The checkbox is a button, not an `<input type=checkbox>`: the whole row is
    // the control, and a real checkbox would need a label association and a
    // second hit target for no gain at this size.
    //
    // The × sits beside the row rather than inside it, because a button inside a
    // button is both invalid markup and two nested click targets.
    const line = node("div", "wg-task-line");
    const row = node("button", item.done ? "wg-task is-done" : "wg-task");
    row.type = "button";
    row.setAttribute("role", "checkbox");
    row.setAttribute("aria-checked", String(Boolean(item.done)));
    row.append(node("span", "wg-check"), node("span", "wg-task-label", item.text));
    row.addEventListener("click", async () => {
      row.disabled = true;
      try {
        await store.toggleItem(page, item.id, !item.done);
        await afterChange("toggle");
      } catch {
        row.disabled = false;
      }
    });
    const remove = node("button", "wg-task-del", "×");
    remove.type = "button";
    remove.title = "Delete task";
    remove.setAttribute("aria-label", "Delete task");
    remove.addEventListener("click", async () => {
      remove.disabled = true;
      try {
        await store.removeItem(page, item.id);
        await afterChange("remove");
      } catch {
        remove.disabled = false;
      }
    });
    line.append(row, remove);
    list.append(line);
  }
  return list;
}

/** The add field under the items. Submitting repaints through `afterChange("add")`,
 *  because a new item changes the counts a list summary carries. */
function buildTaskAddForm(page, store, spec, afterChange) {
  const form = node("form", "wg-task-add");
  const input = node("input", "wg-search-input");
  input.placeholder = "Add a task...";
  input.setAttribute("aria-label", "New task");
  const add = node("button", "wg-add-save", "+");
  add.type = "submit";
  add.setAttribute("aria-label", "Add task");
  form.append(input, add);
  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const text = input.value.trim();
    if (!text) return;
    add.disabled = true;
    try {
      await store.addItem(page, text);
      input.value = "";
      await afterChange("add");
    } catch {
      add.disabled = false;
    }
  });
  return form;
}

/** The full working tasks body: the items and the add field. */
async function renderTaskPicker(pages, settings, spec, local) {
  const store = taskBackend(local);
  const wrap = node("div", "wg-task-picker");

  if (!pages.length) {
    wrap.append(buildTasksEmpty(spec, store.canAddList));
    return wrap;
  }

  const chosen = chosenTaskPage(pages, settings);
  const detail = await store.page(chosen.id).catch(() => null);
  const page = detail?.page ?? null;

  if (!page || (!local && !page.shareToken)) {
    wrap.append(node("div", "wg-empty", "Could not load this list."));
    return wrap;
  }

  // Every one of these writes drops the stored account list in `api.js` — a
  // toggle moves the done count the summary reports just as an add or a delete
  // moves the total — so the repaint here is what re-reads it.
  const afterChange = async () => {
    refreshWidgetData();
    await repaintTasksWidget(spec);
  };
  wrap.append(buildTaskRows(page.items ?? [], page, store, spec, afterChange));
  wrap.append(buildTaskAddForm(page, store, spec, afterChange));
  return wrap;
}

// ── tasks: a panel pointed at a shared list ────────────────────────────────
// One "Open tasks" panel can be connected to a public todo page by its link,
// which makes it a read-write view of that page with no account involved at
// all. The widget keeps whatever it showed before behind its other tab — see
// `buildTaskTabs` — so a connection adds a view rather than replacing one.

/** The same store shape `taskBackend` returns, writing through the public
 *  routes. `page()` cannot fail the way the account's can: the caller has
 *  already fetched the page it renders. `canAddList: false` because creating a
 *  page is not something a share link can do. */
function taskBackendPublic(link, page) {
  return {
    // `page()` is called on repaints, not only on connect, so it re-reads through
    // the stored password — the same one the writes below send. Without it the
    // first write of a locked list would succeed and the repaint would 401 back
    // to a locked screen, which reads as "the edit did not stick".
    //
    // It answers with the page it was handed when that read fails, rather than
    // throwing: every write above already repaints from this value, and a thrown
    // error here would replace a checklist the user is mid-edit on with a stack
    // trace. `renderConnectedTasks` is where a stale password surfaces, on the
    // next full render.
    page: async () => {
      try {
        return { page: (await NEWTAB_API.publicTodos.page(link.token, link.password)).page };
      } catch {
        return { page };
      }
    },
    addItem: (_page, text) => NEWTAB_API.publicTodos.addItem(link.token, text, link.password),
    toggleItem: (_page, itemId, done) => NEWTAB_API.publicTodos.toggleItem(link.token, itemId, done, link.password),
    removeItem: (_page, itemId) => NEWTAB_API.publicTodos.removeItem(link.token, itemId, link.password),
    canAddList: false,
  };
}

/** Why a connection is not showing, in the user's terms. The four cases the
 *  public routes distinguish between are a gone page, a locked one (wrong or
 *  missing password), a write throttle and an unreachable server; the
 *  server's own throttle text is already user-facing, so it is passed through
 *  rather than restated.
 *
 *  A 401 is worded as a *password* problem rather than "not found": the page
 *  exists, and saying "gone" about a list the user just linked from their own
 *  admin panel would be the confusing answer. */
function publicTodoErrorText(err) {
  if (err?.status === 404) return "This list is no longer shared.";
  if (err?.status === 401) return err.message === "Incorrect password"
    ? "Wrong password for this list."
    : "This list needs its password.";
  if (err?.status === 429) return err.message || "Too many edits — wait a minute and try again.";
  return "Could not reach the list.";
}

/** The stored secret belongs to one connection. Disconnecting or relinking a
 *  different address must not leave the previous address's password behind in
 *  the profile for the next list to inherit. */
function forgetTaskPassword(spec) {
  const key = TODO_PASSWORD_KEY;
  if (!spec?.id) return;
  readLocalStore(key).then((store) => {
    if (!store || typeof store !== "object" || !(spec.id in store)) return;
    const next = { ...store };
    delete next[spec.id];
    return writeLocalStore(key, next);
  }).catch(() => {});
}

/** The password this widget's connection was unlocked with, or "". */
async function taskPasswordFor(spec) {
  if (!spec?.id) return "";
  const store = await readLocalStore(TODO_PASSWORD_KEY);
  const value = store && typeof store === "object" ? store[spec.id] : "";
  return typeof value === "string" ? value : "";
}

async function setTaskPassword(spec, password) {
  if (!spec?.id) return;
  const store = (await readLocalStore(TODO_PASSWORD_KEY)) ?? {};
  const next = { ...(store && typeof store === "object" ? store : {}), [spec.id]: password };
  await writeLocalStore(TODO_PASSWORD_KEY, next);
}

/** The connected body: the shared page's items, and an add field that writes
 *  back to it. Repainting re-reads the page, which is what keeps the counts and
 *  the rows in step after every write — there is no cached summary here. */
async function renderConnectedTasks(spec, link) {
  const wrap = node("div", "wg-task-picker");
  // The password is stored per widget id (local, never synced). It is read
  // straight into `link`, which is a local object, so the same value then rides
  // on every read *and* write this render makes through `taskBackendPublic`.
  if (!link.password) link.password = await taskPasswordFor(spec);
  let detail;
  try {
    detail = await NEWTAB_API.publicTodos.page(link.token, link.password);
  } catch (err) {
    if (err?.status === 401) {
      // The unlock prompt belongs to a render the user asked for — opening the
      // panel, switching to its Shared tab, pressing Unlock. `entering` is that
      // signal. A repaint after a write (or any other background refresh) must
      // show the plain error line instead, or a transient 401 mid-edit turns
      // every toggle into a password dialog.
      if (!link.entering) {
        wrap.append(node("div", "wg-empty", publicTodoErrorText(err)));
        return wrap;
      }
      // The prompt's own form reports a wrong password in place; it is never
      // re-opened from here, because a stored bad value in a repaint loop would
      // reopen it forever.
      appendTaskUnlock(spec, link, wrap, err.message === "Incorrect password" ? "That password was not accepted." : null);
      return wrap;
    }
    wrap.append(node("div", "wg-empty", publicTodoErrorText(err)));
    return wrap;
  }
  const page = detail?.page;
  if (!page) {
    wrap.append(node("div", "wg-empty", "Could not load this list."));
    return wrap;
  }
  const store = taskBackendPublic(link, page);
  const afterChange = async () => {
    await repaintTasksWidget(spec);
  };
  wrap.append(buildTaskRows(page.items ?? [], page, store, spec, afterChange));
  wrap.append(buildTaskAddForm(page, store, spec, afterChange));
  return wrap;
}

/** A locked panel: one sentence, one password field, one button. Submits by
 *  re-reading the page with the typed password; only a successful read is
 *  stored, so a typo never shadows a working one. */
function appendTaskUnlock(spec, link, wrap, errorText) {
  wrap.append(node("div", "wg-empty", errorText || "This list is locked. Enter its password."));
  const form = node("form", "wg-add wg-shortcut-form");
  const input = node("input", "wg-search-input");
  input.type = "password";
  input.autocomplete = "off";
  input.maxLength = 200;
  input.placeholder = "List password";
  input.setAttribute("aria-label", "List password");
  input.addEventListener("keydown", (e) => e.stopPropagation());
  const status = node("div", "wg-search-status", "");
  const row = node("div", "wg-shortcut-actions");
  const unlock = node("button", "wg-add-save", "Unlock");
  unlock.type = "submit";
  row.append(unlock);
  form.append(input, row, status);
  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const password = input.value;
    if (!password) {
      status.textContent = "Type the list’s password.";
      status.className = "wg-search-status is-error";
      return;
    }
    unlock.disabled = true;
    try {
      await NEWTAB_API.publicTodos.page(link.token, password);
    } catch (err) {
      unlock.disabled = false;
      status.textContent = err?.status === 401 ? "Incorrect password." : publicTodoErrorText(err);
      status.className = "wg-search-status is-error";
      return;
    }
    await setTaskPassword(spec, password);
    link.password = password;
    await repaintTasksWidget(spec, true);
  });
  wrap.append(form);
}

/** Repaint one tasks panel. `entering` marks a render the user asked for
 *  (opening the panel, switching to its Shared tab, finishing a connect or an
 *  unlock): those are allowed to show the unlock prompt. Writes and background
 *  refreshes leave it off, so a locked list shows an error line rather than a
 *  dialog appearing over the task the user just ticked. */
async function repaintTasksWidget(spec, entering = false) {
  const entry = widgetPanels.get(spec?.id);
  if (!entry) return;
  // The header's chooser is filled from the same read the body makes, so a list
  // created or deleted by a write repaints it along with the rows it changed.
  paintTasksHeaderList(spec, entry.panel?.querySelector(".wg-task-head")).catch(() => {});
  try {
    const body = await WIDGET_RENDERERS.tasks.body(spec, { entering });
    entry.body.replaceChildren(body);
  } catch {
    entry.body.replaceChildren(node("div", "wg-empty", "Sign in from the extension to see this."));
  }
}

// ── timers: the local store ───────────────────────────────────────────────
// The account keeps a timer as a database row so it survives the tab closing.
// The local store has to do the same with nothing but timestamps: a running
// stopwatch records when it last resumed and is summed with the time banked
// before that, and a running countdown records the wall-clock moment it ends.
// Storing a ticking number instead would freeze the moment the page closed and
// quietly lie on the next open.

/** The record `renderTimerStudio` reads, derived from the stored one at `now`.
 *  `anchor` is the wall-clock moment the displayed number is measured from —
 *  the end of a countdown, the resume of a stopwatch — which is what lets the
 *  panel tick the number without re-reading storage every second. `bankedMs` is
 *  the stopwatch time already counted before `anchor`. */
function localTimerView(t, now) {
  // On a break is a pause with a clock on it. The work clock is banked exactly
  // as a mouse-press pause banks it, and the break's own end is a timestamp, so
  // a reload mid-break still knows when to resume.
  const onBreak = t.status === "break";
  if (t.kind === "countdown") {
    const running = t.status === "running";
    const anchor = running ? (t.endsAt ?? now) : now;
    return {
      id: t.id,
      kind: t.kind,
      status: t.status,
      label: t.label,
      elapsedMs: null,
      remainingMs: running ? Math.max(0, anchor - now) : Math.max(0, t.remainingMs ?? 0),
      // The original length, kept so the display can draw "how much of the
      // countdown is left" as a fraction. Records written before this field
      // existed have none, and the ring falls back to an indeterminate sweep.
      durationMs: t.durationMs != null ? Math.max(0, t.durationMs) : null,
      color: t.color ?? null,
      anchor,
      bankedMs: 0,
      // Only a break has one; everything else reports null so the display and
      // the buttons have a single test for "is this a break".
      breakRemainingMs: onBreak ? Math.max(0, (t.breakEndsAt ?? now) - now) : null,
      // The stamp itself, not just its remainder: the display counts down from
      // it between store reads.
      breakEndsAt: onBreak ? (t.breakEndsAt ?? null) : null,
      breakMs: t.breakMs != null ? Math.max(0, t.breakMs) : null,
    };
  }
  const running = t.status === "running";
  const anchor = running ? (t.startedAt ?? now) : now;
  const bankedMs = Math.max(0, t.elapsedMs ?? 0);
  return {
    id: t.id,
    kind: t.kind,
    status: t.status,
    label: t.label,
    elapsedMs: running ? Math.max(0, bankedMs + (now - anchor)) : bankedMs,
    remainingMs: null,
    color: t.color ?? null,
    anchor,
    bankedMs,
    breakRemainingMs: onBreak ? Math.max(0, (t.breakEndsAt ?? now) - now) : null,
    breakEndsAt: onBreak ? (t.breakEndsAt ?? null) : null,
    breakMs: t.breakMs != null ? Math.max(0, t.breakMs) : null,
  };
}

/** The displayed number from a live view, derived at the moment it is painted.
 *  `localTimerView` already settled a paused timer at its banked value; a
 *  running one keeps moving, and this is the one function that says so. */
function timerDisplayMs(t) {
  if (t.status !== "running") return t.kind === "countdown" ? (t.remainingMs ?? 0) : (t.elapsedMs ?? 0);
  if (t.kind === "countdown") return Math.max(0, (t.anchor ?? Date.now()) - Date.now());
  return Math.max(0, (t.bankedMs ?? 0) + (Date.now() - (t.anchor ?? Date.now())));
}

/** One stored timer, in the same shape `.map` writes back. `fn` takes the raw
 *  record; returning null drops it (finish). */
async function updateLocalTimer(id, fn) {
  const stored = (await readLocalStore(LOCAL_TIMERS_KEY)) ?? {};
  const timers = Array.isArray(stored.timers) ? stored.timers : [];
  const next = timers.flatMap((t) => {
    if (t.id !== id) return [t];
    const changed = fn({ ...t });
    return changed ? [changed] : [];
  });
  await writeLocalStore(LOCAL_TIMERS_KEY, { timers: next });
  return next;
}

const LOCAL_TIMERS = {
  async list() {
    const stored = (await readLocalStore(LOCAL_TIMERS_KEY)) ?? {};
    const timers = Array.isArray(stored.timers) ? stored.timers : [];
    const now = Date.now();
    return timers.map((t) => localTimerView(t, now));
  },

  async start(kind, opts = {}) {
    const now = Date.now();
    const durationMs = Math.max(0, Number(opts.durationSeconds) || 0) * 1000;
    const timer =
      kind === "countdown"
        ? {
            id: crypto.randomUUID(),
            kind,
            status: "running",
            label: opts.label || null,
            // Absolute, not a countdown number: this is what lets the reload
            // land on the right remaining time.
            endsAt: now + durationMs,
            remainingMs: durationMs,
            // The original length, so a repaint can draw the ring's fraction
            // without re-deriving it from a start time that may be long gone.
            durationMs,
            color: opts.color || null,
          }
        : {
            id: crypto.randomUUID(),
            kind: "stopwatch",
            status: "running",
            label: opts.label || null,
            startedAt: now,
            elapsedMs: 0,
            color: null,
          };
    const stored = (await readLocalStore(LOCAL_TIMERS_KEY)) ?? {};
    const timers = Array.isArray(stored.timers) ? stored.timers : [];
    await writeLocalStore(LOCAL_TIMERS_KEY, { timers: [...timers, timer] });
    return localTimerView(timer, now);
  },

  async pause(id) {
    const now = Date.now();
    await updateLocalTimer(id, (t) => {
      const view = localTimerView(t, now);
      // The derived number becomes the banked one, and the running anchor goes
      // away, so no time accrues while the timer is paused.
      return t.kind === "countdown"
        ? { ...t, status: "paused", remainingMs: view.remainingMs, endsAt: null }
        : { ...t, status: "paused", elapsedMs: view.elapsedMs, startedAt: null };
    });
  },

  async resume(id) {
    const now = Date.now();
    await updateLocalTimer(id, (t) =>
      t.kind === "countdown"
        ? { ...t, status: "running", endsAt: now + Math.max(0, t.remainingMs ?? 0) }
        : { ...t, status: "running", startedAt: now },
    );
  },

  async finish(id) {
    await updateLocalTimer(id, () => null);
  },

  /** Pause, and put a clock on the pause. `breakMinutes` is the length the
   *  user asked for; the press that ends it early is `endBreak`. */
  async break(id, breakMs) {
    const now = Date.now();
    await updateLocalTimer(id, (t) => {
      const view = localTimerView(t, now);
      const raw = {
        ...t,
        status: "break",
        breakMs,
        breakEndsAt: now + breakMs,
      };
      return t.kind === "countdown"
        ? { ...raw, remainingMs: view.remainingMs, endsAt: null }
        : { ...raw, elapsedMs: view.elapsedMs, startedAt: null };
    });
  },

  /** Come back from a break early. Same resume it would have had on its own. */
  async endBreak(id) {
    const now = Date.now();
    await updateLocalTimer(id, (t) =>
      t.kind === "countdown"
        ? { ...t, status: "running", endsAt: now + Math.max(0, t.remainingMs ?? 0), breakEndsAt: null }
        : { ...t, status: "running", startedAt: now, breakEndsAt: null },
    );
  },
};

// ── timers: label templates ───────────────────────────────────────────────
// The site keeps reusable presets in a `timer_templates` table and the modal's
// "+" writes to the same list when signed in (see `api.js`). With no session
// there is no table to write to, so a small local store stands in — one preset
// is a name and a duration, which is exactly what the modal's fields already
// hold, so the two shapes stay interchangeable.

/** The stored record normalised to the shape the chips read: `{ id, name,
 *  durationSeconds, label, color }`. Tolerant because the account rows and the
 *  local ones must both come out looking the same to the picker. */
function timerTemplateOf(raw) {
  if (!raw || typeof raw !== "object") return null;
  const durationSeconds = Math.max(1, Math.round(Number(raw.durationSeconds)));
  if (!Number.isFinite(durationSeconds)) return null;
  const name = String(raw.name ?? "").trim();
  if (!name) return null;
  return {
    id: typeof raw.id === "string" ? raw.id : `${name}-${durationSeconds}`,
    name: name.slice(0, 120),
    durationSeconds,
    label: raw.label != null ? String(raw.label).trim() || null : null,
    color: typeof raw.color === "string" ? raw.color : "emerald",
  };
}

async function readLocalTimerTemplates() {
  const stored = (await readLocalStore(LOCAL_TIMER_TEMPLATES_KEY)) ?? {};
  const list = Array.isArray(stored.templates) ? stored.templates : [];
  return list.map(timerTemplateOf).filter(Boolean);
}

async function writeLocalTimerTemplate(template) {
  const list = await readLocalTimerTemplates();
  const next = [...list, template];
  await writeLocalStore(LOCAL_TIMER_TEMPLATES_KEY, { templates: next });
  return next;
}

/** Every template the picker should offer, from whichever store the timers
 *  themselves come from. Signed in, that is the account's own list; otherwise
 *  the local one — mirroring `timerSource`, so a profile never mixes presets
 *  from one store with timers from the other. A failed read is an empty list
 *  rather than an error: the modal still works with no presets. */
async function timerTemplateSource(local) {
  if (!local) {
    try {
      const data = await NEWTAB_API.timers.templates();
      return (data.templates ?? []).map(timerTemplateOf).filter(Boolean);
    } catch {
      return [];
    }
  }
  return readLocalTimerTemplates();
}

/** Which store the timers widget should read — the same split as `taskSource`,
 *  including its refusal to swap an offline account onto the local store. */
async function timerSource() {
  const { signedIn, timers } = loadWidgetData();
  if (await signedIn) {
    const read = await timers;
    if (read?.ok) return { list: read.data.timers ?? [], local: false };
    if (!read?.auth) return null;
  }
  return { list: await LOCAL_TIMERS.list(), local: true };
}

/** The controls, addressed either at the account or at the local store. */
function timerBackend(local) {
  return local
    ? {
        start: (kind, opts) => LOCAL_TIMERS.start(kind, opts),
        pause: (id) => LOCAL_TIMERS.pause(id),
        resume: (id) => LOCAL_TIMERS.resume(id),
        finish: (id) => LOCAL_TIMERS.finish(id),
        break: (id, breakMs) => LOCAL_TIMERS.break(id, breakMs),
        endBreak: (id) => LOCAL_TIMERS.endBreak(id),
        saveTemplate: (template) =>
          writeLocalTimerTemplate({ ...template, id: crypto.randomUUID() }),
      }
    : {
        start: (kind, opts) => NEWTAB_API.timers.start(kind, opts),
        pause: (id) => NEWTAB_API.timers.pause(id),
        resume: (id) => NEWTAB_API.timers.resume(id),
        finish: (id) => NEWTAB_API.timers.finish(id, true),
        // The account's break is a row of its own beside a paused parent (see
        // `startBreakForTimer`), so it exists on every device and restarts the
        // work clock by itself. Ending one early is the parent's own resume;
        // the break row is then finished rather than left ticking. The length
        // asked for here is not used: the server's break has its own.
        break: (id) => NEWTAB_API.timers.break(id),
        endBreak: (id) => NEWTAB_API.timers.resume(id),
        saveTemplate: (template) => NEWTAB_API.timers.createTemplate(template),
      };
}

/** The account's break lives in its own row (`isBreak`, `parentId`), apart from
 *  the timer it interrupts — so the parent is still listed while the break runs.
 *  The panel needs it once to tombstone the parent and once to resume it early,
 *  and the list is the only place it can come from. */
const timerBreakParents = new Map();

function timerParentOf(list, t) {
  if (t.local) {
    return t.status === "break" ? t : null;
  }
  const parentId = t.isBreak ? t.parentId : null;
  if (!parentId) return null;
  const parent = list.find((x) => x.id === parentId) ?? timerBreakParents.get(parentId) ?? null;
  if (parent) timerBreakParents.set(parentId, parent);
  return parent;
}

/** The break that has parked a timer, if one has: on the local store it is the
 *  timer's own status, on the account it is a child row in the same list. */
function timerBreakOf(list, t) {
  if (t.local) return t.status === "break" ? t : null;
  return list.find((x) => x.isBreak && x.parentId === t.id) ?? null;
}

/** The break's remaining time. The account's break is a countdown, so its
 *  remaining figure is already the answer; a local break carries its own. */
function timerBreakRemainingMs(t) {
  // Counted from the end stamp rather than read off `breakRemainingMs`: that
  // field is the remainder as of the last store read, so a clock painted from
  // it would show one second for as long as nobody re-read the store. The stamp
  // is the fact, and it is what lets a break tick down and then expire alone.
  if (t.local) return Math.max(0, (t.breakEndsAt ?? 0) - Date.now());
  return t.remainingMs ?? 0;
}

/** Kept in memory only: the local store's break length is remembered so the
 *  next break is the length the last one was, without a setting to manage. */
let timerBreakMs = 5 * 60 * 1000;

// ── timers: the controls variant ──────────────────────────────────────────
// The `list` layout shows what is running. This one also starts things: a
// stopwatch or a countdown, with pause/resume and finish on each row. With a
// session the timer lives in a database row rather than in this page (see
// `api.js`), so it keeps running after the tab closes and shows the same
// elapsed time on the site. Without one it lives in `LOCAL_TIMERS_KEY` instead,
// which survives the reload for the same reason and needs no account.

const TIMER_LABELS = ["work", "break", "study", "build"];

// A local timer's number is recomputed rather than fetched, so a tick is cheap;
// one second matches the resolution `formatElapsed` draws.
const LOCAL_TIMER_TICK_MS = 1000;

// Teardown for whatever timers a body started — an interval or a
// `requestAnimationFrame` loop. A repaint is a fresh call with no memory of what
// it drew last time, so the old body's clocks have to be stopped here or they
// keep writing to discarded nodes. Held as thunks rather than as one kind of
// handle because the two layouts schedule their updates differently.
//
// Keyed by widget id rather than one global set: the timers kind may be placed
// more than once, and a repaint of one panel must stop only *its* previous
// body's clocks — a single set would let a second panel's render silence the
// first panel's ticks.
const timerPanelTicks = new Map();

/** Stop every clock one panel's previous body started. Safe to call before
 *  anything has been scheduled or for an id that has none. */
function stopTimerTicks(spec) {
  const id = spec?.id;
  const stops = timerPanelTicks.get(id);
  if (!stops) return;
  for (const stop of stops) stop();
  timerPanelTicks.delete(id);
}

/** Register one stop thunk against a panel, so the next repaint of that panel
 *  can clear it. */
function addTimerTick(spec, stop) {
  const id = spec?.id;
  if (!timerPanelTicks.has(id)) timerPanelTicks.set(id, new Set());
  timerPanelTicks.get(id).add(stop);
}

// `createElement` alone makes HTML elements, which cannot be an SVG at all —
// the ring would silently not render. The prefix keeps it clear of tools.js's
// own `svgEl`, which lives in the same shared lexical scope.
const WG_SVG_NS = "http://www.w3.org/2000/svg";

function wgSvg(tag, attrs) {
  const el = document.createElementNS(WG_SVG_NS, tag);
  for (const [k, v] of Object.entries(attrs)) el.setAttribute(k, v);
  return el;
}

/** Start the new-timer dialog from a fresh read of which store to use.
 *
 *  Split out of the header button so the empty state can offer the same action:
 *  the decision is "account or local", it has to be made one click later (the
 *  timer read may not have finished when the panel is built), and both entry
 *  points must make it the same way. */
async function openNewTimer(spec) {
  const { local } = (await timerSource()) ?? { local: true };
  openTimerModal(spec, timerBackend(local), local);
}

/** The timers panel's header "+" — the way a timer is started now that the
 *  full-width button has left the body.
 *
 *  It resolves the store itself rather than taking a `backend` the way the
 *  inline button did: the header is built by `buildWidget` for every widget
 *  kind at page-render time, and a header that carried a backend would need the
 *  timer read to have finished before the panel could be drawn at all. */
function buildTimersHeaderAdd(spec) {
  const add = node("button", "wg-head-add", "+");
  add.type = "button";
  add.title = "New timer";
  add.setAttribute("aria-label", "New timer");
  add.addEventListener("click", () => openNewTimer(spec));
  // The header is the drag handle; this is a control inside it, not part of the
  // grip. Stopped here so the press cannot start a drag.
  add.addEventListener("pointerdown", (e) => e.stopPropagation());
  return add;
}

/** The tasks panel's settings glyph.
 *
 *  It replaces a "+ New list" pill, which offered exactly one of the things a
 *  tasks panel needs told: it creates a list, and it went away entirely for a
 *  signed-in account — leaving that panel with no way to be renamed or to be
 *  pointed at a shared list from the header at all. The gear opens one menu
 *  that holds those three answers together: the panel's own name, which list it
 *  draws, and — locally, where a list can still be made without the site — a
 *  new one. Header settings for a widget that has settings.
 *
 *  The menu is the panel's right-click menu. That is where rename, connect,
 *  disconnect and every other per-instance setting already live, and a second
 *  copy built for the gear would be two lists to keep in step. Opening it at the
 *  pointer puts it beside the button that was pressed, which is where a menu is
 *  expected to appear anyway. */
function openTaskListMenu(spec, anchor, pages, chosen, at) {
  closeWidgetMenu();
  const menu = node("div", "wg-menu");
  for (const p of pages) {
    const b = node("button", "wg-menu-item");
    b.type = "button";
    b.append(
      node("span", "wg-menu-mark", p.id === chosen.id ? "●" : ""),
      node("span", "wg-menu-item-label", p.title),
    );
    b.addEventListener("click", async () => {
      closeWidgetMenu();
      if (p.id === chosen.id) return;
      await NEWTAB_SAFE.set({ taskPageId: p.id });
      await repaintTasksWidget(spec);
    });
    menu.append(b);
  }
  mountWidgetMenu(menu, at, anchor);
}

function buildTasksHeaderList(spec) {
  const wrap = node("div", "wg-task-head");
  wrap.addEventListener("pointerdown", (e) => e.stopPropagation());
  paintTasksHeaderList(spec, wrap).catch(() => {});
  return wrap;
}

async function paintTasksHeaderList(spec, wrap) {
  if (!wrap) return;
  wrap.replaceChildren();
  const settings = await NEWTAB_SAFE.get();
  const link = NEWTAB_SAFE.todoLinkOf(settings.widgets.find((w) => w.id === spec?.id)?.data);
  if (link && link.tab !== "own") return;
  const source = await taskSource();
  if (!source) return;
  if (!source.local && NEWTAB_SAFE.widgetVariantFor(settings, spec?.id) !== "picker") return;
  const pages = source.pages;
  if (pages.length < 2) return;

  const chosen = chosenTaskPage(pages, settings);
  const button = node("button", "wg-task-head-list");
  button.type = "button";
  button.title = `List: ${chosen.title}`;
  button.setAttribute("aria-haspopup", "menu");
  button.setAttribute("aria-label", `Choose a list, showing ${chosen.title}`);
  button.append(
    node("span", "wg-task-head-name", chosen.title),
    node("span", "wg-task-head-caret", "▾"),
  );
  button.addEventListener("click", (e) => {
    e.stopPropagation();
    if (widgetMenuNode && menuAnchor === button) {
      closeWidgetMenu();
      return;
    }
    const rect = button.getBoundingClientRect();
    openTaskListMenu(spec, button, pages, chosen, { x: rect.left, y: rect.bottom + 4 });
  });
  wrap.append(button);
}

function buildTasksHeaderSettings(spec) {
  const gear = node("button", "wg-head-gear");
  gear.type = "button";
  gear.title = "Widget settings";
  gear.setAttribute("aria-label", `${NEWTAB_SAFE.widgetLabelOf(spec)} settings`);
  gear.setAttribute("aria-haspopup", "menu");
  // The page gear's own drawing, at the header's size: the same mark for the
  // same idea, so the panel's settings read as settings and no new icon
  // language has to be learned. A span rather than the outer `<svg>` element
  // `newtab.html` writes, because `innerHTML` on a span is parsed as its
  // children wherever the parser mode, while on an svg it would not be.
  gear.append(node("span", "wg-gear-glyph"));
  gear.lastChild.innerHTML =
    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="square" aria-hidden="true">' +
    '<circle cx="12" cy="12" r="3.2" />' +
    '<path d="M12 2.6v3M12 18.4v3M2.6 12h3M18.4 12h3M5.4 5.4l2.1 2.1M16.5 16.5l2.1 2.1M18.6 5.4l-2.1 2.1M7.5 16.5l-2.1 2.1" />' +
    "</svg>";
  // The header is the drag handle, so a press on the gear must not start a drag
  // of the panel — the same guard every other header control carries.
  gear.addEventListener("pointerdown", (e) => e.stopPropagation());
  gear.addEventListener("click", (e) => {
    e.stopPropagation();
    // The menu takes a pointer event for placement. A click carries the same
    // coordinates, and the interface only reads them, so the click itself is
    // passed through rather than a synthesised event that could be mistaken
    // for one a real pointer produced.
    openWidgetMenu(e, spec, { onlyTasksSettings: true, anchor: gear });
  });
  return gear;
}

/** The bookmarks panel's own header controls: a filter for the list and the way
 *  to add a bookmark.
 *
 *  Both live in the header rather than in the body because they belong to the
 *  widget, not to whichever layout it is wearing — "Folders" is the shipped
 *  layout, and reaching either one meant switching the body to "Search & add".
 *  The filter opens *over* the body when pressed, so the list underneath keeps
 *  its layout and its folder folds.
 *
 *  The "+" opens the panel's existing add form (`buildBookmarkAddForm`), which
 *  is drawn in the body: it writes through the same route every other way of
 *  adding a bookmark uses, and it knows where to scroll itself into view. */
function buildBookmarksHeaderTools(spec) {
  const wrap = node("div", "wg-head-tools");

  const searchBtn = node("button", "wg-head-add", "⌕");
  searchBtn.type = "button";
  searchBtn.title = "Search bookmarks";
  searchBtn.setAttribute("aria-label", "Search bookmarks");
  searchBtn.addEventListener("pointerdown", (e) => e.stopPropagation());
  searchBtn.addEventListener("click", (e) => {
    e.stopPropagation();
    toggleBookmarkFilter(spec);
  });
  wrap.append(searchBtn);

  const addBtn = node("button", "wg-head-add", "+");
  addBtn.type = "button";
  addBtn.title = "New bookmark";
  addBtn.setAttribute("aria-label", "New bookmark");
  addBtn.addEventListener("pointerdown", (e) => e.stopPropagation());
  addBtn.addEventListener("click", (e) => {
    e.stopPropagation();
    openBookmarkAddForm(spec);
  });
  wrap.append(addBtn);
  return wrap;
}

/** The filter field, as a strip over the panel body.
 *
 *  One field per panel, kept in `bookmarkFilters` so that closing and reopening
 *  the filter comes back to what was typed rather than to everything. The field
 *  filters the rows the body already holds — the whole list is in hand, so this
 *  is a `hidden` toggle per row rather than a repaint, which keeps folder folds
 *  and scroll position exactly where the user left them. */
const bookmarkFilters = new Map();

function toggleBookmarkFilter(spec) {
  const panel = document.querySelector(`.wg[data-id="${CSS.escape(spec.id)}"]`);
  if (!panel) return;
  const existing = panel.querySelector(".wg-bm-filter");
  if (existing) {
    closeBookmarkFilter(panel);
    return;
  }
  const strip = node("div", "wg-bm-filter");
  const input = node("input", "wg-search-input");
  input.type = "search";
  input.placeholder = "filter bookmarks...";
  input.setAttribute("aria-label", "Filter bookmarks");
  input.value = bookmarkFilters.get(spec.id) ?? "";
  strip.append(input);
  panel.querySelector(".wg-body")?.prepend(strip);
  const apply = () => {
    bookmarkFilters.set(spec.id, input.value);
    applyBookmarkFilter(panel, input.value);
  };
  input.addEventListener("input", apply);
  input.addEventListener("keydown", (e) => {
    if (e.key === "Escape") {
      e.preventDefault();
      e.stopPropagation();
      closeBookmarkFilter(panel);
    }
  });
  input.addEventListener("pointerdown", (e) => e.stopPropagation());
  panel.classList.add("is-filtering");
  apply();
  input.focus();
  input.select();
}

function closeBookmarkFilter(panel) {
  panel.querySelector(".wg-bm-filter")?.remove();
  panel.classList.remove("is-filtering");
  for (const el of panel.querySelectorAll(".wg-bm-row")) el.hidden = false;
  for (const el of panel.querySelectorAll(".wg-bm-group")) el.hidden = false;
  for (const el of panel.querySelectorAll(".wg-bm-empty-match")) el.remove();
}

/** Hide the rows that do not match, and the folders they have all emptied out
 *  of. The search layout draws its own list and filters it as it paints, so
 *  this applies to the row kinds that are already in the DOM only. */
function applyBookmarkFilter(panel, raw) {
  const q = String(raw ?? "").trim().toLowerCase();
  for (const el of panel.querySelectorAll(".wg-bm-row")) el.hidden = false;
  // Groups are unhidden here as well as hidden below: the hide path folds away
  // a group every one of whose rows missed, so clearing the query has to lift
  // those back. `closeBookmarkFilter` resets both too — the two paths agree.
  for (const el of panel.querySelectorAll(".wg-bm .wg-bm-group")) el.hidden = false;
  for (const el of panel.querySelectorAll(".wg-bm-empty-match")) el.remove();
  if (!q) return;

  const rows = [...panel.querySelectorAll(".wg-bm .wg-bm-row")];
  let shown = 0;
  for (const row of rows) {
    // The row's own text is its title, folder and address as drawn; matching it
    // is the same test the body's text invites the eye to make.
    const hit = row.textContent.toLowerCase().includes(q);
    row.closest(".wg-bm-row, .wg-row") && (row.closest(".wg-bm-row, .wg-row").hidden = !hit);
    if (hit) shown += 1;
  }
  for (const group of panel.querySelectorAll(".wg-bm .wg-bm-group")) {
    const visible = [...group.querySelectorAll(".wg-bm-row")].some((r) => !r.hidden);
    group.hidden = !visible;
  }
  if (!shown) {
    const miss = node("div", "wg-empty wg-bm-empty-match", "Nothing matches.");
    panel.querySelector(".wg-bm")?.append(miss);
  }
}

/** Open the bookmarks panel's add form, from a header "+". */
function openBookmarkAddForm(spec) {
  const panel = document.querySelector(`.wg[data-id="${CSS.escape(spec.id)}"]`);
  const toggle = panel?.querySelector(".wg-add-toggle");
  const form = panel?.querySelector(".wg-add");
  if (!form) return;
  // The body's own toggle is the switch; pressing it from the header is the
  // same switch, so the two cannot disagree about whether the form is open.
  if (toggle) {
    if (form.classList.contains("is-hidden")) toggle.click();
    form.querySelector("input")?.focus();
    form.scrollIntoView({ block: "nearest", behavior: "smooth" });
    return;
  }
  form.classList.remove("is-hidden");
  form.querySelector("input")?.focus();
  form.scrollIntoView({ block: "nearest", behavior: "smooth" });
}

/** The running timers as a toggle of their controls: one row per timer, its
 *  pause/resume and finish buttons, and the time still moving under them.
 *
 *  This is the same body the "Controls" layout draws (`renderTimerStudio`), not
 *  a second one — a timer paused from here and a timer paused from the row list
 *  are the same write to the same store, and two implementations of that would
 *  only be two places for it to drift.
 *
 *  Per timer, then, not per panel: a display layout has room in the body for
 *  numbers, and the buttons are asked for one timer at a time. */
function openTimerControls(spec, t, local) {
  const scrim = node("div", "wg-modal-scrim");
  const dialog = node("div", "wg-modal wg-timer-controls");
  dialog.setAttribute("role", "dialog");
  dialog.setAttribute("aria-modal", "true");
  dialog.setAttribute("aria-label", "Timer controls");

  const head = node("div", "wg-modal-head");
  const title = node("div", "wg-modal-title", t.label || (t.kind === "countdown" ? "Countdown" : "Stopwatch"));
  const close = node("button", "wg-modal-close", "×");
  close.type = "button";
  close.title = "Close";
  close.setAttribute("aria-label", "Close");
  head.append(title, close);
  dialog.append(head);

  const body = node("div", "wg-modal-body");
  dialog.append(body);
  scrim.append(dialog);
  document.body.append(scrim);

  // The row draws its own clock and its own buttons; the only thing this
  // wrapper adds is the dismissal, and a repaint after a press. The row is
  // rebuilt after every write rather than patched, because "running" and
  // "paused" change the button glyph and its label together.
  // The dialog's own re-paint runs on the same beat the panel's clocks do, so
  // pressing pause looks instant rather than waiting out a whole second. The
  // row is rebuilt from the store each time — nothing here patches a previous
  // row, so a rebuild cannot inherit a stale status. `paint` takes no row from
  // the one it replaces: it re-reads the store, so a press that wrote through
  // `refreshWidgetData` already has its new state in hand.
  // The account's break is a row of its own, not a status on this one, so the
  // dialog asks for both: the timer, for its pause/finish row, and the break,
  // for the second hand it needs while the timer is parked.
  // The row this dialog was opened for, kept from the click: the panel that
  // handed it over knows the store it read from, and a fresh `timerSource()` can
  // disagree (an account read that briefly fails, or a timer finished in another
  // tab) and leave the dialog with no subject at all. The live row replaces this
  // whenever one is found; this is what keeps the dialog drawable when not.
  const seed = { ...t, local };
  const readList = async () => {
    const source = await timerSource();
    if (!source) return [seed];
    const list = source.list.map((x) => ({ ...x, local: source.local }));
    const mine = list.filter((x) => x.id === t.id || (x.isBreak && x.parentId === t.id));
    return mine.length ? mine : [seed];
  };
  const paint = async () => {
    const locale = NEWTAB_SAFE.widgetLocaleFor(await NEWTAB_SAFE.get(), spec.id);
    const wrap = node("div", "wg-timer-studio is-modal");
    const list = await readList();
    const parent = list.find((x) => x.id === t.id);
    const brk = list.find((x) => x.isBreak);
    // On a break the account lists the break row instead of the timer when it
    // polls; the parent is what the row's numbers come from, so it is the one
    // drawn, with the break's clock riding on it.
    const subject = parent ?? (brk ? timerBreakParents.get(brk.parentId) : null) ?? t;
    const view = brk ? { ...subject, status: "break", isBreak: false, local, breakEndsAt: null } : { ...subject, local };
    wrap.append(renderTimerStudio([view], spec, local, locale, brk ? { breakRow: brk } : undefined));
    body.replaceChildren(wrap);
    // The row holds the break clock, and the panel behind this dialog has the
    // same break in its own body. Something has to write the resume when that
    // clock reaches zero, and the panel's watcher is inside a body that a
    // finished break has no way to redraw itself from — so the row is told not
    // to, and the dialog's watcher is the one that does it.
  };

  const dismiss = () => {
    clearInterval(reflow);
    document.removeEventListener("keydown", onKey, true);
    scrim.remove();
    // The panel's body was left behind while this was open; painting it now
    // means the bars behind the dialog agree with what was just done to them.
    repaintTimersWidget(spec);
  };
  const onKey = (e) => {
    if (e.key === "Escape") {
      e.preventDefault();
      e.stopPropagation();
      dismiss();
    }
  };
  close.addEventListener("click", dismiss);
  scrim.addEventListener("mousedown", (e) => {
    if (e.target === scrim) dismiss();
  });
  document.addEventListener("keydown", onKey, true);

  // The row's own action buttons call `refreshWidgetData` and then repaint the
  // widget body they belong to — which is this dialog's, not the panel's. One
  // second later this reads the store again, so the dialog never shows the
  // state a write just replaced.
  // The dialog's own re-paint runs on the same beat the panel's clocks do, so
  // pressing pause looks instant rather than waiting out a whole second. The
  // row is rebuilt from the store each time — nothing here patches a previous
  // row, so a rebuild cannot inherit a stale status.
  let reflow = 0;
  reflow = setInterval(async () => {
    if (!scrim.isConnected) {
      clearInterval(reflow);
      return;
    }
    refreshWidgetData();
    await paint();
  }, LOCAL_TIMER_TICK_MS);

  paint();
  return body;
}

/** Nothing running: the line, and the way to make something run.
 *
 *  The header "+" is a 16px glyph in the corner; on an otherwise empty panel
 *  that is the only thing to press and the easiest to miss, because a blank box
 *  reads as "there is nothing here" rather than "there is nothing here *yet*".
 *  The empty state is centred in the body and carries its own labelled button,
 *  so the first thing to do is where the eye already is.
 *
 *  This doubles as the settings panel's miniature, where the whole preview is
 *  `pointer-events: none` — the button stays inert there like every other
 *  control in the picture, so the row's switch is still the only hit target. */
function buildTimersEmpty(spec) {
  const wrap = node("div", "wg-timers-empty");
  wrap.append(node("div", "wg-timers-empty-line", "No timers running."));

  const add = node("button", "wg-timers-empty-add");
  add.type = "button";
  add.title = "New timer";
  add.append(node("span", "wg-timers-empty-plus", "+"), node("span", null, "Add new timer"));
  add.addEventListener("click", (e) => {
    e.stopPropagation();
    openNewTimer(spec);
  });
  wrap.append(add);
  return wrap;
}

function buildTasksEmpty(spec, canAddList) {
  const wrap = node("div", "wg-tasks-empty");
  wrap.append(node("div", "wg-tasks-empty-line", "No lists yet."));
  if (!canAddList) return wrap;

  const add = node("button", "wg-tasks-empty-add");
  add.type = "button";
  add.title = "New list";
  add.append(node("span", "wg-tasks-empty-plus", "+"), node("span", null, "Create your first list"));
  add.addEventListener("click", (e) => {
    e.stopPropagation();
    openTaskListModal(spec);
  });
  wrap.append(add);
  return wrap;
}

/** The full controls body: the running timers with per-row actions. */
/** End every break whose clock has run out, without a press.
 *
 *  A local break is a timestamp in the store, so the page has to be the one that
 *  watches it: the panel repaints a second after the break ends, and a reload
 *  mid-break is handled by `localTimerView` treating an expired break as over.
 *  Called from the panel's own repaint and from its tick, so the break ends on
 *  the same beat the number reaches zero whether the tab was open the whole
 *  time or just came back to it.
 *
 *  Returns true when something was resumed, so the caller knows to redraw. */
async function endExpiredLocalBreaks(spec) {
  const source = await timerSource().catch(() => null);
  if (!source?.local) return false;
  const due = source.list.filter((t) => t.status === "break" && timerBreakRemainingMs(t) === 0);
  if (!due.length) return false;
  for (const t of due) await LOCAL_TIMERS.endBreak(t.id);
  refreshWidgetData();
  return true;
}

/** Watch a local timer's break and resume it when it runs out.
 *
 *  A one-second beat rather than one long `setTimeout` for the remaining time:
 *  a break can be ten minutes, and a timer armed that far out is at the mercy
 *  of the browser's own throttling — the tab backgrounded, the machine loaded,
 *  the clock nudged. Checking the store instead means the resume happens on the
 *  first beat after the break is really over, whatever the reason the long
 *  timer would have been late. The beat itself is registered with the panel's
 *  ticks, so a repaint or a closed page leaves nothing watching.
 *
 *  Local only: an account break is a countdown row, which the server finishes
 *  (and so resumes the parent) on its own next read. */
function watchLocalBreak(t, spec) {
  // Assigned before the first beat: `beat` clears `interval` when the break is
  // already over, and a `const` would still be in its temporal dead zone for
  // that first call.
  let interval = 0;
  const beat = () => {
    if (timerBreakRemainingMs(t) > 0) return;
    clearInterval(interval);
    endExpiredLocalBreaks(spec).then((moved) => {
      if (moved) repaintTimersWidget(spec);
    });
  };
  interval = setInterval(beat, LOCAL_TIMER_TICK_MS);
  addTimerTick(spec, () => clearInterval(interval));
  beat();
}

function renderTimerStudio(list, spec, local, locale, opts = {}) {
  const backend = timerBackend(local);
  // This body replaces whatever was drawn before, so the clocks behind the old
  // one's numbers go with it — none of those nodes are on the page any more.
  stopTimerTicks(spec);
  const wrap = node("div", "wg-timer-studio");
  const status = node("div", "wg-search-status is-hidden");

  if (!list.length) {
    wrap.append(buildTimersEmpty(spec));
    return wrap;
  }

  // The break is drawn as this row's clock rather than as a row of its own, so
  // the timer it parked keeps one row and the buttons that end the break are
  // beside the number being counted.
  const onBreak = list.some((x) => x.status === "break" || x.isBreak) || !!opts.breakRow;
  const breakClockMs = () => {
    const brk = opts.breakRow;
    return brk ? (brk.kind === "countdown" ? Math.max(0, brk.remainingMs ?? 0) : 0) : timerBreakRemainingMs(list[0]);
  };

  // The rows are wired to the store they were read from, said once on each row
  // rather than left to whatever `local` says: a row that came from the local
  // store must write there even if the account read succeeds a second later.
  const rows = node("div", "wg-list is-flat");
  for (const t of list) {
    const row = node("div", "wg-timer-row");
    row.style.setProperty("--dot", t.color ? `var(--wg-c-${t.color}, var(--accent))` : "var(--accent)");
    if (onBreak) row.classList.add("is-break");

    const head = node("div", "wg-timer-head");
    head.append(node("span", "wg-row-dot"));
    const stack = node("div", "wg-row-stack");
    const name = t.label || (t.kind === "countdown" ? "Countdown" : "Stopwatch");
    stack.append(node("div", "wg-row-title", onBreak ? "On a break" : name));
    const clock = node("div", "wg-row-sub", onBreak ? formatElapsed(breakClockMs(), locale) : formatElapsed(local ? timerDisplayMs(t) : t.kind === "countdown" ? (t.remainingMs ?? 0) : (t.elapsedMs ?? 0), locale));
    if (onBreak) stack.append(node("div", "wg-row-sub wg-break-name", name));
    stack.append(clock);
    if (onBreak) {
      const tick = () => {
        clock.textContent = formatElapsed(breakClockMs(), locale);
        if (breakClockMs() > 0) return;
        clearInterval(interval);
        // The clock reaching zero is not the end of a local break on its own:
        // the store still says "break" until someone writes the resume. The
        // manual body has no ring or bar behind it to be that something, so it
        // writes the resume itself and redraws the row it is drawing in.
        if (!local || opts.breakRow) return;
        const timer = list[0];
        if (timer.status !== "break") return;
        LOCAL_TIMERS.endBreak(timer.id).then(() => {
          refreshWidgetData();
          // The row that watched this is in the dialog, and the panel behind it
          // still shows a break: ask the panel to redraw, so closing the dialog
          // does not land on a row counting down a break that is already over.
          paint();
          const live = liveBodyOf(spec);
          if (live) repaintTimersWidget(spec, live);
        });
      };
      const interval = setInterval(tick, LOCAL_TIMER_TICK_MS);
      addTimerTick(spec, () => clearInterval(interval));
      tick();
      // The dialog and the panel both watch the same break; whichever is on
      // screen is the one that resumes it, and the other has already gone by
      // then or never drew.
      if (local && !opts.breakRow) watchLocalBreak(list[0], spec);
    }
    // A local timer has no server tick to report progress, so the panel keeps
    // its own clock. Only the newest body's ticks may run: the set is cleared at
    // the top of `renderTimerStudio`, because a repaint replaces these nodes and
    // an interval left behind would keep writing to a discarded one.
    if (local && t.status === "running") {
      const tick = () => {
        clock.textContent = formatElapsed(timerDisplayMs(t), locale);
        if (t.kind === "countdown" && timerDisplayMs(t) === 0) clearInterval(interval);
      };
      const interval = setInterval(tick, LOCAL_TIMER_TICK_MS);
      addTimerTick(spec, () => clearInterval(interval));
      // The first paint may be mid-second; correcting it now means the number
      // never starts life a fraction behind the wall clock.
      tick();
    }
    head.append(stack);
    row.append(head);

    const actions = node("div", "wg-timer-actions");
    // Paused state comes off the row's own `status`: a timer that is paused
    // keeps its elapsed time but stops accruing from `startedAt`, and both
    // backends report that as `"paused"` rather than by zeroing a field.
    const paused = t.status === "paused";
    const run = (fn) => async () => {
      try {
        await fn();
        refreshWidgetData();
        await repaintTimersWidget(spec);
      } catch (err) {
        status.textContent = err instanceof Error ? err.message : "Could not update the timer.";
        status.classList.remove("is-hidden");
      }
    };
    if (onBreak) {
      // One button while the break runs: coming back now is the same resume the
      // break would have done on its own when its clock ran out.
      const back = node("button", "wg-timer-btn is-break", "▸ Resume now");
      back.type = "button";
      back.title = "End the break and resume";
      back.setAttribute("aria-label", "End break and resume timer");
      back.addEventListener("click", run(() => backend.endBreak(opts.breakRow?.parentId ?? t.id)));
      const stopBreak = node("button", "wg-timer-btn is-stop", "■");
      stopBreak.type = "button";
      stopBreak.title = local ? "Finish" : "Finish and save";
      stopBreak.setAttribute("aria-label", "Finish timer");
      stopBreak.addEventListener("click", run(() => backend.finish(t.id)));
      actions.append(back, stopBreak);
      row.append(actions);
      rows.append(row);
      continue;
    }

    const pause = node("button", "wg-timer-btn", paused ? "▸" : "❚❚");
    pause.type = "button";
    pause.title = paused ? "Resume" : "Pause";
    pause.setAttribute("aria-label", paused ? "Resume timer" : "Pause timer");
    pause.addEventListener("click", run(() => (paused ? backend.resume(t.id) : backend.pause(t.id))));

    const stop = node("button", "wg-timer-btn is-stop", "■");
    stop.type = "button";
    stop.title = local ? "Finish" : "Finish and save";
    stop.setAttribute("aria-label", "Finish timer");
    stop.addEventListener("click", run(() => backend.finish(t.id)));

    // A break is a pause with a length, so it sits beside pause and only when
    // there is something worth pausing — a running clock.
    const brk = node("button", "wg-timer-btn is-break", "☕ Break");
    brk.type = "button";
    brk.title = `Pause for a break (${Math.round(timerBreakMs / 60000)} min), then resume by itself`;
    brk.setAttribute("aria-label", "Take a break");
    brk.disabled = t.status !== "running";
    brk.addEventListener("click", run(() => backend.break(t.id, timerBreakMs)));

    actions.append(pause, brk, stop);
    row.append(actions);
    rows.append(row);
  }
  // How long the next break is. Kept in memory for the session, next to the
  // button it feeds, rather than as a stored setting: a break length is a
  // passing choice, not a preference worth a settings page.
  if (!onBreak) {
    const len = node("label", "wg-break-len");
    const input = node("input", "wg-break-input");
    input.type = "number";
    input.min = "1";
    input.max = "120";
    input.value = String(Math.round(timerBreakMs / 60000));
    input.setAttribute("aria-label", "Break length in minutes");
    const settle = () => {
      const n = Math.floor(Number(input.value));
      const mins = Math.min(120, Math.max(1, Number.isFinite(n) ? n : 5));
      timerBreakMs = mins * 60000;
      input.value = String(mins);
    };
    settle();
    input.addEventListener("change", settle);
    input.addEventListener("blur", settle);
    len.append(input, node("span", "wg-break-len-sub", "min break"));
    wrap.append(len);
  }
  wrap.append(rows, status);
  return wrap;
}

// ── timers: the display layout ────────────────────────────────────────────
// What is running, drawn rather than listed: one timer gets a centred ring
// (the site's own progress-ring language — faint track, round-capped arc that
// drains as a countdown runs), and several get a row of thin horizontal bars.
// This is the shipped layout; `renderTimerStudio` above is the opt-in one that
// adds pause/finish buttons per row.

/** The ring's geometry, matching the site's `ProgressRing`
 *  (app/admin/timer/page.tsx:117) and the popup's `createRing`: radius inset by
 *  half the thickness so the sweep fills the box, and a start at twelve o'clock
 *  (the SVG is rotated in CSS, as the site's `-rotate-90` does). */
const TIMER_RING_SIZE = 128;
const TIMER_RING_THICKNESS = 8;

/** How much of a timer is still to run, as 0..1, or `null` when there is no
 *  total to divide by. A countdown has one — `durationMs`, or the account's
 *  `durationSeconds`. A stopwatch has none, and `null` means "draw an
 *  indeterminate sweep rather than a fraction that would be a lie". */
function timerProgressFraction(t, local) {
  const totalMs =
    t.kind === "countdown"
      ? local
        ? (t.durationMs ?? null)
        : (t.durationSeconds != null ? t.durationSeconds * 1000 : null)
      : null;
  if (!totalMs || totalMs <= 0) return null;
  const remaining = t.kind === "countdown" ? (local ? timerDisplayMs(t) : (t.remainingMs ?? 0)) : 0;
  return Math.min(1, Math.max(0, remaining / totalMs));
}

/** One timer as a ring with its time at the centre. Stopped (paused or settled)
 *  timers draw the fraction they hold and no animation; a running stopwatch
 *  spins a short arc so it reads as moving even with nothing to count against. */
function buildTimerRing(t, local, spec, locale) {
  const r = (TIMER_RING_SIZE - TIMER_RING_THICKNESS) / 2;
  const circumference = 2 * Math.PI * r;
  const common = {
    cx: TIMER_RING_SIZE / 2,
    cy: TIMER_RING_SIZE / 2,
    r,
    fill: "none",
    "stroke-width": TIMER_RING_THICKNESS,
  };
  // No `width`/`height` attributes, and a viewBox instead: the CSS box is the
  // ring's size in every context (a full-size widget, the panel's 62%
  // miniature, a scaled widget), and the drawing follows it. Fixed pixels here
  // made the miniatures draw the full-size ring inside a smaller card.
  const svg = wgSvg("svg", {
    viewBox: `0 0 ${TIMER_RING_SIZE} ${TIMER_RING_SIZE}`,
    class: "wg-ring-svg",
  });
  svg.append(wgSvg("circle", { ...common, stroke: "rgba(205, 196, 186, 0.08)", class: "wg-ring-track" }));
  const arc = wgSvg("circle", {
    ...common,
    stroke: "currentColor",
    "stroke-linecap": "round",
    "stroke-dasharray": circumference,
    "stroke-dashoffset": 0,
    class: "wg-ring-arc",
  });
  svg.append(arc);

  const clock = node("div", "wg-ring-clock");
  const face = node("div", "wg-ring-face");
  const title = node("div", "wg-ring-title", t.label || (t.kind === "countdown" ? "Countdown" : "Stopwatch"));
  face.append(clock, title);
  const wrap = node("div", "wg-ring");
  // A break is not the timer paused for no reason: the ring says which it is,
  // because a number counting down under the timer's own name would read as the
  // timer still running.
  const onBreak = Boolean(t.status === "break" || t.isBreak);
  wrap.classList.toggle("is-break", onBreak);
  if (onBreak) title.textContent = "On a break";
  wrap.style.setProperty("--dot", t.color ? `var(--wg-c-${t.color}, var(--accent))` : "var(--accent)");
  wrap.append(svg, face);
  // A single running timer has no bar row to press, so the ring itself is the
  // surface: the same dialog, the same buttons, reached from the number.
  const action = node("button", "wg-ring-action");
  action.type = "button";
  action.title = "Pause, resume or finish";
  action.setAttribute("aria-label", `${t.label || (t.kind === "countdown" ? "Countdown" : "Stopwatch")} controls`);
  action.addEventListener("click", (e) => {
    e.stopPropagation();
    openTimerControls(spec, t, local);
  });
  action.addEventListener("pointerdown", (e) => e.stopPropagation());
  wrap.append(action);

  const running = t.status === "running";
  let raf = 0;
  let start = 0;

  const paint = () => {
    const ms = onBreak
      ? timerBreakRemainingMs(t)
      : local
        ? timerDisplayMs(t)
        : t.kind === "countdown"
          ? (t.remainingMs ?? 0)
          : (t.elapsedMs ?? 0);
    clock.textContent = formatElapsed(ms, locale);
    // On a break the ring fills as the break runs down: a pause that only
    // showed a number would look identical to one that never ends.
    if (onBreak) {
      const total = t.local ? (t.breakMs ?? ms) : (t.durationSeconds ? t.durationSeconds * 1000 : null);
      const fraction = total ? Math.min(1, Math.max(0, ms / total)) : 1;
      arc.setAttribute("stroke-dashoffset", String(circumference * (1 - fraction)));
      return;
    }
    const fraction = timerProgressFraction(t, local);
    if (fraction != null) {
      arc.setAttribute("stroke-dashoffset", String(circumference * (1 - fraction)));
      return;
    }
    // No total: a countdown with no recorded length, or a stopwatch. A running
    // one sweeps a fixed quarter-arc round the track so the ring reads as live.
    if (running) {
      const spin = ((Date.now() - start) / 4000) % 1;
      arc.setAttribute("stroke-dasharray", String(circumference * 0.25));
      arc.setAttribute("stroke-dashoffset", String(-circumference * spin));
    } else {
      arc.setAttribute("stroke-dasharray", String(circumference));
      arc.setAttribute("stroke-dashoffset", String(circumference));
    }
  };

  paint();
  // A break's number moves every second whatever the store: on the account it
  // is a countdown, and its remaining time is counted here rather than waited
  // for, so the panel never shows a frozen break.
  if (onBreak) {
    let ended = false;
    const tick = () => {
      paint();
      if (ended || timerBreakRemainingMs(t) > 0) return;
      ended = true;
      // The watcher may not be the one that saw this: a repaint can rebuild the
      // body without it, and a long break would then sit at 0s. The ring knows
      // its own wrapper and the wrapper its panel, so the end is written and the
      // body redrawn from here as well.
      if (local) {
        LOCAL_TIMERS.endBreak(t.id).then(() => {
          refreshWidgetData();
          const holder = wrap.closest(".wg-body");
          if (holder) repaintTimersWidget(spec, holder);
        });
      }
    };
    const interval = setInterval(tick, LOCAL_TIMER_TICK_MS);
    addTimerTick(spec, () => clearInterval(interval));
    if (local) watchLocalBreak(t, spec);
    return wrap;
  }
  if (running) {
    // The indeterminate sweep wants more frames than a second, so it rides a
    // `requestAnimationFrame` loop; a fraction that only changes once a second
    // can afford the cheap interval, and a *local* fraction is the only one the
    // page can advance itself — an account timer's remaining time arrives on
    // the next poll, so ticking it here would redraw the same number.
    if (timerProgressFraction(t, local) == null) {
      start = Date.now();
      const loop = () => {
        paint();
        raf = requestAnimationFrame(loop);
      };
      raf = requestAnimationFrame(loop);
      addTimerTick(spec, () => cancelAnimationFrame(raf));
    } else if (local) {
      const interval = setInterval(paint, LOCAL_TIMER_TICK_MS);
      addTimerTick(spec, () => clearInterval(interval));
    }
  }
  return wrap;
}

/** One timer as a horizontal bar: its name and time on a line, a track under
 *  it, and a fill that drains (countdown) or grows (stopwatch) as it runs. The
 *  countdown's fill carries the same `stroke-dashoffset` transition the site's
 *  ring uses, so the drain reads as continuous between ticks. */
function buildTimerBar(t, local, spec, locale) {
  const row = node("div", "wg-bar");
  row.style.setProperty("--dot", t.color ? `var(--wg-c-${t.color}, var(--accent))` : "var(--accent)");

  // `Boolean`: a record with no `isBreak` at all gives `undefined`, and a
  // class toggle of a falsy-but-not-false value still writes the class.
  const onBreak = Boolean(t.status === "break" || t.isBreak);
  row.classList.toggle("is-break", onBreak);
  const head = node("div", "wg-bar-head");
  head.append(
    node("span", "wg-row-dot"),
    node("span", "wg-bar-title", onBreak ? "On a break" : t.label || (t.kind === "countdown" ? "Countdown" : "Stopwatch")),
  );
  const clock = node("div", "wg-bar-time", "");
  head.append(clock);

  const track = node("div", "wg-bar-track");
  const fill = node("div", "wg-bar-fill");
  track.append(fill);
  row.append(head, track);
  // The row is the way into its own controls: pause, resume and finish all
  // live behind one press rather than as three permanent buttons on a bar thin
  // enough that they would outweigh the time they act on.
  const action = node("button", "wg-bar-action");
  action.type = "button";
  action.title = "Pause, resume or finish";
  action.setAttribute("aria-label", `${t.label || (t.kind === "countdown" ? "Countdown" : "Stopwatch")} controls`);
  action.addEventListener("click", (e) => {
    e.stopPropagation();
    openTimerControls(spec, t, local);
  });
  // The panel's own press starts a drag; this row is a control inside it, and
  // a press here must reach the button rather than grab the panel.
  action.addEventListener("pointerdown", (e) => e.stopPropagation());
  row.append(action);

  const paint = () => {
    const ms = onBreak
      ? timerBreakRemainingMs(t)
      : local
        ? timerDisplayMs(t)
        : t.kind === "countdown"
          ? (t.remainingMs ?? 0)
          : (t.elapsedMs ?? 0);
    clock.textContent = formatElapsed(ms, locale);
    if (onBreak) {
      const total = t.local ? (t.breakMs ?? ms) : (t.durationSeconds ? t.durationSeconds * 1000 : null);
      fill.style.setProperty("--wg-bar-fraction", String(total ? Math.min(1, Math.max(0, ms / total)) : 1));
      return;
    }
    const fraction = timerProgressFraction(t, local);
    // A countdown drains towards empty, so its fill *is* the fraction. A
    // stopwatch has no end, so it fills against the longest-running of its
    // peers (see the caller) — the caller sets `--wg-bar-fraction` for it.
    if (fraction != null) fill.style.setProperty("--wg-bar-fraction", String(fraction));
  };

  paint();
  if (onBreak) {
    let ended = false;
    const tick = () => {
      paint();
      if (ended || timerBreakRemainingMs(t) > 0) return;
      ended = true;
      // The watcher may not be the one that saw this: a repaint can rebuild the
      // body without it, and a long break would then sit at 0s. The row knows
      // its own stack, and the stack knows its own panel, so the end is written
      // and the body redrawn from here as well.
      if (local) {
        LOCAL_TIMERS.endBreak(t.id).then(() => {
          refreshWidgetData();
          // Redrawn from the store, but only as far as the page goes: the
          // dialog's row sits inside `.wg-modal-body`, and a panel's stack is a
          // different container. Replacing the stack this row found would
          // redraw the panel from inside a dialog that is covering it.
          const holder = row.closest(".wg-body");
          if (holder) repaintTimersWidget(spec, holder);
          else if (row.closest(".wg-modal-body")) paint();
        });
      }
    };
    const interval = setInterval(tick, LOCAL_TIMER_TICK_MS);
    addTimerTick(spec, () => clearInterval(interval));
    if (local) watchLocalBreak(t, spec);
    return row;
  }
  if (t.status === "running" && local && timerProgressFraction(t, local) != null) {
    const interval = setInterval(paint, LOCAL_TIMER_TICK_MS);
    addTimerTick(spec, () => clearInterval(interval));
  }
  return row;
}

/** The display body for one or more timers: a single ring when exactly one is
 *  running, a stack of bars when there is more than one. Empty shows the
 *  centred empty state, so the panel is never a blank box with nothing to
 *  press. */
function renderTimersPanel(list, spec, local, locale) {
  if (!list.length) {
    const wrap = node("div", "wg-timer-single is-empty");
    wrap.append(buildTimersEmpty(spec));
    return wrap;
  }
  // An account break is a row of its own beside the paused timer it interrupts
  // (`isBreak`/`parentId`). The row is the one drawn; the timer it came from is
  // not, or the panel would show the same clock twice, once resumed.
  const shown = list.filter((t) => !(t.isBreak && list.some((x) => x.id === t.parentId)));
  // The number draws the timer; the buttons that act on it live in the
  // header (see `buildTimersHeaderActions`). The display layout is what most
  // profiles keep, so pausing had to stop being a reason to switch to the
  // row list: the panel you are looking at is the one you want to stop.
  if (shown.length === 1) {
    const wrap = node("div", "wg-timer-single");
    wrap.dataset.timersPanel = spec.id;
    wrap.append(buildTimerRing(shown[0], local, spec, locale));
    return wrap;
  }
  const wrap = node("div", "wg-timer-bars");
  // Which panel this stack belongs to, so any row inside it that has to redraw
  // the whole body can name its own panel without being handed it twice.
  wrap.dataset.timersPanel = spec.id;
  // A stopwatch has no total to fill against, so all the bars are scaled to the
  // longest elapsed time among them — every row then shares one meaning for
  // "full", which is the running one. The longest is the latest to finish.
  const stopwatchElapsed = shown
    .filter((t) => t.kind !== "countdown")
    .map((t) => (local ? timerDisplayMs(t) : (t.elapsedMs ?? 0)));
  const longestStopwatch = stopwatchElapsed.length ? Math.max(...stopwatchElapsed, 1) : 1;
  for (const t of shown) {
    const bar = buildTimerBar(t, local, spec, locale);
    if (t.kind !== "countdown") {
      const elapsed = local ? timerDisplayMs(t) : (t.elapsedMs ?? 0);
      bar.querySelector(".wg-bar-fill").style.setProperty("--wg-bar-fraction", String(Math.min(1, elapsed / longestStopwatch)));
    }
    wrap.append(bar);
  }
  return wrap;
}

/** The new-timer form as a page-level modal.
 *
 *  Same construction as `openShortcutModal`: built on demand, torn down on
 *  close, dismissed by Escape, the ×, or a press on the backdrop. The form's
 *  own fields are the ones the inline form used, unchanged — what moved is
 *  where they are drawn, not what starting a timer does.
 *
 *  `backend` is passed in rather than resolved here because the caller already
 *  decided between the account and the local store, and that decision must not
 *  be made twice: a timer started from the account's rows has to land in the
 *  account, and one started with no session has to land in the local store.
 *  `local` is the same decision, carried alongside because the template chips
 *  must read the *same* store the timers come from — a signed-in profile reads
 *  the account's presets, a signed-out one the local list. */
function openTimerModal(spec, backend, local) {
  const scrim = node("div", "wg-modal-scrim");
  const dialog = node("div", "wg-modal");
  dialog.setAttribute("role", "dialog");
  dialog.setAttribute("aria-modal", "true");
  dialog.setAttribute("aria-label", "New timer");

  const head = node("div", "wg-modal-head");
  head.append(node("span", "wg-modal-title", "New timer"));
  const close = node("button", "wg-modal-close", "×");
  close.type = "button";
  close.setAttribute("aria-label", "Close");
  head.append(close);
  dialog.append(head);

  // The form wears the modal's own form class rather than `.wg-timer-start`:
  // that one is a five-in-a-row flex for a 268px panel, and inside a 300px
  // dialog the fields want to stack instead. `.wg-shortcut-form` is the modal's
  // established stack, so nothing new is introduced for it.
  const form = node("form", "wg-add wg-shortcut-form");
  // The duration fields carry `min`/`max` for the spinner and the mobile
  // keypad, but the browser's own constraint validation would *refuse* the
  // submit on an out-of-range value — and a refused submit drops the timer with
  // no message at all. `clampField` is the actual gate, so validation is turned
  // off here and the numbers get settled rather than rejected.
  form.noValidate = true;

  // ── the label, and its "+" ──────────────────────────────────────────────
  // The field and a small "+" sit on one line. The "+" saves whatever is typed
  // as a reusable template — the same presets the site's timer page manages
  // (see `timerTemplateSource`), so a name the user reaches for often is one
  // click rather than retyping it every time.
  const labelRow = node("div", "wg-label-row");
  const label = node("input", "wg-search-input");
  label.placeholder = "Label (optional)";
  label.setAttribute("aria-label", "Timer label");
  label.setAttribute("list", "wg-timer-labels");

  const save = node("button", "wg-tpl-save", "+");
  save.type = "button";
  save.title = "Save this label and duration as a template";
  save.setAttribute("aria-label", "Save as template");
  labelRow.append(label, save);

  const datalist = node("datalist");
  datalist.id = "wg-timer-labels";
  for (const name of TIMER_LABELS) {
    const opt = node("option");
    opt.value = name;
    datalist.append(opt);
  }

  // ── the countdown length: hours, minutes, seconds ───────────────────────
  // Three fields rather than one minutes box. A countdown is often shorter than
  // a minute (a plank, a pause) and occasionally longer than the old 600-minute
  // ceiling allowed, and one box could express neither without arithmetic in the
  // user's head. Only meaningful for a countdown, so the whole row is hidden for
  // a stopwatch — a field that does nothing is worse than one that is not there.
  const duration = node("div", "wg-duration");
  const durationField = (value, max, aria) => {
    const input = node("input", "wg-search-input wg-duration-input");
    input.type = "number";
    input.min = "0";
    input.max = String(max);
    input.value = String(value);
    input.setAttribute("aria-label", aria);
    return input;
  };
  const hours = durationField(0, 99, "Countdown hours");
  const mins = durationField(25, 59, "Countdown minutes");
  const secs = durationField(0, 59, "Countdown seconds");
  const durationCell = (input, text) => {
    const cell = node("label", "wg-duration-cell");
    cell.append(input, node("span", "wg-duration-unit", text));
    return cell;
  };
  duration.append(durationCell(hours, "h"), durationCell(mins, "m"), durationCell(secs, "s"));

  /** Clamp one field to its own bounds on the way out, so a typed "70" in the
   *  seconds box settles to 59 rather than producing a number no clock shows. */
  const clampField = (input, max) => {
    const n = Math.floor(Number(input.value));
    return Math.min(max, Math.max(0, Number.isFinite(n) ? n : 0));
  };
  /** Settle a field in place as it loses focus, so the box shows the number the
   *  form will actually use. The submit path clamps again regardless — this is
   *  only so the visible value and the saved one never disagree. */
  const settle = (input, max) => () => {
    input.value = String(clampField(input, max));
  };
  hours.addEventListener("blur", settle(hours, 99));
  mins.addEventListener("blur", settle(mins, 59));
  secs.addEventListener("blur", settle(secs, 59));
  /** The three fields as one total, in seconds. Capped at the account route's
   *  own ceiling (86 400 s, a full day) so a 30-hour entry cannot become a
   *  request the server rejects outright. */
  const readDurationSeconds = () => {
    const total = clampField(hours, 99) * 3600 + clampField(mins, 59) * 60 + clampField(secs, 59);
    return Math.min(86_400, total);
  };
  const writeDurationSeconds = (total) => {
    const safe = Math.min(86_400, Math.max(0, Math.floor(total)));
    hours.value = String(Math.floor(safe / 3600));
    mins.value = String(Math.floor((safe % 3600) / 60));
    secs.value = String(safe % 60);
  };

  const kind = node("select", "wg-task-select");
  kind.setAttribute("aria-label", "Timer kind");
  for (const [value, text] of [
    ["stopwatch", "Stopwatch"],
    ["countdown", "Countdown"],
  ]) {
    const opt = node("option", null, text);
    opt.value = value;
    kind.append(opt);
  }

  const paintDuration = () => duration.classList.toggle("is-hidden", kind.value !== "countdown");
  kind.addEventListener("change", paintDuration);
  paintDuration();

  // ── the template chips ──────────────────────────────────────────────────
  // A row of the saved presets. Empty until the source answers, and hidden
  // outright when there are none, so an empty row never reads as a broken one.
  const templates = node("div", "wg-tpl-row is-hidden");
  const paintTemplates = async () => {
    let list = [];
    try {
      list = await timerTemplateSource(local);
    } catch {
      list = [];
    }
    templates.replaceChildren();
    if (!list.length) {
      templates.classList.add("is-hidden");
      return;
    }
    for (const tpl of list) {
      const chip = node("button", "wg-tpl-chip");
      chip.type = "button";
      chip.title = `Load “${tpl.name}” — ${formatElapsed(tpl.durationSeconds * 1000)}`;
      chip.append(node("span", "wg-tpl-name", tpl.name), node("span", "wg-tpl-time", formatElapsed(tpl.durationSeconds * 1000)));
      chip.addEventListener("click", () => {
        kind.value = "countdown";
        paintDuration();
        label.value = tpl.label || tpl.name;
        writeDurationSeconds(tpl.durationSeconds);
      });
      templates.append(chip);
    }
    templates.classList.remove("is-hidden");
  };

  const status = node("div", "wg-search-status");
  const row = node("div", "wg-shortcut-actions");
  const start = node("button", "wg-add-save", "Start");
  start.type = "submit";
  const cancel = node("button", "wg-add-toggle", "Cancel");
  cancel.type = "button";
  row.append(start, cancel);
  form.append(labelRow, datalist, kind, duration, templates, row, status);
  dialog.append(form);
  paintTemplates();

  // Closes first, then reads: the write has already landed by the time `dismiss`
  // runs, so the repaint behind it is reading the new list either way, and
  // taking the dialog away first means the form is gone before the body under
  // it is replaced.
  const dismiss = () => {
    document.removeEventListener("keydown", onKey, true);
    scrim.remove();
  };
  const onKey = (e) => {
    if (e.key === "Escape") {
      e.preventDefault();
      dismiss();
    }
  };

  cancel.addEventListener("click", dismiss);
  close.addEventListener("click", dismiss);
  scrim.addEventListener("mousedown", (e) => {
    if (e.target === scrim) dismiss();
  });
  document.addEventListener("keydown", onKey, true);

  // The "+": persist the current label and duration as a reusable preset. It
  // stays open (unlike Start) because saving a template is not the reason the
  // dialog was opened, and closing on save would make the user reopen it to
  // start the very timer the template was for.
  save.addEventListener("click", async () => {
    const name = label.value.trim();
    const durationSeconds = readDurationSeconds();
    status.textContent = "";
    if (!name) {
      status.textContent = "Give it a label first — the label names the template.";
      return;
    }
    if (!durationSeconds) {
      status.textContent = "Set a duration before saving a template.";
      return;
    }
    save.disabled = true;
    try {
      await backend.saveTemplate({
        name,
        durationSeconds,
        label: name,
        color: "emerald",
      });
      await paintTemplates();
    } catch (err) {
      status.textContent = err instanceof Error ? err.message : "Could not save the template.";
    } finally {
      save.disabled = false;
    }
  });

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    start.disabled = true;
    status.textContent = "";
    try {
      const opts = { label: label.value.trim() };
      if (kind.value === "countdown") {
        opts.durationSeconds = readDurationSeconds();
      }
      await backend.start(kind.value, opts);
      dismiss();
      // The cached list is now stale, and the panel behind the dialog has to
      // show the new row — the same refresh-then-repaint the row actions use.
      refreshWidgetData();
      await repaintTimersWidget(spec);
    } catch (err) {
      status.textContent = err instanceof Error ? err.message : "Could not start the timer.";
    } finally {
      start.disabled = false;
    }
  });

  scrim.append(dialog);
  document.body.append(scrim);
  label.focus();
}

async function repaintTimersWidget(spec, body) {
  const entry = widgetPanels.get(spec?.id);
  if (!entry) return;
  // The panels map is written before the body has been drawn into, and a widget
  // removed from the page keeps its entry. Painting into either would replace
  // nothing on screen, so the element that is still on the page is found by
  // walking up from whatever this panel drew last.
  const live = body ?? liveBodyOf(spec);
  if (!live) return;
  try {
    const fresh = await WIDGET_RENDERERS.timers.body(spec);
    live.replaceChildren(fresh);
    widgetPanels.set(spec.id, { panel: live.closest(".wg") ?? live, body: live });
  } catch {
    live.replaceChildren(node("div", "wg-empty", "Sign in from the extension to see this."));
  }
}

/** The timers body for a panel that is actually on the page, found by asking
 *  each candidate's own element whether it is connected.
 *
 *  `widgetPanels` cannot answer this alone: it is written at build time, before
 *  the body has been filled and before the panel has been appended, and a
 *  widget hidden or removed since then leaves its entry behind. The first body
 *  is remembered on the panel element itself, and a repaint hangs the next one
 *  there, so the chain never points at a discarded node. */
// The panel is the only element that outlives every body drawn into it.
const TIMERS_PANEL_BODY = "__wgTimersBody";

function liveBodyOf(spec) {
  const entry = widgetPanels.get(spec?.id);
  const remembered = entry?.panel?.[TIMERS_PANEL_BODY];
  for (const body of [remembered, entry?.body]) {
    if (body && body.isConnected) return body;
  }
  return null;
}

// ── the context menu ──────────────────────────────────────────────────────
// Right-clicking a widget's header opens a small menu of the things that act on
// the widget itself. The dismissal idiom is the popup's `rowMenu` (tools.js):
// fixed-positioned on `<body>` rather than inside the panel, so a panel that
// scrolls or is rebuilt cannot clip or orphan it — and dismissed on pointerdown-
// capture, Escape, and scroll-capture.
//
// Two things are different here, and both come from the page this runs on.
//
//   * The menu is closed at the *start* of every handler below, not after it.
//     Every action either re-renders the page (`applySettings`, which rebuilds
//     all the panels) or removes the panel the menu belongs to, and a menu left
//     open across that would be a floating list pointing at a widget that no
//     longer exists.
//   * Escape has to stop propagating. `panel.js` has a document-level Escape
//     handler that closes the settings panel unconditionally, so letting the
//     event bubble would dismiss the menu *and* the panel behind it — a
//     right-click-then-Escape would look like it closed something unrelated.

let widgetMenuNode = null;
/** The control that opened the menu, when a control did rather than a press on
 *  the panel. Held so the menu can say "open" on it and stop saying it when the
 *  menu goes. The right-click leaves this null. */
let menuAnchor = null;

/** The open rename field's cancel, or null. Set for as long as a Rename row is
 *  being edited in the menu, so `onWidgetMenuKey` can tell Escape-means-cancel
 *  from Escape-means-close — the form lives inside the menu, so closing on that
 *  Escape would take the field away with it. */
let widgetRenameCancel = null;

function closeWidgetMenu() {
  // Silent when nothing is open, so this is safe to call unconditionally — but
  // it is not a no-op on the anchor: a panel that was rebuilt while its menu was
  // up takes the gear it marked with it, and the next menu must not inherit it.
  menuAnchor?.removeAttribute("aria-expanded");
  menuAnchor = null;
  if (!widgetMenuNode) return;
  widgetMenuNode.remove();
  widgetMenuNode = null;
  widgetRenameCancel = null;
  document.removeEventListener("pointerdown", onWidgetMenuOutside, true);
  document.removeEventListener("keydown", onWidgetMenuKey, true);
  window.removeEventListener("scroll", closeWidgetMenu, true);
}

function onWidgetMenuOutside(e) {
  if (!widgetMenuNode) return;
  if (widgetMenuNode.contains(e.target)) return;
  // A press on the control that opened the menu is not "outside": that control
  // owns the toggle, and closing here would take the menu away before its own
  // click could decide whether the press meant open or close.
  if (menuAnchor && menuAnchor.contains(e.target)) return;
  closeWidgetMenu();
}

function onWidgetMenuKey(e) {
  if (e.key !== "Escape") return;
  // Stopped here so `panel.js`'s own Escape handler does not also run and close
  // the settings panel. Only while a menu is open — see the note above.
  e.stopPropagation();
  // This runs in the capture phase, so it is reached before the rename field
  // inside the menu ever sees the key — which is why the field does not carry
  // its own Escape listener. While one is open, Escape backs out of the field
  // and leaves the menu in place, the same one-step-back the site editor's own
  // Escape gives. Only when there is no field does Escape dismiss the menu.
  if (widgetRenameCancel) {
    widgetRenameCancel();
    return;
  }
  closeWidgetMenu();
}

/** Open the context menu for one widget at the pointer.
 *
 *  A second right-click on the same widget closes rather than reopens, which
 *  matches the popup's `rowMenu` and makes the gesture a toggle. */
function openWidgetMenu(event, spec, options = {}) {
  // The tasks header's gear opens a menu about the panel's *settings* — its
  // name and which list it draws — not the full right-click list. `onlyTasks` is
  // read by `widgetMenuItems` to leave the layout, font, width, hide and remove
  // entries to the right-click that already offers them.
  const onlyTasks = options.onlyTasksSettings === true;
  // Pressing the gesture that opened the open menu closes it, which is what a
  // second right-click means. The gear is a button *inside* the panel, so a
  // press on it while the menu is up is a press on the menu — a second click on
  // the same fixed point would land on it and close the menu it had just
  // opened. It always re-opens instead.
  const wasOpen = widgetMenuNode != null;
  closeWidgetMenu();
  if (wasOpen && !onlyTasks) return;

  // The button that asked for this menu, when one did. Only the tasks gear
  // passes it: the menu is fixed and the gear scrolls with nothing, so the gear
  // is what says "open" while the menu is up — and it is also why this menu may
  // open while another was already showing (see above).
  const anchor = options.anchor ?? null;

  const menu = node("div", "wg-menu");
  if (onlyTasks) menu.append(node("div", "wg-menu-head", NEWTAB_SAFE.widgetLabelOf(spec)));
  for (const item of widgetMenuItems(spec, { onlyTasksSettings: onlyTasks })) {
    if (item.kind === "separator") {
      menu.append(node("div", "wg-menu-sep"));
      continue;
    }
    // A row that opens a submenu is not a button: pressing it would do nothing,
    // and a `<button>` there would also swallow the keyboard focus the real
    // items need. It is a plain row inside a wrapper that owns the submenu, so
    // hovering either the row or the panel keeps the pair open.
    if (item.submenu) {
      const wrap = node("div", "wg-submenu-wrap");
      const head = node("div", "wg-menu-item has-sub");
      head.append(node("span", "wg-menu-item-label", item.label));
      if (item.value) head.append(node("span", "wg-menu-value", item.value));
      head.append(node("span", "wg-menu-caret", "▸"));
      wrap.append(head, buildSubmenu(item.submenu));
      menu.append(wrap);
      continue;
    }
    // A slider row: a caption and a draggable track, in the menu itself rather
    // than behind a submenu of fixed steps. The steps are still offered below it
    // for anyone who wants one of four known widths, but a width is a continuum
    // — the point of the control is landing on the one that fits *this* set of
    // tiles, and four options did not always contain it.
    if (item.kind === "slider") {
      const row = node("div", "wg-menu-slider");
      const head = node("div", "wg-menu-slider-head");
      head.append(node("span", "wg-menu-item-label", item.label));
      const readout = node("span", "wg-menu-value", item.format(item.value));
      head.append(readout);
      const input = node("input", "wg-menu-range");
      input.type = "range";
      input.min = String(item.min);
      input.max = String(item.max);
      input.step = String(item.step ?? 1);
      input.value = String(item.value);
      input.setAttribute("aria-label", item.label);
      // Live, on `input`: the panel behind the menu follows the thumb, so the
      // width is chosen by looking at it rather than by committing and
      // re-opening. `onInput` is the cheap visual write; `onCommit` on `change`
      // is the one that goes to storage.
      input.addEventListener("input", () => {
        readout.textContent = item.format(Number(input.value));
        item.onInput(Number(input.value));
      });
      input.addEventListener("change", () => item.onCommit(Number(input.value)));
      // The menu's own dismissal handlers listen on `pointerdown` capture and
      // would read a press on the track as a click outside. The track is inside
      // the menu, but it is a child of a menu that closes on any press that is
      // not on a button — so the press is stopped here.
      input.addEventListener("mousedown", (e) => e.stopPropagation());
      input.addEventListener("click", (e) => e.stopPropagation());
      row.append(head, input);
      menu.append(row);
      continue;
    }
    // A row that edits in place: pressing it does not close the menu, it
    // *becomes* the field. The row is swapped for the form rather than a form
    // being hung beside it, so the menu keeps its height and the field lands
    // where the eye already was. `widgetRenameCancel` is the menu's memory that
    // one is open, which is what turns Escape into "cancel" for as long as it
    // lasts — see `onWidgetMenuKey`.
    if (item.form) {
      const row = node("button", "wg-menu-item");
      row.type = "button";
      row.append(node("span", "wg-menu-item-label", item.label));
      // A field row that already holds a value says what it holds, the way the
      // submenu rows do — otherwise "City" in a menu is a question with no
      // answer on screen beside it.
      if (item.value) row.append(node("span", "wg-menu-value", item.value));
      row.addEventListener("click", () => {
        // The form's Save repaints and thereby closes the menu; Cancel and
        // Escape return the row. Both route through `restore`, which is also
        // what clears the menu's "a field is open" flag. `restore` only ever
        // runs after `form` is initialised — it is wired to a later click or
        // keypress — so reading it inside the closure is safe.
        const restore = () => {
          widgetRenameCancel = null;
          form.replaceWith(row);
          row.focus();
        };
        const { form, focus } = item.form(restore);
        widgetRenameCancel = restore;
        row.replaceWith(form);
        // The field is a little taller than the row it replaced, so a menu that
        // was sitting against the bottom edge would now hang off it. The same
        // clamp the menu was placed with is re-run against the pointer this menu
        // belongs to — `event` is still in scope from `openWidgetMenu`.
        const height = menu.offsetHeight;
        const top = Math.min(Math.max(6, event.clientY), Math.max(6, window.innerHeight - height - 6));
        menu.style.top = `${top}px`;
        focus();
      });
      menu.append(row);
      continue;
    }
    const b = node("button", item.danger ? "wg-menu-item is-danger" : "wg-menu-item");
    b.type = "button";
    // The tick is a real child of the label rather than part of its text, so a
    // checked row at rest is just a row — the marker does not shift the label
    // every time the state changes.
    if (item.kind === "check" || item.kind === "radio") {
      b.append(node("span", "wg-menu-mark", item.checked ? (item.kind === "radio" ? "●" : "✓") : ""));
    }
    b.append(node("span", "wg-menu-item-label", item.label));
    b.addEventListener("click", (e) => {
      // Closed before the action, never after: the action may remove this menu's
      // own anchor from the document. See the block comment above.
      closeWidgetMenu();
      // The event goes with it. "Move" arms a gesture that follows the pointer,
      // and this click is the only thing that knows where the pointer was when
      // the user asked for it — without it the panel would not sit under the
      // cursor until the first move. `closeWidgetMenu` has already detached the
      // button, but the event object outlives its target.
      item.onSelect(e);
    });
    menu.append(b);
  }
  mountWidgetMenu(menu, { x: event.clientX, y: event.clientY }, anchor);
}

/** Put a finished menu on the page at a point and arm its dismissal.
 *
 *  Shared by the widget's own menu and the tasks header's list chooser so the
 *  two dismiss exactly alike — outside press, Escape, and scroll all mean the
 *  same thing to both, which is what makes the second one read as part of the
 *  same vocabulary rather than an imitation of it. */
function mountWidgetMenu(menu, at, anchor) {
  document.body.append(menu);

  // Positioned at the point given, then pulled inside the viewport if that
  // would push it off an edge.
  const width = menu.offsetWidth;
  const height = menu.offsetHeight;
  const left = Math.min(Math.max(6, at.x), Math.max(6, window.innerWidth - width - 6));
  const top = Math.min(Math.max(6, at.y), Math.max(6, window.innerHeight - height - 6));
  menu.style.left = `${left}px`;
  menu.style.top = `${top}px`;

  for (const wrap of menu.querySelectorAll(".wg-submenu-wrap")) {
    const sub = wrap.querySelector(".wg-submenu");
    if (!sub) continue;
    placeSubmenu(sub, wrap);
  }

  menuAnchor?.removeAttribute("aria-expanded");
  menuAnchor = anchor ?? null;
  anchor?.setAttribute("aria-expanded", "true");

  widgetMenuNode = menu;
  document.addEventListener("pointerdown", onWidgetMenuOutside, true);
  document.addEventListener("keydown", onWidgetMenuKey, true);
  window.addEventListener("scroll", closeWidgetMenu, true);
}

function placeSubmenu(sub, wrap) {
  sub.style.visibility = "hidden";
  sub.style.display = "block";
  const width = sub.offsetWidth;
  const height = sub.offsetHeight;
  sub.style.display = "";
  sub.style.visibility = "";

  const row = wrap.getBoundingClientRect();
  const GUTTER = 6;
  const rightEdge = window.innerWidth - GUTTER;
  const bottomEdge = window.innerHeight - GUTTER;

  const fitsRight = row.right + width <= rightEdge;
  const fitsLeft = row.left - width >= GUTTER;
  sub.classList.toggle("is-left", !fitsRight && fitsLeft);
  if (!fitsRight && !fitsLeft) {
    sub.style.left = `${GUTTER - row.left}px`;
    sub.style.right = "auto";
  } else {
    sub.style.left = "";
    sub.style.right = "";
  }

  const restingTop = row.top - 5;
  const overhang = restingTop + height - bottomEdge;
  sub.style.top = overhang > 0 ? `${-5 - Math.min(overhang, restingTop - GUTTER)}px` : "";
}

/** One submenu panel. Each entry is a `radio` or `check`-style row; both render
 *  the same way and differ only in the mark, so the caller decides which by
 *  what it puts in the item. */
function buildSubmenu(entries) {
  const panel = node("div", "wg-submenu");
  for (const entry of entries) {
    const b = node("button", "wg-menu-item");
    b.type = "button";
    b.append(
      node("span", "wg-menu-mark", entry.checked ? (entry.kind === "radio" ? "●" : "✓") : ""),
      node("span", "wg-menu-item-label", entry.label),
    );
    if (entry.face) b.style.fontFamily = entry.face;
    b.addEventListener("click", () => {
      closeWidgetMenu();
      entry.onSelect();
    });
    panel.append(b);
  }
  return panel;
}

/** The rename row's edit field, drawn inside the menu in place of the row that
 *  opened it.
 *
 *  A second text-entry surface rather than the shared `buildShortcutForm`: that
 *  one is the two-field name+address form for a pinned site, and this is one
 *  field and no address. It wears the same classes (`.wg-search-input`,
 *  `.wg-add-save`, `.wg-add-toggle`, `.wg-search-status`) so it reads as the same
 *  vocabulary the panels' own forms do — the two surfaces differ in what they
 *  edit, not in how they look.
 *
 *  `save` writes through `setWidgetLabel`, which stores `null` for a blank name,
 *  so clearing the field is the way back to the kind's own label rather than an
 *  unnamed panel. The hint line says so, because an empty box that silently
 *  restores a default is a behaviour nobody would guess. */
function buildWidgetRenameForm(spec, onCancel) {
  const current = NEWTAB_SAFE.widgetLabelOf(spec);
  // `.wg-add` is the existing column-of-fields stack; `.wg-shortcut-actions` the
  // existing button row. No new class is introduced for a surface that is the
  // shortcut form's shape with one field instead of two. The inset matches a
  // menu row's own `6px 10px` so the field lines up with the labels above it —
  // an inline padding because the value belongs to this menu's gutter, not to
  // the shared form vocabulary.
  const form = node("form", "wg-add");
  form.style.padding = "2px 10px 6px";
  // A press anywhere in the field belongs to the field. The menu's own
  // outside-press check is containment-based and so would leave it alone on its
  // own, but stopping it here is the same guard the slider track carries and
  // keeps a press on the form from reaching any other document-level handler.
  form.addEventListener("mousedown", (e) => e.stopPropagation());

  const input = node("input", "wg-search-input");
  input.type = "text";
  input.value = current;
  input.maxLength = 40;
  input.placeholder = NEWTAB_SAFE.widgetLabelOf({ kind: NEWTAB_SAFE.widgetKindOf(spec) });
  input.setAttribute("aria-label", "Widget name");
  // Typing in the field must not reach the page: it owns no bare-letter
  // shortcuts today, but a key listener added later would fire on every
  // character otherwise, and Escape is stopped at the menu level (see
  // `onWidgetMenuKey`) rather than here. `keydown` only, not `keypress`, so a
  // paste or an IME composition is not touched.
  input.addEventListener("keydown", (e) => e.stopPropagation());

  const status = node("div", "wg-search-status", "Blank restores the default name.");
  const row = node("div", "wg-shortcut-actions");
  const save = node("button", "wg-add-save", "Save");
  save.type = "submit";
  const cancel = node("button", "wg-add-toggle", "Cancel");
  cancel.type = "button";
  row.append(save, cancel);
  form.append(input, row, status);

  // Cancel restores the row the field replaced; the menu itself stays open, so
  // the user can pick something else without re-opening it. Escape reaches this
  // same callback through `onWidgetMenuKey`, which owns the key because it runs
  // in the capture phase before the field could.
  cancel.addEventListener("click", () => onCancel());
  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    save.disabled = true;
    await NEWTAB_SAFE.setWidgetLabel(spec.id, input.value);
    // The label is drawn by `renderWidgets` off the stored spec rather than by
    // an attribute on the header, so the write only reaches the title through a
    // repaint — the same path every other identity change takes. `renderWidgets`
    // closes any open menu on its way in (see its own note), so the field and
    // the row it replaced both go with it and there is nothing to restore.
    await renderWidgets();
  });

  return { form, focus: () => { input.focus(); input.select(); } };
}

/** One place a weather panel could be pointed at, as the modal's suggestion
 *  list holds it: what to show, and what to store. */
const WEATHER_PLACES = [
  { name: "Tehran", region: "Iran" },
  { name: "Mashhad", region: "Iran" },
  { name: "Isfahan", region: "Iran" },
  { name: "Shiraz", region: "Iran" },
  { name: "Tabriz", region: "Iran" },
  { name: "Karaj", region: "Iran" },
  { name: "Ahvaz", region: "Iran" },
  { name: "Qom", region: "Iran" },
  { name: "Kermanshah", region: "Iran" },
  { name: "Rasht", region: "Iran" },
  { name: "Yazd", region: "Iran" },
  { name: "Kish", region: "Iran" },
  { name: "London", region: "United Kingdom" },
  { name: "Manchester", region: "United Kingdom" },
  { name: "Edinburgh", region: "United Kingdom" },
  { name: "Dublin", region: "Ireland" },
  { name: "Paris", region: "France" },
  { name: "Berlin", region: "Germany" },
  { name: "Munich", region: "Germany" },
  { name: "Amsterdam", region: "Netherlands" },
  { name: "Brussels", region: "Belgium" },
  { name: "Madrid", region: "Spain" },
  { name: "Barcelona", region: "Spain" },
  { name: "Lisbon", region: "Portugal" },
  { name: "Rome", region: "Italy" },
  { name: "Milan", region: "Italy" },
  { name: "Vienna", region: "Austria" },
  { name: "Zurich", region: "Switzerland" },
  { name: "Stockholm", region: "Sweden" },
  { name: "Oslo", region: "Norway" },
  { name: "Copenhagen", region: "Denmark" },
  { name: "Helsinki", region: "Finland" },
  { name: "Warsaw", region: "Poland" },
  { name: "Prague", region: "Czechia" },
  { name: "Budapest", region: "Hungary" },
  { name: "Athens", region: "Greece" },
  { name: "Istanbul", region: "Turkey" },
  { name: "Ankara", region: "Turkey" },
  { name: "Moscow", region: "Russia" },
  { name: "Kyiv", region: "Ukraine" },
  { name: "Dubai", region: "UAE" },
  { name: "Abu Dhabi", region: "UAE" },
  { name: "Doha", region: "Qatar" },
  { name: "Riyadh", region: "Saudi Arabia" },
  { name: "Jeddah", region: "Saudi Arabia" },
  { name: "Kuwait City", region: "Kuwait" },
  { name: "Baghdad", region: "Iraq" },
  { name: "Erbil", region: "Iraq" },
  { name: "Baku", region: "Azerbaijan" },
  { name: "Tbilisi", region: "Georgia" },
  { name: "Yerevan", region: "Armenia" },
  { name: "Kabul", region: "Afghanistan" },
  { name: "Islamabad", region: "Pakistan" },
  { name: "Karachi", region: "Pakistan" },
  { name: "Lahore", region: "Pakistan" },
  { name: "Delhi", region: "India" },
  { name: "Mumbai", region: "India" },
  { name: "Bangalore", region: "India" },
  { name: "Chennai", region: "India" },
  { name: "Dhaka", region: "Bangladesh" },
  { name: "Colombo", region: "Sri Lanka" },
  { name: "Kathmandu", region: "Nepal" },
  { name: "Bangkok", region: "Thailand" },
  { name: "Kuala Lumpur", region: "Malaysia" },
  { name: "Singapore", region: "Singapore" },
  { name: "Jakarta", region: "Indonesia" },
  { name: "Manila", region: "Philippines" },
  { name: "Hanoi", region: "Vietnam" },
  { name: "Hong Kong", region: "China" },
  { name: "Shanghai", region: "China" },
  { name: "Beijing", region: "China" },
  { name: "Seoul", region: "South Korea" },
  { name: "Tokyo", region: "Japan" },
  { name: "Osaka", region: "Japan" },
  { name: "Sydney", region: "Australia" },
  { name: "Melbourne", region: "Australia" },
  { name: "Auckland", region: "New Zealand" },
  { name: "New York", region: "United States" },
  { name: "Los Angeles", region: "United States" },
  { name: "San Francisco", region: "United States" },
  { name: "Chicago", region: "United States" },
  { name: "Seattle", region: "United States" },
  { name: "Toronto", region: "Canada" },
  { name: "Vancouver", region: "Canada" },
  { name: "Mexico City", region: "Mexico" },
  { name: "Sao Paulo", region: "Brazil" },
  { name: "Rio de Janeiro", region: "Brazil" },
  { name: "Buenos Aires", region: "Argentina" },
  { name: "Cairo", region: "Egypt" },
  { name: "Alexandria", region: "Egypt" },
  { name: "Casablanca", region: "Morocco" },
  { name: "Nairobi", region: "Kenya" },
  { name: "Lagos", region: "Nigeria" },
  { name: "Johannesburg", region: "South Africa" },
  { name: "Cape Town", region: "South Africa" },
  { name: "Reykjavik", region: "Iceland" },
  { name: "Honolulu", region: "United States" },
];

/** Whether a spelled-out place looks like the one being typed. Matched on the
 *  name and on the country, so "japan" finds Tokyo and "tok" finds it too. */
function weatherPlaceMatches(place, q) {
  if (!q) return true;
  const hay = [place.name, place.region].join(" ").toLowerCase();
  return q.split(/s+/).every((part) => hay.includes(part));
}

/** The city picker: a search field over the place list, with the typed word
 *  itself kept as the last suggestion.
 *
 *  A menu row was the wrong shape for this. A place is a word you *search* for,
 *  not one of six you pick, and a field wedged into a context menu is narrow,
 *  sits against whichever edge the menu was pulled to, and gives nowhere to
 *  show suggestions. The dialog has room to list what matches while you type.
 *
 *  The typed word is always offered as its own row, because the list here is a
 *  convenience rather than a boundary — wttr.in resolves a great many places
 *  this file has never heard of, and refusing a name that is not in a hardcoded
 *  table would make the widget worse than the bare field it replaces. */
function openWeatherCityModal(spec) {
  const current = NEWTAB_SAFE.weatherCityOf({ widgets: [] }, null);
  const scrim = node("div", "wg-modal-scrim");
  const dialog = node("div", "wg-modal wg-city-modal");
  dialog.setAttribute("role", "dialog");
  dialog.setAttribute("aria-modal", "true");
  dialog.setAttribute("aria-label", "Weather city");

  const head = node("div", "wg-modal-head");
  head.append(node("div", "wg-modal-title", "Weather city"));
  const close = node("button", "wg-modal-close", "×");
  close.type = "button";
  close.title = "Close";
  close.setAttribute("aria-label", "Close");
  head.append(close);
  dialog.append(head);

  const body = node("div", "wg-modal-body");
  const input = node("input", "wg-search-input wg-city-input");
  input.type = "search";
  input.placeholder = "Search a city...";
  input.value = "";
  input.setAttribute("aria-label", "Search for a city");
  const list = node("div", "wg-city-list", );
  list.setAttribute("role", "listbox");
  list.setAttribute("aria-label", "City suggestions");

  body.append(input, list);
  dialog.append(body);
  scrim.append(dialog);
  document.body.append(scrim);

  let index = -1;
  let rows = [];

  const pick = async (city) => {
    const clean = String(city ?? "").trim();
    if (!clean) return;
    await NEWTAB_SAFE.setWidgetCity(spec.id, clean);
    dismiss();
    await renderWidgets();
  };

  const paint = () => {
    const q = input.value.trim().toLowerCase();
    list.replaceChildren();
    rows = [];
    const exact = WEATHER_PLACES.some((p) => p.name.toLowerCase() === q);
    // The typed word first, unless it is exactly a place already in the list —
    // two rows that both mean "Tehran" would only ask which one you meant.
    if (q && !exact) {
      const typed = node("button", "wg-city-row is-typed");
      typed.type = "button";
      typed.append(node("span", "wg-city-name", input.value.trim()));
      typed.append(node("span", "wg-city-region", "search this place"));
      typed.addEventListener("click", () => pick(input.value));
      rows.push(typed);
    }
    for (const place of WEATHER_PLACES.filter((p) => weatherPlaceMatches(p, q)).slice(0, 40)) {
      const row = node("button", "wg-city-row");
      row.type = "button";
      row.append(node("span", "wg-city-name", place.name));
      row.append(node("span", "wg-city-region", place.region));
      row.addEventListener("click", () => pick(place.name));
      rows.push(row);
    }
    if (!rows.length) {
      rows.push(node("div", "wg-empty", "No place matches. Type a name and press Enter."));
      index = -1;
      list.append(...rows);
      return;
    }
    index = Math.min(index, rows.length - 1);
    list.append(...rows);
    markActive();
    // The list is long enough to scroll; keep the active row in view rather
    // than letting the arrow keys walk the highlight out of the box.
    rows[index]?.scrollIntoView({ block: "nearest" });
  };

  const markActive = () => {
    rows.forEach((r, i) => r.classList.toggle("is-active", i === index));
  };

  const move = (delta) => {
    if (!rows.length) return;
    index = (index + delta + rows.length) % rows.length;
    markActive();
    rows[index].scrollIntoView({ block: "nearest" });
  };

  input.addEventListener("input", () => {
    index = 0;
    paint();
  });
  input.addEventListener("keydown", (e) => {
    // The page's own key handlers (the shortcut keys, the search box) sit on
    // document; a name typed here is not a command.
    e.stopPropagation();
    if (e.key === "ArrowDown") {
      e.preventDefault();
      move(1);
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      move(-1);
    } else if (e.key === "Enter") {
      e.preventDefault();
      const active = rows[index];
      if (!active) return;
      // The typed row already knows its word; a place row stores its name.
      const name = active.classList.contains("is-typed")
        ? input.value
        : active.querySelector(".wg-city-name")?.textContent;
      pick(name);
    } else if (e.key === "Escape") {
      e.preventDefault();
      dismiss();
    }
  });

  const dismiss = () => {
    document.removeEventListener("keydown", onKey, true);
    scrim.remove();
  };
  const onKey = (e) => {
    if (e.key === "Escape") {
      e.preventDefault();
      e.stopPropagation();
      dismiss();
    }
  };
  close.addEventListener("click", dismiss);
  scrim.addEventListener("mousedown", (e) => {
    if (e.target === scrim) dismiss();
  });
  document.addEventListener("keydown", onKey, true);

  paint();
  input.focus();
}

/** What one widget's context menu offers: the layout picker for the kinds that
 *  have variants, three size steps, the two layering moves, and hide.
 *
 *  The variant and size rows read the widget's *own* entry out of `spec` rather
 *  than re-reading the whole settings blob, so the ticks shown are the same
 *  resolution the panel renders — `widgetVariantFor` and `widgetScaleFor` both
 *  take a settings-shaped object and only ever look at `widgets`. */
function widgetMenuItems(spec, options = {}) {
  const items = [];
  const kind = NEWTAB_SAFE.widgetKindOf(spec);
  const title = NEWTAB_SAFE.widgetLabelOf(spec);
  // The tasks header's gear asks for the panel's settings only — see
  // `openWidgetMenu`. Everything that is not the name or the list is left to the
  // right-click, so the gear answers "how is this panel named and which list is
  // it" and nothing else.
  const onlyTasks = options.onlyTasksSettings === true;

  // Variants are a property of the kind, and are looked up by kind — a
  // shortcuts panel has none, and its minted id is not in the map either.
  //
  // The layouts go in a submenu rather than as five rows of the menu itself: a
  // calendar's five layouts plus three sizes was eight lines of picker before
  // the menu reached anything you could *do* to the widget.
  const variants = NEWTAB_SAFE.WIDGET_VARIANTS[kind];
  if (variants && !onlyTasks) {
    const current = NEWTAB_SAFE.widgetVariantFor({ widgets: [spec] }, spec.id);
    items.push({
      label: "Layout",
      value: variants.find((v) => v.id === current)?.label ?? "",
      submenu: variants.map((option) => ({
        kind: "radio",
        label: option.label,
        checked: option.id === current,
        onSelect: () => chooseWidgetVariant(spec.id, option.id),
      })),
    });
  }

  // Which place this panel forecasts. Per panel rather than page-wide, so two
  // weather widgets can be two cities; offered on the kind alone, because the
  // city means nothing to any other body. The field is the rename form's shape
  // with a place in it instead of a name — the menu is the only place a
  // *panel* is addressed, and unlike the calendar's system a city is a word to
  // type rather than one of a short list to pick.
  if (kind === "weather") {
    items.push({
      label: "City",
      value: spec?.city || "Tehran",
      onSelect: () => openWeatherCityModal(spec),
    });
  }

  // Which face the panel's own text wears. Offered for every kind, because the
  // numbers and dates inside a timer or a weather day are as much a reading in
  // the reader's script as a calendar's month name is. The face may also carry a
  // language (see `WIDGET_FONTS`), so picking Vazirmatn here brings the panel's
  // dates and numerals across with it.
  const font = NEWTAB_SAFE.widgetFontFor({ widgets: [spec] }, spec.id);
  if (!onlyTasks) items.push({
    label: "Font",
    value: NEWTAB_SAFE.WIDGET_FONTS.find((f) => f.id === font)?.label ?? "",
    submenu: NEWTAB_SAFE.WIDGET_FONTS.map((option) => ({
      kind: "radio",
      label: option.label,
      checked: option.id === font,
      face: option.stack,
      onSelect: () => chooseWidgetFont(spec.id, option.id),
    })),
  });

  // Which calendar the panel counts in is a separate axis, offered only by the
  // kind that has one. It reads the widget's own entry, like the layout row
  // above, so the tick is this instance's resolution rather than the first
  // calendar's — a Hijri panel beside a Gregorian one is the case the setting
  // exists for.
  if (kind === "calendar" && !onlyTasks) {
    const current = NEWTAB_SAFE.calendarSystemFor({ widgets: [spec] }, spec.id);
    items.push({
      label: "Calendar",
      value: NEWTAB_SAFE.CALENDAR_SYSTEMS.find((s) => s.id === current)?.label ?? "",
      submenu: NEWTAB_SAFE.CALENDAR_SYSTEMS.map((option) => ({
        kind: "radio",
        label: option.label,
        checked: option.id === current,
        onSelect: () => chooseCalendarSystem(spec.id, option.id),
      })),
    });
  }

  // Three steps of the same 0.6–2 multiplier the panel's slider drives. A menu
  // can only offer discrete choices, and the slider remains the place for a
  // free value.
  const scale = NEWTAB_SAFE.widgetScaleFor({ widgets: [spec] }, spec.id);
  const steps = [
    { factor: 0.75, label: "Smaller" },
    { factor: 1, label: "Normal size" },
    { factor: 1.5, label: "Larger" },
  ];
  if (!onlyTasks) items.push({
    label: "Size",
    value: steps.find((s) => s.factor === scale)?.label ?? `${Math.round(scale * 100)}%`,
    submenu: steps.map((step) => ({
      kind: "radio",
      label: step.label,
      checked: scale === step.factor,
      onSelect: () => resizeWidget(spec.id, step.factor),
    })),
  });

  // Width, as its own axis rather than three more size steps. Size multiplies
  // everything — a "larger" grid of pinned sites grows its names along with the
  // box — where width moves the box alone, which is the one a panel of tiles
  // actually wants: more of them per row at the size they already read at. The
  // single block is left out because it is 92px by definition; widening it would
  // be asking it to stop being an icon.
  if (!onlyTasks && (kind !== "shortcuts" || NEWTAB_SAFE.widgetVariantFor({ widgets: [spec] }, spec.id) !== "single")) {
    // The steps are measured off the kind's own base, so "Wide" means the same
    // proportion on a calendar (168px) as on everything else (268px).
    const base = widgetBaseWidth(spec);
    const own = NEWTAB_SAFE.widgetWidthFor({ widgets: [spec] }, spec.id);
    const widths = [
      { width: Math.round(base * 0.75), label: "Narrow" },
      { width: null, label: "Default" },
      { width: Math.round(base * 1.5), label: "Wide" },
      { width: Math.round(base * 2), label: "Full" },
    ];
    // The slider first, because the width is a continuum and the named steps are
    // four points on it. Its start is the widget's own width when it has one and
    // the kind's base when it does not — the same number the menu's "Default"
    // row would restore, so opening the slider never moves the panel by itself.
    items.push({
      kind: "slider",
      label: "Width",
      value: Math.round(own ?? base),
      min: NEWTAB_SAFE.WIDGET_WIDTH_MIN,
      max: NEWTAB_SAFE.WIDGET_WIDTH_MAX,
      step: 4,
      format: (v) => `${Math.round(v)}px`,
      // Drawn on the panel as the thumb travels, written once on release. The
      // preview is a style write because a storage round-trip per pixel of
      // travel would be hundreds of them for one drag, each one a full
      // re-render of the page behind the menu.
      onInput: (v) => previewWidgetWidth(spec.id, v),
      onCommit: (v) => setWidgetWidthValue(spec.id, v),
    });
    items.push({
      label: "Width step",
      value: own == null ? "Default" : `${Math.round(own)}px`,
      submenu: widths.map((w) => ({
        kind: "radio",
        // "Default" stores `null` rather than the base number, so a widget that
        // never chose a width stays distinguishable from one that chose the
        // number its kind happens to use today — and a later change to the
        // kind's base moves the first and leaves the second alone.
        label: w.label,
        checked: own == null ? w.width == null : w.width === own,
        onSelect: () => setWidgetWidthValue(spec.id, w.width),
      })),
    });
  }

  // The header toggle, offered on every widget. It is a change to how the panel
  // is drawn like the two pickers below, so a checkbox is honest about what
  // pressing it will do.
  const hidden = NEWTAB_SAFE.widgetHeaderHidden({ widgets: [spec] }, spec.id);
  if (!onlyTasks) items.push({
    kind: "check",
    label: "Hide title bar",
    checked: hidden,
    onSelect: () => toggleWidgetHeader(spec.id, !hidden),
  });

  // Only a shortcuts panel has names to drop: its tiles are the only ones that
  // carry a label the user typed. Offered here rather than as a per-kind rule so
  // the one shortcuts panel that wants bare icons can have them while the next
  // one keeps its names — the two are the same kind and different panels.
  if (kind === "shortcuts" && !onlyTasks) {
    const labelHidden = NEWTAB_SAFE.widgetLabelHidden({ widgets: [spec] }, spec.id);
    items.push({
      kind: "check",
      label: "Hide icon name",
      checked: labelHidden,
      onSelect: () => toggleWidgetLabel(spec.id, !labelHidden),
    });
  }

  // Rename. The label is what tells two of the same kind apart — "Shortcuts 2"
  // from "Shortcuts 3" — and only a widget the user *added* has one worth
  // changing: a shipped singleton is its kind, is named by its kind, and has no
  // second of itself to be confused with. The test is `isRemovableWidget`, the
  // same "this one was minted" check the row that takes the panel away uses, so
  // the two appear and disappear together rather than each answering the
  // question their own way.
  if (NEWTAB_SAFE.isRemovableWidget(spec)) {
    items.push({ label: "Rename", form: (onCancel) => buildWidgetRenameForm(spec, onCancel) });
  }

  // Connecting an Open tasks panel to a shared list. Lives here rather than in
  // the settings panel because the link is a property of *this* panel, and the
  // menu is already where a single instance is addressed — the same reason
  // Rename is here.
  if (kind === "tasks") {
    items.push({ kind: "separator" });
    // The header's gear asks only these three questions, so the name comes first
    // there — it is the one thing that changes what the header says. The
    // right-click keeps its existing order, where Rename sits alone above this
    // block.
    if (onlyTasks) items.push({ label: "Rename…", form: (onCancel) => buildWidgetRenameForm(spec, onCancel) });
    const link = NEWTAB_SAFE.todoLinkOf(spec?.data);
    if (link) {
      items.push({ label: "Open linked list", onSelect: () => window.open(link.url, "_blank", "noopener") });
      // The panel draws one list at a time, and switching between the shared one
      // and the account's own is the header's tab switcher — but that switcher
      // only exists while a link does, so the menu has to be able to put the
      // panel back on its own lists as well as take the link away for good.
      const tab = link.tab === "own" ? "shared" : "own";
      items.push({
        label: tab === "own" ? "Show my lists" : "Show the shared list",
        onSelect: () => switchTaskList(spec, tab),
      });
      items.push({
        label: `Disconnect “${link.title || link.token}”`,
        danger: true,
        onSelect: () => disconnectTaskList(spec),
      });
    } else {
      // "..." because it opens a dialog rather than acting on the spot, matching
      // the "Add a site..." / "Edit site..." convention above.
      items.push({
        label: "Connect a shared list...",
        onSelect: () => openTaskConnectModal(spec),
      });
    }
    // Creating a list is only offered where it can actually happen: a new list
    // is local, so a signed-in account makes one on the site, which is also
    // where it renames and deletes them. The entry is here rather than a header
    // button so the gear works the same signed in and out; it is added
    // optimistically and taken back when the account read says otherwise, the
    // same way the button it replaces hid itself.
    const newList = { label: "New list…", onSelect: () => openTaskListModal(spec) };
    items.push(newList);
    const delList = { label: "Delete list…", danger: true, onSelect: () => openTaskDeleteModal(spec) };
    items.push(delList);
    taskSource()
      .then((source) => {
        const own = !link || link.tab === "own";
        if (source?.local && own && source.pages.length) return;
        for (const entry of [newList, delList]) {
          const index = items.indexOf(entry);
          if (index >= 0) items.splice(index, 1);
        }
      })
      .catch(() => {});
  }

  // The way into a pinned site's name and address, for a panel where the tile
  // cannot carry it. The single-icon block *is* its tile, so a right-click there
  // already means "edit this one" and there is nowhere else to put a form; the
  // grid keeps its per-tile right-click. That leaves two cases for this entry:
  // the single block, where "edit" is well defined because there is one site;
  // and an empty grid, where "add" is the only thing there is to do.
  if (kind === "shortcuts") {
    const links = spec?.data?.links ?? [];
    const single = NEWTAB_SAFE.widgetVariantFor({ widgets: [spec] }, spec.id) === "single";
    // The single block draws `links[0]` and nothing else, so it has a site to
    // edit whenever the store holds one — not only when the list is exactly one
    // long. A list that grew while the panel was a grid and was then switched to
    // this layout would otherwise leave the drawn site with no way to be changed.
    // The grid keeps its per-tile right-click, so this entry is the block's.
    const editable = single && links.length >= 1;
    if (editable || !links.length) {
      items.push({ kind: "separator" });
      items.push({
        // "…" because it opens a dialog rather than acting on the spot, which is
        // the one thing in this menu that behaves that way.
        label: editable ? "Edit site…" : "Add a site…",
        onSelect: () => openShortcutModal(spec, editable ? { index: 0, link: links[0] } : null),
      });
    }
  }

  if (onlyTasks) return items;

  // Moving without a drag to find first. A widget whose header is hidden, or
  // that is one of the bare single-icon blocks, has no grab handle on screen at
  // rest — and a title bar that only slides out on hover is a thing you have to
  // already know about. This hands the panel straight to the pointer, so the
  // position is one gesture from wherever the menu was opened rather than a
  // hunt for what to grab. Offered on every widget, including the ones with a
  // perfectly good header: the menu is where you look when dragging did not
  // occur to you.
  items.push({ kind: "separator" });
  items.push({ label: "Move", onSelect: (e) => startMoveMode(spec.id, e) });
  items.push({ label: "Bring to front", onSelect: () => layerWidget(spec.id, "front") });
  items.push({ label: "Send to back", onSelect: () => layerWidget(spec.id, "back") });
  items.push({ kind: "separator" });
  items.push({
    label: `Hide ${title.toLowerCase()}`,
    danger: true,
    // The same write the header's × makes, so the two paths cannot diverge.
    onSelect: () => hideWidget(spec.id),
  });
  // Only a widget the user added can be taken away again. The two are worded
  // apart on purpose: hiding is "not now", removing is "not this panel", and a
  // singleton offering the second would be offering to delete a widget that is
  // about to be switched back on.
  if (NEWTAB_SAFE.isRemovableWidget(spec)) {
    items.push({
      label: "Remove this panel",
      danger: true,
      onSelect: () => removeShortcutPanel(spec),
    });
  }
  return items;
}

/** Take one added panel off the page for good, then rebuild the layout — the
 *  panel this menu was anchored to is about to stop existing, so unlike a
 *  variant or a size change there is nothing left to repaint in place. */
async function removeShortcutPanel(spec) {
  await NEWTAB_SAFE.removeWidget(spec.id);
  await renderWidgets();
}

/** The "Connect a shared list..." form as a page-level modal.
 *
 *  Same construction as `openShortcutModal` and `openTimerModal`: built on
 *  demand, torn down on close, dismissed by Escape, the ×, or a press on the
 *  backdrop. The form's own field, buttons and status line are the ones the
 *  menu-embedded form used, unchanged — what moved is where they are drawn,
 *  not what connecting does.
 *
 *  The menu is already gone by the time this runs (`openWidgetMenu` closes it
 *  before invoking `onSelect`), so nothing needs cleaning up when it opens. */
function openTaskConnectModal(spec) {
  const scrim = node("div", "wg-modal-scrim");
  const dialog = node("div", "wg-modal");
  dialog.setAttribute("role", "dialog");
  dialog.setAttribute("aria-modal", "true");
  dialog.setAttribute("aria-label", "Connect a shared list");

  const head = node("div", "wg-modal-head");
  head.append(node("span", "wg-modal-title", "Connect a shared list"));
  const close = node("button", "wg-modal-close", "×");
  close.type = "button";
  close.setAttribute("aria-label", "Close");
  head.append(close);
  dialog.append(head);

  const dismiss = () => {
    document.removeEventListener("keydown", onKey, true);
    scrim.remove();
  };
  // The form's Save writes the connection and repaints the widget behind the
  // dialog — the modal's version of the inline path's close-then-render.
  const { form, focus } = buildTaskConnectForm(spec, () => dismiss(), async () => {
    dismiss();
    refreshWidgetData();
    // Entering the just-connected list: if it turns out to be locked the panel
    // offers the password field rather than a dead error line.
    await repaintTasksWidget(spec, true);
  });
  dialog.append(form);

  // Escape belongs to the modal while it is up. Stopped here in the capture
  // phase so `panel.js`'s own document-level Escape listener — which runs in
  // the bubble phase — does not also close the settings panel behind it, the
  // same one-key-two-surfaces guard `bangOnKey` applies.
  const onKey = (e) => {
    if (e.key !== "Escape") return;
    e.preventDefault();
    e.stopPropagation();
    dismiss();
  };
  close.addEventListener("click", dismiss);
  // A press on the backdrop closes; a press inside the dialog must not, which
  // is what the identity check is for — the scrim is the dialog's parent.
  scrim.addEventListener("mousedown", (e) => {
    if (e.target === scrim) dismiss();
  });
  document.addEventListener("keydown", onKey, true);

  scrim.append(dialog);
  document.body.append(scrim);
  focus();
}

/** The connect field, drawn in `openTaskConnectModal`.
 *
 *  It wears the same classes as `openTimerModal`'s form — one field, the
 *  `.wg-shortcut-actions` row, a `.wg-search-status` line — because the two
 *  are the same kind of surface: a small entry form in a 300px dialog.
 *
 *  `onCancel` is the dialog's dismiss. `onDone` runs after a successful
 *  connect, once the write has landed, so the caller can repaint the widget
 *  behind the dialog in its connected state.
 *
 *  The field is `type="text"`, never `type="url"`: the browser's own URL
 *  validation silently refuses a bare host, and a form that cannot be submitted
 *  and does not say why is the worst version of this. `buildShortcutForm`
 *  carries the full note. */
function buildTaskConnectForm(spec, onCancel, onDone) {
  const form = node("form", "wg-add wg-shortcut-form");

  const input = node("input", "wg-search-input");
  input.type = "text";
  input.maxLength = 300;
  input.placeholder = "https://ixiflower.vercel.app/todo/name";
  input.setAttribute("aria-label", "Shared list link");
  // Escape belongs to the menu, which owns it in the capture phase — see
  // `onWidgetMenuKey`. Typing must not reach the page.
  input.addEventListener("keydown", (e) => e.stopPropagation());

  // Revealed only once the site says the list is locked, or immediately on a
  // retry after "Incorrect password". A protected list is the one case that
  // needs a second field, and asking a public list for a password it does not
  // have would make every connect look like a login. Optional either way: a
  // typed value is sent, an empty one is not.
  const password = node("input", "wg-search-input");
  password.type = "password";
  password.autocomplete = "off";
  password.maxLength = 200;
  password.placeholder = "List password";
  password.setAttribute("aria-label", "List password (if it is protected)");
  // Hidden — and `disabled` in step — until a locked list reveals it. Disabling a
  // hidden field is belt-and-braces: it keeps an autofill or a stray keyboard
  // from putting text into a field the user has not been shown, and the form's
  // own submit handler sends the value, not the browser's implicit encoding, so
  // nothing downstream depends on it being submitted.
  password.hidden = true;
  password.disabled = true;
  password.addEventListener("keydown", (e) => e.stopPropagation());
  const revealPassword = () => {
    if (!password.hidden) return;
    password.hidden = false;
    password.disabled = false;
    password.focus();
  };

  const status = node("div", "wg-search-status", "Paste the address of a shared todo page.");
  const row = node("div", "wg-shortcut-actions");
  const save = node("button", "wg-add-save", "Connect");
  save.type = "submit";
  const cancel = node("button", "wg-add-toggle", "Cancel");
  cancel.type = "button";
  row.append(save, cancel);
  form.append(input, password, row, status);

  cancel.addEventListener("click", () => onCancel());
  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const parsed = NEWTAB_SAFE.todoTokenFromUrl(input.value);
    if (!parsed) {
      status.textContent = "That doesn’t look like a shared todo link.";
      status.className = "wg-search-status is-error";
      return;
    }
    save.disabled = true;
    // Fetched before it is stored. A link that does not resolve is refused here
    // rather than written and then rendered as an error forever — the widget
    // only ever sees a connection that worked at least once. A locked list is
    // the one exception: it resolves, it just needs its password first.
    let detail;
    try {
      detail = await NEWTAB_API.publicTodos.page(parsed.token, password.value || undefined);
    } catch (err) {
      if (!form.isConnected) return;
      save.disabled = false;
      if (err?.status === 401) {
        const retry = !password.hidden;
        revealPassword();
        status.textContent = retry ? "Incorrect password." : "This list is protected — enter its password.";
        status.className = "wg-search-status is-error";
        return;
      }
      status.textContent = err?.status === 404 ? "No shared list at that link." : "Could not reach the site.";
      status.className = "wg-search-status is-error";
      return;
    }
    // The dialog may have been dismissed while the request was in flight; the
    // form being detached is what that looks like from here.
    if (!form.isConnected) return;
    // Written before the connection, so the panel's very first render already
    // has the password it needs. A submitted form always carries a value here —
    // the submit is refused until a locked list's password is filled in — so
    // this only ever sets; a relink to a different list is caught by
    // `disconnectTaskList` having cleared the old one.
    if (password.value) await setTaskPassword(spec, password.value);
    else await forgetTaskPassword(spec);
    await NEWTAB_SAFE.setWidgetData(spec.id, {
      todoLink: { token: parsed.token, url: parsed.url, title: detail?.page?.title ?? "", tab: "shared" },
    });
    refreshWidgetData();
    // The dialog is closed and the widget repainted by the caller — the modal's
    // version of the old inline form's close-then-render.
    await onDone?.();
  });

  return { form, focus: () => input.focus() };
}

/** Put a connected panel on its other tab — the shared list, or the account's
 *  own lists — and repaint. The header's tab switcher (`buildTaskTabs`) writes
 *  exactly this, but it is only on screen while the panel's header is, which a
 *  widget with its title bar hidden does not have; the menu is how the same
 *  switch is reached there. */
async function switchTaskList(spec, tab) {
  const link = NEWTAB_SAFE.todoLinkOf(spec?.data);
  if (!link) return;
  // Written whole because `setWidgetData` replaces the entry's `data` rather
  // than merging into it.
  await NEWTAB_SAFE.setWidgetData(spec.id, { todoLink: { ...link, tab } });
  // A full render, unlike the tab switcher's in-place repaint: the header's
  // two tabs are drawn from this same stored link, and they have to light the
  // new one. `spec` is the stale `layoutState` copy — the write above goes to
  // storage — so nothing here may be patched by hand to compensate.
  await renderWidgets();
}

/** Forget the connection and rebuild, so the panel goes back to being an
 *  ordinary tasks widget — header switcher and all. */
async function disconnectTaskList(spec) {
  // Forgetting the connection forgets how it was unlocked too: a password left
  // behind would unlock the *next* list this panel is pointed at, which may be
  // an address someone else sent.
  forgetTaskPassword(spec);
  await NEWTAB_SAFE.setWidgetData(spec.id, null);
  refreshWidgetData();
  await renderWidgets();
}

async function chooseWidgetVariant(id, variant) {
  await NEWTAB_SAFE.setWidgetVariant(id, variant);
  await window.ixiNewtabPage.applySettings();
}

/** Switch which calendar one panel counts in. Goes through the page's own
 *  `applySettings` like the layout picker, so the caption, the cells and the
 *  panel's width are all redrawn from the one new spec. */
async function chooseCalendarSystem(id, system) {
  await NEWTAB_SAFE.setWidgetCalendar(id, system);
  await window.ixiNewtabPage.applySettings();
}

async function chooseWidgetFont(id, font) {
  await NEWTAB_SAFE.setWidgetFont(id, font);
  await window.ixiNewtabPage.applySettings();
}

async function resizeWidget(id, factor) {
  await NEWTAB_SAFE.setWidgetScale(id, factor);
  await window.ixiNewtabPage.applySettings();
}

/** The width twin of `resizeWidget`, and it takes `null` — see the Width
 *  submenu's note on why "Default" clears rather than writes. */
async function setWidgetWidthValue(id, width) {
  await NEWTAB_SAFE.setWidgetWidth(id, width);
  await window.ixiNewtabPage.applySettings();
}

/** Draw a width on the panel without storing it.
 *
 *  The slider's other half: it fires on every `input`, and a settings write is
 *  `chrome.storage` plus a full re-render of the page — for a drag across the
 *  track that is one re-render per pixel. So the travel is drawn straight onto
 *  the one panel, and only the release writes. The panel is looked up by id so
 *  the write lands on the widget the menu belongs to and not on another panel of
 *  the same kind.
 *
 *  Deliberately not stored, so it is also what a cancelled control would leave
 *  behind — but nothing can cancel a range input short of reloading, and the
 *  release always follows. */
function previewWidgetWidth(id, width) {
  const entry = widgetPanels.get(id);
  if (!entry) return;
  entry.panel.style.width = `${Math.round(width)}px`;
  // The calendar's cells are driven off the panel's width, so a drag that grows
  // the box has to regrow them with it — otherwise the one kind whose whole
  // point is the scaling would be the one kind the slider did not visibly move.
  // The width being previewed is passed in rather than read back, because the
  // stored settings still hold the old one for as long as the drag lasts.
  const spec = layoutState.find((w) => w.id === id);
  if (spec) applyCalendarScale(entry.panel, spec, width);
}

async function layerWidget(id, direction) {
  await NEWTAB_SAFE.setWidgetLayer(id, direction);
  await window.ixiNewtabPage.applySettings();
}

async function toggleWidgetHeader(id, hidden) {
  await NEWTAB_SAFE.setWidgetHeaderHidden(id, hidden);
  await window.ixiNewtabPage.applySettings();
}

/** The tile-label twin of `toggleWidgetHeader`. Same repaint path — the label
 *  is drawn by the renderer rather than by an attribute, so this has to be a
 *  full re-render, not a class flip. */
async function toggleWidgetLabel(id, hidden) {
  await NEWTAB_SAFE.setWidgetLabelHidden(id, hidden);
  await window.ixiNewtabPage.applySettings();
}

async function hideWidget(id) {
  await NEWTAB_SAFE.setWidgetVisible(id, false);
  await renderWidgets();
}

// ── the panels ────────────────────────────────────────────────────────────

/** Every live panel, by widget id. Kept so `refreshAll()` can re-render the
 *  bodies without rebuilding (and so re-positioning) the panels themselves. */
const widgetPanels = new Map();

/** Clamp a stored position into the viewport. A window that was closed at
 *  2560px wide and reopened at 1280 would otherwise drop every widget outside
 *   the right edge with no way to drag it back.
 *
 *  `width`/`height` are the widget's **rendered** size, which is why this takes
 *  numbers rather than measuring the element itself: a resized widget is wider
 *  and taller than its layout box, and clamping to the layout box would let a
 *  widget at 2× be dragged half off-screen. The caller measures once per gesture
 *  (and again if the size changes mid-drag), since reading a rect inside the
 *  drag loop would force a layout every frame.
 *
 *  The two axes are clamped independently but against the same rule — the whole
 *  panel stays between the screen's edges on both, so a widget can never be
 *  dragged out past the left/right/top/bottom. The bottom used to clamp only the
 *  panel's *top* (`innerHeight - 48`), which let a tall widget be pushed so far
 *  down that its lower half — and its resize corner — sat off the screen; the
 *  height is now subtracted like the width is. Each axis floors at 12/48 so a
 *  panel wider or taller than the viewport still leaves a grab strip on screen
 *  rather than pinning to a negative coordinate. */
function clampPosition(x, y, width, height = 0) {
  const maxX = Math.max(12, window.innerWidth - width - 12);
  const maxY = Math.max(48, window.innerHeight - height - 12);
  return { x: Math.min(Math.max(12, x), maxX), y: Math.min(Math.max(48, y), maxY) };
}

/** The space left between two panels when a drag is pushed clear of another
 *  one. The same 12px `clampPosition` keeps off the screen edge, so "beside"
 *  means the same distance wherever the user meets it. */
const WIDGET_DRAG_GAP = 12;

/** How far the pointer must travel before a press on a drag handle becomes a
 *  drag. Under this it stays a click, and the click reaches whatever is beneath
 *  the pointer — which is what lets the single-icon tile be a link *and* a drag
 *  handle, since pointer capture retargets the trailing click to the panel and
 *  would otherwise swallow the link's own navigation. Small enough that a
 *  deliberate drag starts on the first movement, large enough to ride out the
 *  jitter of an ordinary click. */
const WIDGET_DRAG_SLOP = 4;

/** The rect of every visible panel except the one being dragged. Measured once
 *  at gesture start because the others do not move while this drag runs —
 *  re-measuring per frame is exactly the forced layout `clampPosition`'s note
 *  warns about. The dragged panel is left out so a widget never counts itself
 *  as the thing in its way. */
function widgetDragObstacles(skipId) {
  const rects = [];
  for (const [id, entry] of widgetPanels) {
    if (id === skipId) continue;
    rects.push(entry.panel.getBoundingClientRect());
  }
  return rects;
}

/** Whether a candidate rect shares any area with an obstacle. Touching edges
 *  are not an overlap: that is exactly what "next to it" looks like, and a
 *  comparison that counted a flush edge would push the panel one gap further
 *  every pass. */
function widgetRectsOverlap(a, b) {
  return a.left < b.right && a.right > b.left && a.top < b.bottom && a.bottom > b.top;
}

/** Nudge a dragged position until it clears every other panel.
 *
 *  The dragged widget refuses to cover another one, so a drag aimed *at* a
 *  neighbour has to resolve to a spot beside it instead. The spots beside a
 *  panel are its four sides, and for each side two placements — keeping the
 *  cross-axis where the pointer already is, or squaring up with the panel's own
 *  edge — so "next to it" reads as aligned when the pointer was near an edge
 *  and as level when it was not.
 *
 *  Every candidate is measured from the *clamped* start rather than by walking
 *  side to side from obstacle to obstacle: a step-by-step search can be cornered
 *  — three panels around a candidate leave a direction blocked and a strict
 *  loop with nowhere to go — where scoring all of them at once simply picks the
 *  best of the ones that fit. Ties and unreachable placements resolve by
 *  distance from where the pointer wanted the panel, so the answer stays close
 *  to the hand that dragged it. When nothing fits at all — a viewport too small
 *  to seat the widget beside anything — the clamped start stands, because an
 *  overlap the user can undo beats a panel that cannot be put down. */
function resolveWidgetCollisions(x, y, size, obstacles) {
  const start = clampPosition(x, y, size.width);
  // Free space is the common case and must stay exactly where the pointer left
  // it: the widget is only ever moved when it actually covers something, and a
  // rule that nudged it toward the nearest neighbour regardless would turn every
  // drag into a magnet.
  const startRect = { left: start.x, top: start.y, right: start.x + size.width, bottom: start.y + size.height };
  if (!obstacles.some((o) => widgetRectsOverlap(startRect, o))) return start;
  const candidates = [];
  for (const o of obstacles) {
    const beside = [
      { x: o.right + WIDGET_DRAG_GAP, y: start.y },
      { x: o.left - WIDGET_DRAG_GAP - size.width, y: start.y },
      { x: start.x, y: o.bottom + WIDGET_DRAG_GAP },
      { x: start.x, y: o.top - WIDGET_DRAG_GAP - size.height },
      { x: o.right + WIDGET_DRAG_GAP, y: o.top },
      { x: o.right + WIDGET_DRAG_GAP, y: o.bottom - size.height },
      { x: o.left - WIDGET_DRAG_GAP - size.width, y: o.top },
      { x: o.left - WIDGET_DRAG_GAP - size.width, y: o.bottom - size.height },
      { x: o.left, y: o.bottom + WIDGET_DRAG_GAP },
      { x: o.right - size.width, y: o.bottom + WIDGET_DRAG_GAP },
      { x: o.left, y: o.top - WIDGET_DRAG_GAP - size.height },
      { x: o.right - size.width, y: o.top - WIDGET_DRAG_GAP - size.height },
    ];
    for (const spot of beside) candidates.push(clampPosition(spot.x, spot.y, size.width));
  }
  let best = null;
  let bestDistance = Infinity;
  for (const option of candidates) {
    const rect = { left: option.x, top: option.y, right: option.x + size.width, bottom: option.y + size.height };
    if (obstacles.some((o) => widgetRectsOverlap(rect, o))) continue;
    const distance = (option.x - start.x) ** 2 + (option.y - start.y) ** 2;
    if (distance < bestDistance) {
      bestDistance = distance;
      best = option;
    }
  }
  return best ?? start;
}

/** How close two edges have to be before the shift-drag guides call them
 *  aligned. Small enough that free placement still feels free, wide enough that
 *  a pointer can find the line without a fight. */
const WIDGET_GUIDE_TOLERANCE = 6;

/** The three reference lines across a rect's width — left edge, centre, right
 *  edge. The same three exist down its height. Both are derived from `left` and
 *  `width` rather than read off `right`/`bottom`, because the callers pass the
 *  dragged widget's size as `{ left, top, width, height }` — an object that has
 *  no `right` at all, and a helper that read one would hand every caller
 *  `undefined` edges and comparisons that never come out true. */
function widgetGuideColumns(rect) {
  return [rect.left, rect.left + rect.width / 2, rect.left + rect.width];
}

function widgetGuideRows(rect) {
  return [rect.top, rect.top + rect.height / 2, rect.top + rect.height];
}

/** The reference coordinates a dragged widget could line up with: every other
 *  panel's three columns and three rows, plus the viewport's own centre pair,
 *  which is what makes centring a widget easy. */
function widgetGuideTargets(obstacles) {
  const targetsX = [window.innerWidth / 2];
  const targetsY = [window.innerHeight / 2];
  for (const o of obstacles) {
    targetsX.push(...widgetGuideColumns(o));
    targetsY.push(...widgetGuideRows(o));
  }
  return { targetsX, targetsY };
}

/** How far the widget should move to sit on the nearest alignment.
 *
 *  Every one of the dragged widget's three columns is compared with every
 *  column of every other panel plus the viewport's own centre, and likewise for
 *  the rows. A match inside the tolerance contributes a candidate nudge that
 *  would put the matching edge exactly on the other party's coordinate; the
 *  smallest one wins, so the snap pulls toward the nearest alignment rather than
 *  to whichever pair happened to be tested first.
 *
 *  Snapping is the point rather than a nicety: a guide a widget cannot actually
 *  land on is decoration, and the user asked for help placing things. The
 *  caller still runs the result through the collision resolver and the clamp —
 *  a guide pull must never be the reason two panels end up overlapping. */
function widgetGuideSnap(x, y, size, obstacles) {
  const columns = widgetGuideColumns({ left: x, top: y, width: size.width, height: size.height });
  const rows = widgetGuideRows({ left: x, top: y, width: size.width, height: size.height });
  const { targetsX, targetsY } = widgetGuideTargets(obstacles);

  let shiftX = 0;
  let shiftY = 0;
  let hasX = false;
  let hasY = false;
  for (const target of targetsX) {
    for (const column of columns) {
      const delta = target - column;
      if (Math.abs(delta) > WIDGET_GUIDE_TOLERANCE) continue;
      if (!hasX || Math.abs(delta) < Math.abs(shiftX)) {
        shiftX = delta;
        hasX = true;
      }
    }
  }
  for (const target of targetsY) {
    for (const row of rows) {
      const delta = target - row;
      if (Math.abs(delta) > WIDGET_GUIDE_TOLERANCE) continue;
      if (!hasY || Math.abs(delta) < Math.abs(shiftY)) {
        shiftY = delta;
        hasY = true;
      }
    }
  }
  return { x: x + shiftX, y: y + shiftY };
}

/** The guide lines a position calls for. Run after the collision resolver has
 *  had its say: the widget often ends up beside a panel rather than exactly on
 *  the guide it was pulled toward, and the line has to mark where the widget
 *  actually sits or it is a lie. Every target a reference now lands on gets a
 *  line, so a widget square with two neighbours shows both. */
function widgetGuidesAt(x, y, size, obstacles) {
  const columns = widgetGuideColumns({ left: x, top: y, width: size.width, height: size.height });
  const rows = widgetGuideRows({ left: x, top: y, width: size.width, height: size.height });
  const { targetsX, targetsY } = widgetGuideTargets(obstacles);
  const verticals = new Set();
  const horizontals = new Set();
  for (const target of targetsX) {
    if (columns.some((column) => Math.abs(column - target) <= 0.5)) verticals.add(Math.round(target));
  }
  for (const target of targetsY) {
    if (rows.some((row) => Math.abs(row - target) <= 0.5)) horizontals.add(Math.round(target));
  }
  return { verticals: [...verticals], horizontals: [...horizontals] };
}

/** The guide overlay, built on first use and kept for the life of the page. A
 *  layer per gesture would be a node created and dropped on every drag; this
 *  one is created once and only its handful of lines are rebuilt. It is empty
 *  — and so invisible — whenever no shift-drag is running. */
let widgetGuideLayer = null;

function widgetGuideLayerNode() {
  if (widgetGuideLayer && widgetGuideLayer.isConnected) return widgetGuideLayer;
  widgetGuideLayer = node("div", "wg-guides");
  widgetGuideLayer.setAttribute("aria-hidden", "true");
  document.body.append(widgetGuideLayer);
  return widgetGuideLayer;
}

/** Draw the lines the current pointer position calls for. Rebuilt wholesale
 *  rather than diffed: there are rarely more than a few, and a move that
 *  matches nothing has to leave the layer empty. */
function paintWidgetGuides(verticals, horizontals) {
  const layer = widgetGuideLayerNode();
  const lines = [
    ...verticals.map((x) => {
      const line = node("div", "wg-guide");
      line.dataset.axis = "x";
      line.style.left = `${x}px`;
      return line;
    }),
    ...horizontals.map((y) => {
      const line = node("div", "wg-guide");
      line.dataset.axis = "y";
      line.style.top = `${y}px`;
      return line;
    }),
  ];
  layer.replaceChildren(...lines);
}

/** Drop the guides. Called on release and on cancel — a gesture that ends any
 *  way at all must not leave a ruler on the page, and a cancelled one must not
 *  strand lines for the next drag to inherit. */
function clearWidgetGuides() {
  if (widgetGuideLayer) widgetGuideLayer.replaceChildren();
}

/** Cascade the widgets that have no stored position yet, so a fresh profile
 *  gets a readable arrangement instead of eight panels stacked at 0,0. */
function autoPosition(index) {
  return { x: 24 + (index % 3) * 300, y: 120 + Math.floor(index / 3) * 260 };
}

/** The width `.wg` is laid out at, and so the number a scale multiplies. Kept
 *  beside the usage rather than read off the stylesheet, because the clamping
 *  math needs it before the panel is in the DOM — an unparented element reports
 *  an offset of 0, which would silently let every widget be dragged off-screen
 *  on the first paint.
 *
 *  The calendar is narrower because its content is: seven 16px columns are
 *  112px, and the 268px default would leave the grid floating in a panel more
 *  than half empty. The stylesheet has to agree — `.wg[data-widget="calendar"]`
 *  carries the same number.
 *
 *  The shortcuts kind is listed at its *grid* width, but its single-icon variant
 *  is narrower still (92px). A variant cannot be keyed in this map — it is a
 *  property of the entry, not the kind — so `widgetBaseWidth` checks it below,
 *  and `.wg[data-widget="shortcuts"][data-variant="single"]` carries the 92. */
const WIDGET_SINGLE_WIDTH = 92;
const WIDGET_BASE_WIDTHS = { calendar: 168, clock: 172 };
const WIDGET_BASE_WIDTH = 268;

/** A widget's laid-out width before scaling, by kind — and, for the one kind
 *  whose single-icon layout is a block rather than a panel, by variant. */
function widgetBaseWidth(spec) {
  const kind = NEWTAB_SAFE.widgetKindOf(spec);
  if (kind === "shortcuts" && spec?.variant === "single") return WIDGET_SINGLE_WIDTH;
  return WIDGET_BASE_WIDTHS[kind] ?? WIDGET_BASE_WIDTH;
}

/** A widget's rendered width at its scale. */
function widgetWidth(spec, scale) {
  return widgetBaseWidth(spec) * scale;
}

/** A widget's rendered width, preferring its own over the kind's.
 *
 *  Three things can decide this and the order matters: an explicit width the
 *  user chose wins outright, then the kind's own base (a calendar is narrower
 *  than everything else), and the scale multiplies whichever of the two won — so
 *  a widened panel that is then scaled up grows from the width it was given
 *  rather than snapping back to its kind's. */
function widgetRenderedWidth(spec, settings) {
  const own = NEWTAB_SAFE.widgetWidthFor(settings, spec.id);
  return (own ?? widgetBaseWidth(spec)) * NEWTAB_SAFE.widgetScaleFor(settings, spec.id);
}

/** Write the calendar's cell-growth factor onto a panel.
 *
 *  The one kind whose body is a grid of fixed-size cells rather than a flowing
 *  list: the other widgets get wider by fitting more per row at the same type
 *  size, which is what width means for them, but a month grid has exactly seven
 *  columns and no row to add. Widening it would otherwise buy nothing but empty
 *  space around the same small month, so the cells themselves grow — see the
 *  `--cal-scale` rules in newtab.css, which every part of the drawing reads.
 *
 *  Measured from the panel's *layout* width — `ownWidth`, the same number the
 *  inline width above was written from — and deliberately not from
 *  `widgetRenderedWidth`. Size is a CSS `transform`, so a panel at 2× is still
 *  168px in layout and the transform magnifies the grown cells along with
 *  everything else. Counting the multiplier here as well grew the cells for a
 *  336px box inside a 168px one and then magnified them again, which is why a
 *  large calendar overflowed its own body. Width is the only axis the grid can
 *  spend; size already handles size.
 *
 *  The base is the left side of the clamp in the stylesheet's per-kind rule, and
 *  the two have to agree — `widgetBaseWidth` is the same number for the same
 *  reason it is for the width itself.
 *
 *  Square-rooted rather than linear, and capped: the grid can only use so much
 *  of a wide panel before the cells outgrow the words in them, and the day
 *  numbers running to 100px type in a 640px panel would be a poster, not a
 *  widget. The root keeps the first few steps of widening visible — which is
 *  where the user actually is — without the last few becoming absurd. */
function applyCalendarScale(panel, spec, ownWidth) {
  if (NEWTAB_SAFE.widgetKindOf(spec) !== "calendar") return;
  const base = WIDGET_BASE_WIDTHS.calendar;
  const layout = ownWidth ?? base;
  const growth = Math.max(0, layout / base - 1);
  const factor = Math.min(CAL_SCALE_MAX, 1 + Math.sqrt(growth) * 0.55);
  panel.style.setProperty("--cal-scale", factor.toFixed(3));
}

/** The most a calendar's cells may grow, however wide the panel gets. Chosen so
 *  the day numbers stay legible as a month and not as a wall chart: at this
 *  factor the grid is a little over twice its shipped size. */
const CAL_SCALE_MAX = 2.2;

/** The header's tab switcher for a connected tasks panel: the shared list on one
 *  side, the widget's own account/local lists on the other.
 *
 *  A connection *adds* a view rather than replacing one — which is what makes a
 *  panel that was already earning its place worth connecting without giving up
 *  what it showed. The two labels are the two sources by name: the link's page,
 *  and the lists the widget drew before it was connected. "My lists" covers both
 *  the account's and the local store's, which is the point — the tab is "not the
 *  shared one", and which store is behind it is the body's business, not a
 *  second label's.
 *
 *  Pressing a tab writes the choice and repaints only this body: the switcher
 *  owns its own visual state, and a full `renderWidgets` would close menus and
 *  re-measure every panel on the page for a change that touches one. The body
 *  re-reads the tab out of storage on its way in, so the two cannot disagree. */
function buildTaskTabs(spec, link) {
  const rail = node("div", "wg-task-tabs");
  const tabs = [
    { id: "shared", label: "Shared" },
    { id: "own", label: "My lists" },
  ];
  const buttons = new Map();
  for (const tab of tabs) {
    const button = node("button", tab.id === link.tab ? "wg-task-tab is-active" : "wg-task-tab", tab.label);
    button.type = "button";
    button.addEventListener("click", async () => {
      if (tab.id === link.tab) return;
      // Written before the repaint so the body reads the new tab. Read from
      // storage rather than spreading this render's `link`, which was read
      // before any menu action since: a switch to "My lists" would otherwise
      // carry the shared link back in and undo a Disconnect.
      const current = NEWTAB_SAFE.todoLinkOf(spec?.data);
      if (!current) return;
      await NEWTAB_SAFE.setWidgetData(spec.id, { todoLink: { ...current, tab: tab.id } });
      link.tab = tab.id;
      for (const [id, b] of buttons) b.classList.toggle("is-active", id === tab.id);
      // Switching to the Shared tab is entering the list, so an unlock prompt is
      // the right answer there.
      await repaintTasksWidget(spec, true);
    });
    buttons.set(tab.id, button);
    rail.append(button);
  }
  // The header is the panel's drag handle; the tabs are not part of it. Stopped
  // here rather than by a class the drag handler would have to know about,
  // because the press lands on the button inside the rail and a capture on the
  // button is the narrowest place that catches it.
  rail.addEventListener("pointerdown", (e) => e.stopPropagation());
  return rail;
}

function buildWidget(spec, settings) {
  const panel = node("section", "wg");
  // The *kind*, not the id: `data-widget` is what the stylesheet matches, and
  // every rule in it is written per kind. A second shortcuts panel has an id
  // nothing could match, so it would render with no width, no material and no
  // header row — the id would style it as an unknown widget. The per-instance
  // stacking and position still key on the id via `widgetPanels`.
  panel.dataset.widget = NEWTAB_SAFE.widgetKindOf(spec);
  // The instance's own id, so a caller that knows which widget it just made can
  // find the panel it became. Nothing in the stylesheet keys off this; the paste
  // gesture is what needs it, to point at the block it has just placed.
  panel.dataset.id = spec.id;
  // The one line that carries a widget's style to the screen. `data-style` is
  // what the six blocks in newtab.css key off, and `widgetStyleFor` is where the
  // per-widget override and the page-wide default are resolved — so a widget
  // that never chose a style follows the page, and one that did keeps its own
  // even when the page's changes.
  panel.dataset.style = NEWTAB_SAFE.widgetStyleFor(settings, spec.id);

  // Which layout the body draws, for the kinds that have more than one. Written
  // as an attribute on the panel so the stylesheet can restyle the whole widget
  // per variant, and read back by the renderer through the same resolver — so
  // the attribute and the body can never disagree.
  const variant = NEWTAB_SAFE.widgetVariantFor(settings, spec.id);
  if (variant) panel.dataset.variant = variant;

  // Which calendar the panel counts in — its own second axis, for the one kind
  // that has it. The layout above can stay layout-neutral in CSS, but a month
  // name in Arabic or Persian is a different width from "October", and the
  // stylesheet needs to know which it is holding to size the caption and the
  // year columns. Written for every calendar, Gregorian included, so the
  // selector is a plain match rather than "when not the default".
  if (NEWTAB_SAFE.widgetKindOf(spec) === "calendar") {
    panel.dataset.calendar = NEWTAB_SAFE.calendarSystemFor(settings, spec.id);
  }

  // The face the panel's own contents wear, for every kind — a Persian face is
  // as much a choice for a timer's digits or a weather day's temperature as for
  // a calendar's month name. `data-font` rather than `data-cal-font` because the
  // rule that applies it is not per kind; the stylesheet matches the id, and the
  // widget's labels stay English while its dates and numerals follow the locale
  // the same choice implies (see `WIDGET_FONTS`).
  panel.dataset.font = NEWTAB_SAFE.widgetFontFor(settings, spec.id);

  // The title bar's visibility, as an attribute the stylesheet matches. The
  // header stays in the DOM when it is hidden — it is collapsed to nothing and
  // slides back on hover, rather than removed, because it is the panel's only
  // drag handle and a widget you cannot move is worse than one with a title on
  // it. See the rules in newtab.css for how the reveal works.
  if (NEWTAB_SAFE.widgetHeaderHidden(settings, spec.id)) panel.dataset.header = "hidden";

  // The widget's own width, if it has one. Written as an inline width rather than
  // a class so the three stored values that decide it — the user's choice, the
  // kind's base, the scale — stay resolved in one place (`widgetRenderedWidth`).
  // The stylesheet's per-kind width is the fallback, so a widget that never
  // chose one is still the width its kind was designed at. The single-icon block
  // is exempt: it is 92px by definition and its kind's rule is what says so.
  const ownWidth = NEWTAB_SAFE.widgetWidthFor(settings, spec.id);
  // Resolved through the same resolver the `data-variant` attribute above came
  // from rather than read back off that attribute: this runs before the `bare`
  // local is declared, and reading the attribute here would be a second,
  // subtly-different answer to the question the line above already asked.
  if (ownWidth != null && variant !== "single") panel.style.width = `${ownWidth}px`;
  // How much wider than shipped this panel is, for the one kind whose contents
  // are drawn on a grid of fixed-size cells. Set from the same two numbers the
  // inline width above came from, so a widened calendar grows its month rather
  // than surrounding a small one with empty space — see `applyCalendarScale`.
  applyCalendarScale(panel, spec, ownWidth);

  // The widget's size, as a transform rather than a width. `scale()` is the one
  // thing that grows the type, the padding and the icons together; setting a
  // width would stretch the box and leave every glyph at its design size, which
  // is a wider widget rather than a bigger one. `transform-origin: top left`
  // (in the stylesheet) keeps `left`/`top` meaning the panel's real top-left
  // corner, so the drag math below stays the arithmetic it already was.
  const scale = NEWTAB_SAFE.widgetScaleFor(settings, spec.id);
  if (scale !== 1) panel.style.transform = `scale(${scale})`;
  panel.style.transformOrigin = "top left";

  // The stacking order. The `#widgets` host is `position: fixed; inset: 0` and
  // is itself pointer-events-none, so a z-index written here competes only with
  // the other panels inside it — the page's own layers (decor, gear, panel) are
  // siblings of the host and are unaffected. That is the point: bringing a
  // widget forward must not lift it over the settings panel.
  panel.style.zIndex = String(NEWTAB_SAFE.widgetZFor(settings, spec.id));

  // The single-icon layout *is* the icon: no header, no frame, no padding —
  // the panel is drawn empty so all that is left of it is the tile. It is the
  // one variant that drops the chrome rather than restyling it, which is why
  // it is decided here instead of in the stylesheet: a header the DOM never got
  // cannot be laid out, clicked, or caught by a `[data-header]` rule.
  const bare = panel.dataset.variant === "single";

  const body = node("div", "wg-body");
  const resize = buildResizeGrip(spec, panel);

  if (bare) {
    // No × and no ⋮. The block is one icon and the right-click menu is the whole
    // control surface — a persistent pair of glyphs on a 92px block would be
    // most of what is drawn. Moving is the tile's own gesture (see
    // `shortcutsSingle`), and hiding, resizing and taking the panel off the page
    // are all in the menu.
    //
    // The resize grip stays. It is 10px in a corner, it is only visible under
    // the pointer, and it is the one control with no menu equivalent beyond the
    // three fixed steps — without it the block could only ever take those.
    panel.append(body, resize);
    // On the body rather than on the tile: the renderer hangs its own
    // right-click, which edits the pinned site, on the tile, and it has to win
    // there. Everywhere else in the block, the menu is what a right-click gets.
    body.addEventListener("contextmenu", (e) => {
      e.preventDefault();
      openWidgetMenu(e, spec);
    });
    widgetPanels.set(spec.id, { panel, body });
    return panel;
  }

  const header = node("header", "wg-head");
  const grip = node("span", "wg-grip", "⠿");
  grip.setAttribute("aria-hidden", "true");
  // The instance's own name, not the kind's: two shortcuts panels are told apart
  // by their headers, and a rename has to show up here as well as in the list.
  const title = node("span", "wg-title", NEWTAB_SAFE.widgetLabelOf(spec));
  const close = node("button", "wg-close", "×");
  close.type = "button";
  close.title = "Hide this widget";
  close.setAttribute("aria-label", `Hide ${NEWTAB_SAFE.widgetLabelOf(spec)}`);
  header.append(grip, title);
  // A connected tasks panel carries the two-tab switcher in its header. Read off
  // the merged `settings` this function was already handed rather than a fresh
  // read, so the header and the body built from the same blob agree.
  const taskLink =
    NEWTAB_SAFE.widgetKindOf(spec) === "tasks"
      ? NEWTAB_SAFE.todoLinkOf(settings.widgets.find((w) => w.id === spec.id)?.data)
      : null;
  if (taskLink) header.append(buildTaskTabs(spec, taskLink));
  // A timers panel starts a timer from a "+" in its own header rather than a
  // full-width button in the body. The button belongs to the widget's chrome,
  // not to whichever layout the body happens to be drawing, so it is here —
  // where every other panel keeps its header controls — and it is present under
  // both layouts.
  const headerKind = NEWTAB_SAFE.widgetKindOf(spec);
  // The list chooser sits beside the panel's other header controls: which list a
  // tasks panel draws is a property of the panel, not of the body it is wearing.
  // Built empty and filled from the same read the body makes — see
  // `paintTasksHeaderList`.
  const headerList = headerKind === "tasks" ? buildTasksHeaderList(spec) : null;
  if (headerList) header.append(headerList);
  const headerAdd =
    headerKind === "timers"
      ? buildTimersHeaderAdd(spec)
      : headerKind === "tasks"
        ? buildTasksHeaderSettings(spec)
        : null;
  if (headerAdd) header.append(headerAdd);
  // A bookmarks panel offers a filter and an add in the same place, for the
  // same reason: they belong to the panel, not to the layout the body is
  // wearing, and the shipped layout had neither.
  const kind = NEWTAB_SAFE.widgetKindOf(spec);
  const headerTools =
    kind === "bookmarks" ? buildBookmarksHeaderTools(spec) : null;
  if (headerTools) header.append(headerTools);
  header.append(close);

  panel.append(header, body, resize);

  // The whole header is the drag handle, but the header's own buttons are not —
  // they sit inside it, and their click would otherwise start a drag.
  header.addEventListener("pointerdown", (e) => {
    if (e.target === close || (headerAdd && headerAdd.contains(e.target)) || (headerTools && headerTools.contains(e.target))) return;
    startDrag(e, panel, spec.id);
  });

  // Right-click on the header opens the context menu. On the header rather than
  // on the whole panel so a right-click on a bookmark row or a link keeps the
  // browser's own menu — those have things to offer (open in a new tab, copy the
  // address) that a widget menu would only get in the way of.
  header.addEventListener("contextmenu", (e) => {
    e.preventDefault();
    openWidgetMenu(e, spec);
  });

  close.addEventListener("click", async () => {
    await NEWTAB_SAFE.setWidgetVisible(spec.id, false);
    renderWidgets();
  });

  // Remembered for `repaintTimersWidget`: the panel outlives each body drawn
  // into it, so the pair stays a handle on what is on the page rather than on
  // what was once appended.
  panel[TIMERS_PANEL_BODY] = body;
  widgetPanels.set(spec.id, { panel, body });
  return panel;
}

/**
 * The corner grip. Drag it and the widget scales; it is the same gesture the
 * decor art already uses, on a different thing.
 *
 * It is a child of the *panel* and not of the body, because `.wg-body` is
 * `overflow-y: auto` and clips anything that overflows it — a grip parked in the
 * corner would be cut off the moment the body had something to scroll. The panel
 * itself clips nothing, so this is where it has to live.
 *
 * Width is the free number, unlike the decor's height: a widget's height comes
 *  from its content and there is no sensible way to drag it to one, whereas a
 *  width is exactly what decides whether a bookmark title fits on one line. The
 *  grip writes the *width*, not the scale — it is the free-form half of the
 *  menu's Width submenu, the way a slider is the free-form half of a set of
 *  steps, and it lands on the same `setWidgetWidth` the submenu calls.
 */
function buildResizeGrip(spec, panel) {
  const grip = node("span", "wg-resize", "◢");
  grip.title = "Drag to resize";
  grip.setAttribute("aria-hidden", "true");
  grip.addEventListener("pointerdown", (e) => startWidgetResize(e, panel, spec.id));
  return grip;
}

function startWidgetResize(event, panel, id) {
  if (event.button !== 0) return;
  // Without this the browser starts a text selection on the first move and the
  // rest of the drag is the selection doing the moving.
  event.preventDefault();
  // Or the pointerdown reaches the header underneath and moves the widget while
  // it is being resized.
  event.stopPropagation();

  const startX = event.clientX;
  const spec = layoutState.find((w) => w.id === id) ?? { id };
  const scale = NEWTAB_SAFE.widgetScaleFor({ widgets: [spec] }, id);
  // The single-icon block keeps the old scale gesture. It is 92px by definition
  // and its Width entry is withheld for that reason, so a grip that wrote a
  // width would be the one way to break that rule — and there would be no way
  // back, since the menu offers no width entry to reset. Scaling it is the
  // honest gesture here: the icon grows, and the block stops being a thumbnail.
  const scalesOnly = NEWTAB_SAFE.widgetVariantFor({ widgets: [spec] }, id) === "single";
  // The rendered width over the scale is the unscaled width, which is how this
  // avoids depending on `widgetBaseWidth` — the calendar's narrower panel is
  // already accounted for in the rect, and so is a width the user already chose.
  const rendered = panel.getBoundingClientRect().width;
  // The unscaled width the gesture starts from. For the scaling case this is the
  // denominator the scale is read back out of; for the width case it is the
  // starting value, though `nextWidth` works from `rendered` either way.
  const base = rendered / scale;

  panel.classList.add("is-resizing");
  panel.setPointerCapture(event.pointerId);

  function nextWidth(e) {
    // The target is in *rendered* px; the stored value is unscaled, so the
    // pointer delta is divided by the scale before it is clamped. Clamped here
    // as well as in the store so the drag stops against the limits instead of
    // running past them and springing back on release.
    const target = (rendered + (e.clientX - startX)) / scale;
    return Math.min(NEWTAB_SAFE.WIDGET_WIDTH_MAX, Math.max(NEWTAB_SAFE.WIDGET_WIDTH_MIN, target));
  }

  function move(e) {
    if (scalesOnly) {
      panel.style.transform = `scale(${Math.min(2, Math.max(0.6, (rendered + (e.clientX - startX)) / base))})`;
      return;
    }
    // Written unscaled: the transform (if any) is still in force on the panel,
    // so this is the width the panel would have at scale 1 and the browser
    // multiplies it out. That is what keeps the corner under the pointer.
    panel.style.width = `${Math.round(nextWidth(e))}px`;
  }

  function up(e) {
    panel.classList.remove("is-resizing");
    panel.removeEventListener("pointermove", move);
    panel.removeEventListener("pointerup", up);
    panel.removeEventListener("pointercancel", up);
    if (scalesOnly) {
      // Read off the rect rather than re-deriving, because the transform above
      // and the browser's own rounding can disagree by a hair.
      const next = Math.min(2, Math.max(0.6, panel.getBoundingClientRect().width / base));
      NEWTAB_SAFE.setWidgetScale(id, next).then(() => renderWidgets());
      return;
    }
    // On release, not during: the position has to be re-clamped against the new
    // width, and a full re-render per pointermove would drag sixty times a
    // second. Read from the same function the last paint used rather than off
    // the rect, for the same rounding reason.
    NEWTAB_SAFE.setWidgetWidth(id, Math.round(nextWidth(e))).then(() => renderWidgets());
  }

  panel.addEventListener("pointermove", move);
  panel.addEventListener("pointerup", up);
  panel.addEventListener("pointercancel", up);
}

/** Pointer-based drag. Pointer events rather than HTML5 drag-and-drop because
 *  those need a draggable element and a drop target, and this is free movement
 *  over the page rather than a transfer between lists. */
function startDrag(event, panel, id) {

  if (event.button !== 0) return;
  const rect = panel.getBoundingClientRect();
  const offsetX = event.clientX - rect.left;
  const offsetY = event.clientY - rect.top;
  // Measured once, from the rect rather than from the layout box: a scaled
  // widget's rect is the size the user sees, and reading it here keeps the
  // gesture from forcing a layout on every frame.
  const width = rect.width;
  const height = rect.height;

  // Both the collision set and the overlap rule are settled before the first
  // move: the other panels do not move during this gesture, so their rects are
  // read once here, and the setting is read once into a boolean because
  // `pointermove` must not await storage. Reading it at grab time also means
  // toggling the switch mid-drag cannot leave the gesture half-ruled.
  const obstacles = widgetDragObstacles(id);
  const size = { width, height };
  let noOverlap = true;
  Promise.resolve(NEWTAB_SAFE.get())
    .then((settings) => {
      noOverlap = !NEWTAB_SAFE.widgetOverlapAllowed(settings);
    })
    .catch(() => {});

  // A layer from a previous gesture that ended without a pointerup — a
  // cancelled one, or a page that lost the pointer — must not be inherited.
  clearWidgetGuides();

  // The gesture is only a drag once it has *moved*, not the moment it is
  // pressed, so the two things sharing this handle — the header as a move grip,
  // and the single-icon tile as a link — can be told apart. Capture is the
  // reason this has to be deferred rather than assumed: it retargets the
  // trailing click to the panel, so capturing on the press would eat the link's
  // own navigation and a plain click on the tile would do nothing. Until the
  // slop is crossed nothing is captured and no panel is marked, and the click
  // reaches whatever is under the pointer.
  const startX = event.clientX;
  const startY = event.clientY;
  let dragging = false;
  // The live panel size, kept current so the on-screen clamp is always measured
  // against what the user actually sees. It starts from the rect read above and
  // is refreshed on each drag because a *vertical* resize (or a scale done from
  // the corner) can make the panel taller or wider than it was when the gesture
  // grabbed it — clamping to the grabbed width would then let the new edge hang
  // past the screen. One rect read per frame only while the size is changing; the
  // common case is the same two numbers and costs a comparison.
  let panelW = width;
  let panelH = height;
  const measure = () => {
    const r = panel.getBoundingClientRect();
    if (r.width !== panelW || r.height !== panelH) {
      panelW = r.width;
      panelH = r.height;
    }
  };

  function move(e) {
    if (!dragging) {
      if (Math.hypot(e.clientX - startX, e.clientY - startY) < WIDGET_DRAG_SLOP) return;
      dragging = true;
      panel.classList.add("is-dragging");
      // Set once, when the gesture actually becomes a drag: capturing on every
      // move would leak a capture per frame. Best-effort like the search box's —
      // a synthetic event, or a pointer the browser has already released, throws
      // and would otherwise abort the whole drag.
      try {
        panel.setPointerCapture(event.pointerId);
      } catch {
        /* tracking still works while the pointer is over the panel */
      }
    }
    // The order here is the order the two features were asked for: the raw
    // pointer position, then the shift-guide pull toward an alignment, then the
    // refusal to overlap, and only then the clamp that keeps the panel on
    // screen. Collision avoidance runs last of the position rules so a guide
    // can never be the reason a widget ends up covering another one.
    let x = e.clientX - offsetX;
    let y = e.clientY - offsetY;
    const guides = e.shiftKey;
    if (guides) {
      const snapped = widgetGuideSnap(x, y, size, obstacles);
      x = snapped.x;
      y = snapped.y;
    }
    if (noOverlap) {
      const resolved = resolveWidgetCollisions(x, y, size, obstacles);
      x = resolved.x;
      y = resolved.y;
    }
    measure();
    const clamped = clampPosition(x, y, panelW, panelH);
    panel.style.left = `${clamped.x}px`;
    panel.style.top = `${clamped.y}px`;
    if (guides) {
      const lines = widgetGuidesAt(clamped.x, clamped.y, size, obstacles);
      paintWidgetGuides(lines.verticals, lines.horizontals);
    } else {
      clearWidgetGuides();
    }
  }

  function up() {
    // The listeners always come off, dragging or not: a click that never moved
    // still has this press's `move` and `up` on the window, and leaving them
    // there would stack a fresh pair per click.
    window.removeEventListener("pointermove", move);
    window.removeEventListener("pointerup", up);
    window.removeEventListener("pointercancel", up);
    // Nothing moved, so nothing was dragged: no class was added, no capture was
    // taken, and there is no new position to write. Writing here anyway would
    // turn every click on a header into a storage write.
    if (!dragging) return;
    panel.classList.remove("is-dragging");
    clearWidgetGuides();
    const rect2 = panel.getBoundingClientRect();
    // Written on release rather than during the drag: a storage write per
    // pointermove would be hundreds of writes per gesture for one final value.
    NEWTAB_SAFE.setWidgetPosition(id, Math.round(rect2.left), Math.round(rect2.top));
  }

  // On the window rather than on the panel: capture is only taken once the
  // gesture becomes a drag, so before that a pointer that slips off the panel
  // would otherwise leave the listeners behind and strand the gesture.
  window.addEventListener("pointermove", move);
  window.addEventListener("pointerup", up);
  window.addEventListener("pointercancel", up);
}

// One armed move, or null. Held outside `startMoveMode` so a second arming can
// tear the first one down: two panels both following the pointer is not a state
// anything could recover from, and the one that lost would keep its dashed
// outline with no listener left able to drop it.
let moveModeState = null;

/** Put a widget on the pointer without a drag handle to grab.
 *
 *  A drag cannot be started from a menu entry. The entry is a click, so by the
 *  time this runs the button is already up — there is no pointerdown left to
 *  capture, and synthesizing one would race the menu's own gesture. So the entry
 *  arms a *mode* instead: the panel tracks the pointer, and the next press
 *  anywhere puts it down. That is also why the held look matters (`.is-moving`,
 *  in newtab.css) — with the menu closed and no button down, nothing else on
 *  screen would say which panel is following the pointer.
 *
 *  The drop is read off the panel's own rect and written once, exactly as
 *  `startDrag` does it: a storage write per pointermove would be hundreds of
 *  writes for one final value. */
function startMoveMode(id, anchor) {
  cancelMoveMode();
  const entry = widgetPanels.get(id);
  if (!entry) return;
  const { panel } = entry;

  const rect = panel.getBoundingClientRect();
  // Measured once, as in `startDrag` — a scaled panel's rect is the size the
  // user sees, and the others do not move during this gesture. The live copy is
  // refreshed on each move so the on-screen clamp uses whatever the panel's real
  // size is by then; a fixed measurement let a panel that grew after arm time be
  // dropped past the bottom edge.
  let size = { width: rect.width, height: rect.height };
  const origin = { x: rect.left, y: rect.top };
  const obstacles = widgetDragObstacles(id);
  let noOverlap = true;
  Promise.resolve(NEWTAB_SAFE.get())
    .then((settings) => {
      noOverlap = !NEWTAB_SAFE.widgetOverlapAllowed(settings);
    })
    .catch(() => {});

  function measure() {
    const r = panel.getBoundingClientRect();
    if (r.width !== size.width || r.height !== size.height) {
      size = { width: r.width, height: r.height };
    }
  }

  function move(e) {
    // The panel is put *under* the pointer, not offset by wherever a grab
    // happened. With a drag the offset is what makes a panel feel held — your
    // hand is on a spot and the panel keeps that spot under it. Here there is no
    // grab: the entry was clicked on a menu row somewhere across the screen, and
    // the widget is being *placed*. Carrying that row as an offset would park
    // the panel a menu's-width away from the cursor and leave the last step of
    // every move as a nudge. Under the pointer, the spot being pointed at is the
    // spot the widget takes.
    //
    // Same order as a dragged panel — pointer, then guide pull, then the refusal
    // to overlap, then the clamp — so a widget moved from the menu and one
    // dragged by its header land in the same places.
    let x = e.clientX;
    let y = e.clientY;
    if (e.shiftKey) {
      const snapped = widgetGuideSnap(x, y, size, obstacles);
      x = snapped.x;
      y = snapped.y;
    }
    if (noOverlap) {
      const resolved = resolveWidgetCollisions(x, y, size, obstacles);
      x = resolved.x;
      y = resolved.y;
    }
    measure();
    const clamped = clampPosition(x, y, size.width, size.height);
    panel.style.left = `${clamped.x}px`;
    panel.style.top = `${clamped.y}px`;
    if (e.shiftKey) {
      const lines = widgetGuidesAt(clamped.x, clamped.y, size, obstacles);
      paintWidgetGuides(lines.verticals, lines.horizontals);
    } else {
      clearWidgetGuides();
    }
  }

  function drop(e) {
    // The press that puts the panel down must not also land on the page. The
    // widget has just been carried out from under the pointer, so whatever is
    // beneath it now is not something the user aimed at — without this, putting
    // a widget down over a bookmark would open the bookmark.
    e.preventDefault();
    e.stopPropagation();
    const box = panel.getBoundingClientRect();
    NEWTAB_SAFE.setWidgetPosition(id, Math.round(box.left), Math.round(box.top));
    cancelMoveMode();
    suppressNextClick();
  }

  function key(e) {
    if (e.key !== "Escape") return;
    // Escape is the cancel, and cancel means back where it started — not "put
    // down here", which is what the press is for. Anything else would make the
    // two ways out of this mode the same gesture.
    panel.style.left = `${origin.x}px`;
    panel.style.top = `${origin.y}px`;
    e.stopPropagation();
    cancelMoveMode();
  }

  // A right-click during the move is someone trying to open the menu again.
  // Suppressed rather than passed through: the menu would open anchored to a
  // panel that is still following the pointer.
  function blockContext(e) {
    e.preventDefault();
    e.stopPropagation();
  }

  panel.classList.add("is-moving");

  // Placed under the cursor straight away rather than waiting for the first
  // move: the mode is armed by a click, and a click that does nothing visible
  // reads as one that did not register. The anchor is that click, so this is the
  // same position the first pointermove would have produced.
  if (anchor && Number.isFinite(anchor.clientX)) {
    move({ clientX: anchor.clientX, clientY: anchor.clientY, shiftKey: false });
  }

  window.addEventListener("pointermove", move);
  // On the window, so the press can land anywhere — a bookmark row, a search
  // box — and in the capture phase, because those own handlers must not run.
  window.addEventListener("pointerdown", drop, true);
  window.addEventListener("contextmenu", blockContext, true);
  window.addEventListener("keydown", key, true);

  moveModeState = { panel, move, drop, blockContext, key };
}

/** Swallow the click that trails a move's drop. The pointerdown half is stopped
 *  in `drop` itself, but the click comes after the release and by then the
 *  move's listeners are gone — so this registers its own, takes itself off on
 *  the click it eats, and gives up after a moment in case no click follows at
 *  all (a press that never became one). */
function suppressNextClick() {
  const swallow = (e) => {
    e.preventDefault();
    e.stopPropagation();
    window.removeEventListener("click", swallow, true);
  };
  window.addEventListener("click", swallow, true);
  setTimeout(() => window.removeEventListener("click", swallow, true), 400);
}

function cancelMoveMode() {
  const state = moveModeState;
  if (!state) return;
  moveModeState = null;
  state.panel.classList.remove("is-moving");
  clearWidgetGuides();
  window.removeEventListener("pointermove", state.move);
  window.removeEventListener("pointerdown", state.drop, true);
  window.removeEventListener("contextmenu", state.blockContext, true);
  window.removeEventListener("keydown", state.key, true);
}

/** Paint the widget bodies. Split from `renderWidgets` so a data refresh does
 *  not tear down the panels and lose their positions mid-session.
 *
 *  Every body is built at once rather than one after another: a body that has
 *  to await the account (`timers`, `tasks`, `bookmarks`) would otherwise hold
 *  the next one back for the length of its own round trip, so the page waited
 *  for the *sum* of the widget fetches instead of the slowest one. The bodies
 *  touch disjoint DOM — each writes only its own `entry.body` — so running them
 *  together is safe, and each keeps its own catch, so one failing widget still
 *  cannot take the rest of the page down with it. */
async function paintWidgetBodies() {
  await Promise.all(
    layoutState.map(async (spec) => {
      const entry = widgetPanels.get(spec.id);
      if (!entry) return;
      const renderer = WIDGET_RENDERERS[NEWTAB_SAFE.widgetKindOf(spec)];
      entry.body.replaceChildren(node("div", "wg-loading", "·"));
      try {
        // A page load (or a layout apply) is the user arriving at the widgets,
        // so it counts as entering the list: a locked panel opens with its
        // unlock prompt. Writes and background refreshes go through
        // `repaintTasksWidget` instead, which does not.
        const built = await renderer.body(spec, { entering: true });
        entry.body.replaceChildren(built);
      } catch {
        // A widget must never break the page — the account being signed out or
        // the server being down is an ordinary state on a new tab.
        entry.body.replaceChildren(node("div", "wg-empty", "Sign in from the extension to see this."));
      }
    }),
  );
}

let layoutState = [];

/** Build every visible widget from the saved layout. */
async function renderWidgets() {
  // A rebuild replaces every panel, so any open menu is now pointing at a node
  // that is about to be discarded — dismissed first rather than left floating
  // over whatever lands in its place.
  closeWidgetMenu();
  const settings = await NEWTAB_SAFE.get();
  layoutState = settings.widgets.filter((w) => w.visible && WIDGET_RENDERERS[NEWTAB_SAFE.widgetKindOf(w)]);
  const host = document.getElementById("widgets");
  if (!host) return;
  // A full rebuild replaces every panel, so every panel's clocks go with it —
  // including the ones behind an id that is no longer in the layout at all.
  for (const id of [...timerPanelTicks.keys()]) stopTimerTicks({ id });
  widgetPanels.clear();

  // The shipped clock entry is drawn by the page's own header block, not as a
  // panel, so that one entry only toggles the block. Added clocks are ordinary
  // panels and are built below with everything else.
  const clockBlock = document.getElementById("clock-block");
  if (clockBlock) clockBlock.classList.toggle("hidden", !settings.widgets.find((w) => w.id === "clock")?.visible);

  const panels = layoutState
    .filter((s) => !(NEWTAB_SAFE.widgetKindOf(s) === "clock" && s.id === "clock"))
    .map((spec, index) => {
      const panel = buildWidget(spec, settings);
      const pos = spec.x == null || spec.y == null ? autoPosition(index) : { x: spec.x, y: spec.y };
      // The scale is read from the settings rather than measured off the panel,
      // which is not in the DOM yet and would report a zero-size rect.
      const { x, y } = clampPosition(pos.x, pos.y, widgetRenderedWidth(spec, settings));
      panel.style.left = `${x}px`;
      panel.style.top = `${y}px`;
      // First paint adopts the cascade position rather than leaving it unsaved,
      // so the arrangement survives a reload without any drag having happened.
      if (spec.x == null || spec.y == null) NEWTAB_SAFE.setWidgetPosition(spec.id, x, y);
      return panel;
    });
  host.replaceChildren(...panels);

  await paintWidgetBodies();
}

window.ixiNewtabWidgets = {
  renderWidgets,
  paintWidgetBodies,
  refreshWidgetData,
  refreshClockBodies,
  WIDGET_RENDERERS,
  // `shortcuts.js` owns the page's floating icons, but the two things they act
  // on — the panel body and the site editor — were built here, with `node` and
  // the modal idiom. Exporting them keeps one implementation rather than a
  // second copy that would drift.
  repaintShortcutsWidget,
  openShortcutModal,
  // `backup.js` reads and writes these two stores as part of a save file. It
  // takes the names from here rather than repeating the literals: the store and
  // its key are one fact, and a restore writing to a key this file stopped using
  // would produce a backup that looked complete and restored nothing.
  LOCAL_TODOS_KEY,
  LOCAL_TIMERS_KEY,
  // The controls body, so a timer's own row can reach its pause and finish
  // buttons without the panel having to be switched to the "Controls" layout.
  renderTimerStudio,
  // One write for a bookmark, whichever list is live. The page's "Add bookmark
  // icon" and the panel's add form both go through it, so a shortcut placed
  // from the page shows up in the panel on the next paint.
  saveBookmark,
  dragObstacles: widgetDragObstacles,
  guideSnap: widgetGuideSnap,
  guidesAt: widgetGuidesAt,
  paintGuides: paintWidgetGuides,
  clearGuides: clearWidgetGuides,
};
