// Decorations: the art from `extension/decor/` dropped anywhere on the page.
//
// A decoration is deliberately not a widget. A widget is a *panel* — a titled
// frame with a body that scrolls, sitting at a fixed 268px layout width. The
// point of this art is that it is not that: it is a picture sitting on the page,
// sized by its own proportions, with no chrome until you reach for it.
//
// So there is no panel per placement. Each one is a bare `<img>` in a
// positioned box, and the three controls — move, resize, remove — appear on
// hover (and on focus, so they are keyboard-reachable) rather than being drawn
// all the time. What the user sees on a settled page is only the art.
//
// Everything about a placement is a setting: its position, its scale and which
// piece of art it is live in `settings.js`, which means the layout syncs to the
// account and survives a reload for free.

const DECOR_SAFE = window.ixiNewtabSettings;

/** Every live placement, by placement id. Kept so a repaint can update an
 *  element in place instead of rebuilding the layer — rebuilding mid-drag would
 *  delete the node the pointer is captured on. */
const decorNodes = new Map();

/** The layer itself. Fixed, full-viewport, and click-through — only the
 *  placements inside it take pointer events, so the empty space between them
 *  still belongs to the page. */
function decorLayer() {
  return document.getElementById("decor-layer");
}

/** The rendered height of one placement. Every piece is drawn at the same base
 *  height and the aspect ratio decides the width, so a wide piece and a tall one
 *  are the same size to the eye rather than the same number of pixels wide. */
function decorHeight(placement) {
  return Math.round(DECOR_SAFE.DECOR_BASE_HEIGHT * DECOR_SAFE.decorScaleOf(placement));
}

/** Where to put a decoration that was added without a drop point — the panel's
 *  click-to-place path, and the keyboard path.
 *
 *  Cascaded off the top-left rather than centred: the stage's middle is the
 *  clock and the search box, and dropping art on top of the search field is a
 *  worse first impression than a piece sitting visibly in the open corner. Each
 *  new piece steps down-right, and wraps back to the top rather than marching
 *  off the bottom. */
function decorCascadePoint() {
  const step = 34;
  const index = decorNodes.size;
  const x = 48 + (index % 5) * step;
  const y = 96 + (index % 7) * step;
  return { x, y };
}

function clampDecor(x, y, el) {
  const rect = el.getBoundingClientRect();
  const maxX = Math.max(4, window.innerWidth - rect.width - 4);
  const maxY = Math.max(4, window.innerHeight - rect.height - 4);
  return { x: Math.min(Math.max(4, x), maxX), y: Math.min(Math.max(4, y), maxY) };
}

/** One placement's element: the image, plus its three controls. */
function buildDecor(placement) {
  const art = DECOR_SAFE.decorById(placement.asset);
  const el = document.createElement("div");
  el.className = "dc";
  el.dataset.decor = placement.id;
  el.tabIndex = 0; // focusable so the controls are reachable without a mouse
  el.style.left = `${placement.x}px`;
  el.style.top = `${placement.y}px`;
  el.style.height = `${decorHeight(placement)}px`;

  const img = document.createElement("img");
  img.className = "dc-img";
  img.alt = art?.label ?? "Decoration";
  // A decoration is furniture, not content: it should not be announced by a
  // screen reader as part of the page's reading order, and there is nothing
  // behind it, so its alt text is a label for the controls rather than prose.
  img.setAttribute("aria-hidden", "true");
  img.draggable = false; // the pointer drag below owns the gesture
  // The path is built from the asset id, and the id comes from storage or the
  // account blob — both of which the user can edit. Anything that is not one of
  // the catalog's own ids has already been filtered out by `mergeStored`, so
  // this cannot be steered at another file.
  img.src = `decor/${placement.asset}.webp`;
  el.append(img);

  const remove = document.createElement("button");
  remove.type = "button";
  remove.className = "dc-btn dc-remove";
  remove.textContent = "×";
  remove.title = "Remove this decoration";
  remove.setAttribute("aria-label", `Remove ${art?.label ?? "decoration"}`);
  remove.addEventListener("click", async (e) => {
    e.stopPropagation();
    await DECOR_SAFE.removeDecor(placement.id);
    await renderDecor();
  });

  const grip = document.createElement("span");
  grip.className = "dc-btn dc-grip";
  grip.textContent = "⤡";
  grip.title = "Drag to resize";
  grip.setAttribute("aria-hidden", "true");
  grip.addEventListener("pointerdown", (e) => startDecorResize(e, el, placement));

  el.append(remove, grip);
  // The whole box is the move handle, controls excepted — the same rule the
  // widget header uses.
  el.addEventListener("pointerdown", (e) => {
    if (e.target === grip || e.target === remove) return;
    startDecorDrag(e, el, placement);
  });

  return el;
}

/** Pointer drag, moving the art under the cursor. */
function startDecorDrag(event, el, placement) {
  if (event.button !== 0) return;
  event.preventDefault(); // no text selection while dragging art
  const rect = el.getBoundingClientRect();
  const offsetX = event.clientX - rect.left;
  const offsetY = event.clientY - rect.top;

  el.classList.add("is-moving");
  el.setPointerCapture(event.pointerId);

  function move(e) {
    const { x, y } = clampDecor(e.clientX - offsetX, e.clientY - offsetY, el);
    el.style.left = `${x}px`;
    el.style.top = `${y}px`;
  }

  function up() {
    el.classList.remove("is-moving");
    el.removeEventListener("pointermove", move);
    el.removeEventListener("pointerup", up);
    el.removeEventListener("pointercancel", up);
    const current = el.getBoundingClientRect();
    // Written on release: a storage write per pointermove would be hundreds of
    // writes per gesture for one final value.
    DECOR_SAFE.updateDecor(placement.id, {
      x: Math.round(current.left),
      y: Math.round(current.top),
    });
    // Keep the in-memory record in step so a second drag starts from where the
    // first one ended rather than from the position this closure was built with.
    placement.x = Math.round(current.left);
    placement.y = Math.round(current.top);
  }

  el.addEventListener("pointermove", move);
  el.addEventListener("pointerup", up);
  el.addEventListener("pointercancel", up);
}

/** Pointer resize from the bottom-right grip.
 *
 *  Height is the only free number: the width follows from the aspect ratio, so
 *  a piece cannot be squashed out of shape. Dragging is measured from the
 *  element's own top-left, which is fixed, so the art grows away from its anchor
 *  the way the handle's position implies. */
function startDecorResize(event, el, placement) {
  if (event.button !== 0) return;
  event.preventDefault();
  event.stopPropagation();
  const startY = event.clientY;
  const startHeight = el.getBoundingClientRect().height;
  const base = DECOR_SAFE.DECOR_BASE_HEIGHT;

  el.classList.add("is-resizing");
  el.setPointerCapture(event.pointerId);

  function move(e) {
    // Clamped here as well as in the store so the outline cannot be dragged to a
    // size the store will refuse and then snap back on release.
    const next = Math.min(
      DECOR_SAFE.DECOR_MAX_SCALE * base,
      Math.max(DECOR_SAFE.DECOR_MIN_SCALE * base, startHeight + (e.clientY - startY)),
    );
    el.style.height = `${Math.round(next)}px`;
  }

  function up() {
    el.classList.remove("is-resizing");
    el.removeEventListener("pointermove", move);
    el.removeEventListener("pointerup", up);
    el.removeEventListener("pointercancel", up);
    const height = el.getBoundingClientRect().height;
    placement.scale = Math.min(
      DECOR_SAFE.DECOR_MAX_SCALE,
      Math.max(DECOR_SAFE.DECOR_MIN_SCALE, height / base),
    );
    DECOR_SAFE.updateDecor(placement.id, { scale: placement.scale });
    el.style.height = `${decorHeight(placement)}px`;
  }

  el.addEventListener("pointermove", move);
  el.addEventListener("pointerup", up);
  el.addEventListener("pointercancel", up);
}

/** Repaint the whole layer from the saved placements. */
async function renderDecor() {
  const host = decorLayer();
  if (!host) return;
  const settings = await DECOR_SAFE.get();
  decorNodes.clear();
  const nodes = [];
  for (const placement of settings.decor) {
    // An asset that is not in the catalog has no file behind it. The store
    // normally drops these, so this is the second line of defence — a build that
    // shipped without the decor directory must draw nothing, not a broken icon.
    if (!DECOR_SAFE.decorById(placement.asset)) continue;
    const el = buildDecor(placement);
    decorNodes.set(placement.id, el);
    nodes.push(el);
  }

  // Placed under the widgets: a decoration is scenery, and a widget is a
  // control the user has to be able to reach.
  host.replaceChildren(...nodes);
}

/** Drop one piece of art at a point on the page. Centred on the cursor, because
 *  a drop lands where the pointer is and the pointer was never at the art's
 *  top-left corner. */
async function dropDecor(assetId, clientX, clientY) {
  const art = DECOR_SAFE.decorById(assetId);
  if (!art) return;
  const height = DECOR_SAFE.DECOR_BASE_HEIGHT;
  const width = (art.width / art.height) * height;
  await DECOR_SAFE.addDecor(assetId, clientX - width / 2, clientY - height / 2);
  await renderDecor();
}

/** Place one piece without a drop point — the panel's click-to-add path. */
async function placeDecor(assetId) {
  const { x, y } = decorCascadePoint();
  await DECOR_SAFE.addDecor(assetId, x, y);
  await renderDecor();
}

/** A widget's resize and a decoration's are the same gesture on different
 *  things, so the window's own resize has to re-clamp the art as well as the
 *  panels — otherwise shrinking the window strands pieces off the right edge. */
async function reclampDecor() {
  const settings = await DECOR_SAFE.get();
  for (const placement of settings.decor) {
    const el = decorNodes.get(placement.id);
    if (!el) continue;
    const { x, y } = clampDecor(placement.x, placement.y, el);
    if (x !== placement.x || y !== placement.y) {
      el.style.left = `${x}px`;
      el.style.top = `${y}px`;
      DECOR_SAFE.updateDecor(placement.id, { x, y });
    }
  }
}

// ── dropping from the gallery ─────────────────────────────────────────────
// The settings panel covers the right of the page, and while it is open the
// scrim covers the rest — which would make the page an unreachable drop target.
// So the scrim is the drop target too: it is already exactly the page's own
// area, and a drop on it can be translated straight into page coordinates.

function decorDropTarget(el) {
  if (!el) return;
  el.addEventListener("dragover", (e) => {
    // Without this the browser refuses the drop and shows a "no entry" cursor.
    if (e.dataTransfer?.types?.includes("text/plain")) {
      e.preventDefault();
      e.dataTransfer.dropEffect = "copy";
    }
  });
  el.addEventListener("drop", (e) => {
    const assetId = e.dataTransfer?.getData("text/plain");
    if (!assetId) return;
    e.preventDefault();
    dropDecor(assetId, e.clientX, e.clientY);
  });
}

window.ixiNewtabDecor = {
  render: renderDecor,
  drop: dropDecor,
  place: placeDecor,
  reclamp: reclampDecor,
  decorDropTarget,
  decorNodes,
};
